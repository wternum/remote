// tests/orderflow.test.ts
import assert from "node:assert/strict";

// remote/setup-mcp-project-locally/src/lib/engine.ts
var FEE_RATE = 5e-4;
var SLIP_RATE = 1e-4;
var MAX_HOLD_5M = 96;
var MAX_HOLD_15M = 48;
var MAX_COST_RATIO = 0.3;
var DEFAULT_PARAMS = {
  pivotLeft: 8,
  pivotRight: 5,
  lookback: 288,
  minGap: 8,
  minHeightAtr: 2,
  priorMoveAtr: 1.5,
  tolAtr: 0.35,
  tolPct: 4e-4,
  sweepAtr: 0.5,
  closeBufAtr: 0.05,
  stopAtr: 0.75,
  targetFrac: 1,
  minRR: 1.2,
  maxRR: 4,
  enableBreak: false,
  breakWithin: 24,
  entryMode: "limit",
  limitOffsetAtr: 0.1,
  trendBlock: 1
};
function atrSeries(cs, p = 14) {
  const n = cs.length;
  const out = new Array(n).fill(0);
  const tr = new Array(n).fill(0);
  for (let i = 1; i < n; i++) {
    const c = cs[i];
    const pc = cs[i - 1].c;
    tr[i] = Math.max(c.h - c.l, Math.abs(c.h - pc), Math.abs(c.l - pc));
  }
  let sum2 = 0;
  for (let i = 1; i < n; i++) {
    sum2 += tr[i];
    if (i - p >= 1) sum2 -= tr[i - p];
    out[i] = sum2 / Math.min(i, p);
  }
  return out;
}
function approxDeltaAt(cs, i) {
  const c = cs[i];
  const range = c.h - c.l;
  if (range <= 0) return c.c > c.o ? c.v / 2 : c.c < c.o ? -c.v / 2 : 0;
  return c.v * (2 * ((c.c - c.l) / range) - 1);
}
function approxDeltaSeries(cs) {
  const out = new Array(cs.length);
  for (let i = 0; i < cs.length; i++) out[i] = approxDeltaAt(cs, i);
  return out;
}
var closePos = (c) => c.h - c.l > 0 ? (c.c - c.l) / (c.h - c.l) : 0.5;
function scanSide(w, dw, atr, p, top) {
  const n = w.length;
  const L = Math.max(1, Math.round(p.pivotLeft));
  const R = Math.max(1, Math.round(p.pivotRight));
  const priorBars = Math.max(3 * L, 24);
  const active = [];
  const all = [];
  const sigs = [];
  const T = (b, t) => top ? t : b;
  const volAround = (k) => (w[Math.max(0, k - 1)].v + w[k].v + w[Math.min(n - 1, k + 1)].v) / 3;
  const legRatio = (from, to) => {
    let d = 0;
    let v = 0;
    for (let q = Math.max(0, from); q <= to; q++) {
      d += dw[q];
      v += w[q].v;
    }
    return v > 0 ? d / v : 0;
  };
  const avgVolBefore = (k) => {
    let s = 0;
    let m = 0;
    for (let q = Math.max(0, k - 20); q < k; q++) {
      s += w[q].v;
      m++;
    }
    return m ? s / m : 0;
  };
  const emaOf = (period) => {
    const k = 2 / (period + 1);
    const out = new Array(n);
    let e = w[0]?.c ?? 0;
    for (let q = 0; q < n; q++) {
      e = q === 0 ? w[0].c : w[q].c * k + e * (1 - k);
      out[q] = e;
    }
    return out;
  };
  const ef = emaOf(20);
  const es = emaOf(50);
  const trendOk = (i) => p.trendBlock >= 50 || !(atr[i] > 0) || (ef[i] - es[i]) / atr[i] >= -p.trendBlock;
  const avgVolRange = (from, to) => {
    let sv = 0;
    let m = 0;
    for (let q = Math.max(0, from); q <= to; q++) {
      sv += w[q].v;
      m++;
    }
    return m ? sv / m : 0;
  };
  const costOk = (entry, risk) => risk > 0 && Math.abs(entry) * 2 * (FEE_RATE + SLIP_RATE) / risk <= MAX_COST_RATIO;
  const rejectNow = (c, level, a) => {
    const range = Math.max(1e-12, c.h - c.l);
    const lowerWick = (Math.min(c.o, c.c) - c.l) / range;
    return c.c >= level + p.closeBufAtr * a && closePos(c) >= 0.5 && (c.c > c.o || lowerWick >= 0.35);
  };
  const basePts = (lv, t) => [
    { k: lv.priorIdx, price: lv.prior, label: T("\u8D77\u8DCC\u70B9", "\u8D77\u6DA8\u70B9"), low: false },
    { k: lv.j, price: lv.price, label: T("\u4E00\u5E95", "\u4E00\u9876"), low: true },
    { k: lv.frozenNeckIdx, price: lv.frozenNeck, label: "\u9888\u7EBF", low: false },
    { k: t, price: w[t].l, label: T("\u4E8C\u5E95", "\u4E8C\u9876"), low: true }
  ];
  const makeReject = (lv, t, i, a) => {
    const c = w[i];
    const testLow = Math.min(w[t].l, c.l);
    const entry = c.c;
    const stop = Math.min(lv.price, testLow) - p.stopAtr * a;
    const risk = entry - stop;
    if (!costOk(entry, risk)) return null;
    const room = (lv.frozenNeck - entry) * p.targetFrac;
    if (!(room > 0)) return null;
    const tp = entry + Math.min(room, p.maxRR * risk);
    const rr = (tp - entry) / risk;
    if (rr < p.minRR) return null;
    const tags = [];
    let s = 50;
    const height = lv.frozenNeck - lv.price;
    if (testLow < lv.price) {
      s += 6;
      tags.push(T("\u626B\u4F4E\u6536\u56DE", "\u626B\u9AD8\u56DE\u843D"));
    } else {
      tags.push(testLow - lv.price <= 0.1 * a ? T("\u7B49\u4F4E\u53CC\u5E95", "\u7B49\u9AD8\u53CC\u9876") : T("\u4E8C\u5E95\u62AC\u9AD8", "\u4E8C\u9876\u964D\u4F4E"));
    }
    if (volAround(t) < volAround(lv.j) * 0.9) {
      s += 10;
      tags.push(T("\u4E8C\u5E95\u7F29\u91CF", "\u4E8C\u9876\u7F29\u91CF"));
    }
    if (legRatio(lv.frozenNeckIdx + 1, t) > legRatio(lv.priorIdx + 1, lv.j) + 0.05) {
      s += 8;
      tags.push(T("\u5356\u538B\u8870\u7AED", "\u4E70\u76D8\u8870\u7AED"));
    }
    const tb = w[t];
    if ((Math.min(tb.o, tb.c) - tb.l) / Math.max(1e-12, tb.h - tb.l) >= 0.45) {
      s += 6;
      tags.push(T("\u4E0B\u5F71\u627F\u63A5", "\u4E0A\u5F71\u53D7\u538B"));
    }
    if (closePos(c) >= 0.7) {
      s += 5;
      tags.push(T("\u5F3A\u52BF\u6536\u76D8", "\u5F31\u52BF\u6536\u76D8"));
    }
    if (height >= 3 * a) {
      s += 6;
      tags.push("\u5F62\u6001\u9AD8\u5EA6\u5145\u8DB3");
    }
    if (i - lv.j >= 96) {
      s += 5;
      tags.push(T("\u5386\u53F2\u5E95\u90E8", "\u5386\u53F2\u9876\u90E8"));
    }
    if (rr >= 2) {
      s += 4;
      tags.push(`\u76C8\u4E8F\u6BD4 ${rr.toFixed(1)}`);
    }
    const pts = basePts(lv, t);
    if (t !== i) pts.push({ k: i, price: c.c, label: "\u786E\u8BA4", low: false });
    return {
      idx: i,
      kind: "reject",
      entry,
      stop,
      tp,
      strength: Math.min(100, s),
      tags,
      note: `${i - lv.j} \u6839\u524D\u7684${T("\u5E95\u90E8", "\u9876\u90E8")}\u88AB\u7B2C\u4E8C\u6B21\u6D4B\u8BD5\uFF0C${T("\u652F\u6491", "\u963B\u529B")}\u533A\u6536\u76D8\u62D2\u7EDD\u786E\u8BA4`,
      pts,
      line: { fromK: lv.j, toK: i, price: lv.price, label: T("\u53CC\u5E95\u652F\u6491", "\u53CC\u9876\u963B\u529B") }
    };
  };
  const makeLimit = (lv, i, a, entryPx) => {
    const c = w[i];
    const fill = Math.min(c.o, entryPx);
    const stop = lv.price - p.stopAtr * a;
    const risk0 = entryPx - stop;
    if (!costOk(entryPx, risk0) || fill <= stop) return null;
    const room = (lv.frozenNeck - entryPx) * p.targetFrac;
    if (!(room > 0)) return null;
    const tp = entryPx + Math.min(room, p.maxRR * risk0);
    const rr = (tp - entryPx) / risk0;
    if (rr < p.minRR) return null;
    const tags = [T("\u7B49\u4F4E\u652F\u6491\u6302\u5355", "\u7B49\u9AD8\u963B\u529B\u6302\u5355")];
    let s = 50;
    const height = lv.frozenNeck - lv.price;
    if (avgVolRange(lv.frozenNeckIdx + 1, i) < avgVolRange(lv.priorIdx + 1, lv.j) * 0.9) {
      s += 8;
      tags.push(T("\u56DE\u6D4B\u7F29\u91CF", "\u53CD\u5F39\u7F29\u91CF"));
    }
    if (legRatio(lv.frozenNeckIdx + 1, i) > legRatio(lv.priorIdx + 1, lv.j) + 0.05) {
      s += 8;
      tags.push(T("\u5356\u538B\u8870\u7AED", "\u4E70\u76D8\u8870\u7AED"));
    }
    if (height >= 3 * a) {
      s += 6;
      tags.push("\u5F62\u6001\u9AD8\u5EA6\u5145\u8DB3");
    }
    if (i - lv.j >= 96) {
      s += 5;
      tags.push(T("\u5386\u53F2\u5E95\u90E8", "\u5386\u53F2\u9876\u90E8"));
    }
    if (rr >= 2) {
      s += 4;
      tags.push(`\u76C8\u4E8F\u6BD4 ${rr.toFixed(1)}`);
    }
    return {
      idx: i,
      kind: "limit",
      entry: fill,
      stop,
      tp,
      strength: Math.min(100, s),
      tags,
      note: `${i - lv.j} \u6839\u524D\u7684${T("\u5E95\u90E8", "\u9876\u90E8")}\u88AB\u7B2C\u4E8C\u6B21\u6D4B\u8BD5\uFF0C${T("\u7B49\u4F4E\u652F\u6491", "\u7B49\u9AD8\u963B\u529B")}\u533A\u6302\u5355\u6210\u4EA4`,
      pts: basePts(lv, i),
      line: { fromK: lv.j, toK: i, price: lv.price, label: T("\u53CC\u5E95\u652F\u6491", "\u53CC\u9876\u963B\u529B") }
    };
  };
  const makeBreak = (lv, i, a) => {
    const c = w[i];
    const N = lv.frozenNeck;
    const height = N - lv.price;
    if (!(c.c > c.o) || closePos(c) < 0.55 || c.c - N > 0.5 * height) return null;
    const entry = c.c;
    const stop = entry - (0.5 * height + p.stopAtr * a);
    const risk = entry - stop;
    if (!costOk(entry, risk)) return null;
    const tp = N + height * p.targetFrac;
    const rr = (tp - entry) / risk;
    if (rr < p.minRR) return null;
    const tags = [T("\u9888\u7EBF\u7A81\u7834", "\u9888\u7EBF\u8DCC\u7834")];
    let s = 52;
    const av = avgVolBefore(i);
    const vr = av > 0 ? c.v / av : 1;
    if (vr >= 1.5) {
      s += 8;
      tags.push(`${T("\u7A81\u7834", "\u8DCC\u7834")}\u653E\u91CF ${vr.toFixed(1)}x`);
    } else if (vr < 1) s -= 4;
    if (closePos(c) >= 0.7) {
      s += 5;
      tags.push(T("\u5F3A\u52BF\u6536\u76D8", "\u5F31\u52BF\u6536\u76D8"));
    }
    if (c.v > 0 && dw[i] / c.v >= 0.2) {
      s += 5;
      tags.push(T("\u4E3B\u52A8\u4E70\u5165", "\u4E3B\u52A8\u5356\u51FA"));
    }
    if (height >= 3 * a) {
      s += 4;
      tags.push("\u5F62\u6001\u9AD8\u5EA6\u5145\u8DB3");
    }
    return {
      idx: i,
      kind: "break",
      entry,
      stop,
      tp,
      strength: Math.min(100, s),
      tags,
      note: `\u4E8C\u6B21\u6D4B\u8BD5\u540E\u7B2C ${i - lv.t} \u6839\u6536\u76D8${T("\u7AD9\u4E0A", "\u8DCC\u7834")}\u9888\u7EBF`,
      pts: [...basePts(lv, lv.t), { k: i, price: c.c, label: T("\u7A81\u7834", "\u8DCC\u7834"), low: false }],
      line: { fromK: lv.frozenNeckIdx, toK: i, price: N, label: "\u9888\u7EBF" }
    };
  };
  for (let i = 1; i < n; i++) {
    const a = atr[i];
    const c = w[i];
    if (a > 0) {
      const cands = [];
      for (const lv of active) {
        if (lv.state === "done") continue;
        const tol = Math.max(p.tolAtr * a, p.tolPct * Math.abs(lv.price));
        const qualified = lv.state === "fresh" && i - lv.j >= p.minGap && lv.neck - lv.price >= p.minHeightAtr * a;
        if (p.entryMode === "limit" && qualified) {
          const entryPx = lv.price + Math.min(p.limitOffsetAtr * a, tol);
          if (c.l <= entryPx) {
            lv.frozenNeck = lv.neck;
            lv.frozenNeckIdx = lv.neckIdx;
            lv.t = i;
            lv.tested = true;
            lv.state = "tested";
            if (trendOk(i)) {
              const s = makeLimit(lv, i, a, entryPx);
              if (s) cands.push(s);
            }
          }
        }
        if (c.l < lv.price - p.sweepAtr * a || c.c < lv.price - tol) {
          lv.state = "done";
          lv.brokenAt = i;
          continue;
        }
        const touch = c.l <= lv.price + tol;
        if (lv.state === "fresh") {
          if (touch && qualified) {
            lv.frozenNeck = lv.neck;
            lv.frozenNeckIdx = lv.neckIdx;
            lv.t = i;
            lv.tested = true;
            if (p.entryMode === "limit") {
              lv.state = "tested";
            } else if (rejectNow(c, lv.price, a)) {
              const s = trendOk(i) ? makeReject(lv, i, i, a) : null;
              if (s) cands.push(s);
              lv.state = "tested";
            } else {
              lv.state = "pending";
            }
          } else if (c.h > lv.neck) {
            lv.neck = c.h;
            lv.neckIdx = i;
          }
        } else if (lv.state === "pending") {
          const tb = w[lv.t];
          if (trendOk(i) && c.c > c.o && c.c > tb.c && c.c >= lv.price + p.closeBufAtr * a && closePos(c) >= 0.5) {
            const s = makeReject(lv, lv.t, i, a);
            if (s) cands.push(s);
          }
          lv.state = "tested";
        } else if (lv.state === "tested") {
          if (p.enableBreak && !lv.aboveNeck && i - lv.t <= p.breakWithin && c.c > lv.frozenNeck) {
            lv.aboveNeck = true;
            const s = trendOk(i) ? makeBreak(lv, i, a) : null;
            if (s) cands.push(s);
          }
        }
      }
      if (cands.length) {
        cands.sort((x, y) => y.strength - x.strength);
        sigs.push(cands[0]);
      }
      for (let q = active.length - 1; q >= 0; q--) {
        const lv = active[q];
        if (lv.state === "fresh" && i - lv.j > p.lookback) {
          lv.state = "done";
          lv.expired = true;
        } else if (lv.state === "tested" && i - lv.j > 3 * p.lookback) {
          lv.state = "done";
          lv.expired = true;
        }
        if (lv.state === "done") active.splice(q, 1);
      }
    }
    const j = i - R;
    if (j - L >= 0) {
      const lj = w[j].l;
      let ok = true;
      for (let k = j - L; k < j; k++)
        if (w[k].l <= lj) {
          ok = false;
          break;
        }
      if (ok) {
        for (let k = j + 1; k <= i; k++)
          if (w[k].l < lj) {
            ok = false;
            break;
          }
      }
      const aj = atr[i] > 0 ? atr[i] : atr[j];
      if (ok && aj > 0) {
        let prior = -Infinity;
        let priorIdx = j;
        for (let k = Math.max(0, j - priorBars); k < j; k++)
          if (w[k].h > prior) {
            prior = w[k].h;
            priorIdx = k;
          }
        const tol = Math.max(p.tolAtr * aj, p.tolPct * Math.abs(lj));
        const dup = active.some((lv) => lv.state !== "done" && Math.abs(lv.price - lj) <= tol);
        if (!dup && prior - lj >= p.priorMoveAtr * aj) {
          let neck = -Infinity;
          let neckIdx = j;
          for (let k = j + 1; k <= i; k++)
            if (w[k].h > neck) {
              neck = w[k].h;
              neckIdx = k;
            }
          const lv = {
            j,
            price: lj,
            priorIdx,
            prior,
            neck,
            neckIdx,
            state: "fresh",
            t: -1,
            frozenNeck: neck,
            frozenNeckIdx: neckIdx,
            brokenAt: -1,
            aboveNeck: false,
            tested: false,
            expired: false
          };
          active.push(lv);
          all.push(lv);
        }
      }
    }
  }
  return { sigs, levels: all };
}
function scanDoubles(cs, p = DEFAULT_PARAMS) {
  const signals = [];
  const levels = [];
  if (cs.length < 30) return { signals, levels };
  const atr = atrSeries(cs);
  const delta = approxDeltaSeries(cs);
  const last = cs.length - 1;
  for (const sgn of [1, -1]) {
    const top = sgn === -1;
    const w = top ? cs.map((c) => ({ ts: c.ts, o: -c.o, h: -c.l, l: -c.h, c: -c.c, v: c.v })) : cs;
    const dw = top ? delta.map((d) => -d) : delta;
    const r = scanSide(w, dw, atr, p, top);
    const P = (x) => sgn * x;
    for (const s of r.sigs) {
      const pattern = s.kind === "break" ? top ? "dt_break" : "db_break" : top ? "dt_reject" : "db_reject";
      const pts = s.pts.map((pt) => ({
        ts: cs[pt.k].ts,
        price: P(pt.price),
        label: pt.label,
        pos: pt.low !== top ? "below" : "above"
      }));
      const path = [...pts].sort((a, b) => a.ts - b.ts).filter((pt, k, arr) => k === 0 || pt.ts !== arr[k - 1].ts).map((pt) => ({ ts: pt.ts, price: pt.price }));
      const strength = Math.round(s.strength);
      signals.push({
        idx: s.idx,
        ts: cs[s.idx].ts,
        side: top ? "short" : "long",
        pattern,
        entry: P(s.entry),
        stop: P(s.stop),
        tp: P(s.tp),
        conf: strength,
        confl: strength,
        fill: s.kind === "limit" ? "limit" : "close",
        strength,
        note: s.note,
        tags: s.tags,
        geo: {
          pts,
          path,
          neck: { from: cs[s.line.fromK].ts, to: cs[s.line.toK].ts, price: P(s.line.price), label: s.line.label }
        }
      });
    }
    for (const lv of r.levels) {
      if (lv.expired) continue;
      if (lv.brokenAt >= 0 && !lv.tested) continue;
      levels.push({
        from: cs[lv.j].ts,
        to: cs[lv.brokenAt >= 0 ? lv.brokenAt : last].ts,
        price: P(lv.price),
        side: top ? "top" : "bottom",
        tested: lv.tested,
        broken: lv.brokenAt >= 0
      });
    }
  }
  signals.sort((a, b) => a.idx - b.idx);
  return { signals, levels };
}

// src/quant/flow.ts
function hasRealFlow(bar, candleVol, volumeSource) {
  if (volumeSource && volumeSource !== "quote") return false;
  if (!bar || !Number.isFinite(bar.buy) || !Number.isFinite(bar.sell) || bar.buy < 0 || bar.sell < 0 || !(bar.buy + bar.sell > 0) || candleVol == null || !Number.isFinite(candleVol) || !(candleVol > 0)) return false;
  const coverage = (bar.buy + bar.sell) / candleVol;
  return coverage >= (bar.src === "rubik" ? 0.95 : 0.85) && coverage <= 1.1;
}

// src/quant/context.ts
function emaSeries(cs, period) {
  const k = 2 / (period + 1);
  const out = new Array(cs.length);
  let e = cs[0]?.c ?? 0;
  for (let i = 0; i < cs.length; i++) {
    e = i === 0 ? cs[i].c : cs[i].c * k + e * (1 - k);
    out[i] = e;
  }
  return out;
}
function buildContext(cs, flow) {
  const n = cs.length;
  const atr = atrSeries(cs);
  const delta = new Array(n);
  const real = new Uint8Array(n);
  const oi = new Array(n).fill(NaN);
  const vols = new Array(n);
  const volMa = new Array(n).fill(0);
  const index = /* @__PURE__ */ new Map();
  let covered = 0;
  for (let i = 0; i < n; i++) {
    const fb = flow?.bars.get(cs[i].ts);
    if (hasRealFlow(fb, cs[i].v, cs[i].volumeSource)) {
      delta[i] = fb.buy - fb.sell;
      real[i] = 1;
      covered++;
    } else {
      delta[i] = approxDeltaAt(cs, i);
    }
    const position = fb?.oiContracts && fb.oiContracts > 0 ? fb.oiContracts : fb?.oiUsd;
    if (position && position > 0) oi[i] = position;
    vols[i] = cs[i].v;
    index.set(cs[i].ts, i);
  }
  let s = 0;
  for (let i = 0; i < n; i++) {
    if (i >= 1) s += cs[i - 1].v;
    if (i >= 21) s -= cs[i - 21].v;
    const m = Math.min(i, 20);
    volMa[i] = m ? s / m : cs[i].v;
  }
  return {
    cs,
    n,
    atr,
    delta,
    real,
    oi,
    vols,
    ema20: emaSeries(cs, 20),
    ema50: emaSeries(cs, 50),
    volMa,
    index,
    flowCoverage: n ? covered / n : 0
  };
}

// src/quant/orderflow.ts
var clamp01 = (v) => v < 0 ? 0 : v > 1 ? 1 : v;
var clampR = (v, lo = -1, hi = 1) => v < lo ? lo : v > hi ? hi : v;
var r3 = (v) => Number.isFinite(v) ? Number(v.toFixed(3)) : 0;
var pct = (v) => `${v >= 0 ? "+" : ""}${(v * 100).toFixed(0)}%`;
function windowFlow(ctx, from, to) {
  const a = Math.max(0, Math.min(from, to));
  const b = Math.min(ctx.n - 1, Math.max(from, to));
  let vol = 0;
  let delta = 0;
  let known = 0;
  let base = 0;
  let bars = 0;
  for (let i = a; i <= b; i++) {
    vol += ctx.vols[i];
    delta += ctx.delta[i];
    known += ctx.real[i];
    base += ctx.volMa[i];
    bars++;
  }
  return {
    from: a,
    to: b,
    bars,
    vol,
    delta,
    ratio: vol > 0 ? delta / vol : 0,
    known: bars ? known / bars : 0,
    volRatio: base > 0 ? vol / base : 1
  };
}
function pivotOf(ctx, sig) {
  const pts = sig.geo?.pts ?? [];
  const at = (label) => pts.find((p) => p.label.includes(label));
  const priorPt = at("\u8D77");
  const firstPt = at("\u4E00");
  const neckPt = at("\u9888\u7EBF");
  const secondPt = at("\u4E8C");
  const idxOf = (ts, fallback) => ctx.index.get(ts) ?? fallback;
  const i = sig.idx;
  const prior = idxOf(priorPt?.ts ?? -1, Math.max(0, i - 140));
  const first = idxOf(firstPt?.ts ?? -1, Math.max(0, i - 60));
  const neck = idxOf(neckPt?.ts ?? -1, Math.max(first + 1, i - 12));
  const second = idxOf(secondPt?.ts ?? -1, i);
  return {
    prior,
    first,
    neck,
    second: Math.max(first, second),
    level: firstPt?.price ?? (ctx.cs[first]?.c ?? sig.entry),
    neckPrice: neckPt?.price ?? sig.tp,
    secondPrice: secondPt?.price ?? sig.entry
  };
}
function legsOf(pv) {
  let l1a = Math.min(pv.prior, pv.first);
  let l1b = Math.max(pv.prior, pv.first);
  let l2a = Math.min(pv.neck, pv.second);
  let l2b = Math.max(pv.neck, pv.second);
  if (l1b - l1a < 2) {
    l1a = Math.max(0, pv.first - 24);
    l1b = pv.first;
  }
  if (l2b - l2a < 2) {
    l2a = Math.max(pv.first + 1, pv.second - 24);
    l2b = pv.second;
  }
  return { l1a, l1b, l2a, l2b };
}
var logistic = (x) => 1 / (1 + Math.exp(-x));
var roundPx = (v) => Number.isFinite(v) ? Number(v.toFixed(v >= 1e3 ? 2 : 6)) : 0;
function readTouch(ctx, level, idx, testIdx) {
  const { cs, n, atr, delta, vols, volMa } = ctx;
  const i = Math.max(0, Math.min(idx, n - 1));
  const a = Math.max(atr[i] || 0, 1e-9);
  const top = level.side === "top";
  const dir = top ? -1 : 1;
  const up = top ? 1 : -1;
  const px = level.price;
  const over = (v) => (top ? v - px : px - v) / a;
  let t = Math.max(0, Math.min(testIdx ?? i, n - 1));
  if (testIdx == null) {
    for (let q = Math.max(0, i - 5); q <= i; q++) if (top ? cs[q].h > cs[t].h : cs[q].l < cs[t].l) t = q;
  }
  const tb = cs[t];
  const depth = over(top ? tb.h : tb.l);
  const approach = windowFlow(ctx, Math.max(0, t - 4), t);
  const wide = windowFlow(ctx, Math.max(0, t - 12), t);
  const after = i > t ? windowFlow(ctx, t + 1, i) : null;
  const tvol = vols[t];
  const tRatio = tvol > 0 ? delta[t] / tvol : 0;
  const tVol = volMa[t] > 0 ? tvol / volMa[t] : 1;
  const range = Math.max(1e-9, tb.h - tb.l);
  const wick = top ? (tb.h - Math.max(tb.o, tb.c)) / range : (Math.min(tb.o, tb.c) - tb.l) / range;
  const known = ctx.real[t] === 1;
  const inside = over(tb.c) <= 0.05;
  let beyondCloses = 0;
  for (let q = t; q <= i; q++) if (over(cs[q].c) > 0.1) beyondCloses++;
  const accepted = over(cs[i].c) > 0.2 || beyondCloses >= 2;
  const near = depth > -0.5;
  const pressure = clampR(approach.ratio * up * 4);
  const thrust = clamp01((approach.volRatio - 1.2) / 1) * clamp01(pressure * 1.5);
  const e1 = clampR(-pressure - 0.6 * thrust) * approach.known;
  let e2 = 0;
  if (known) {
    if (inside && tVol >= 1.1 && tRatio * up <= 0.05) e2 = 0.8;
    else if (inside && tVol < 0.9) e2 = 0.4;
    else if (!inside && tRatio * up > 0.1 && tVol >= 1.2) e2 = -0.9;
    else if (!inside) e2 = -0.3;
  } else {
    if (inside && tVol < 0.9) e2 = 0.35;
    else if (!inside) e2 = -0.35;
  }
  const e3 = near ? clampR((wick - 0.3) * 2) : 0;
  const e4 = clampR(-wide.ratio * up * 5) * wide.known;
  const e5 = after ? clampR(-after.ratio * up * 4) * after.known : null;
  const wsum = 0.3 + 0.25 + 0.12 + 0.13 + (e5 == null ? 0 : 0.2);
  let ev = (0.3 * e1 + 0.25 * e2 + 0.12 * e3 + 0.13 * e4 + (e5 == null ? 0 : 0.2 * e5)) / wsum;
  if (accepted) ev = Math.min(ev, -0.6);
  ev = clampR(ev * 1.6);
  const buy = top ? "\u4E3B\u52A8\u4E70\u5165" : "\u4E3B\u52A8\u5356\u51FA";
  const sell = top ? "\u4E3B\u52A8\u5356\u51FA" : "\u4E3B\u52A8\u4E70\u5165";
  const word = top ? "\u524D\u9AD8" : "\u524D\u4F4E";
  const src = known ? "" : "\uFF08\u8FD1\u4F3C\uFF09";
  const reasons = [];
  if (accepted) reasons.push(`\u6536\u76D8\u5DF2\u7AD9\u5728${word}\u5916\u4FA7\uFF08${beyondCloses} \u6839\uFF09\uFF1A\u7A81\u7834\u88AB\u63A5\u53D7`);
  if (depth > 0.05 && !accepted) reasons.push(`\u523A\u7834${word} ${depth.toFixed(2)} ATR${inside ? "\u540E\u6536\u56DE" : "\uFF0C\u5C1A\u672A\u6536\u56DE"}`);
  if (pressure <= -0.15) reasons.push(`\u51B2\u5411${word}\u65F6${sell}\u5DF2\u5360\u4F18\uFF08${pct(approach.ratio * -up)}\uFF09\uFF1A\u63A8\u8FDB\u52A8\u80FD\u4E0D\u5728\u7A81\u7834\u65B9${src}`);
  else if (pressure < 0.2) reasons.push(`\u51B2\u5411${word}\u65F6${buy}\u504F\u5F31\uFF08${pct(approach.ratio * up)}\uFF09\uFF1A\u7F3A\u5C11\u7A81\u7834\u52A8\u80FD${src}`);
  else reasons.push(`\u51B2\u5411${word}\u7684${buy}\u5F3A\u52B2\uFF08${pct(approach.ratio * up)}${thrust > 0.3 ? `\uFF0C\u653E\u91CF ${approach.volRatio.toFixed(1)}x` : ""}\uFF09\uFF1A\u5B58\u5728\u771F\u7A81\u7834\u98CE\u9669${src}`);
  if (e2 >= 0.8) reasons.push(`\u89E6${word}\u90A3\u6839\u653E\u91CF ${tVol.toFixed(1)}x \u5374\u6536\u5728\u4F4D\u5185\u3001${buy}\u672A\u5360\u4F18\uFF1A\u7A81\u7834\u76D8\u88AB\u5438\u6536`);
  else if (e2 > 0) reasons.push(`\u89E6${word}\u90A3\u6839\u7F29\u91CF ${tVol.toFixed(1)}x \u4E14\u6536\u5728\u4F4D\u5185\uFF1A\u8FFD\u4EF7\u610F\u613F\u4E0D\u8DB3`);
  else if (e2 <= -0.9) reasons.push(`\u89E6${word}\u90A3\u6839\u653E\u91CF ${tVol.toFixed(1)}x\u3001${buy} ${pct(tRatio * up)} \u4E14\u6536\u5728\u4F4D\u5916\uFF1A\u7A81\u7834\u65B9\u4E3B\u5BFC`);
  if (near && wick >= 0.45) reasons.push(`\u89E6${word}\u90A3\u6839${top ? "\u4E0A" : "\u4E0B"}\u5F71\u7EBF\u5360 ${Math.round(wick * 100)}%\uFF1A\u62D2\u7EDD\u660E\u663E`);
  if (e4 > 0.3) reasons.push(`\u8FD1 12 \u6839\u7D2F\u8BA1${buy}\u6CA1\u6709\u8DDF\u4E0A\u4EF7\u683C\uFF1ACVD \u80CC\u79BB`);
  if (after && e5 != null && e5 > 0.25) reasons.push(`\u89E6\u53CA\u4E4B\u540E${sell}\u63A5\u7BA1\uFF08${pct(-after.ratio * up)}\uFF09`);
  else if (after && e5 != null && e5 < -0.25) reasons.push(`\u89E6\u53CA\u4E4B\u540E${buy}\u7EE7\u7EED\u5360\u4F18\uFF08${pct(after.ratio * up)}\uFF09`);
  const fakeProb = clamp01(logistic(ev * 1.6));
  const breakProb = 1 - fakeProb;
  const kind = accepted ? "accepted" : depth > 0.05 ? "sweep" : depth > -0.35 ? "touch" : "approach";
  const verdict = accepted ? "breakout" : fakeProb >= 0.62 ? "reject" : fakeProb <= 0.4 ? "breakout" : "uncertain";
  const pc = Math.round(fakeProb * 100);
  const act = top ? "\u505A\u7A7A" : "\u505A\u591A";
  const tag = top ? "\u89E6\u9876" : "\u89E6\u5E95";
  const headline = accepted ? top ? "\u6536\u76D8\u7AD9\u4E0A\u524D\u9AD8\uFF1A\u771F\u7A81\u7834\uFF0C\u4E0D\u505A\u7A7A" : "\u6536\u76D8\u8DCC\u7834\u524D\u4F4E\uFF1A\u771F\u8DCC\u7834\uFF0C\u4E0D\u505A\u591A" : verdict === "reject" ? kind === "approach" ? `\u63A5\u8FD1${word}\uFF1A\u8BA2\u5355\u6D41\u504F\u5411\u88AB\u62D2\u7EDD\uFF08\u5047\u7A81\u7834 ${pc}%\uFF09\uFF0C\u89E6\u53CA\u540E\u53EF${act}` : `${tag}\u8BA2\u5355\u6D41\uFF1A\u5047\u7A81\u7834\u6982\u7387 ${pc}% \u2192 \u53EF${act}` : verdict === "breakout" ? `${tag}\u8BA2\u5355\u6D41\uFF1A\u7A81\u7834\u6982\u7387 ${100 - pc}%\uFF08${buy}\u4ECD\u5728\u63A8\u8FDB\uFF09\uFF0C\u4E0D\u62A2${top ? "\u7A7A" : "\u591A"}` : `${tag}\u8BA2\u5355\u6D41\u4E0D\u660E\u6717\uFF08\u5047\u7A81\u7834 ${pc}%\uFF09\uFF1A\u7B49\u62D2\u7EDDK\u6216\u7A81\u7834\u786E\u8BA4`;
  let plan = null;
  if (!accepted) {
    let ext = px;
    for (let q = t; q <= i; q++) ext = top ? Math.max(ext, cs[q].h) : Math.min(ext, cs[q].l);
    const entry = px + dir * 0.1 * a;
    const stop = ext - dir * 0.75 * a;
    const risk = Math.abs(entry - stop);
    let neck = entry;
    for (let q = Math.max(0, level.idx ?? i - 60); q <= i; q++) neck = top ? Math.min(neck, cs[q].l) : Math.max(neck, cs[q].h);
    const dist = Math.min(Math.max(Math.abs(entry - neck), 1.2 * risk), 4 * risk);
    if (risk > 0) plan = { entry: roundPx(entry), stop: roundPx(stop), tp: roundPx(entry + dir * dist), rr: Number((dist / risk).toFixed(1)) };
  }
  return {
    side: level.side,
    dir,
    level: px,
    testIdx: t,
    kind,
    depthAtr: r3(depth),
    approach,
    pressure: r3(pressure),
    bar: { deltaRatio: r3(tRatio), volRatio: r3(tVol), wick: r3(wick), known },
    evidence: r3(ev),
    fakeProb: r3(fakeProb),
    breakProb: r3(breakProb),
    verdict,
    reasons,
    headline,
    plan
  };
}
function scanTouches(ctx, horizon = 12) {
  const { cs, n, atr } = ctx;
  const events = [];
  const stats = { n: 0, reject: 0, hiN: 0, hiReject: 0, loN: 0, loReject: 0 };
  for (const lv of findSwingLevels(ctx)) {
    const top = lv.side === "top";
    const end = Math.min(lv.breakIdx ?? n - 1, n - 1 - horizon);
    for (let q = lv.idx + 8; q <= end; q++) {
      const a = atr[q];
      if (!(a > 0)) continue;
      const hit = top ? cs[q].h >= lv.price - 0.2 * a : cs[q].l <= lv.price + 0.2 * a;
      if (!hit) continue;
      const rd = readTouch(ctx, lv, q, q);
      let outcome = "drift";
      for (let k = q; k <= Math.min(n - 1, q + horizon); k++) {
        const c = cs[k];
        if (top ? c.c > lv.price + 0.2 * a : c.c < lv.price - 0.2 * a) {
          outcome = "break";
          break;
        }
        if (top ? c.l <= lv.price - a : c.h >= lv.price + a) {
          outcome = "reject";
          break;
        }
      }
      events.push({ idx: q, ts: cs[q].ts, price: lv.price, side: lv.side, fakeProb: rd.fakeProb, outcome });
      stats.n++;
      if (outcome === "reject") stats.reject++;
      if (rd.fakeProb >= 0.6) {
        stats.hiN++;
        if (outcome === "reject") stats.hiReject++;
      } else if (rd.fakeProb <= 0.45) {
        stats.loN++;
        if (outcome === "reject") stats.loReject++;
      }
      q += horizon;
    }
  }
  return { events, stats };
}
var sourceOf = (known) => known >= 0.95 ? "taker" : known <= 0.05 ? "approx" : "mixed";
function readSecondTest(ctx, sig) {
  const { cs, n, atr, delta, vols, volMa, oi } = ctx;
  const i = Math.min(sig.idx, n - 1);
  const a = Math.max(atr[i] || 0, 1e-9);
  const pv = pivotOf(ctx, sig);
  const dir = sig.side === "long" ? 1 : -1;
  const top = dir < 0;
  const { l1a, l1b, l2a, l2b } = legsOf(pv);
  const leg1 = windowFlow(ctx, l1a, l1b);
  const leg2 = windowFlow(ctx, l2a, l2b);
  let cvdFirst = 0;
  let cvdSecond = 0;
  let totalVol = 0;
  let betweenKnown = 0;
  let betweenBars = 0;
  for (let q = l1a; q <= Math.min(n - 1, pv.second); q++) {
    if (q <= pv.first) cvdFirst += delta[q];
    else {
      betweenKnown += ctx.real[q];
      betweenBars++;
    }
    cvdSecond += delta[q];
    totalVol += vols[q];
  }
  const norm = Math.max(1e-9, totalVol * 0.08);
  const cvdCov = betweenBars > 0 ? betweenKnown / betweenBars : 0;
  const flowCov = Math.min(leg1.known, leg2.known);
  const cvdDiv = clampR((cvdSecond - cvdFirst) * dir / norm * cvdCov);
  const legDeltaDiff = clampR((leg2.ratio - leg1.ratio) * dir * 6 * flowCov);
  const v1 = leg1.vol / Math.max(1, leg1.bars);
  const v2 = leg2.vol / Math.max(1, leg2.bars);
  const legVolRatio = v1 > 0 ? v2 / v1 : 1;
  const from = Math.max(0, Math.min(pv.second, i));
  const to = Math.min(n - 1, Math.max(i, pv.second));
  let absorb = 0;
  let breach = 0;
  let deepestIdx = from;
  let depth = 0;
  let sweepBars = 0;
  let sweepFrom = -1;
  let sweepTo = -1;
  for (let q = from; q <= to; q++) {
    const c = cs[q];
    const avg = volMa[q] > 0 ? volMa[q] : c.v || 1;
    const beyond = top ? c.h - pv.level : pv.level - c.l;
    if (beyond > depth) {
      depth = beyond;
    }
    if (top ? c.h > cs[deepestIdx].h : c.l < cs[deepestIdx].l) deepestIdx = q;
    if (beyond > 0.05 * a) {
      sweepBars++;
      if (sweepFrom < 0) sweepFrom = q;
      sweepTo = q;
    }
    if (top) {
      if (c.h >= pv.level - 0.1 * a && c.c <= pv.level - 0.25 * a && c.v >= avg * 1.1) absorb++;
      if (c.c > pv.level + 0.2 * a) breach++;
    } else {
      if (c.l <= pv.level + 0.1 * a && c.c >= pv.level + 0.25 * a && c.v >= avg * 1.1) absorb++;
      if (c.c < pv.level - 0.2 * a) breach++;
    }
  }
  const sweepFlow = sweepFrom >= 0 ? windowFlow(ctx, sweepFrom, sweepTo) : null;
  const last = cs[to];
  const closedInside = top ? last.c <= pv.level : last.c >= pv.level;
  const accepted = top ? last.c > pv.level + 0.2 * a : last.c < pv.level - 0.2 * a;
  const barOf = (q) => ({
    idx: q,
    deltaRatio: vols[q] > 0 ? delta[q] / vols[q] : 0,
    volRatio: volMa[q] > 0 ? vols[q] / volMa[q] : 1,
    known: ctx.real[q] === 1
  });
  const test = barOf(deepestIdx);
  const confirm = { ...barOf(to), closedInside };
  let oiPct = null;
  const oiStart = oi[l2a];
  const oiEnd = oi[Math.min(n - 1, pv.second)];
  if (Number.isFinite(oiStart) && Number.isFinite(oiEnd) && oiStart > 0) oiPct = oiEnd / oiStart - 1;
  const reasons = [];
  let score = 0;
  const depthAtr = depth / a;
  const occurred = sweepBars > 0 && depthAtr >= 0.05;
  const sideWord = top ? "\u963B\u529B" : "\u652F\u6491";
  if (occurred) {
    score += 0.3 + clamp01((depthAtr - 0.1) / 0.5) * 0.15;
    reasons.push(`${top ? "\u4E0A\u7A7F" : "\u4E0B\u7834"}${sideWord} ${depthAtr.toFixed(2)} ATR\uFF08\u626B\u635F\uFF09${closedInside ? "\u540E\u6536\u56DE" : "\uFF0C\u5C1A\u672A\u6536\u56DE"}`);
    if (sweepFlow) {
      const w = sweepFlow.known >= 0.5 ? 1 : 0.5;
      const against = sweepFlow.ratio * dir;
      if (against > 0.05) {
        score += 0.2 * w;
        reasons.push(top ? `\u626B\u9AD8\u671F\u95F4\u4E3B\u52A8\u5356\u51FA\u5360\u4F18\uFF08${pct(sweepFlow.ratio)}\uFF09\uFF1A\u8FFD\u591A\u76D8\u88AB\u53CD\u624B` : `\u626B\u4F4E\u671F\u95F4\u4E3B\u52A8\u4E70\u5165\u5360\u4F18\uFF08${pct(sweepFlow.ratio)}\uFF09\uFF1A\u7834\u4F4D\u5356\u76D8\u88AB\u627F\u63A5`);
      } else if (against < -0.12 && sweepFlow.volRatio >= 1.3 && closedInside) {
        score += 0.2 * w;
        reasons.push(top ? `\u8FFD\u591A\u6210\u4EA4\u653E\u91CF ${sweepFlow.volRatio.toFixed(1)}x \u5374\u88AB\u5438\u6536\uFF0C\u4EF7\u683C\u6536\u56DE` : `\u6050\u614C\u5356\u51FA\u653E\u91CF ${sweepFlow.volRatio.toFixed(1)}x \u5374\u88AB\u5438\u6536\uFF0C\u4EF7\u683C\u6536\u56DE`);
      } else if (against < -0.12 && !closedInside) {
        score -= 0.3;
        reasons.push(`\u7A81\u7834\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u5360\u4F18\uFF08${pct(sweepFlow.ratio)}\uFF09\u4E14\u672A\u6536\u56DE\uFF1A\u66F4\u50CF\u771F\u7A81\u7834`);
      }
    }
  }
  if (cvdDiv > 0.25) {
    score += 0.15;
    reasons.push(top ? "CVD \u80CC\u79BB\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u9AD8\uFF0C\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5165\u672A\u8DDF\u4E0A" : "CVD \u80CC\u79BB\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u4F4E\uFF0C\u7D2F\u8BA1\u4E3B\u52A8\u5356\u51FA\u672A\u8DDF\u4E0A");
  }
  if (legDeltaDiff > 0.3) {
    score += 0.1;
    reasons.push(top ? `\u7B2C\u4E8C\u817F\u4E3B\u52A8\u4E70\u5165 ${pct(leg2.ratio)} \u5F31\u4E8E\u7B2C\u4E00\u817F ${pct(leg1.ratio)}` : `\u7B2C\u4E8C\u817F\u4E3B\u52A8\u5356\u51FA ${pct(-leg2.ratio)} \u5F31\u4E8E\u7B2C\u4E00\u817F ${pct(-leg1.ratio)}`);
  }
  if (oiPct != null && oiPct > 3e-3) {
    score += 0.1;
    reasons.push(top ? `\u51B2\u9AD8\u6BB5\u6301\u4ED3 +${(oiPct * 100).toFixed(2)}%\uFF1A\u65B0\u591A\u5728\u9876\u90E8\u88AB\u5957` : `\u6740\u8DCC\u6BB5\u6301\u4ED3 +${(oiPct * 100).toFixed(2)}%\uFF1A\u65B0\u7A7A\u5728\u5E95\u90E8\u88AB\u5957`);
  }
  if (absorb > 0) {
    score += 0.1;
    reasons.push(`${sideWord}\u4F4D\u51FA\u73B0 ${absorb} \u6839\u653E\u91CF\u523A\u7834\u540E\u6536\u56DE\u7684\u5438\u6536K`);
  }
  if (breach > 0 && !closedInside) {
    score -= 0.25;
    reasons.push(`\u5DF2\u6709 ${breach} \u6839\u6536\u76D8\u505C\u5728${sideWord}\u5916\u4FA7`);
  }
  score = clamp01(score);
  const kind = !accepted && score >= 0.5 ? top ? "bullTrap" : "bearTrap" : null;
  const lean = clamp01(
    0.5 + 0.14 * cvdDiv + 0.1 * legDeltaDiff + 0.08 * clampR((1 - legVolRatio) * 2) + (sweepFlow ? 0.1 * clampR(sweepFlow.ratio * dir * 4) : 0) + 0.08 * clampR(confirm.deltaRatio * dir * 3) - (accepted ? 0.25 : 0)
  );
  const knownAll = (leg1.known * leg1.bars + leg2.known * leg2.bars) / Math.max(1, leg1.bars + leg2.bars);
  const flowSource = sourceOf(knownAll);
  const headline = accepted ? top ? "\u4EF7\u683C\u6536\u76D8\u7AD9\u4E0A\u963B\u529B\uFF1A\u53CC\u9876\u5931\u6548\uFF0C\u53EF\u80FD\u662F\u771F\u7A81\u7834" : "\u4EF7\u683C\u6536\u76D8\u8DCC\u7834\u652F\u6491\uFF1A\u53CC\u5E95\u5931\u6548\uFF0C\u53EF\u80FD\u662F\u771F\u8DCC\u7834" : kind ? top ? "\u8BF1\u591A\uFF1A\u626B\u8FC7\u524D\u9AD8\u540E\u6536\u56DE\uFF0C\u7A81\u7834\u4E70\u76D8\u88AB\u5957" : "\u8BF1\u7A7A\uFF1A\u626B\u8FC7\u524D\u4F4E\u540E\u6536\u56DE\uFF0C\u7834\u4F4D\u5356\u76D8\u88AB\u5957" : occurred ? `${top ? "\u626B\u9AD8" : "\u626B\u4F4E"}\u540E\u6536\u56DE\uFF0C\u4F46\u8BA2\u5355\u6D41\u786E\u8BA4\u4E0D\u8DB3` : top ? "\u7B49\u9AD8\u4E8C\u6B21\u6D4B\u8BD5\uFF1A\u672A\u626B\u524D\u9AD8" : "\u7B49\u4F4E\u4E8C\u6B21\u6D4B\u8BD5\uFF1A\u672A\u626B\u524D\u4F4E";
  return {
    scene: top ? "doubleTop" : "doubleBottom",
    dir,
    level: pv.level,
    neck: pv.neckPrice,
    leg1,
    leg2,
    cvdDiv: r3(cvdDiv),
    legDeltaDiff: r3(legDeltaDiff),
    legVolRatio: r3(legVolRatio),
    test,
    confirm,
    sweep: { occurred, depthAtr: r3(depthAtr), bars: sweepBars, flow: sweepFlow, accepted },
    absorption: { count: absorb, breach },
    oi: { pct: oiPct == null ? null : r3(oiPct) },
    trap: { kind, score: r3(score), reasons },
    touch: readTouch(ctx, { price: pv.level, side: top ? "top" : "bottom", idx: pv.first }, i, deepestIdx),
    lean: r3(lean),
    flowSource,
    headline
  };
}
var swingCache = /* @__PURE__ */ new WeakMap();
function findSwingLevels(ctx, opts = {}) {
  const isDefault = opts.left == null && opts.right == null && opts.priorAtr == null && opts.maxAge == null;
  if (isDefault) {
    const hit = swingCache.get(ctx);
    if (hit) return hit.map((l) => ({ ...l }));
  }
  const { cs, n, atr } = ctx;
  const L = opts.left ?? 8;
  const R = opts.right ?? 5;
  const priorAtr = opts.priorAtr ?? 1.5;
  const maxAge = opts.maxAge ?? 576;
  const out = [];
  const active = [];
  for (let i = L + R; i < n; i++) {
    const a = atr[i];
    if (!(a > 0)) continue;
    for (let q = active.length - 1; q >= 0; q--) {
      const lv = active[q];
      const c = cs[i];
      const broke = lv.side === "top" ? c.c > lv.price + 0.1 * a : c.c < lv.price - 0.1 * a;
      if (broke) {
        lv.breakIdx = i;
        active.splice(q, 1);
      } else if (i - lv.idx > maxAge) {
        active.splice(q, 1);
      }
    }
    const j = i - R;
    for (const side of ["top", "bottom"]) {
      const ext = side === "top" ? cs[j].h : cs[j].l;
      let ok = true;
      for (let k = j - L; k < j && ok; k++) {
        if (side === "top" ? cs[k].h >= ext : cs[k].l <= ext) ok = false;
      }
      for (let k = j + 1; k <= i && ok; k++) {
        if (side === "top" ? cs[k].h > ext : cs[k].l < ext) ok = false;
      }
      if (!ok) continue;
      let prior = side === "top" ? Infinity : -Infinity;
      for (let k = Math.max(0, j - 24); k < j; k++) prior = side === "top" ? Math.min(prior, cs[k].l) : Math.max(prior, cs[k].h);
      if (!(Math.abs(ext - prior) >= priorAtr * a)) continue;
      const tol = Math.max(0.35 * a, 4e-4 * Math.abs(ext));
      if (active.some((lv2) => lv2.side === side && Math.abs(lv2.price - ext) <= tol)) continue;
      const lv = { idx: j, ts: cs[j].ts, price: ext, side, breakIdx: null };
      active.push(lv);
      out.push(lv);
    }
  }
  if (isDefault) swingCache.set(ctx, out.map((l) => ({ ...l })));
  return out;
}
var emptyBreakoutStats = () => ({
  buckets: { retest_hold: { n: 0, win: 0 }, retest_heavy: { n: 0, win: 0 }, no_retest: { n: 0, win: 0 } },
  chase: { n: 0, win: 0 }
});
function readBreakout(ctx, level, breakIdx, uptoIdx, stats) {
  const { cs, n, atr, oi } = ctx;
  const upto = Math.min(n - 1, Math.max(breakIdx, uptoIdx));
  const dir = level.side === "top" ? 1 : -1;
  const a = Math.max(atr[breakIdx] || atr[upto] || 0, 1e-9);
  const L = level.price;
  const up = dir > 0;
  const brk = cs[breakIdx];
  const breakFlow = windowFlow(ctx, breakIdx, breakIdx);
  const extensionAtr = (brk.c - L) * dir / a;
  let peak = up ? brk.h : brk.l;
  let peakIdx = breakIdx;
  for (let q = breakIdx + 1; q <= upto; q++) {
    const c = cs[q];
    if (up ? c.h > peak : c.l < peak) {
      peak = up ? c.h : c.l;
      peakIdx = q;
    }
  }
  const impulseFlow = windowFlow(ctx, breakIdx, peakIdx);
  const climax = breakFlow.volRatio >= 2.5 || extensionAtr >= 1.2;
  const legSize = Math.max((peak - L) * dir, 0.5 * a);
  let extreme = peak;
  let touched = false;
  let held = false;
  let failed = false;
  let touchIdx = -1;
  let runPeak = up ? brk.h : brk.l;
  let runPeakIdx = breakIdx;
  for (let q = breakIdx + 1; q <= upto; q++) {
    const c = cs[q];
    if (q > peakIdx) {
      const e = up ? c.l : c.h;
      if (up ? e < extreme : e > extreme) extreme = e;
    }
    const madeHigh = up ? c.h > runPeak : c.l < runPeak;
    if (madeHigh) {
      runPeak = up ? c.h : c.l;
      runPeakIdx = q;
    }
    const near = up ? c.l <= L + 0.3 * a : c.h >= L - 0.3 * a;
    if (near && !madeHigh && q > runPeakIdx && (runPeak - L) * dir >= 0.4 * a) {
      touched = true;
      if (touchIdx < 0) touchIdx = q;
    }
    const back = up ? c.c < L - 0.2 * a : c.c > L + 0.2 * a;
    if (back) failed = true;
    if (touched && !failed && (up ? c.c >= L + 0.1 * a : c.c <= L - 0.1 * a)) {
      const range = Math.max(1e-9, c.h - c.l);
      const pos = (c.c - c.l) / range;
      if (up ? pos >= 0.5 : pos <= 0.5) held = true;
    }
  }
  const pullbackBars = upto > peakIdx ? upto - peakIdx : 0;
  const pullbackFlow = pullbackBars > 0 ? windowFlow(ctx, peakIdx + 1, upto) : null;
  const depth = clamp01((peak - extreme) * dir / legSize);
  const started = pullbackBars > 0 && (depth >= 0.25 || touched);
  const impulsePer = impulseFlow.vol / Math.max(1, impulseFlow.bars);
  const pullPer = pullbackFlow ? pullbackFlow.vol / Math.max(1, pullbackFlow.bars) : 0;
  const pbVolRatio = pullbackFlow && impulsePer > 0 ? pullPer / impulsePer : 0;
  const pbDelta = pullbackFlow ? pullbackFlow.ratio : 0;
  const healthy = started && pbVolRatio <= 0.8 && pbDelta * dir > -0.15;
  const heavy = started && (pbVolRatio > 0.8 && pbDelta * dir < -0.05);
  let oiPct = null;
  const oi0 = oi[Math.max(0, breakIdx - 1)];
  const oi1 = oi[peakIdx];
  if (Number.isFinite(oi0) && Number.isFinite(oi1) && oi0 > 0) oiPct = oi1 / oi0 - 1;
  const bucket = touched ? healthy || held ? "retest_hold" : "retest_heavy" : "no_retest";
  const reasons = [];
  let p = 0.5;
  const dConf = clampR(breakFlow.ratio * dir / 0.15);
  p += 0.1 * dConf;
  reasons.push(
    breakFlow.ratio * dir >= 0.08 ? `\u7A81\u7834K\u4E3B\u52A8${up ? "\u4E70\u5165" : "\u5356\u51FA"}\u5360\u4F18\uFF08${pct(breakFlow.ratio)}\uFF09` : breakFlow.ratio * dir <= -0.05 ? `\u7A81\u7834K\u4E3B\u52A8\u6210\u4EA4\u53CD\u5411\uFF08${pct(breakFlow.ratio)}\uFF09\uFF1A\u9760\u88AB\u52A8\u76D8\u63A8\u52A8\uFF0C\u53EF\u4FE1\u5EA6\u4F4E` : `\u7A81\u7834K\u4E3B\u52A8\u6210\u4EA4\u5747\u8861\uFF08${pct(breakFlow.ratio)}\uFF09`
  );
  if (breakFlow.volRatio >= 1.3 && breakFlow.volRatio < 2.5) {
    p += 0.08;
    reasons.push(`\u7A81\u7834\u653E\u91CF ${breakFlow.volRatio.toFixed(1)}x`);
  } else if (breakFlow.volRatio < 1) {
    p -= 0.06;
    reasons.push(`\u7A81\u7834\u7F29\u91CF ${breakFlow.volRatio.toFixed(1)}x\uFF1A\u53C2\u4E0E\u4E0D\u8DB3`);
  }
  if (climax) {
    p -= 0.08;
    reasons.push(`\u51B2\u9AD8${up ? "" : "/\u6740\u8DCC"}\u8FC7\u6025\uFF08${breakFlow.volRatio.toFixed(1)}x \u91CF \xB7 \u79BB\u4F4D ${extensionAtr.toFixed(1)} ATR\uFF09\uFF1A\u8FFD\u5355\u591A\u534A\u8981\u88AB\u56DE\u8C03\u6D17`);
  }
  if (oiPct != null && oiPct > 2e-3) {
    p += 0.04;
    reasons.push(`\u7A81\u7834\u6BB5\u6301\u4ED3 +${(oiPct * 100).toFixed(2)}%\uFF1A\u6709\u65B0\u8D44\u91D1\u8DDF\u8FDB`);
  }
  if (started) {
    if (healthy) {
      p += 0.12;
      reasons.push(`\u56DE\u8C03\u7F29\u91CF ${pbVolRatio.toFixed(2)}x \xB7 \u56DE\u8C03\u4E2D\u4E3B\u52A8${up ? "\u5356" : "\u4E70"}\u538B\u4E0D\u91CD\uFF08${pct(pbDelta)}\uFF09`);
    } else if (heavy) {
      p -= 0.12;
      reasons.push(`\u56DE\u8C03\u653E\u91CF ${pbVolRatio.toFixed(2)}x \u4E14\u4E3B\u52A8${up ? "\u5356\u51FA" : "\u4E70\u5165"}\u5360\u4F18\uFF08${pct(pbDelta)}\uFF09`);
    } else {
      reasons.push(`\u56DE\u8C03\u91CF\u80FD ${pbVolRatio.toFixed(2)}x \xB7 \u4E3B\u52A8\u5DEE ${pct(pbDelta)}`);
    }
  }
  if (held) {
    p += 0.15;
    reasons.push(`\u56DE\u8E29 ${L} \u540E\u6536\u76D8\u7AD9\u56DE${up ? "\u4E0A\u65B9" : "\u4E0B\u65B9"}\uFF1A${up ? "\u963B\u529B\u8F6C\u652F\u6491" : "\u652F\u6491\u8F6C\u963B\u529B"}\u6210\u7ACB`);
  }
  if (failed) {
    p = 0.15;
    reasons.push(`\u5DF2\u6709\u6536\u76D8\u56DE\u5230\u5173\u952E\u4F4D${up ? "\u4E0B\u65B9" : "\u4E0A\u65B9"}\uFF1A\u7A81\u7834\u5931\u8D25\uFF0C${up ? "\u8FFD\u591A" : "\u8FFD\u7A7A"}\u76D8\u88AB\u5957`);
  }
  let empiricalN = 0;
  let chaseRate = null;
  if (stats && !failed) {
    const b = stats.buckets[bucket];
    if (b.n >= 8) {
      empiricalN = b.n;
      p = (p * 8 + b.win / b.n * b.n) / (8 + b.n);
    }
    if (stats.chase.n >= 8) chaseRate = stats.chase.win / stats.chase.n;
  }
  const followProb = failed ? 0.15 : r3(clampR(p, 0.08, empiricalN ? 0.92 : 0.85));
  let verdict;
  if (failed) verdict = "failed";
  else if (held) verdict = followProb >= 0.5 ? "follow" : "follow_weak";
  else if (started) verdict = heavy ? "avoid" : "wait_pullback";
  else if (climax || extensionAtr >= 0.8) verdict = "chase_risk";
  else if (upto - breakIdx >= 6 && depth < 0.25) verdict = "strong_hold";
  else verdict = "chase_risk";
  const headline = verdict === "failed" ? up ? "\u5047\u7A81\u7834 / \u8BF1\u591A\uFF1A\u4E0D\u8DDF\uFF0C\u53CD\u5411\u673A\u4F1A" : "\u5047\u8DCC\u7834 / \u8BF1\u7A7A\uFF1A\u4E0D\u8DDF\uFF0C\u53CD\u5411\u673A\u4F1A" : verdict === "follow" ? `\u56DE\u8E29\u786E\u8BA4\uFF0C\u53EF\u8DDF\u968F\uFF08${Math.round(followProb * 100)}%\uFF09` : verdict === "follow_weak" ? `\u56DE\u8E29\u5B88\u4F4F\uFF0C\u4F46\u672C\u56FE\u5386\u53F2\u5151\u73B0\u7387\u4EC5 ${Math.round(followProb * 100)}%\uFF1A\u8F7B\u4ED3\u6216\u89C2\u671B` : verdict === "wait_pullback" ? "\u7F29\u91CF\u56DE\u8C03\u4E2D\uFF1A\u7B49\u56DE\u8E29\u5230\u4F4D\u518D\u8DDF" : verdict === "avoid" ? "\u56DE\u8C03\u653E\u91CF\u629B\u538B\u91CD\uFF1A\u6682\u4E0D\u8DDF\u968F" : verdict === "strong_hold" ? "\u5F3A\u52BF\u4E0D\u56DE\u8C03\uFF1A\u53EA\u80FD\u8F7B\u4ED3\u6216\u7B49\u9996\u6B21\u7F29\u91CF\u56DE\u8E29" : "\u521A\u7A81\u7834\u4E0D\u8FFD\uFF1A\u7B49\u56DE\u8E29";
  const known = (impulseFlow.known * impulseFlow.bars + (pullbackFlow?.known ?? 0) * pullbackBars) / Math.max(1, impulseFlow.bars + pullbackBars);
  return {
    dir,
    level: L,
    levelTs: level.ts,
    breakIdx,
    breakTs: brk.ts,
    barsSince: upto - breakIdx,
    impulse: {
      bars: impulseFlow.bars,
      volRatio: r3(breakFlow.volRatio),
      deltaRatio: r3(breakFlow.ratio),
      known: r3(impulseFlow.known),
      extensionAtr: r3(extensionAtr),
      climax,
      peak,
      peakIdx
    },
    pullback: {
      started,
      depth: r3(depth),
      bars: pullbackBars,
      volRatio: r3(pbVolRatio),
      deltaRatio: r3(pbDelta),
      known: r3(pullbackFlow?.known ?? 0),
      touched,
      held,
      failed,
      extreme
    },
    oiPct: oiPct == null ? null : r3(oiPct),
    bucket,
    verdict,
    followProb,
    chaseRate: chaseRate == null ? null : r3(chaseRate),
    empiricalN,
    reasons,
    headline,
    flowSource: sourceOf(known),
    zone: up ? { lo: L - 0.1 * a, hi: L + 0.3 * a } : { lo: L - 0.3 * a, hi: L + 0.1 * a }
  };
}
function scanBreakouts(ctx, horizon = 48) {
  const { cs, n, atr } = ctx;
  const levels = findSwingLevels(ctx);
  const stats = emptyBreakoutStats();
  const events = [];
  for (const lv of levels) {
    if (lv.breakIdx == null) continue;
    const b = lv.breakIdx;
    if (b + 2 >= n) continue;
    const dir = lv.side === "top" ? 1 : -1;
    const a = Math.max(atr[b] || 0, 1e-9);
    const end = Math.min(n - 1, b + horizon);
    const read = readBreakout(ctx, lv, b, Math.min(end, b + 12));
    const full = readBreakout(ctx, lv, b, end);
    const bucket = full.bucket;
    let win = null;
    let touchIdx = -1;
    let runPeak = dir > 0 ? cs[b].h : cs[b].l;
    for (let q = b + 1; q <= end; q++) {
      const c = cs[q];
      const madeHigh = dir > 0 ? c.h > runPeak : c.l < runPeak;
      if (madeHigh) runPeak = dir > 0 ? c.h : c.l;
      const near = dir > 0 ? c.l <= lv.price + 0.3 * a : c.h >= lv.price - 0.3 * a;
      if (near && !madeHigh && (runPeak - lv.price) * dir >= 0.4 * a) {
        touchIdx = q;
        break;
      }
    }
    if (touchIdx > 0) {
      win = false;
      for (let q = touchIdx; q <= end; q++) {
        const c = cs[q];
        if (dir > 0 ? c.c < lv.price - 0.2 * a : c.c > lv.price + 0.2 * a) break;
        if (dir > 0 ? c.h >= lv.price + 1.5 * a : c.l <= lv.price - 1.5 * a) {
          win = true;
          break;
        }
      }
    }
    let chaseWin = false;
    const entry = cs[b].c;
    for (let q = b + 1; q <= end; q++) {
      const c = cs[q];
      if (dir > 0 ? c.c < lv.price - 0.2 * a : c.c > lv.price + 0.2 * a) break;
      if (dir > 0 ? c.h >= entry + 1.5 * a : c.l <= entry - 1.5 * a) {
        chaseWin = true;
        break;
      }
    }
    if (end - b < 12) chaseWin = null;
    const ev = { level: lv, breakIdx: b, bucket, win, chaseWin };
    events.push(ev);
    if (win != null && (bucket !== "no_retest" || end - b >= horizon)) {
      const cell = stats.buckets[bucket];
      cell.n++;
      if (win) cell.win++;
    }
    if (chaseWin != null) {
      stats.chase.n++;
      if (chaseWin) stats.chase.win++;
    }
    void read;
  }
  return { events, stats };
}

// src/quant/model.ts
var FACTORS = [
  {
    key: "touchFlow",
    label: "\u89E6\u9876\u8BA2\u5355\u6D41",
    short: "TOUCH",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.95,
    hint: "\u4EF7\u683C\u89E6\u53CA\uFF08\u6216\u903C\u8FD1\uFF09\u524D\u9AD8/\u524D\u4F4E\u65F6\uFF0C\u7528\u8BA2\u5355\u6D41\u5224\u65AD\u662F\u771F\u7A81\u7834\u8FD8\u662F\u5047\u7A81\u7834\uFF1A\u51B2\u5411\u5173\u952E\u4F4D\u7684\u4E3B\u52A8\u6210\u4EA4\u662F\u5426\u5F3A\u52B2\u3001\u89E6\u53CA\u90A3\u6839\u662F\u5426\u88AB\u5438\u6536\uFF08\u653E\u91CF\u6536\u5728\u4F4D\u5185\u3001\u7A81\u7834\u65B9\u6CA1\u8D62\u5F97\u4E3B\u52A8\u6210\u4EA4\uFF09\u3001\u62D2\u7EDD\u5F71\u7EBF\u3001\u7D2F\u8BA1\u4E3B\u52A8\u6210\u4EA4\uFF08CVD\uFF09\u662F\u5426\u8DDF\u4E0A\u4EF7\u683C\u3001\u89E6\u53CA\u4E4B\u540E\u53CD\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u662F\u5426\u63A5\u7BA1\u3002+1 = \u660E\u663E\u7684\u5047\u7A81\u7834/\u88AB\u62D2\u7EDD\uFF0C\u22121 = \u771F\u7A81\u7834\uFF08\u7A81\u7834\u65B9\u4E3B\u5BFC\u6216\u6536\u76D8\u5DF2\u7AD9\u5230\u5173\u952E\u4F4D\u5916\u4FA7\uFF09\u3002"
  },
  {
    key: "volDiverge",
    label: "\u4E8C\u6B21\u6D4B\u8BD5\u7F29\u91CF",
    short: "VOL DIV",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.55,
    hint: "\u7B2C\u4E8C\u817F\uFF08\u63A8\u5411\u4E8C\u9876/\u4E8C\u5E95\uFF09\u7684\u5355\u4F4D\u6210\u4EA4\u91CF\u660E\u663E\u5C0F\u4E8E\u7B2C\u4E00\u817F \u2192 \u63A8\u52A8\u52A8\u80FD\u8870\u7AED\uFF0C\u53CD\u8F6C\u6982\u7387\u4E0A\u5347\uFF1B\u653E\u91CF\u521B\u65B0\u9AD8/\u65B0\u4F4E\u5219\u66F4\u53EF\u80FD\u662F\u7A81\u7834\u800C\u975E\u53CC\u9876\u3002"
  },
  {
    key: "deltaDiverge",
    label: "\u4E3B\u52A8\u6210\u4EA4\u5DEE\u80CC\u79BB",
    short: "CVD DIV",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.7,
    hint: "\u7528\u9010\u6839\u4E3B\u52A8\u4E70\u5356\u5DEE\uFF08delta/\u6210\u4EA4\u91CF\uFF09\u8861\u91CF\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u9AD8\u4F46\u5DEE\u503C\u8D70\u5F31\uFF08\u9876\uFF09\u6216\u4EF7\u683C\u518D\u521B\u65B0\u4F4E\u4F46\u629B\u538B\u8D70\u5F31\uFF08\u5E95\uFF09= \u7ECF\u5178\u8BA2\u5355\u6D41\u80CC\u79BB\u3002"
  },
  {
    key: "absorption",
    label: "\u5173\u952E\u4F4D\u5438\u6536\u5019\u9009",
    short: "ABSORB",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.8,
    hint: "\u6D4B\u8BD5\u7A97\u53E3\u5185\u51FA\u73B0\u201C\u653E\u91CF\u523A\u7834\u5173\u952E\u4F4D\u4F46\u6536\u76D8\u6536\u56DE\u201D\u7684K\u7EBF\uFF08\u4EF7\u683C\u7ED3\u679C\u672A\u8DDF\u968F\u4E3B\u52A8\u63A8\u8FDB\uFF09\u8D8A\u591A\uFF0C\u8D8A\u652F\u6301\u627F\u63A5\u5019\u9009\uFF1B\u4E0D\u8BC1\u660E\u88AB\u52A8\u8BA2\u5355\u8EAB\u4EFD\uFF1B\u6536\u76D8\u505C\u5728\u5173\u952E\u4F4D\u5916\u4FA7\u5219\u89C6\u4E3A\u51FB\u7A7F\u3002"
  },
  {
    key: "wickReject",
    label: "\u62D2\u7EDD\u5F71\u7EBF",
    short: "REJECT",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.5,
    hint: "\u6700\u6DF1\u6D4B\u8BD5K\u7EBF\u7684\u5F71\u7EBF\u5360\u6BD4 + \u786E\u8BA4K\u7EBF\u6536\u76D8\u4F4D\u7F6E\uFF1A\u957F\u4E0B\u5F71/\u957F\u4E0A\u5F71\u4E14\u6536\u76D8\u6536\u56DE\u5F62\u6001\u5185\u4FA7\uFF0C\u8BF4\u660E\u8BE5\u4EF7\u4F4D\u6709\u771F\u5B9E\u5BF9\u6297\u3002"
  },
  {
    key: "thrustVolume",
    label: "\u786E\u8BA4K\u91CF\u80FD",
    short: "THRUST",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.45,
    liveOnly: true,
    hint: "\u786E\u8BA4K\u7EBF\u76F8\u5BF9\u8FD1 20 \u6839\u5747\u91CF\u7684\u653E\u5927\u500D\u6570\u3002<1 \u7684\u5F31\u786E\u8BA4\u7ECF\u5E38\u88AB\u518D\u6B21\u523A\u7834\uFF1B\u22651.5 \u7684\u62D2\u7EDD\u66F4\u53EF\u9760\u3002\u4EC5\u5B9E\u65F6\u884C\u60C5\u53EF\u7528\u3002"
  },
  {
    key: "bookImbalance",
    label: "\u76D8\u53E3\u5931\u8861",
    short: "BOOK",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.5,
    liveOnly: true,
    hint: "\u5341\u6863\u4E70\u5356\u6302\u5355\u91CF\u5931\u8861\u5EA6\uFF1A\u505A\u591A\u8981\u6C42\u4E70\u76D8\u66F4\u539A\uFF0C\u505A\u7A7A\u8981\u6C42\u5356\u76D8\u66F4\u539A\u3002\u4EC5\u5B9E\u65F6\u884C\u60C5\u53EF\u7528\uFF08\u56DE\u6D4B\u65E0\u5386\u53F2\u76D8\u53E3\uFF09\u3002"
  },
  {
    key: "tapeBias",
    label: "\u5927\u5355\u4E3B\u52A8\u65B9\u5411",
    short: "TAPE",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.4,
    liveOnly: true,
    hint: "\u6210\u4EA4\u6D41\u4E2D\u5927\u5355\u7684\u540D\u4E49\u91D1\u989D\u504F\u5411\u3002\u4E0E\u4EA4\u6613\u65B9\u5411\u4E00\u81F4\u4EC5\u8868\u793A\u5927\u5355\u4E3B\u52A8\u65B9\u5411\uFF1B\u4E0D\u8BC1\u660E\u673A\u6784\u8EAB\u4EFD\u6216\u610F\u56FE\u3002\u4EC5\u5B9E\u65F6\u53EF\u7528\u3002"
  },
  {
    key: "levelIntegrity",
    label: "\u5173\u952E\u4F4D\u5B8C\u6574\u5EA6",
    short: "LEVEL",
    group: "\u7ED3\u6784",
    weight: 0.4,
    hint: "\u540C\u4E00\u4EF7\u4F4D\u88AB\u6D4B\u8BD5\u6B21\u6570\u8D8A\u591A\u3001\u671F\u95F4\u662F\u5426\u51FA\u73B0\u8FC7\u201C\u6536\u76D8\u51FB\u7A7F\u201D\uFF0C\u51B3\u5B9A\u8FD9\u6761\u7EBF\u8FD8\u5269\u591A\u5C11\u9632\u5B88\u4EF7\u503C\uFF1B\u523A\u7834\u540E\u5FEB\u901F\u6536\u56DE\uFF08\u626B\u4F4D\u6536\u56DE\uFF09\u989D\u5916\u52A0\u5206\u3002"
  },
  {
    key: "patternHeight",
    label: "\u5F62\u6001\u9AD8\u5EA6",
    short: "HEIGHT",
    group: "\u7ED3\u6784",
    weight: 0.3,
    hint: "\u5173\u952E\u4F4D\u5230\u9888\u7EBF\u7684\u8DDD\u79BB\uFF08ATR \u500D\u6570\uFF09\u3002\u592A\u77EE\u5219\u7A7A\u95F4\u4E0D\u8DB3\u4EE5\u8986\u76D6\u6210\u672C\u4E0E\u6ED1\u70B9\uFF0C\u8FC7\u9AD8\u5219\u9700\u8981\u66F4\u4E45\u6301\u4ED3\u3002"
  },
  {
    key: "patternSpan",
    label: "\u5F62\u6001\u65F6\u95F4\u8DE8\u5EA6",
    short: "SPAN",
    group: "\u7ED3\u6784",
    weight: 0.25,
    hint: "\u4E24\u6B21\u6D4B\u8BD5\u4E4B\u95F4\u7684\u6839\u6570\u3002\u8FC7\u77ED\u662F\u566A\u97F3\u6296\u52A8\uFF0C\u8FC7\u957F\u5219\u5173\u952E\u4F4D\u5DF2\u7ECF\u949D\u5316\uFF1B\u5BF9\u6570\u5C3A\u5EA6\u4E0A\u4EE5\u7EA6 110 \u6839\u4E3A\u6700\u4F18\u3002"
  },
  {
    key: "trendExhaust",
    label: "\u8D8B\u52BF\u5DF2\u8F6C\u5E73",
    short: "FLATTEN",
    group: "\u7ED3\u6784",
    weight: 0.5,
    hint: "EMA20-EMA50 / ATR \u5EA6\u91CF\u9006\u52BF\u538B\u529B\u3002\u4E8C\u6B21\u6D4B\u8BD5\u8981\u6210\u7ACB\uFF0C\u9006\u7740\u4EA4\u6613\u65B9\u5411\u7684\u8D8B\u52BF\u5FC5\u987B\u5DF2\u7ECF\u8870\u7AED\uFF1A\u5747\u7EBF\u5DEE\u63A5\u8FD1\u8D70\u5E73\u6216\u8F7B\u5FAE\u8F6C\u5411\u65F6\u6700\u4F18\uFF1B\u4ECD\u5728\u5F3A\u9006\u52BF\u63A8\u8FDB\u65F6\u662F\u63A5\u98DE\u5200\uFF0C\u5F97\u5206\u6700\u4F4E\u3002"
  },
  {
    key: "legDecel",
    label: "\u63A8\u8FDB\u51CF\u901F",
    short: "DECEL",
    group: "\u7ED3\u6784",
    weight: 0.45,
    hint: "\u7B2C\u4E8C\u817F\u6BCF\u6839K\u7EBF\u7684\u63A8\u8FDB\u5E45\u5EA6\u76F8\u5BF9\u7B2C\u4E00\u817F\u7684\u8870\u51CF\u6BD4\u4F8B\u3002\u7B2C\u4E8C\u817F\u660E\u663E\u66F4\u6162 = \u8FB9\u9645\u4E70\u5BB6/\u5356\u5BB6\u51CF\u5C11\uFF0C\u53CD\u8F6C\u7ED3\u6784\u6210\u7ACB\u3002"
  },
  {
    key: "volRegime",
    label: "\u6CE2\u52A8\u73AF\u5883",
    short: "REGIME",
    group: "\u7ED3\u6784",
    weight: 0.2,
    hint: "\u5F53\u524D ATR \u5728\u8FD1 500 \u6839\u4E2D\u7684\u5206\u4F4D\u3002\u6CE2\u52A8\u8FC7\u4F4E\u6CA1\u6709\u8DDF\u968F\uFF0C\u8FC7\u9AD8\u5219\u6B62\u635F\u88AB\u968F\u673A\u626B\u51FA\uFF1B\u4E2D\u9AD8\u5206\u4F4D\u6700\u6709\u5229\u4E8E\u5F62\u6001\u5151\u73B0\u3002"
  },
  {
    key: "rrQuality",
    label: "\u76EE\u6807\u53EF\u8FBE\u6027",
    short: "REACH",
    group: "\u98CE\u9669",
    weight: 0.6,
    hint: "\u6A21\u578B\u9884\u6D4B\u7684\u662F\u300C\u80DC\u7387\u300D\u800C\u4E0D\u662F\u300C\u8D54\u7387\u300D\uFF1A\u76EE\u6807\u8D8A\u8FDC\uFF08R:R \u8D8A\u9AD8\uFF09\u8D8A\u96BE\u5728\u8D85\u65F6\u524D\u5151\u73B0\uFF0C\u56E0\u6B64\u9AD8 R:R \u5BF9\u80DC\u7387\u662F\u8D1F\u8BC1\u636E\u3002\u540C\u65F6\u6263\u9664\u5F80\u8FD4\u6210\u672C\u5360\u98CE\u9669\u8FC7\u9AD8\u7684\u5F62\u6001\u3002\u8D54\u7387\u7684\u4EF7\u503C\u5728\u671F\u671B\u503C\u4E00\u680F\u5355\u72EC\u4F53\u73B0\u3002"
  },
  // ── 真实订单流因子（OKX 主动买卖成交额 / 持仓量；无真实数据时按近似或记为无数据）──
  {
    key: "cvdDiverge",
    label: "CVD \u6781\u503C\u80CC\u79BB",
    short: "CVD",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.6,
    hint: "\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5356\u5DEE\uFF08CVD\uFF09\u5728\u4E8C\u9876/\u4E8C\u5E95\u5904\u4E0E\u4E00\u9876/\u4E00\u5E95\u5904\u7684\u5DEE\u503C\uFF1A\u4EF7\u683C\u518D\u521B\u7B49\u9AD8/\u7B49\u4F4E\u70B9\uFF0C\u4F46\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5165\uFF08\u9876\uFF09\u6216\u7D2F\u8BA1\u4E3B\u52A8\u5356\u51FA\uFF08\u5E95\uFF09\u6CA1\u6709\u540C\u6B65\u521B\u51FA\u6781\u503C\uFF0C\u8BF4\u660E\u63A8\u52A8\u65B9\u5DF2\u88AB\u52A8\uFF0C\u53CD\u8F6C\u6982\u7387\u4E0A\u5347\u3002"
  },
  {
    key: "sweepTrap",
    label: "\u626B\u4F4D\u9677\u9631\u5019\u9009",
    short: "TRAP",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.65,
    hint: "\u8BF1\u591A / \u8BF1\u7A7A\u5019\u9009\uFF1A\u4EF7\u683C\u523A\u7A7F\u524D\u9AD8/\u524D\u4F4E\u540E\u6536\u56DE\uFF0C\u4E14\u523A\u7A7F\u671F\u95F4\u4E3B\u52A8\u6210\u4EA4\u7AD9\u5728\u53CD\u8F6C\u4E00\u4FA7\u6216\u8FFD\u5355\u653E\u91CF\u88AB\u5438\u6536 \u2192 \u7A81\u7834\u8FFD\u968F\u8005\u53EF\u80FD\u5904\u4E8E\u4E0D\u5229\u4F4D\u7F6E\uFF08\u89E3\u91CA\u6A21\u578B\uFF0C\u975E\u8D26\u6237\u4E8B\u5B9E\uFF09\u3002\u6536\u76D8\u505C\u5728\u5173\u952E\u4F4D\u5916\u4FA7\u4E14\u7A81\u7834\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u5360\u4F18\u5219\u4E3A\u771F\u7A81\u7834\uFF0C\u8BB0\u8D1F\u5206\u3002"
  },
  {
    key: "testDelta",
    label: "\u786E\u8BA4K\u4E3B\u52A8\u65B9\u5411",
    short: "\u0394CONF",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.4,
    hint: "\u62D2\u7EDD / \u786E\u8BA4 K \u7EBF\u5185\u771F\u5B9E\u4E3B\u52A8\u4E70\u5356\u5DEE\u7684\u65B9\u5411\uFF1A\u505A\u7A7A\u8981\u6C42\u4E3B\u52A8\u5356\u51FA\u63A5\u7BA1\uFF0C\u505A\u591A\u8981\u6C42\u4E3B\u52A8\u4E70\u5165\u63A5\u7BA1\u3002\u4EC5\u5728\u8BE5\u6839\u6709\u771F\u5B9E\u4E3B\u52A8\u6210\u4EA4\u6570\u636E\u65F6\u53C2\u4E0E\u8BC4\u5206\u3002"
  },
  {
    key: "oiTrap",
    label: "\u6301\u4ED3\u91CF\u53D8\u5316",
    short: "OI",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.3,
    hint: "\u7B2C\u4E8C\u817F\uFF08\u51B2\u5411\u4E8C\u9876 / \u6740\u5411\u4E8C\u5E95\uFF09\u671F\u95F4\u6C38\u7EED\u6301\u4ED3\u91CF\u7684\u53D8\u5316\uFF1A\u6301\u4ED3\u589E\u52A0\u8BF4\u660E\u603B\u6301\u4ED3\u6269\u5F20\uFF0C\u4F46\u4E0D\u80FD\u8BC6\u522B\u591A\u7A7A\u8EAB\u4EFD\u6216\u8C01\u88AB\u5957\uFF1B\u6301\u4ED3\u51CF\u5C11\u5219\u662F\u5E73\u4ED3\u9A71\u52A8\u7684\u51B2\u523A\uFF0C\u53CD\u8F6C\u540E\u7F3A\u5C11\u71C3\u6599\u3002\u4EC5\u5728\u6709\u6301\u4ED3\u91CF\u6570\u636E\u65F6\u53C2\u4E0E\u8BC4\u5206\u3002"
  }
];
var FACTOR_INDEX = FACTORS.reduce(
  (acc, f, i) => ({ ...acc, [f.key]: i }),
  {}
);
var MODEL = {
  base: -0.15,
  gain: 0.42
};
var clamp = (v, lo = -1, hi = 1) => v < lo ? lo : v > hi ? hi : v;
function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}
function scoreEvidence(evidence) {
  let logit = MODEL.base;
  const parts = new Array(FACTORS.length).fill(0);
  let covered = 0;
  for (let i = 0; i < FACTORS.length; i++) {
    const e = evidence[i];
    if (e == null || !Number.isFinite(e)) continue;
    const w = FACTORS[i].weight;
    const part = MODEL.gain * w * clamp(e);
    parts[i] = part;
    logit += part;
    covered += w;
  }
  const shrink = Math.min(1, covered / 4.5);
  logit = MODEL.base + (logit - MODEL.base) * shrink;
  return { proba: sigmoid(logit), logit, evidence, parts, covered };
}
var GRADE_BANDS = [
  { grade: "A", min: 0.66, label: "\u9AD8\u6A21\u578B\u5206 \xB7 \u5F85\u9A8C\u8BC1", color: "#2ebd85" },
  { grade: "B", min: 0.58, label: "\u4E2D\u6A21\u578B\u5206 \xB7 \u5F85\u9A8C\u8BC1", color: "#37c8dd" },
  { grade: "C", min: 0.5, label: "\u8FB9\u7F18\u5206\u6570 \xB7 \u89C2\u5BDF", color: "#f0b90b" },
  { grade: "D", min: 0, label: "\u4F4E\u6A21\u578B\u5206 \xB7 \u4E0D\u91C7\u7EB3", color: "#f6465d" }
];
function gradeOf(proba) {
  for (const b of GRADE_BANDS) if (proba >= b.min) return b.grade;
  return "D";
}

// src/quant/scan.ts
var r6 = (v) => Number.isFinite(v) ? Number(v.toFixed(v >= 1e3 ? 2 : 6)) : 0;
var r32 = (v) => Number.isFinite(v) ? Number(v.toFixed(3)) : 0;
var r1 = (v) => Number.isFinite(v) ? Number(v.toFixed(1)) : 0;
var sum = (arr, from, to) => {
  let s = 0;
  for (let i = Math.max(0, from); i <= Math.min(arr.length - 1, to); i++) s += arr[i];
  return s;
};
function collectEvidence(ctx, sig, live) {
  const { cs, n, atr, delta, vols, ema20, ema50, volMa } = ctx;
  const i = Math.min(sig.idx, n - 1);
  const a = Math.max(atr[i] || 0, 1e-9);
  const pv = pivotOf(ctx, sig);
  const dir = sig.side === "long" ? 1 : -1;
  const out = new Array(FACTORS.length).fill(null);
  const isTouch = sig.fill === "limit";
  const { l1a, l1b, l2a, l2b } = legsOf(pv);
  const read = readSecondTest(ctx, sig);
  const set = (key, v) => {
    out[FACTOR_INDEX[key]] = v == null || !Number.isFinite(v) ? null : clamp(v);
  };
  const v1 = sum(vols, l1a, l1b) / Math.max(1, l1b - l1a + 1);
  const v2 = sum(vols, l2a, l2b) / Math.max(1, l2b - l2a + 1);
  set("volDiverge", v1 + v2 > 0 ? (v1 - v2) / ((v1 + v2) / 2) * 1.1 : 0);
  set("deltaDiverge", read.legDeltaDiff);
  set("absorption", (read.absorption.count - read.absorption.breach) / 2);
  const deepest = cs[read.test.idx];
  const dr = Math.max(1e-9, deepest.h - deepest.l);
  const tail = dir > 0 ? (Math.min(deepest.o, deepest.c) - deepest.l) / dr : (deepest.h - Math.max(deepest.o, deepest.c)) / dr;
  const cb = cs[i];
  const cRange = Math.max(1e-9, cb.h - cb.l);
  const closePos2 = (cb.c - cb.l) / cRange;
  set(
    "wickReject",
    (tail - 0.3) * 1.8 + (isTouch ? 0 : (dir > 0 ? closePos2 - 0.5 : 0.5 - closePos2) * 1.6)
  );
  if (live) {
    set("thrustVolume", isTouch || live.volRatio == null ? null : ((live.volRatio || 0) - 1) / 1);
    set("bookImbalance", live.bookImb == null ? null : (live.bookImb || 0) * 2 * dir);
    set("tapeBias", live.bigBias == null ? null : (live.bigBias || 0) * 1.5 * dir);
  }
  const to = Math.min(n - 1, Math.max(i, pv.second));
  let touches = 0;
  let broken = false;
  for (let q = Math.max(0, pv.first); q <= to; q++) {
    const c = cs[q];
    const extreme = dir > 0 ? c.l : c.h;
    if (Math.abs(extreme - pv.level) <= 0.25 * a) touches++;
    if (dir > 0 ? c.c < pv.level - 0.15 * a : c.c > pv.level + 0.15 * a) broken = true;
  }
  const sweepReclaim = read.sweep.occurred && read.confirm.closedInside;
  set("levelIntegrity", 0.4 - (Math.min(touches, 5) - 2) * 0.3 + (sweepReclaim ? 0.35 : 0) - (broken ? 0.6 : 0));
  const height = (pv.neckPrice - pv.level) * dir;
  set("patternHeight", (height / a - 2.2) / 2.5);
  const span = Math.max(1, i - pv.first);
  set("patternSpan", 1 - clamp(Math.abs(Math.log(span / 110)) / Math.log(4), 0, 1) * 2);
  const stretch = (ema20[i] - ema50[i]) / a * -dir;
  set("trendExhaust", 1 - clamp(Math.abs(stretch + 0.3) / 1.9, 0, 1) * 2);
  const mag1 = Math.abs(pv.level - (dir > 0 ? cs[Math.min(l1a, n - 1)]?.h ?? pv.level : cs[Math.min(l1a, n - 1)]?.l ?? pv.level));
  const slope1 = mag1 / Math.max(1, l1b - l1a);
  const slope2 = Math.abs(pv.neckPrice - pv.secondPrice) / Math.max(1, l2b - l2a);
  set("legDecel", slope2 > 0 ? (slope1 / slope2 - 1) * 0.8 : 0);
  const look = 500;
  let below = 0;
  let seen = 0;
  for (let q = Math.max(1, i - look); q <= i; q++) {
    if (atr[q] <= 0) continue;
    seen++;
    if (atr[q] <= a) below++;
  }
  const pct2 = seen > 20 ? below / seen : 0.5;
  set("volRegime", 1 - clamp(Math.abs(pct2 - 0.6) / 0.42, 0, 1) * 1.7);
  const risk = Math.abs(sig.entry - sig.stop);
  const rr = risk > 0 ? Math.abs(sig.tp - sig.entry) / risk : 0;
  const costDrag = sig.entry > 0 && risk > 0 ? Math.abs(sig.entry) * 2 * (FEE_RATE + SLIP_RATE) / risk : 9;
  set("rrQuality", clamp((2.1 - rr) / 1.1) - clamp((costDrag - 0.18) / 0.5, 0, 1) * 0.8);
  set("cvdDiverge", read.cvdDiv);
  if (read.sweep.accepted) set("sweepTrap", -0.8);
  else if (read.sweep.occurred) set("sweepTrap", (read.trap.score - 0.35) / 0.45);
  else set("sweepTrap", 0);
  set("touchFlow", read.touch.evidence);
  set("testDelta", !isTouch && read.confirm.known ? read.confirm.deltaRatio * dir * 3 : null);
  set("oiTrap", read.oi.pct == null ? null : read.oi.pct / 6e-3 * 1);
  void volMa;
  void delta;
  return out;
}
function simulateOutcome(ctx, sig, mode, maxHold) {
  const { cs, n } = ctx;
  const i = sig.idx;
  if (i < 30 || i > n - 2) return null;
  const limit = mode === "touch";
  const next = cs[i + 1];
  let entryPrice;
  let entryTs;
  if (limit) {
    entryPrice = sig.entry;
    entryTs = sig.ts;
  } else {
    if (sig.side === "long" ? next.o <= sig.stop || next.o >= sig.tp : next.o >= sig.stop || next.o <= sig.tp) {
      return {
        filled: false,
        why: "gap",
        entryPrice: 0,
        entryTs: 0,
        exitPrice: 0,
        exitTs: 0,
        r: 0,
        pnlPct: 0,
        holdingBars: 0,
        costR: 0
      };
    }
    entryPrice = sig.side === "long" ? next.o * (1 + SLIP_RATE) : next.o * (1 - SLIP_RATE);
    entryTs = next.ts;
  }
  let exitPrice = null;
  let exitTs = 0;
  let why = "time";
  let exitIdx = -1;
  const endJ = Math.min(i + maxHold, n - 1);
  for (let j = limit ? i : i + 1; j <= endJ; j++) {
    const k = cs[j];
    const hitSL = sig.side === "long" ? k.l <= sig.stop : k.h >= sig.stop;
    const hitTP = !(limit && j === i) && (sig.side === "long" ? k.h >= sig.tp : k.l <= sig.tp);
    if (hitSL) {
      exitPrice = sig.stop;
      why = "sl";
    } else if (hitTP) {
      exitPrice = sig.tp;
      why = "tp";
    }
    if (exitPrice != null) {
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
  }
  if (exitPrice == null) {
    exitPrice = cs[endJ].c;
    exitTs = cs[endJ].ts;
    exitIdx = endJ;
  }
  const exitAdj = sig.side === "long" ? exitPrice * (1 - SLIP_RATE) : exitPrice * (1 + SLIP_RATE);
  const gross = sig.side === "long" ? exitAdj - entryPrice : entryPrice - exitAdj;
  const fee = (entryPrice + exitAdj) * FEE_RATE;
  const slipCost = (limit ? exitPrice : next.o + exitPrice) * SLIP_RATE;
  const pnl = gross - fee;
  const risk = sig.side === "long" ? entryPrice - sig.stop : sig.stop - entryPrice;
  return {
    filled: true,
    why,
    entryPrice: r6(entryPrice),
    entryTs,
    exitPrice: r6(exitAdj),
    exitTs,
    r: r32(risk > 0 ? pnl / risk : 0),
    pnlPct: r32(pnl / entryPrice * 100),
    holdingBars: Math.max(1, exitIdx - i),
    costR: r32(risk > 0 ? (fee + slipCost) / risk : 0)
  };
}
function candidateFrom(ctx, sig, mode, maxHold, live, sym, bar, plan = "neck") {
  if (sig.idx < 30 || sig.idx > ctx.n - 1) return null;
  const evidence = collectEvidence(ctx, sig, sig.idx >= ctx.n - 1 ? live : void 0);
  const score = scoreEvidence(evidence);
  const pv = pivotOf(ctx, sig);
  const read = readSecondTest(ctx, sig);
  const risk = Math.abs(sig.entry - sig.stop);
  const rr = risk > 0 ? Math.abs(sig.tp - sig.entry) / risk : 0;
  const outcome = simulateWithPlan(ctx, sig, mode, maxHold, plan);
  const proba = r32(score.proba);
  const prefix = `${sym ? `${sym}_` : ""}${bar ? `${bar}_` : ""}`;
  return {
    id: `${prefix}${mode}_${sig.ts}_${sig.pattern}_${sig.side}`,
    idx: sig.idx,
    ts: sig.ts,
    side: sig.side,
    pattern: sig.pattern,
    mode,
    level: r6(pv.level),
    neck: r6(pv.neckPrice),
    firstTs: ctx.cs[pv.first]?.ts ?? sig.ts,
    secondTs: ctx.cs[pv.second]?.ts ?? sig.ts,
    entry: r6(sig.entry),
    stop: r6(sig.stop),
    tp: r6(sig.tp),
    structure: Math.round(sig.strength ?? sig.conf),
    proba,
    grade: gradeOf(proba),
    evidence: evidence.map((v) => v == null ? null : r32(v)),
    parts: score.parts.map((v) => r32(v)),
    tags: [...read.trap.kind ? [read.trap.kind === "bullTrap" ? "\u8BF1\u591A\xB7\u626B\u4F4D\u6536\u56DE\u5019\u9009" : "\u8BF1\u7A7A\xB7\u626B\u4F4D\u6536\u56DE\u5019\u9009"] : [], ...sig.tags ?? []],
    note: sig.note ?? "",
    trap: read.trap.kind,
    trapScore: read.trap.score,
    flowSource: read.flowSource,
    headline: read.headline,
    read,
    rr: r1(rr),
    heightAtr: r1((pv.neckPrice - pv.level) * (sig.side === "long" ? 1 : -1) / Math.max(1e-9, ctx.atr[sig.idx])),
    spanBars: Math.max(0, sig.idx - pv.first),
    live: sig.idx >= ctx.n - 2,
    sym,
    bar,
    outcome,
    exits: {
      neck: plan === "neck" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "neck"),
      r15: plan === "r15" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "r15"),
      r10: plan === "r10" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "r10"),
      be: plan === "be" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "be"),
      partial: plan === "partial" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "partial")
    }
  };
}
function runScan(cs, bar, live, sym, plan = "neck", flow) {
  const ctx = buildContext(cs, flow);
  const maxHold = bar === "15m" ? MAX_HOLD_15M : MAX_HOLD_5M;
  const pick = (mode) => {
    const p = {
      ...DEFAULT_PARAMS,
      entryMode: mode === "touch" ? "limit" : "confirm",
      trendBlock: 50
    };
    return scanDoubles(cs, p).signals.map((s) => candidateFrom(ctx, s, mode, maxHold, live, sym, bar, plan)).filter((c) => !!c);
  };
  return { confirm: pick("confirm"), touch: pick("touch"), ctx };
}
function simulateWithPlan(ctx, sig, mode, maxHold, plan) {
  if (plan === "neck") return simulateOutcome(ctx, sig, mode, maxHold);
  const { cs, n, atr } = ctx;
  const i = sig.idx;
  if (i < 30 || i > n - 2) return null;
  const limit = mode === "touch";
  const next = cs[i + 1];
  const dir = sig.side === "long" ? 1 : -1;
  let entryPrice;
  let entryTs;
  if (limit) {
    entryPrice = sig.entry;
    entryTs = sig.ts;
  } else {
    if (dir > 0 ? next.o <= sig.stop : next.o >= sig.stop) {
      return { filled: false, why: "gap", entryPrice: 0, entryTs: 0, exitPrice: 0, exitTs: 0, r: 0, pnlPct: 0, holdingBars: 0, costR: 0 };
    }
    entryPrice = dir > 0 ? next.o * (1 + SLIP_RATE) : next.o * (1 - SLIP_RATE);
    entryTs = next.ts;
  }
  const risk = (entryPrice - sig.stop) * dir;
  if (!(risk > 0)) return null;
  const target = plan === "r10" ? entryPrice + dir * risk : plan === "r15" ? entryPrice + dir * 1.5 * risk : sig.tp;
  if (!limit && (dir > 0 ? next.o >= target : next.o <= target)) {
    return { filled: false, why: "gap", entryPrice: 0, entryTs: 0, exitPrice: 0, exitTs: 0, r: 0, pnlPct: 0, holdingBars: 0, costR: 0 };
  }
  const trigger = entryPrice + dir * risk;
  const targetBeforeTrigger = (target - entryPrice) * dir < risk;
  const useBe = plan === "be" || plan === "partial";
  const half = plan === "partial";
  let stop = sig.stop;
  let armed = false;
  let tookHalf = false;
  let halfExitAdj = 0;
  let lockedR = 0;
  let exitPrice = null;
  let exitTs = 0;
  let why = "time";
  let exitIdx = -1;
  const endJ = Math.min(i + maxHold, n - 1);
  const feePct = FEE_RATE;
  for (let j = limit ? i : i + 1; j <= endJ; j++) {
    const k = cs[j];
    const hitStop = dir > 0 ? k.l <= stop : k.h >= stop;
    const hitTrig = useBe && !armed && !(limit && j === i) && (dir > 0 ? k.h >= trigger : k.l <= trigger);
    const hitTarget = !(limit && j === i) && (dir > 0 ? k.h >= target : k.l <= target);
    if (hitStop) {
      exitPrice = stop;
      why = armed ? "be" : "sl";
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
    if (targetBeforeTrigger && hitTarget) {
      exitPrice = target;
      why = "tp";
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
    if (hitTrig) {
      armed = true;
      stop = entryPrice * (1 + dir * feePct * 2);
      if (half && !tookHalf) {
        tookHalf = true;
        const trigAdj = dir > 0 ? trigger * (1 - SLIP_RATE) : trigger * (1 + SLIP_RATE);
        halfExitAdj = trigAdj;
        const halfGross = (trigAdj - entryPrice) * dir;
        const halfFee = (entryPrice + trigAdj) * FEE_RATE;
        lockedR = 0.5 * ((halfGross - halfFee) / risk);
      }
    }
    if (hitTarget) {
      exitPrice = target;
      why = "tp";
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
  }
  if (exitPrice == null) {
    exitPrice = cs[endJ].c;
    exitTs = cs[endJ].ts;
    exitIdx = endJ;
  }
  const exitAdj = dir > 0 ? exitPrice * (1 - SLIP_RATE) : exitPrice * (1 + SLIP_RATE);
  const gross = (exitAdj - entryPrice) * dir;
  const fee = (entryPrice + exitAdj) * FEE_RATE;
  const pnl = gross - fee;
  const restR = pnl / risk;
  const r = tookHalf ? lockedR + 0.5 * restR : restR;
  const entrySlip = limit ? 0 : next.o * SLIP_RATE;
  const totalFees = entryPrice * FEE_RATE + (tookHalf ? 0.5 * halfExitAdj * FEE_RATE : 0) + (tookHalf ? 0.5 : 1) * exitAdj * FEE_RATE;
  const totalCost = totalFees + entrySlip + (tookHalf ? 0.5 * trigger * SLIP_RATE : 0) + (tookHalf ? 0.5 : 1) * exitPrice * SLIP_RATE;
  void atr;
  return {
    filled: true,
    // `be` describes the exit mechanism, not the sign of the final R.
    // Fees/slippage can make a break-even stop slightly negative; reclassifying
    // it as `sl` corrupts tp/sl/time/be statistics.
    why,
    entryPrice: r6(entryPrice),
    entryTs,
    exitPrice: r6(exitAdj),
    exitTs,
    r: r32(r),
    pnlPct: r32(tookHalf ? r * (risk / entryPrice) * 100 : pnl / entryPrice * 100),
    holdingBars: Math.max(1, exitIdx - i),
    costR: r32(totalCost / risk)
  };
}

// tests/orderflow.test.ts
var BAR = 3e5;
var T0 = 17e11;
function build(start, segs, tweak) {
  const cs = [];
  const ratios = [];
  let px = start;
  for (const s of segs) {
    const step = (s.to - px) / s.bars;
    for (let k = 0; k < s.bars; k++) {
      const o = px;
      const c = px + step + (k % 2 ? 0.04 : -0.04);
      px = px + step;
      const i = cs.length;
      let bar = { ts: T0 + i * BAR, o, h: Math.max(o, c) + 0.25, l: Math.min(o, c) - 0.25, c, v: s.vol };
      if (tweak) bar = tweak(i, bar);
      cs.push(bar);
      ratios.push(s.flow);
    }
  }
  return { cs, ratios };
}
function flowOf(cs, ratios, override = {}, oi) {
  const bars = /* @__PURE__ */ new Map();
  cs.forEach((c, i) => {
    const r = override[i] ?? ratios[i];
    bars.set(c.ts, { ts: c.ts, buy: c.v * (1 + r) / 2, sell: c.v * (1 - r) / 2, oiUsd: oi ? oi(i) : void 0, src: "rubik" });
  });
  return { instId: "TEST", period: "5m", barMs: BAR, bars, from: cs[0].ts, to: cs[cs.length - 1].ts, oiFrom: cs[0].ts, updatedAt: 0, complete: true, tape: { connected: false, trades: 0, bootstrapped: true } };
}
var V = 1e6;
function doubleTopTrap() {
  const segs = [
    { to: 95, bars: 60, vol: V, flow: 0 },
    // 盘整
    { to: 100, bars: 40, vol: 1.4 * V, flow: 0.3 },
    // 第一腿：放量主动买入
    { to: 97, bars: 40, vol: V, flow: -0.25 },
    // 回落到颈线
    { to: 99.45, bars: 40, vol: 0.8 * V, flow: 0.05 },
    // 第二腿：缩量、主动买入弱
    { to: 98.2, bars: 30, vol: 1.1 * V, flow: -0.2 }
    // 确认后下跌
  ];
  const SWEEP = 180;
  const { cs, ratios } = build(95, segs, (i, c) => {
    if (i === SWEEP) return { ...c, o: 99.45, h: 100.49, l: 99.3, c: 99.5, v: 2 * V };
    return c;
  });
  const flow = flowOf(cs, ratios, { [SWEEP]: -0.2 }, (i) => 3e8 * (1 + (i > 140 && i <= SWEEP ? 0.01 : 0)));
  return { cs, flow, SWEEP };
}
{
  const { cs, flow, SWEEP } = doubleTopTrap();
  const sigs = scanDoubles(cs, { ...DEFAULT_PARAMS, entryMode: "confirm", trendBlock: 50 }).signals;
  const sig = sigs.find((s) => s.idx === SWEEP && s.pattern === "dt_reject");
  assert.ok(sig, `\u5E94\u5728\u7B2C ${SWEEP} \u6839\u8BC6\u522B\u51FA\u53CC\u9876\u4E8C\u6B21\u6D4B\u8BD5\u62D2\u7EDD\uFF0C\u5B9E\u9645: ${JSON.stringify(sigs.map((s) => [s.idx, s.pattern]))}`);
  const ctx = buildContext(cs, flow);
  const read = readSecondTest(ctx, sig);
  assert.equal(read.scene, "doubleTop");
  assert.ok(read.sweep.occurred && read.sweep.depthAtr > 0.2, "\u5E94\u8BC6\u522B\u51FA\u626B\u9AD8");
  assert.ok(read.confirm.closedInside && !read.sweep.accepted, "\u626B\u9AD8\u540E\u5E94\u6536\u56DE");
  assert.ok(read.sweep.flow && read.sweep.flow.ratio < -0.1, "\u626B\u9AD8\u671F\u95F4\u4E3B\u52A8\u5356\u51FA\u5360\u4F18");
  assert.ok(read.cvdDiv > 0.25, `CVD \u80CC\u79BB\u5E94\u4E3A\u6B63\uFF0C\u5B9E\u9645 ${read.cvdDiv}`);
  assert.equal(read.trap.kind, "bullTrap", `\u5E94\u5224\u5B9A\u8BF1\u591A\uFF0C\u8BC4\u5206 ${read.trap.score}\uFF0C\u7406\u7531 ${read.trap.reasons.join(" / ")}`);
  assert.ok(read.oi.pct != null && read.oi.pct > 3e-3, "\u51B2\u9AD8\u6BB5\u6301\u4ED3\u5E94\u589E\u52A0");
  assert.equal(read.flowSource, "taker");
  const scan = runScan(cs, "5m", void 0, "TEST", "r15", flow);
  const cand = scan.confirm.find((c) => c.idx === SWEEP);
  assert.ok(cand, "\u5019\u9009\u5E94\u5B58\u5728");
  assert.equal(cand.trap, "bullTrap");
  assert.equal(cand.flowSource, "taker");
  assert.ok(cand.proba > 0.5, `\u771F\u5B9E\u8BA2\u5355\u6D41\u4E0B\u4E0B\u8DCC\u6982\u7387\u5E94 > 50%\uFF0C\u5B9E\u9645 ${cand.proba}`);
  assert.ok(cand.tags.includes("\u8BF1\u591A\xB7\u626B\u4F4D\u6536\u56DE\u5019\u9009"));
  const approx = runScan(cs, "5m", void 0, "TEST", "r15", null).confirm.find((c) => c.idx === SWEEP);
  assert.equal(approx.flowSource, "approx");
  assert.ok(cand.proba >= approx.proba, `\u771F\u5B9E\u8BA2\u5355\u6D41\u786E\u8BA4\u5E94\u4E0D\u4F4E\u4E8E\u8FD1\u4F3C\uFF1A${cand.proba} vs ${approx.proba}`);
  console.log("PASS \u53CC\u9876\u626B\u9AD8\u6536\u56DE + \u4E3B\u52A8\u5356\u51FA\u5360\u4F18 \u2192 \u8BF1\u591A\uFF0C\u4E0B\u8DCC\u6982\u7387", cand.proba, "\uFF08\u8FD1\u4F3C", approx.proba, "\uFF09");
}
{
  const { cs, flow, SWEEP } = doubleTopTrap();
  const mirrored = cs.map((c) => ({ ts: c.ts, o: 200 - c.o, h: 200 - c.l, l: 200 - c.h, c: 200 - c.c, v: c.v }));
  const mflow = { ...flow, bars: new Map([...flow.bars].map(([ts, b]) => [ts, { ...b, buy: b.sell, sell: b.buy }])) };
  const sig = scanDoubles(mirrored, { ...DEFAULT_PARAMS, entryMode: "confirm", trendBlock: 50 }).signals.find((s) => s.idx === SWEEP && s.pattern === "db_reject");
  assert.ok(sig, "\u955C\u50CF\u540E\u5E94\u8BC6\u522B\u51FA\u53CC\u5E95\u4E8C\u6B21\u6D4B\u8BD5");
  const read = readSecondTest(buildContext(mirrored, mflow), sig);
  assert.equal(read.scene, "doubleBottom");
  assert.equal(read.trap.kind, "bearTrap", `\u5E94\u5224\u5B9A\u8BF1\u7A7A\uFF0C\u8BC4\u5206 ${read.trap.score}`);
  console.log("PASS \u53CC\u5E95\u626B\u4F4E\u6536\u56DE + \u4E3B\u52A8\u4E70\u5165\u5360\u4F18 \u2192 \u8BF1\u7A7A");
}
function breakoutScenario(kind) {
  const segs = [
    { to: 95, bars: 60, vol: V, flow: 0 },
    { to: 100, bars: 40, vol: 1.4 * V, flow: 0.3 },
    { to: 97, bars: 40, vol: V, flow: -0.25 },
    { to: 99.4, bars: 39, vol: 0.9 * V, flow: 0.1 }
  ];
  const BREAK = 179;
  const after = kind === "chase" ? [{ to: 101.3, bars: 2, vol: 1.3 * V, flow: 0.2 }] : [
    { to: 101.4, bars: 8, vol: 1.3 * V, flow: 0.2 },
    // 冲击段
    kind === "follow" ? { to: 100.3, bars: 8, vol: 0.5 * V, flow: -0.05 } : { to: 99.7, bars: 8, vol: 1.6 * V, flow: -0.3 },
    // 放量跌回
    kind === "follow" ? { to: 100.9, bars: 4, vol: 0.9 * V, flow: 0.15 } : { to: 99.2, bars: 4, vol: 1.2 * V, flow: -0.2 }
  ];
  const { cs, ratios } = build(95, [...segs, { to: kind === "chase" ? 101.1 : 100.5, bars: 1, vol: 2 * V, flow: 0.25 }, ...after], (i, c) => {
    if (i === BREAK) return { ...c, o: 99.4, h: kind === "chase" ? 101.2 : 100.6, l: 99.3, c: kind === "chase" ? 101.1 : 100.5, v: (kind === "chase" ? 3 : 1.8) * V };
    return c;
  });
  return { cs, flow: flowOf(cs, ratios, { [BREAK]: 0.25 }), BREAK };
}
{
  const { cs, flow, BREAK } = breakoutScenario("follow");
  const ctx = buildContext(cs, flow);
  const levels = findSwingLevels(ctx);
  const top = levels.find((l) => l.side === "top" && Math.abs(l.price - 100.25) < 0.3);
  assert.ok(top, `\u5E94\u627E\u5230 100 \u9644\u8FD1\u7684\u6446\u52A8\u9AD8\u70B9\uFF0C\u5B9E\u9645 ${JSON.stringify(levels.map((l) => [l.side, l.price, l.breakIdx]))}`);
  assert.equal(top.breakIdx, BREAK, "\u5E94\u5728\u7A81\u7834K\u5904\u6807\u8BB0\u6536\u76D8\u7A81\u7834");
  const read = readBreakout(ctx, top, BREAK, ctx.n - 1);
  assert.ok(read.pullback.touched && read.pullback.held && !read.pullback.failed, `\u56DE\u8E29\u5E94\u89E6\u53CA\u5E76\u5B88\u4F4F\uFF1A${JSON.stringify(read.pullback)}`);
  assert.equal(read.verdict, "follow");
  assert.ok(read.followProb > 0.6, `\u53EF\u8DDF\u968F\u6982\u7387\u5E94 > 60%\uFF0C\u5B9E\u9645 ${read.followProb}`);
  assert.ok(read.pullback.volRatio < 0.8, "\u56DE\u8E29\u5E94\u7F29\u91CF");
  console.log("PASS \u771F\u7A81\u7834 \xB7 \u7F29\u91CF\u56DE\u8E29\u5B88\u4F4F \u2192", read.headline);
  const early = readBreakout(ctx, top, BREAK, BREAK + 10);
  assert.ok(["wait_pullback", "chase_risk", "strong_hold"].includes(early.verdict), `\u56DE\u8E29\u672A\u5230\u4F4D\u524D\u4E0D\u5E94\u7ED9\u51FA\u8DDF\u968F\uFF1A${early.verdict}`);
}
{
  const { cs, flow, BREAK } = breakoutScenario("failed");
  const ctx = buildContext(cs, flow);
  const top = findSwingLevels(ctx).find((l) => l.side === "top" && l.breakIdx === BREAK);
  const read = readBreakout(ctx, top, BREAK, ctx.n - 1);
  assert.equal(read.verdict, "failed");
  assert.ok(read.followProb < 0.25, `\u5047\u7A81\u7834\u540E\u8DDF\u968F\u6982\u7387\u5E94\u5F88\u4F4E\uFF0C\u5B9E\u9645 ${read.followProb}`);
  assert.ok(read.reasons.some((r) => r.includes("\u7A81\u7834\u5931\u8D25")));
  console.log("PASS \u653E\u91CF\u8DCC\u56DE\u5173\u952E\u4F4D \u2192 \u5047\u7A81\u7834/\u8BF1\u591A\uFF0C\u4E0D\u8DDF\u968F");
}
{
  const { cs, flow, BREAK } = breakoutScenario("chase");
  const ctx = buildContext(cs, flow);
  const top = findSwingLevels(ctx).find((l) => l.side === "top" && l.breakIdx === BREAK);
  const read = readBreakout(ctx, top, BREAK, ctx.n - 1);
  assert.equal(read.verdict, "chase_risk");
  assert.ok(read.impulse.climax, "3x \u653E\u91CF\u4E14\u79BB\u4F4D >1.2 ATR \u5E94\u5224\u4E3A\u51B2\u9AD8\u8FC7\u6025");
  console.log("PASS \u521A\u7A81\u7834\u653E\u91CF\u79BB\u4F4D \u2192 \u4E0D\u8FFD\uFF0C\u7B49\u56DE\u8E29");
}
{
  const { cs, flow } = breakoutScenario("follow");
  const { events, stats } = scanBreakouts(buildContext(cs, flow));
  assert.ok(events.length >= 1);
  const total = Object.values(stats.buckets).reduce((s, b) => s + b.n, 0) + stats.chase.n;
  assert.ok(total >= 1, "\u5E94\u6709\u7EDF\u8BA1\u6837\u672C");
  console.log("PASS \u5386\u53F2\u7A81\u7834\u7EDF\u8BA1", JSON.stringify(stats));
}
function touchScene(kind) {
  const segs = [
    { to: 95, bars: 60, vol: V, flow: 0 },
    { to: 100, bars: 40, vol: 1.4 * V, flow: 0.3 },
    // 第一顶
    { to: 96, bars: 40, vol: V, flow: -0.25 },
    // 回落
    ...kind === "strong" ? [{ to: 99.9, bars: 30, vol: 2.2 * V, flow: 0.45 }] : [
      { to: 98.3, bars: 18, vol: 1.2 * V, flow: 0.1 },
      // 先有一段正常推进
      { to: 99.9, bars: 12, vol: 0.55 * V, flow: -0.1 }
      // 靠近前高时缩量、主动买入转弱
    ]
  ];
  const total = 60 + 40 + 40 + 30;
  const { cs, ratios } = build(
    95,
    segs,
    (i, c) => kind === "accepted" && i >= total - 2 ? { ...c, o: c.c, h: c.c + 1.3, l: c.c - 0.1, c: c.c + 1.1, v: 2 * V } : c
  );
  const flow = flowOf(cs, ratios);
  const ctx = buildContext(cs, flow);
  const lv = findSwingLevels(ctx).find((l) => l.side === "top");
  return { ctx, lv };
}
{
  const w = touchScene("weak");
  const weak = readTouch(w.ctx, w.lv, w.ctx.n - 1);
  assert.equal(weak.verdict, "reject", `\u7F29\u91CF\u5F31\u4E70\u5165\u89E6\u9876\u5E94\u5224\u62D2\u7EDD\uFF1A${weak.headline}`);
  assert.ok(weak.fakeProb >= 0.6, `\u5047\u7A81\u7834\u6982\u7387\u5E94 \u226560%\uFF0C\u5B9E\u9645 ${weak.fakeProb}`);
  assert.ok(weak.plan && weak.plan.stop > weak.plan.entry && weak.plan.entry > weak.plan.tp, "\u505A\u7A7A\u8BA1\u5212\uFF1A\u6B62\u635F > \u5165\u573A > \u76EE\u6807");
  const s = touchScene("strong");
  const strong = readTouch(s.ctx, s.lv, s.ctx.n - 1);
  assert.equal(strong.verdict, "breakout", `\u653E\u91CF\u5F3A\u4E70\u51B2\u51FB\u524D\u9AD8\u5E94\u5224\u771F\u7A81\u7834\uFF1A${strong.headline}`);
  assert.ok(strong.fakeProb <= 0.4, `\u5047\u7A81\u7834\u6982\u7387\u5E94 \u226440%\uFF0C\u5B9E\u9645 ${strong.fakeProb}`);
  assert.ok(weak.fakeProb - strong.fakeProb > 0.3, "\u540C\u4E00\u51E0\u4F55\u4E0B\uFF0C\u8BA2\u5355\u6D41\u4E0D\u540C\uFF0C\u6982\u7387\u5FC5\u987B\u660E\u663E\u4E0D\u540C");
  const k = touchScene("accepted");
  const acc = readTouch(k.ctx, k.lv, k.ctx.n - 1);
  assert.equal(acc.kind, "accepted");
  assert.equal(acc.verdict, "breakout");
  assert.equal(acc.plan, null, "\u7A81\u7834\u88AB\u63A5\u53D7\u540E\u4E0D\u518D\u7ED9\u53CD\u624B\u8BA1\u5212");
  console.log("PASS \u89E6\u9876\u8BA2\u5355\u6D41 \xB7 \u5F31\u4E70\u5165", weak.fakeProb, "\u2192 \u5047\u7A81\u7834\uFF1B\u5F3A\u4E70\u5165", strong.fakeProb, "\u2192 \u771F\u7A81\u7834\uFF1B\u7AD9\u4E0A\u524D\u9AD8 \u2192 \u4E0D\u505A\u7A7A");
}
{
  const { ctx } = touchScene("weak");
  const { stats } = scanTouches(ctx);
  assert.ok(stats.n >= 0 && stats.reject <= stats.n);
  console.log("PASS \u89E6\u9876\u5386\u53F2\u7EDF\u8BA1", JSON.stringify(stats));
}
console.log("\n\u8BA2\u5355\u6D41\u5224\u8BFB\u6D4B\u8BD5\u5168\u90E8\u901A\u8FC7");
