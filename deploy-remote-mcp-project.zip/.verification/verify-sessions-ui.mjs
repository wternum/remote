// Visual regression: session labels must NOT paint into the top OHLC-legend zone,
// and the session ribbon must live in the bottom lane. Screenshots for review.
import { chromium } from '@playwright/test';
import { mkdir } from 'node:fs/promises';

const url = process.env.TEST_URL || 'http://127.0.0.1:3000/';
await mkdir('.verification', { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, locale: 'zh-CN' });
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto(url, { waitUntil: 'domcontentloaded' });
await page.waitForSelector('canvas[data-session-layer="pd-session-over"]', { timeout: 45000 });
await page.waitForTimeout(6000);

const probe = await page.evaluate(() => {
  const c = document.querySelector('canvas[data-session-layer="pd-session-over"]');
  if (!c) return null;
  const ctx = c.getContext('2d');
  const { width: w, height: h } = c;
  const img = ctx.getImageData(0, 0, w, h).data;
  const ink = (x0, y0, x1, y1) => {
    let n = 0;
    for (let y = Math.max(0, y0); y < Math.min(h, y1); y++)
      for (let x = Math.max(0, x0); x < Math.min(w, x1); x++)
        if (img[(y * w + x) * 4 + 3] > 8) n++;
    return n;
  };
  const dpr = window.devicePixelRatio || 1;
  const topZone = Math.round(64 * dpr);
  const bottomLane = Math.round(24 * dpr);
  return {
    w, h, dpr,
    // top-left legend zone (exclude right-edge AH/AL tags): must be empty
    topLegendInk: ink(0, 0, w - Math.round(140 * dpr), topZone),
    // bottom ribbon lane: must contain badges + underline
    bottomRibbonInk: ink(0, h - bottomLane, w, h),
  };
});
console.log('PROBE', JSON.stringify(probe));
await page.screenshot({ path: '.verification/sessions-ui-desktop.png' });

// mobile
await page.setViewportSize({ width: 390, height: 844 });
await page.waitForTimeout(1500);
await page.screenshot({ path: '.verification/sessions-ui-mobile.png' });

console.log('ERRORS', JSON.stringify(errors));
await browser.close();
if (!probe) { console.error('no session canvas'); process.exit(1); }
// Allow tiny ink from AH/AL sweep diamonds (<400px); badges would be thousands.
if (probe.topLegendInk > 400) { console.error('FAIL: session badges still in top legend zone', probe.topLegendInk); process.exit(1); }
if (probe.bottomRibbonInk <= 0) { console.error('FAIL: no ribbon ink at bottom'); process.exit(1); }
console.log('PASS sessions-ui layout');
