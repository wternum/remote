// tests/session-clock.test.ts
import assert from "node:assert/strict";

// src/lib/lru.ts
function setBounded(map, key, value, max) {
  map.delete(key);
  map.set(key, value);
  while (map.size > max) {
    const oldest = map.keys().next().value;
    if (oldest === void 0) break;
    map.delete(oldest);
  }
}

// src/vela/sessions/sessionClock.ts
var formatters = /* @__PURE__ */ new Map();
function formatter(zone) {
  let f = formatters.get(zone);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", { timeZone: zone, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
    setBounded(formatters, zone, f, 8);
  }
  return f;
}
var parts = (zone, ms) => {
  const o = {};
  for (const p of formatter(zone).formatToParts(new Date(ms))) if (p.type !== "literal") o[p.type] = Number(p.value);
  return o;
};
function zoneOffsetMs(zone, ms) {
  const p = parts(zone, ms);
  return Date.UTC(p.year, p.month - 1, p.day, p.hour % 24, p.minute, p.second) - Math.floor(ms / 1e3) * 1e3;
}
var wallCache = /* @__PURE__ */ new Map();
function localWallToUtc(zone, dayMs, minutes) {
  const key = `${zone}|${dayMs}|${minutes}`;
  const hit = wallCache.get(key);
  if (hit !== void 0) return hit;
  const d = new Date(dayMs);
  const guess = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) + minutes * 6e4;
  let utc = guess - zoneOffsetMs(zone, guess);
  utc = guess - zoneOffsetMs(zone, utc);
  setBounded(wallCache, key, utc, 2048);
  return utc;
}
var hhmm = (ms) => new Date(ms).toISOString().slice(11, 16);
var windowsCache = /* @__PURE__ */ new Map();
function macroWindows(dayMs, mode) {
  const key = `${mode}|${dayMs}`;
  const hit = windowsCache.get(key);
  if (hit) return hit;
  const mk = (id, zone, startMin, endMin, localLabel) => {
    const startMs = mode === "local" && zone ? localWallToUtc(zone, dayMs, startMin) : dayMs + startMin * 6e4;
    const endMs = mode === "local" && zone ? localWallToUtc(zone, dayMs, endMin) : dayMs + endMin * 6e4;
    return Object.freeze({ id, startMs, endMs, label: `${hhmm(startMs)}\u2013${hhmm(endMs)} UTC`, localLabel });
  };
  const windows = Object.freeze(mode === "fixed" ? [
    mk("asia", null, 0, 480, "00:00\u201308:00 UTC \u5408\u6210\u4E9A\u592A\u4EA4\u6613\u65F6\u6BB5"),
    mk("london", null, 480, 960, "\u56FA\u5B9A UTC \u9884\u8BBE"),
    mk("ny", null, 780, 1260, "\u56FA\u5B9A UTC \u9884\u8BBE")
  ] : [
    mk("asia", null, 0, 480, "00:00\u201308:00 UTC \u5408\u6210\u4E9A\u592A\u4EA4\u6613\u65F6\u6BB5"),
    mk("london", "Europe/London", 480, 990, "\u4F26\u6566 08:00\u201316:30"),
    mk("ny", "America/New_York", 480, 1020, "\u7EBD\u7EA6 08:00\u201317:00")
  ]);
  setBounded(windowsCache, key, windows, 800);
  return windows;
}
function overlapWindow(windows) {
  const l = windows.find((w) => w.id === "london"), n = windows.find((w) => w.id === "ny");
  if (!l || !n) return null;
  const startMs = Math.max(l.startMs, n.startMs), endMs = Math.min(l.endMs, n.endMs);
  return endMs > startMs ? { id: "overlap", startMs, endMs, label: `${hhmm(startMs)}\u2013${hhmm(endMs)} UTC`, localLabel: "\u4F26\u6566/\u7EBD\u7EA6\u5B9E\u9645\u4EA4\u96C6" } : null;
}

// src/vela/sessions/sessionMath.ts
var DAY_MS = 864e5;
var MIN_MS = 6e4;
var SESSION_STYLES = {
  asia: {
    id: "asia",
    name: "\u4E9A\u592A\u4EA4\u6613\u65F6\u6BB5",
    shortLabel: "\u4E9A\u592A\u4EA4\u6613\u65F6\u6BB5",
    utcWindow: "00:00\u201308:00 UTC",
    cnWindow: "\u5317\u4EAC 08:00\u201316:00",
    description: "\u4E1C\u4EAC/\u9999\u6E2F/\u65B0\u52A0\u5761\u4E3B\u529B\u65F6\u6BB5\uFF0C\u901A\u5E38\u5448\u533A\u95F4\u9707\u8361\u84C4\u79EF\uFF0C\u6784\u5EFA\u65F6\u6BB5\u9AD8\u70B9\u4E0E\u65F6\u6BB5\u4F4E\u70B9\u53C2\u7167\u3002",
    hex: "#8b5cf6",
    bandFill: "rgba(139, 92, 246, 0.055)",
    bandTopBorder: "rgba(167, 139, 250, 0.48)",
    dividerStroke: "rgba(167, 139, 250, 0.24)",
    badgeBg: "rgba(24, 19, 42, 0.88)",
    badgeBorder: "rgba(139, 92, 246, 0.45)",
    badgeText: "#c4b5fd"
  },
  london: {
    id: "london",
    name: "\u4F26\u6566\u4EA4\u6613\u65F6\u6BB5",
    shortLabel: "\u4F26\u6566\u4EA4\u6613\u65F6\u6BB5",
    utcWindow: "08:00\u201316:00 UTC",
    cnWindow: "\u5317\u4EAC 16:00\u201324:00",
    description: "\u6B27\u6D32\u65F6\u6BB5\u89C2\u5BDF\u7A97\u53E3\uFF1B\u8D8A\u4F4D/\u6536\u56DE\u53EA\u63CF\u8FF0\u4EF7\u683C\u4E8B\u5B9E\uFF0C\u4E0D\u8BC1\u660E\u673A\u6784\u610F\u56FE\u6216\u6B62\u635F\u89E6\u53D1\u3002",
    hex: "#0ea5e9",
    bandFill: "rgba(14, 165, 233, 0.06)",
    bandTopBorder: "rgba(56, 189, 248, 0.52)",
    dividerStroke: "rgba(56, 189, 248, 0.26)",
    badgeBg: "rgba(12, 28, 44, 0.88)",
    badgeBorder: "rgba(14, 165, 233, 0.48)",
    badgeText: "#7dd3fc"
  },
  ny: {
    id: "ny",
    name: "\u7EBD\u7EA6\u4EA4\u6613\u65F6\u6BB5",
    shortLabel: "\u7EBD\u7EA6\u4EA4\u6613\u65F6\u6BB5",
    utcWindow: "13:00\u201321:00 UTC",
    cnWindow: "\u5317\u4EAC 21:00\u201305:00",
    description: "\u7F8E\u80A1\u4E0E\u5B8F\u89C2\u6570\u636E\u76F8\u5173\u89C2\u5BDF\u7A97\u53E3\uFF1B\u91CF\u80FD\u5CF0\u503C\u9700\u6309\u5F53\u65E5\u771F\u5B9E\u6570\u636E\u9A8C\u8BC1\u3002",
    hex: "#f59e0b",
    bandFill: "rgba(245, 158, 11, 0.06)",
    bandTopBorder: "rgba(251, 191, 36, 0.55)",
    dividerStroke: "rgba(251, 191, 36, 0.28)",
    badgeBg: "rgba(38, 25, 10, 0.88)",
    badgeBorder: "rgba(245, 158, 11, 0.48)",
    badgeText: "#fcd34d"
  },
  overlap: {
    id: "overlap",
    name: "\u4F26\u6566\u4E0E\u7EBD\u7EA6\u91CD\u53E0\u65F6\u6BB5",
    shortLabel: "\u4F26\u6566\u4E0E\u7EBD\u7EA6\u91CD\u53E0\u65F6\u6BB5",
    utcWindow: "13:00\u201316:00 UTC",
    cnWindow: "\u5317\u4EAC 21:00\u201324:00",
    description: "\u4F26\u6566\u4E0E\u7EBD\u7EA6\u7A97\u53E3\u4EA4\u96C6\uFF1B\u6DF1\u5EA6\u4E0E\u6210\u4EA4\u5CF0\u503C\u662F\u5F85\u9A8C\u8BC1\u5047\u8BBE\uFF0C\u4E0D\u662F\u65B9\u5411\u4FE1\u53F7\u3002",
    hex: "#10b981",
    bandFill: "rgba(16, 185, 129, 0.065)",
    bandTopBorder: "rgba(52, 211, 153, 0.65)",
    dividerStroke: "rgba(52, 211, 153, 0.32)",
    badgeBg: "rgba(11, 35, 29, 0.90)",
    badgeBorder: "rgba(16, 185, 129, 0.52)",
    badgeText: "#6ee7b7"
  },
  london_close: {
    id: "london_close",
    name: "\u4F26\u6566\u6536\u76D8\u89C2\u5BDF\u65F6\u6BB5",
    shortLabel: "\u4F26\u6566\u6536\u76D8\u89C2\u5BDF\u65F6\u6BB5",
    utcWindow: "15:00\u201317:00 UTC",
    cnWindow: "\u5317\u4EAC 23:00\u201301:00",
    description: "\u6B27\u76D8\u5934\u5BF8\u5E73\u4ED3\u7ED3\u7B97\u4E0E 16:00 UTC \u8D44\u91D1\u8D39\u7387\u8282\u70B9\uFF0C\u5E38\u89C1\u65E5\u5185\u8D8B\u52BF\u51CF\u901F\u6216\u56DE\u64A4\u518D\u5E73\u8861\u3002",
    hex: "#10b981",
    bandFill: "rgba(16, 185, 129, 0.055)",
    bandTopBorder: "rgba(52, 211, 153, 0.52)",
    dividerStroke: "rgba(52, 211, 153, 0.26)",
    badgeBg: "rgba(11, 35, 29, 0.88)",
    badgeBorder: "rgba(16, 185, 129, 0.45)",
    badgeText: "#6ee7b7"
  }
};
var MACRO_SESSIONS = [
  {
    ...SESSION_STYLES.asia,
    startMin: 0,
    endMin: 8 * 60
    // 00:00 - 08:00 UTC
  },
  {
    ...SESSION_STYLES.london,
    startMin: 8 * 60,
    endMin: 16 * 60
    // 08:00 - 16:00 UTC
  },
  {
    ...SESSION_STYLES.ny,
    startMin: 13 * 60,
    endMin: 21 * 60
    // 13:00 - 21:00 UTC
  },
  {
    ...SESSION_STYLES.overlap,
    startMin: 13 * 60,
    endMin: 16 * 60,
    // 13:00 - 16:00 UTC 欧美重叠
    isOverlay: true
  }
];
var KILLZONE_SESSIONS = [
  {
    ...SESSION_STYLES.asia,
    name: "\u4E9A\u592A\u4EA4\u6613\u89C2\u5BDF\u533A\u95F4",
    shortLabel: "\u4E9A\u592A\u4EA4\u6613\u89C2\u5BDF\u533A\u95F4",
    utcWindow: "00:00\u201308:00 UTC",
    cnWindow: "\u5317\u4EAC 08:00\u201316:00",
    description: "00:00\u201308:00 UTC \u5408\u6210\u4E9A\u592A\u4EA4\u6613\u533A\u95F4\uFF0C\u63D0\u4F9B\u65F6\u6BB5\u9AD8\u70B9\u4E0E\u65F6\u6BB5\u4F4E\u70B9\u53C2\u7167\u3002",
    startMin: 0,
    endMin: 8 * 60
    // 00:00 - 08:00 UTC
  },
  {
    ...SESSION_STYLES.london,
    name: "\u4F26\u6566\u5F00\u76D8\u89C2\u5BDF\u7A97\u53E3",
    shortLabel: "\u4F26\u6566\u5F00\u76D8\u89C2\u5BDF\u7A97\u53E3",
    utcWindow: "07:00\u201310:00 UTC",
    cnWindow: "\u5317\u4EAC 15:00\u201318:00",
    description: "\u56FA\u5B9A UTC \u6559\u5B66\u7A97\u53E3\uFF1B\u4E0D\u7B49\u540C\u5168\u5E74\u4F26\u6566\u672C\u5730\u5F00\u76D8\u65F6\u95F4\u3002",
    startMin: 7 * 60,
    endMin: 10 * 60
    // 07:00 - 10:00 UTC
  },
  {
    ...SESSION_STYLES.ny,
    name: "\u7EBD\u7EA6\u5F00\u76D8\u89C2\u5BDF\u7A97\u53E3",
    shortLabel: "\u7EBD\u7EA6\u5F00\u76D8\u89C2\u5BDF\u7A97\u53E3",
    utcWindow: "12:30\u201315:30 UTC",
    cnWindow: "\u5317\u4EAC 20:30\u201323:30",
    description: "\u7F8E\u56FD\u5B8F\u89C2\u6570\u636E\uFF0812:30/13:30\uFF09\u4E0E\u7F8E\u80A1\u5F00\u76D8\uFF0813:30/14:30\uFF09\u7A97\u53E3\uFF0C\u4E8C\u7EA7\u7A81\u7834\u4E0E\u6DF1\u5EA6\u56DE\u8E29\u9AD8\u53D1\u671F\u3002",
    startMin: 12 * 60 + 30,
    endMin: 15 * 60 + 30
    // 12:30 - 15:30 UTC
  },
  {
    ...SESSION_STYLES.london_close,
    startMin: 15 * 60,
    endMin: 17 * 60,
    // 15:00 - 17:00 UTC
    isOverlay: true
  }
];
function formatMinToHHMM(totalMin) {
  const h = Math.floor(totalMin / 60) % 24;
  const m = totalMin % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}
function utcDayFloor(ms) {
  return Math.floor(ms / DAY_MS) * DAY_MS;
}
function computeSessionSpans(minTimeMs, maxTimeMs, options) {
  if (!Number.isFinite(minTimeMs) || !Number.isFinite(maxTimeMs) || maxTimeMs < minTimeMs) {
    return [];
  }
  const defs = options.mode === "killzone" ? KILLZONE_SESSIONS : MACRO_SESSIONS;
  const firstDay = utcDayFloor(minTimeMs);
  const lastDay = utcDayFloor(maxTimeMs);
  const maxDays = 60;
  const startDay = Math.max(firstDay, lastDay - maxDays * DAY_MS);
  const spans2 = [];
  const clockMode = options.clockMode ?? "fixed";
  for (let dayMs = startDay; dayMs <= lastDay; dayMs += DAY_MS) {
    const windows = options.mode === "macro" ? macroWindows(dayMs, clockMode) : null;
    const ov = windows ? overlapWindow(windows) : null;
    for (const def of defs) {
      if (def.id === "asia" && !options.enabledSessions.asia) continue;
      if (def.id === "london" && !options.enabledSessions.london) continue;
      if (def.id === "ny" && !options.enabledSessions.ny) continue;
      if ((def.id === "overlap" || def.id === "london_close") && !options.showOverlap) continue;
      if (def.id === "overlap" && (!options.enabledSessions.london || !options.enabledSessions.ny)) continue;
      const w = windows ? def.id === "overlap" ? ov : windows.find((x) => x.id === def.id) : null;
      const startMs = w ? w.startMs : dayMs + def.startMin * MIN_MS;
      const endMs = w ? w.endMs : dayMs + def.endMin * MIN_MS;
      if (endMs < minTimeMs || startMs > maxTimeMs) continue;
      spans2.push({
        key: `${options.mode}:${options.clockMode ?? "fixed"}:${def.id}:${dayMs}`,
        id: def.id,
        name: def.name,
        shortLabel: def.shortLabel,
        badgeLabel: `${def.name} ${w ? w.label.replace(/\s*UTC$/, "") : formatMinToHHMM(def.startMin) + "\u2013" + formatMinToHHMM(def.endMin)}`,
        utcWindow: w ? w.label : def.utcWindow,
        dayStartMs: dayMs,
        startMs,
        endMs,
        isOverlay: Boolean(def.isOverlay),
        style: def
      });
    }
  }
  return spans2;
}
function getActiveSessionClock(nowMs = Date.now(), mode = "macro", clockMode = "fixed") {
  const d = new Date(nowMs);
  const h = d.getUTCHours();
  const m = d.getUTCMinutes();
  const utcMinutes = h * 60 + m;
  const utcHHMM = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")} UTC`;
  const dayProgressPct = Math.min(100, Math.max(0, utcMinutes / 1440 * 100));
  const defs = mode === "killzone" ? KILLZONE_SESSIONS : MACRO_SESSIONS;
  const day = utcDayFloor(nowMs);
  const windows = mode === "macro" ? macroWindows(day, clockMode) : defs.filter((d2) => !d2.isOverlay).map((d2) => ({ id: d2.id, startMs: day + d2.startMin * MIN_MS, endMs: day + d2.endMin * MIN_MS, label: d2.utcWindow, localLabel: "\u56FA\u5B9A UTC \u6559\u5B66\u7A97\u53E3" }));
  const overlap = mode === "macro" ? overlapWindow(windows) : null;
  const all = overlap ? [...windows, overlap] : windows;
  const activeSessions = defs.filter((def) => all.some((w) => w.id === def.id && nowMs >= w.startMs && nowMs < w.endMs));
  let bestDef = defs[0];
  let bestWait = Infinity;
  for (const offset of [-DAY_MS, 0, DAY_MS]) {
    const ws = mode === "macro" ? macroWindows(day + offset, clockMode) : defs.filter((d2) => !d2.isOverlay).map((d2) => ({ id: d2.id, startMs: day + offset + d2.startMin * MIN_MS }));
    for (const w of ws) {
      const wait = (w.startMs - nowMs) / MIN_MS;
      if (wait > 0 && wait < bestWait) {
        bestWait = wait;
        bestDef = defs.find((d2) => d2.id === w.id) ?? defs[0];
      }
    }
  }
  return { utcHHMM, utcMinutes, dayProgressPct, activeSessions, nextSession: { def: bestDef, inMinutes: bestWait }, windows, overlap };
}

// tests/session-clock.test.ts
var W = Date.parse("2026-01-15T00:00:00Z");
var S = Date.parse("2026-06-15T00:00:00Z");
var at = (d, h, m = 0) => d + h * 36e5 + m * 6e4;
var win = (d, mode, id) => macroWindows(d, mode).find((w) => w.id === id);
assert.equal(win(W, "local", "london").startMs, at(W, 8));
assert.equal(win(W, "local", "london").endMs, at(W, 16, 30));
assert.equal(win(S, "local", "london").startMs, at(S, 7));
assert.equal(win(S, "local", "london").endMs, at(S, 15, 30));
assert.equal(win(W, "local", "ny").startMs, at(W, 13));
assert.equal(win(S, "local", "ny").startMs, at(S, 12));
assert.equal(win(W, "fixed", "london").startMs, at(W, 8));
assert.equal(win(S, "fixed", "london").startMs, at(S, 8));
assert.equal(overlapWindow(macroWindows(W, "local")).startMs, at(W, 13));
assert.equal(overlapWindow(macroWindows(S, "local")).endMs, at(S, 15, 30));
assert.equal(win(S, "local", "asia").startMs, S);
assert.equal(win(S, "local", "asia").endMs, at(S, 8));
var opts = { mode: "macro", clockMode: "local", enabledSessions: { asia: true, london: true, ny: true }, showOverlap: true };
var spans = computeSessionSpans(S, S + 864e5, opts);
assert.equal(spans.find((x) => x.id === "london").startMs, at(S, 7));
assert.equal(getActiveSessionClock(at(S, 7, 30), "macro", "local").activeSessions.some((x) => x.id === "london"), true);
assert.equal(getActiveSessionClock(at(S, 7, 30), "macro", "fixed").activeSessions.some((x) => x.id === "london"), false);
var kzOpts = { mode: "killzone", clockMode: "local", enabledSessions: { asia: true, london: true, ny: true }, showOverlap: true };
assert.equal(computeSessionSpans(S, S + 864e5, kzOpts).find((x) => x.id === "london").startMs, at(S, 7));
assert.equal(getActiveSessionClock(at(S, 7, 30), "killzone", "local").windows.find((x) => x.id === "london").startMs, at(S, 7));
assert.equal(localWallToUtc("America/New_York", Date.parse("2026-03-08T00:00:00Z"), 8 * 60), Date.parse("2026-03-08T12:00:00Z"));
console.log("session-clock: fixed/local conventions, DST boundaries and actual overlap passed");
