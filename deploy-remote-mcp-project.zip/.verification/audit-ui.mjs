import { chromium } from 'playwright';
const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on('pageerror', e => errors.push(String(e)));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
await page.addInitScript(() => localStorage.setItem('pulsedesk.signal-annotations.v2', JSON.stringify({ enabled: true, version: 2 })));
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(12000);
console.log('buttons:', await page.locator('button').evaluateAll(bs => bs.map(b => ({ text: b.textContent?.trim(), aria: b.getAttribute('aria-label'), title: b.title })).filter(x => x.text || x.aria || x.title)));
const btn = page.getByRole('button', { name: '逐棒审计', exact: true });
await btn.first().click();
await page.waitForSelector('[data-testid="price-action-panel"]', { timeout: 10000 });
await page.waitForFunction(() => document.querySelector('[data-testid="price-action-panel"]')?.textContent?.includes('数据质量'), { timeout: 60000 });
await page.waitForTimeout(2500);
await page.screenshot({ path: '.verification/audit-panel.png' });
const info = await page.evaluate(() => {
  const p = document.querySelector('[data-testid="price-action-panel"]');
  const r = p?.getBoundingClientRect();
  return { text: p?.textContent?.slice(0, 900), panel: r ? { x: r.x, y: r.y, w: r.width, h: r.height } : null,
    overflow: p ? p.scrollWidth > p.clientWidth + 1 : null };
});
console.log(JSON.stringify(info));
console.log('errors:', JSON.stringify(errors.slice(0, 10)));
await browser.close();
