var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/lib/types.ts
function ctValOf(symbol) {
  return SYMBOLS.find((s) => s.id === symbol)?.ctVal ?? 1;
}
var SYMBOLS, barMs;
var init_types = __esm({
  "src/lib/types.ts"() {
    "use strict";
    SYMBOLS = [
      { id: "BTC-USDT-SWAP", base: "BTC", label: "BTC \u6C38\u7EED", ctVal: 0.01, minTick: 0.1 },
      { id: "ETH-USDT-SWAP", base: "ETH", label: "ETH \u6C38\u7EED", ctVal: 0.1, minTick: 0.01 },
      { id: "SOL-USDT-SWAP", base: "SOL", label: "SOL \u6C38\u7EED", ctVal: 1, minTick: 0.01 }
    ];
    barMs = (bar) => bar === "15m" ? 9e5 : bar === "1m" ? 6e4 : 3e5;
  }
});

// src/lib/okxVolume.ts
function quoteVolumeOfRow(row, symbol) {
  const finite = (v) => v !== "" && v != null && Number.isFinite(Number(v)) && Number(v) >= 0;
  const quote = Number(row[7]), base = Number(row[6]), contracts = Number(row[5]), close = Number(row[4]);
  if (finite(row[7]) && (quote > 0 || contracts === 0 && (!finite(row[6]) || base === 0))) return { value: quote, source: "quote" };
  if (!(close > 0) || !Number.isFinite(close)) return null;
  if (finite(row[6]) && base > 0) return { value: base * close, source: "base_close_estimate" };
  if (finite(row[5]) && contracts > 0) {
    const value = contracts * ctValOf(symbol) * close;
    return Number.isFinite(value) ? { value, source: "contracts_close_estimate" } : null;
  }
  return null;
}
function quoteVolumeFromRow(row, symbol) {
  return quoteVolumeOfRow(row, symbol)?.value ?? 0;
}
var init_okxVolume = __esm({
  "src/lib/okxVolume.ts"() {
    "use strict";
    init_types();
  }
});

// src/lib/okxCandles.ts
function parseOkxCandle(row, symbol) {
  if (!Array.isArray(row) || row.length < 6) return null;
  const [ts, o, h, l, c] = row.slice(0, 5).map(Number);
  if (![ts, o, h, l, c].every(Number.isFinite) || !Number.isSafeInteger(ts) || ts <= 0 || Math.min(o, h, l, c) <= 0 || h < l || h < Math.max(o, c) || l > Math.min(o, c)) return null;
  const volume = quoteVolumeOfRow(row, symbol);
  if (!volume) return null;
  const rawConfirm = row[8];
  const confirm = rawConfirm === 1 || rawConfirm === "1" ? 1 : rawConfirm === 0 || rawConfirm === "0" ? 0 : void 0;
  return { ts, o, h, l, c, v: volume.value, volumeSource: volume.source, ...confirm === void 0 ? {} : { confirm } };
}
function isClosedCandle(c, intervalMs, now = Date.now(), legacyGraceMs = 1500) {
  if (c.confirm === 1) return true;
  if (c.confirm === 0) return false;
  return Number.isFinite(c.ts) && c.ts + intervalMs + legacyGraceMs <= now;
}
function preferCandle(existing, incoming, existingVolume, incomingVolume, expired = false) {
  if (!existing) return incoming;
  const rank = (c) => c.confirm === 1 ? 2 : c.confirm === 0 || expired ? 1 : 0;
  const quality = (c) => c.volumeSource === "quote" ? 1 : 0;
  const a = rank(existing), b = rank(incoming);
  if (a !== b) return b > a ? incoming : existing;
  const qa = quality(existing), qb = quality(incoming);
  if (qa !== qb) return qb > qa ? incoming : existing;
  return incomingVolume >= existingVolume ? incoming : existing;
}
function mergeCandles(base, incoming, intervalMs, now = Date.now()) {
  const out = /* @__PURE__ */ new Map();
  for (const c of base) out.set(c.ts, c);
  for (const c of incoming) {
    const old = out.get(c.ts);
    out.set(c.ts, preferCandle(old, c, old?.v ?? 0, c.v, isClosedCandle(c, intervalMs, now)));
  }
  return [...out.values()].sort((a, b) => a.ts - b.ts);
}
var init_okxCandles = __esm({
  "src/lib/okxCandles.ts"() {
    "use strict";
    init_okxVolume();
  }
});

// src/vela/okxProvider.ts
var okxProvider_exports = {};
__export(okxProvider_exports, {
  OKXProvider: () => OKXProvider,
  OKX_TIMEFRAMES: () => OKX_TIMEFRAMES,
  barsHub: () => barsHub,
  tfMs: () => tfMs,
  toOkxBar: () => toOkxBar
});
function toOkxBar(tf) {
  if (tf === "D" || tf === "1D") return "1Dutc";
  if (tf === "W" || tf === "1W") return "1Wutc";
  if (tf === "M" || tf === "1M") return "1Mutc";
  const m = Number(tf);
  if (!Number.isFinite(m)) return "5m";
  if (m >= 60 && m % 60 === 0) return `${m / 60}H`;
  return `${m}m`;
}
function tfMs(tf) {
  if (tf === "D" || tf === "1D") return 864e5;
  if (tf === "W" || tf === "1W") return 7 * 864e5;
  if (tf === "M" || tf === "1M") return 30 * 864e5;
  const m = Number(tf);
  return (Number.isFinite(m) ? m : 5) * 6e4;
}
function parseRow(r, symbol) {
  const c = parseOkxCandle(r, symbol);
  if (!c) return null;
  return { time: c.ts, open: c.o, high: c.h, low: c.l, close: c.c, volume: c.v, confirm: c.confirm, volumeSource: c.volumeSource };
}
async function okxGet(path, params, signal) {
  const url = new URL(REST + path);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  for (let attempt = 0; attempt < 4; attempt++) {
    const res = await fetch(url.toString(), { signal, cache: "no-store" });
    if (res.status === 429) {
      if (attempt === 3) throw new Error("OKX rate limited (429)");
      await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
      continue;
    }
    if (!res.ok) throw new Error(`OKX HTTP ${res.status}`);
    const json2 = await res.json();
    if (json2.code && json2.code !== "0") throw new Error(`OKX code ${json2.code}`);
    return json2.data ?? [];
  }
  return [];
}
function newer(existing, incoming) {
  return preferCandle(existing, incoming, existing?.volume ?? 0, incoming.volume ?? 0);
}
function mergeFull(key, cur, incoming) {
  const map = /* @__PURE__ */ new Map();
  for (const b of cur) map.set(b.time, b);
  for (const b of incoming) map.set(b.time, newer(map.get(b.time), b));
  const next = [...map.values()].sort((a, b) => a.time - b.time).slice(-MAX_STORE_BARS);
  store.set(key, next);
  listeners.forEach((fn) => fn(key));
}
function merge(key, incoming) {
  if (!incoming.length) return;
  const cur = store.get(key) ?? [];
  const tail = cur[cur.length - 1];
  const head = incoming[0];
  const ordered = !tail || !head || head.time >= tail.time;
  if (!ordered) {
    mergeFull(key, cur, incoming);
    return;
  }
  const next = cur.length ? cur.slice() : [];
  for (const b of incoming) {
    const last = next[next.length - 1];
    if (last && b.time === last.time) next[next.length - 1] = newer(last, b);
    else if (!last || b.time > last.time) next.push(b);
    else {
      mergeFull(key, cur, incoming);
      return;
    }
  }
  if (next.length > MAX_STORE_BARS) next.splice(0, next.length - MAX_STORE_BARS);
  store.set(key, next);
  listeners.forEach((fn) => fn(key));
}
var REST, WS, OKX_TIMEFRAMES, SWAPS, BRAND_MARKS, brandIcon, TICK, store, listeners, keyOf, MAX_STORE_BARS, barsHub, OKXProvider;
var init_okxProvider = __esm({
  "src/vela/okxProvider.ts"() {
    "use strict";
    init_okxCandles();
    REST = "https://www.okx.com";
    WS = "wss://ws.okx.com/ws/v5/business";
    OKX_TIMEFRAMES = ["1", "3", "5", "15", "30", "60", "240", "D", "W"];
    SWAPS = [
      { ticker: "BTC-USDT-SWAP", description: "Bitcoin / USDT \u6C38\u7EED", type: "swap" },
      { ticker: "ETH-USDT-SWAP", description: "Ethereum / USDT \u6C38\u7EED", type: "swap" },
      { ticker: "SOL-USDT-SWAP", description: "Solana / USDT \u6C38\u7EED", type: "swap" }
    ];
    BRAND_MARKS = {
      btc: `<circle cx="16" cy="16" r="16" fill="#F7931A"/>
    <path fill="#fff" d="M22.4 13.9c.3-2.1-1.3-3.2-3.4-4l.7-2.7-1.7-.4-.7 2.6c-.4-.1-.9-.2-1.4-.3l.7-2.7-1.6-.4-.7 2.7c-.3-.1-.7-.2-1-.2l-2.4-.6-.5 1.8 1.3.3c.7.2.9.6.8 1l-.8 3.2-.2.7-1.1 4.4c-.1.2-.3.6-.8.5l-1.2-.3-.9 1.9 2.2.6c.4.1.8.2 1.2.3l-.7 2.8 1.7.4.7-2.8c.5.1.9.3 1.4.4l-.7 2.8 1.7.4.7-2.8c2.9.6 5 .4 5.9-2.2.7-2.1 0-3.3-1.5-4.1 1.1-.3 1.9-1 2.1-2.5Zm-3.8 5.4c-.5 2.1-4 1-5.2.7l.9-3.7c1.1.3 4.8.8 4.3 3Zm.5-5.4c-.5 1.9-3.4.9-4.3.7l.8-3.4c1 .2 4 .6 3.5 2.7Z"/>`,
      eth: `<circle cx="16" cy="16" r="16" fill="#627EEA"/>
    <g fill="#fff">
      <path d="M16.1 3.9v9.3l7.8 3.5-7.8-12.8Z" fill-opacity=".6"/>
      <path d="M16.1 3.9 8.2 16.7l7.9-3.5V3.9Z"/>
      <path d="M16.1 22.1v6l7.9-10.9-7.9 4.9Z" fill-opacity=".6"/>
      <path d="M16.1 28.1v-6l-7.9-4.9 7.9 10.9Z"/>
      <path d="m16.1 20.7 7.8-4.4-7.8-3.5v7.9Z" fill-opacity=".25"/>
      <path d="m8.2 16.3 7.9 4.4v-7.9l-7.9 3.5Z" fill-opacity=".6"/>
    </g>`,
      sol: `<circle cx="16" cy="16" r="16" fill="#9945FF"/>
    <path fill="#14F195" d="M12.9 9.4h11.2c.5 0 .8.6.4.9l-2.8 2.8c-.2.2-.5.3-.8.3H9.7c-.5 0-.8-.6-.4-.9l2.8-2.8c.2-.2.5-.3.8-.3Z"/>
    <path fill="#FFFFFF" d="M19.1 13.9H7.9c-.5 0-.8.6-.4.9l2.8 2.8c.2.2.5.3.8.3h11.2c.5 0 .8-.6.4-.9l-2.8-2.8c-.2-.2-.5-.3-.8-.3Z"/>
    <path fill="#00D8FF" d="M12.9 18.4h11.2c.5 0 .8.6.4.9l-2.8 2.8c-.2.2-.5.3-.8.3H9.7c-.5 0-.8-.6-.4-.9l2.8-2.8c.2-.2.5-.3.8-.3Z"/>
  `
    };
    brandIcon = (base) => {
      const mark = BRAND_MARKS[base];
      if (!mark) return void 0;
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" role="img">${mark}</svg>`;
      return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
    };
    TICK = { BTC: 0.1, ETH: 0.01, SOL: 0.01 };
    store = /* @__PURE__ */ new Map();
    listeners = /* @__PURE__ */ new Set();
    keyOf = (ticker, tf) => `${ticker}|${tf}`;
    MAX_STORE_BARS = 12e3;
    barsHub = {
      key: keyOf,
      get(ticker, tf) {
        return store.get(keyOf(ticker, tf)) ?? [];
      },
      subscribe(fn) {
        listeners.add(fn);
        return () => {
          listeners.delete(fn);
        };
      }
    };
    OKXProvider = class {
      info() {
        return {
          name: "okx",
          displayName: "OKX",
          supportedTimeframes: OKX_TIMEFRAMES,
          capabilities: { enumerate: true, stream: true, symbolInfo: true }
        };
      }
      async listSymbols() {
        return SWAPS;
      }
      async getSymbolInfo(ticker) {
        const base = ticker.split("-")[0];
        const tick = TICK[base] ?? 0.01;
        return {
          ticker,
          description: SWAPS.find((s) => s.ticker === ticker)?.description ?? ticker,
          type: "swap",
          currency: "USDT",
          // Vela's price axis reads `mintick`. Without it the axis falls back to a
          // zoom-range formula, so a freshly loaded SOL chart can show only one
          // decimal (e.g. 93.1 instead of 93.10) until the user zooms.
          mintick: tick,
          pricescale: Math.round(1 / tick),
          minmove: 1,
          timezone: "Etc/UTC"
        };
      }
      resolveSymbolIcon(symbol) {
        const base = symbol.ticker.split("-")[0]?.toLowerCase();
        return base ? brandIcon(base) : void 0;
      }
      /** 默认回看深度：短周期更深（双顶/双底需要足够多的历史关键位） */
      depthFor(timeframe, range) {
        const m = Number(timeframe);
        const base = !Number.isFinite(m) ? 800 : m <= 5 ? 6e3 : m <= 15 ? 4e3 : m <= 60 ? 2500 : 1500;
        return Math.min(Math.max(range.limit ?? 0, base, 100), 12e3);
      }
      async getBars(ticker, timeframe, range) {
        return this.getBarsProgressive(ticker, timeframe, range, () => void 0);
      }
      /**
       * 渐进历史：第一页（最新 300 根）立刻交给图表绘制，随后分页向前补齐并逐批推送——
       * 与参考站一致：先出图，再变深。
       */
      async getBarsProgressive(ticker, timeframe, range, onBatch, opts) {
        const bar = toOkxBar(timeframe);
        const want = this.depthFor(timeframe, range);
        const map = /* @__PURE__ */ new Map();
        const snapshot = () => [...map.values()].sort((a, b) => a.time - b.time).slice(-want);
        const marketKey = keyOf(ticker, timeframe);
        const emit = () => {
          const snap = snapshot();
          merge(marketKey, snap);
          const latest = new Map((store.get(marketKey) ?? []).map((b) => [b.time, b]));
          const out = snap.map((b) => latest.get(b.time) ?? b);
          onBatch(out);
          return out;
        };
        const firstParams = { instId: ticker, bar, limit: "300", ...range.to ? { after: String(range.to + tfMs(timeframe)) } : {} };
        let first = await okxGet("/api/v5/market/candles", firstParams, opts?.signal);
        if (!first.length && range.to) {
          first = await okxGet("/api/v5/market/history-candles", firstParams, opts?.signal);
        }
        for (const r of first) {
          const b = parseRow(r, ticker);
          if (b) map.set(b.time, b);
        }
        emit();
        let oldest = Math.min(...map.keys());
        let guard = 0;
        while (map.size < want && Number.isFinite(oldest) && guard++ < 160) {
          if (opts?.signal?.aborted) break;
          if (range.from && oldest <= range.from) break;
          let page = [];
          try {
            page = await okxGet("/api/v5/market/history-candles", { instId: ticker, bar, after: String(oldest), limit: "300" }, opts?.signal);
          } catch {
            break;
          }
          if (!page.length) break;
          let added = 0;
          for (const r of page) {
            const b = parseRow(r, ticker);
            if (b && !map.has(b.time)) {
              map.set(b.time, b);
              added++;
            }
          }
          if (!added) break;
          oldest = Math.min(oldest, ...page.map((r) => Number(r[0])));
          if (guard % 2 === 0) {
            emit();
            await new Promise((r) => setTimeout(r, 120));
          }
        }
        return emit();
      }
      subscribe(ticker, timeframe, onBar) {
        const channel = `candle${toOkxBar(timeframe)}`;
        const bar = toOkxBar(timeframe);
        const marketKey = keyOf(ticker, timeframe);
        let ws = null;
        let stopped = false;
        let timer = null;
        let ping = null;
        let opened = false;
        const backfill = async () => {
          try {
            const page = await okxGet("/api/v5/market/candles", { instId: ticker, bar, limit: "300" });
            const fresh = [];
            for (const r of page) {
              const parsed = parseRow(r, ticker);
              if (parsed) fresh.push(parsed);
            }
            if (!fresh.length || stopped) return;
            merge(marketKey, fresh);
            const last = fresh[fresh.length - 1];
            if (last) onBar(last);
          } catch {
          }
        };
        const open = () => {
          if (stopped) return;
          try {
            ws = new WebSocket(WS);
          } catch {
            timer = window.setTimeout(open, 3e3);
            return;
          }
          ws.onopen = () => {
            ws?.send(JSON.stringify({ op: "subscribe", args: [{ channel, instId: ticker }] }));
            ping = window.setInterval(() => ws?.readyState === 1 && ws.send("ping"), 2e4);
            if (opened) void backfill();
            opened = true;
          };
          ws.onmessage = (ev) => {
            if (ev.data === "pong") return;
            try {
              const msg = JSON.parse(ev.data);
              if (msg.arg?.channel !== channel || !msg.data) return;
              const fresh = [];
              for (const r of msg.data) {
                const b = parseRow(r, ticker);
                if (b) {
                  onBar(b);
                  fresh.push(b);
                }
              }
              if (fresh.length) merge(keyOf(ticker, timeframe), fresh);
            } catch {
            }
          };
          ws.onclose = () => {
            if (ping) window.clearInterval(ping);
            if (!stopped) timer = window.setTimeout(open, 2e3);
          };
          ws.onerror = () => ws?.close();
        };
        open();
        return () => {
          stopped = true;
          if (timer) window.clearTimeout(timer);
          if (ping) window.clearInterval(ping);
          ws?.close();
        };
      }
    };
  }
});

// src/server/okx.ts
var okx_exports = {};
__export(okx_exports, {
  fetchBookLive: () => fetchBookLive,
  fetchCandlesLive: () => fetchCandlesLive,
  fetchCandlesTail: () => fetchCandlesTail,
  fetchCandlesWithMeta: () => fetchCandlesWithMeta,
  fetchFundingLive: () => fetchFundingLive,
  fetchInstrumentMeta: () => fetchInstrumentMeta,
  fetchTickerLive: () => fetchTickerLive,
  getCandles: () => getCandles,
  synthBook: () => synthBook,
  synthCandles: () => synthCandles,
  synthTicker: () => synthTicker
});
function makeGate(gapMs) {
  let chain = Promise.resolve();
  return () => {
    const next = chain.then(() => sleep(gapMs));
    chain = next.catch(() => void 0);
    return next;
  };
}
async function okxGet2(path, params, timeoutMs = 5e3) {
  if (path.includes("history-candles")) await historyGate();
  else if (path.includes("candles")) await candlesGate();
  const url = new URL(BASE + path);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(url.toString(), { signal: ctl.signal });
    if (!res.ok) throw new OkxError("HTTP " + res.status, res.status === 429 || res.status >= 500);
    const json2 = await res.json();
    if (json2.code && json2.code !== "0") throw new OkxError("OKX code " + json2.code);
    return json2.data;
  } finally {
    clearTimeout(t);
  }
}
async function okxGetRetry(path, params, tries = 3) {
  let lastErr = null;
  for (let t = 0; t < tries; t++) {
    try {
      const d = await okxGet2(path, params, 8e3);
      return d ?? [];
    } catch (e) {
      lastErr = e;
      if (e instanceof OkxError && !e.retryable) break;
      if (t < tries - 1) await sleep(300 * (t + 1));
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("OKX request failed");
}
function parseCandleRow(row, symbol) {
  return parseOkxCandle(row, symbol);
}
async function fetchCandlesWithMeta(symbol, bar, count) {
  const want = Math.max(1, Math.min(count, 12e3));
  const bm = barMs(bar);
  const map = /* @__PURE__ */ new Map();
  const add = (rows) => {
    for (const r of rows ?? []) {
      const c = parseCandleRow(r, symbol);
      if (c) map.set(c.ts, c);
    }
  };
  const first = await okxGetRetry("/api/v5/market/candles", {
    instId: symbol,
    bar,
    limit: String(Math.min(300, want))
  });
  add(first);
  if (map.size === 0) throw new OkxError("empty candles", false);
  if (map.size < want) {
    const oldest = Math.min(...map.keys());
    let step = 100;
    let startK = 0;
    const failed = [];
    if (want > 1200) {
      try {
        const probe = await okxGetRetry("/api/v5/market/history-candles", {
          instId: symbol,
          bar,
          after: String(oldest),
          limit: "300"
        });
        add(probe);
        if (probe.length >= 200) step = 300;
        startK = 1;
      } catch {
      }
    }
    if (map.size < want) {
      const remPages = Math.ceil((want - map.size) / step);
      const limitStr = String(step);
      const loadPage = async (k) => {
        const rows = await okxGetRetry("/api/v5/market/history-candles", {
          instId: symbol,
          bar,
          after: String(oldest - k * step * bm),
          limit: limitStr
        });
        add(rows);
      };
      await Promise.all(
        Array.from({ length: remPages }, (_, idx) => {
          const k = startK + idx;
          return loadPage(k).catch(() => {
            failed.push(k);
          });
        })
      );
      if (failed.length) {
        await Promise.all(
          [...new Set(failed)].map(
            (k) => loadPage(k).catch(() => {
            })
          )
        );
      }
    }
    if (want > 1200 && map.size < want && map.size >= want - 600 && failed.length === 0) {
      for (let extra = 0; extra < 2 && map.size < want; extra++) {
        const curOldest = Math.min(...map.keys());
        const rows = await okxGetRetry("/api/v5/market/history-candles", {
          instId: symbol,
          bar,
          after: String(curOldest),
          limit: String(step)
        }).catch(() => []);
        const before = map.size;
        add(rows);
        if (map.size === before) break;
      }
    }
  }
  const sorted = [...map.values()].sort((a, b) => a.ts - b.ts);
  const candles = sorted.slice(-want);
  let missingBars = 0;
  for (let i = 1; i < candles.length; i++) {
    const step = Math.round((candles[i].ts - candles[i - 1].ts) / bm);
    if (step > 1) missingBars += step - 1;
  }
  return { candles, missingBars, short: candles.length < want };
}
async function fetchCandlesLive(symbol, bar, count) {
  const { candles } = await fetchCandlesWithMeta(symbol, bar, count);
  return candles;
}
async function fetchCandlesTail(symbol, bar, count = 3) {
  const key = `${symbol}|${bar}|${count}`;
  const hit = tailCache.get(key);
  if (hit && Date.now() - hit.at < TAIL_TTL) return hit.candles;
  const running = tailInflight.get(key);
  if (running) return running;
  const job = fetchCandlesLive(symbol, bar, count).then((candles) => {
    tailCache.delete(key);
    tailCache.set(key, { at: Date.now(), candles });
    while (tailCache.size > 12) {
      const oldest = tailCache.keys().next().value;
      if (oldest === void 0) break;
      tailCache.delete(oldest);
    }
    return candles;
  }).finally(() => {
    if (tailInflight.get(key) === job) tailInflight.delete(key);
  });
  tailInflight.set(key, job);
  return job;
}
async function fetchTickerLive(symbol) {
  const data = await okxGet2("/api/v5/market/ticker", { instId: symbol });
  const t = data?.[0];
  if (!t) throw new Error("empty ticker");
  const last = Number(t.last);
  const open24 = Number(t.open24h);
  return {
    last,
    open24,
    high24: Number(t.high24h),
    low24: Number(t.low24h),
    chg24: open24 > 0 ? (last - open24) / open24 * 100 : 0,
    // 永续：volCcy24h 为 24h 成交的币数量（张数×面值），× 最新价 ≈ USDT 成交额
    vol24Quote: t.volCcy24h ? Number(t.volCcy24h) * last : void 0
  };
}
async function fetchFundingLive(symbol) {
  const data = await okxGet2("/api/v5/public/funding-rate", { instId: symbol });
  const d = data?.[0];
  if (!d) return { fundingRate: void 0, nextFundingTime: void 0 };
  return { fundingRate: Number(d.fundingRate), nextFundingTime: Number(d.nextFundingTime) };
}
async function fetchInstrumentMeta(symbol) {
  const hit = metaCache.get(symbol);
  if (hit && Date.now() - hit.at < META_TTL) return hit.val;
  const running = metaInflight.get(symbol);
  if (running) return running;
  const job = (async () => {
    const data = await okxGet2("/api/v5/public/instruments", { instType: "SWAP", instId: symbol });
    const d = data?.[0];
    const ctVal = Number(d?.ctVal), tickSz = Number(d?.tickSz);
    const val = { ctVal: Number.isFinite(ctVal) && ctVal > 0 ? ctVal : void 0, tickSz: Number.isFinite(tickSz) && tickSz > 0 ? tickSz : void 0 };
    if (val.ctVal && val.tickSz && d?.state === "live") metaCache.set(symbol, { at: Date.now(), val });
    return val;
  })().finally(() => {
    if (metaInflight.get(symbol) === job) metaInflight.delete(symbol);
  });
  metaInflight.set(symbol, job);
  return job;
}
async function fetchBookLive(symbol, levels = 10) {
  const data = await okxGet2("/api/v5/market/books", { instId: symbol, sz: String(levels) });
  const mapLv = (a) => ({ p: Number(a[0]), s: Number(a[1]) });
  return {
    bids: (data.bids ?? []).map(mapLv),
    asks: (data.asks ?? []).map(mapLv)
  };
}
function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = a + 1831565813 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function synthCandles(symbol, bar, count, endTs) {
  const cfg = SYNTH_BASE[symbol] ?? { price: 100, vol: 2e-3, volUnit: 1e3 };
  const bm = barMs(bar);
  const dayKey = Math.floor((endTs ?? Date.now()) / 864e5);
  const rng = mulberry32(hashStr(`${symbol}|${bar}|${dayKey}`));
  const lastStart = Math.floor((endTs ?? Date.now()) / bm) * bm - bm;
  const start = lastStart - (count - 1) * bm;
  const out = [];
  let price = cfg.price * (0.97 + rng() * 0.06);
  let regime = 0;
  for (let i = 0; i < count; i++) {
    regime = regime * 0.982 + (rng() - 0.5) * 0.09;
    if (rng() < 0.012) regime += (rng() - 0.5) * 0.9;
    const vScale = 1 + 1.6 * Math.abs(regime) + (rng() < 0.06 ? rng() * 2.4 : 0);
    const pull = -15e-4 * Math.log(price / cfg.price);
    const ret = regime * cfg.vol * 1.6 + pull + (rng() + rng() - 1) * cfg.vol * vScale;
    const o = price * (rng() < 0.02 ? 1 + (rng() - 0.5) * cfg.vol * 6 : 1);
    let p = o;
    let hi = o;
    let lo = o;
    let pc = o;
    for (let s = 0; s < 4; s++) {
      pc = p * (1 + ret / 4 + (rng() - 0.5) * cfg.vol * 0.55 * vScale);
      p = pc;
      hi = Math.max(hi, p);
      lo = Math.min(lo, p);
    }
    const c = p;
    hi = Math.max(hi, o, c) * (1 + rng() * cfg.vol * 0.5 * vScale);
    lo = Math.min(lo, o, c) * (1 - rng() * cfg.vol * 0.5 * vScale);
    const bodyPct = Math.abs(c - o) / o;
    const v = cfg.volUnit * ctValOf(symbol) * (0.45 + rng() * 0.8) * (1 + bodyPct / cfg.vol / 2.2) * c;
    out.push({ ts: start + i * bm, o, h: hi, l: lo, c, v, volumeSource: "synthetic" });
    price = c;
  }
  return out;
}
function synthTicker(candles, bar = "5m") {
  const last = candles[candles.length - 1];
  const bars24h = Math.max(1, Math.round(864e5 / barMs(bar)));
  const open24 = candles[Math.max(0, candles.length - 1 - bars24h)]?.c ?? last.o;
  const highs = candles.slice(-bars24h).map((c) => c.h);
  const lows = candles.slice(-bars24h).map((c) => c.l);
  return {
    last: last.c,
    open24,
    high24: Math.max(...highs),
    low24: Math.min(...lows),
    chg24: (last.c - open24) / open24 * 100
  };
}
function synthBook(last, seedExtra = 0) {
  const rng = mulberry32(hashStr("book" + seedExtra));
  const step = last * 18e-5;
  const bids = [];
  const asks = [];
  for (let i = 1; i <= 10; i++) {
    bids.push({ p: last - step * i, s: 0.4 + rng() * 2.2 });
    asks.push({ p: last + step * i, s: 0.4 + rng() * 2.2 });
  }
  return { bids, asks };
}
function mergeByTs(base, incoming, intervalMs) {
  return mergeCandles(base, incoming, intervalMs);
}
function holesOf(cs, bm) {
  let n = 0;
  for (let i = 1; i < cs.length; i++) {
    const step = Math.round((cs[i].ts - cs[i - 1].ts) / bm);
    if (step > 1) n += step - 1;
  }
  return n;
}
function refreshTail(key, entry, symbol, bar) {
  const running = tailRefresh.get(key);
  if (running) return running;
  const job = (async () => {
    try {
      const rows = await okxGetRetry("/api/v5/market/candles", { instId: symbol, bar, limit: "300" });
      const fresh = [];
      for (const r of rows) {
        const c = parseCandleRow(r, symbol);
        if (c) fresh.push(c);
      }
      if (!fresh.length) return false;
      const bm = barMs(bar);
      const merged = mergeByTs(entry.data, fresh, bm).slice(-Math.max(entry.data.length, 1));
      if (holesOf(merged, bm) > holesOf(entry.data, bm)) return false;
      entry.data = merged;
      const now = Date.now();
      entry.tailAt = now;
      entry.tailAttemptAt = now;
      return true;
    } catch {
      entry.tailAttemptAt = Date.now();
      return false;
    }
  })().finally(() => {
    if (tailRefresh.get(key) === job) tailRefresh.delete(key);
  });
  tailRefresh.set(key, job);
  return job;
}
function remember(key, entry) {
  cache.delete(key);
  cache.set(key, entry);
  while (cache.size > CACHE_MAX) {
    const oldest = cache.keys().next().value;
    if (oldest === void 0) break;
    cache.delete(oldest);
  }
}
async function getCandles(symbol, bar, count, fresh = false) {
  const key = `${symbol}|${bar}`;
  if (!fresh) {
    const hit = cache.get(key);
    if (hit && (hit.data.length >= count || hit.want >= count)) {
      const ttl = hit.live && !hit.gapped ? TTL_LIVE : TTL_DEGRADED;
      if (Date.now() - hit.at < ttl) {
        const last = hit.data[hit.data.length - 1];
        const bm = barMs(bar);
        const now = Date.now();
        const needsTail = hit.live && !!last && last.ts + bm <= now && now - hit.tailAttemptAt >= 2e3;
        const usable = !needsTail || await refreshTail(key, hit, symbol, bar);
        if (usable) return { live: hit.live, gapped: hit.gapped, candles: hit.data.slice(-count) };
      }
    }
    const pending = inflight.get(key);
    if (pending && pending.count >= count) {
      const r = await pending.promise;
      return { live: r.live, gapped: r.gapped, candles: r.candles.slice(-count) };
    }
  }
  const job = (async () => {
    try {
      const { candles, missingBars, short } = await fetchCandlesWithMeta(symbol, bar, count);
      if (candles.length < Math.min(count, 200)) throw new Error("insufficient live data");
      const gapped = missingBars > 0 || short;
      const now = Date.now();
      remember(key, { at: now, live: true, gapped, data: candles, want: count, tailAt: now, tailAttemptAt: now });
      return { live: true, gapped, candles };
    } catch {
      const candles = synthCandles(symbol, bar, count);
      const now = Date.now();
      remember(key, { at: now, live: false, gapped: false, data: candles, want: count, tailAt: now, tailAttemptAt: now });
      return { live: false, gapped: false, candles };
    }
  })();
  inflight.set(key, { promise: job, count });
  try {
    return await job;
  } finally {
    if (inflight.get(key)?.promise === job) inflight.delete(key);
  }
}
var BASE, sleep, candlesGate, historyGate, OkxError, TAIL_TTL, tailCache, tailInflight, META_TTL, metaCache, metaInflight, SYNTH_BASE, CACHE_MAX, TTL_LIVE, TTL_DEGRADED, cache, inflight, tailRefresh;
var init_okx = __esm({
  "src/server/okx.ts"() {
    "use strict";
    init_types();
    init_okxCandles();
    BASE = "https://www.okx.com";
    sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    candlesGate = makeGate(55);
    historyGate = makeGate(105);
    OkxError = class extends Error {
      constructor(message, retryable = true) {
        super(message);
        this.retryable = retryable;
        this.name = "OkxError";
      }
    };
    TAIL_TTL = 1500;
    tailCache = /* @__PURE__ */ new Map();
    tailInflight = /* @__PURE__ */ new Map();
    META_TTL = 36e5;
    metaCache = /* @__PURE__ */ new Map();
    metaInflight = /* @__PURE__ */ new Map();
    SYNTH_BASE = {
      "BTC-USDT-SWAP": { price: 97400, vol: 11e-4, volUnit: 9200 },
      "ETH-USDT-SWAP": { price: 3625, vol: 16e-4, volUnit: 26e3 },
      "SOL-USDT-SWAP": { price: 214, vol: 22e-4, volUnit: 9e3 }
    };
    CACHE_MAX = 12;
    TTL_LIVE = 12e4;
    TTL_DEGRADED = 15e3;
    cache = /* @__PURE__ */ new Map();
    inflight = /* @__PURE__ */ new Map();
    tailRefresh = /* @__PURE__ */ new Map();
  }
});

// tests/volume.test.ts
init_okxVolume();
import assert from "node:assert/strict";
var B = 3e5;
var passed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`PASS ${name}`);
  } catch (e) {
    console.error(`FAIL ${name}
  ${e.message}`);
    process.exitCode = 1;
  }
}
var sockets = [];
var g = globalThis;
g.window = { setTimeout, clearTimeout, setInterval: () => 0, clearInterval: () => void 0 };
g.WebSocket = class {
  constructor() {
    sockets.push(this);
    setTimeout(() => this.onopen?.(), 0);
  }
  send() {
  }
  close() {
  }
};
var realFetch = globalThis.fetch;
var row9 = (t, contracts) => [String(t), "100", "101", "99", "100", String(contracts), String(contracts), String(contracts * 100), "0"];
var push = (t, contracts) => sockets.at(-1)?.onmessage?.({ data: JSON.stringify({ arg: { channel: "candle5m" }, data: [row9(t, contracts)] }) });
var json = (data, status = 200) => new Response(JSON.stringify({ code: "0", data }), { status });
var setFetch = (fn) => {
  globalThis.fetch = (async (input) => fn(new URL(String(input))));
};
var { OKXProvider: OKXProvider2, barsHub: barsHub2 } = await Promise.resolve().then(() => (init_okxProvider(), okxProvider_exports));
var { getCandles: getCandles2, synthCandles: synthCandles2 } = await Promise.resolve().then(() => (init_okx(), okx_exports));
await test("\u5B57\u6BB5\u6362\u7B97\u4F18\u5148\u7EA7\uFF1AvolCcyQuote > volCcy\xD7\u4EF7\u683C > \u5F20\u6570\xD7\u9762\u503C\xD7\u4EF7\u683C", () => {
  assert.equal(quoteVolumeFromRow(["0", "1", "1", "1", "90", "100", "100", "9000"], "SOL-USDT-SWAP"), 9e3);
  assert.equal(quoteVolumeFromRow(["0", "1", "1", "1", "90", "100", "100", "0"], "SOL-USDT-SWAP"), 100 * 90);
  assert.equal(quoteVolumeFromRow(["0", "1", "1", "1", "80000", "100", "0", "0"], "BTC-USDT-SWAP"), 100 * 0.01 * 8e4);
  assert.equal(quoteVolumeFromRow(["0", "1", "1", "1", "NaN", "100", "0", "0"], "BTC-USDT-SWAP"), 0);
});
await test("\u56FE\u8868\u7AEF\uFF1A\u52A0\u8F7D\u4E2D\u9014 WebSocket \u63A8\u9001\u66F4\u65B0\u540E\uFF0C\u540E\u7EED\u6279\u6B21\u4E0E\u955C\u50CF\u4E0D\u518D\u56DE\u9000\u5230\u65E7\u5FEB\u7167", async () => {
  const now = Math.floor(Date.now() / B) * B;
  let pages = 0;
  setFetch((u) => {
    if (u.pathname.endsWith("/market/candles")) return json(Array.from({ length: 300 }, (_, i) => row9(now - i * B, i === 0 ? 1e3 : 5e3)));
    if (++pages === 2) push(now, 4e3);
    const after = Number(u.searchParams.get("after"));
    return json(Array.from({ length: 100 }, (_, i) => row9(after - (i + 1) * B, 5e3)));
  });
  const p = new OKXProvider2();
  p.subscribe("V1-USDT-SWAP", "5", () => void 0);
  await new Promise((r) => setTimeout(r, 5));
  const seq = [];
  await p.getBarsProgressive("V1-USDT-SWAP", "5", { limit: 1500 }, (bars) => seq.push(bars.at(-1).volume ?? 0));
  assert.equal(barsHub2.get("V1-USDT-SWAP", "5").at(-1).volume, 4e5);
  assert.ok(seq.every((v, i) => i === 0 || v >= seq[i - 1]), `\u6279\u6B21\u51FA\u73B0\u56DE\u9000\uFF1A${seq.join(",")}`);
  assert.equal(seq.at(-1), 4e5);
});
await test("\u56FE\u8868\u7AEF\uFF1A\u52A0\u8F7D\u671F\u95F4\u6536\u76D8\u7684 K \u7EBF\u4FDD\u7559\u5B8C\u6574\u6210\u4EA4\u91CF\uFF0C\u4E0D\u88AB\u6B8B\u7F3A\u5FEB\u7167\u6C38\u4E45\u8986\u76D6", async () => {
  const now = Math.floor(Date.now() / B) * B;
  let pages = 0;
  setFetch((u) => {
    if (u.pathname.endsWith("/market/candles")) return json(Array.from({ length: 300 }, (_, i) => row9(now - i * B, i === 0 ? 1200 : 5e3)));
    if (++pages === 3) {
      push(now, 5e3);
      push(now + B, 300);
    }
    const after = Number(u.searchParams.get("after"));
    return json(Array.from({ length: 100 }, (_, i) => row9(after - (i + 1) * B, 5e3)));
  });
  const p = new OKXProvider2();
  p.subscribe("V2-USDT-SWAP", "5", () => void 0);
  await new Promise((r) => setTimeout(r, 5));
  await p.getBarsProgressive("V2-USDT-SWAP", "5", { limit: 1500 }, () => void 0);
  const bars = barsHub2.get("V2-USDT-SWAP", "5");
  assert.equal(bars.find((b) => b.time === now).volume, 5e5);
  assert.equal(bars.at(-1).time, now + B);
});
await test("\u56FE\u8868\u7AEF\uFF1A\u5411\u5DE6\u6EDA\u52A8\u52A0\u8F7D\u66F4\u65E9\u533A\u95F4\uFF0C\u8FD4\u56DE\u7684\u5168\u90E8\u5728 range.to \u4E4B\u524D", async () => {
  const now = Math.floor(Date.now() / B) * B;
  const to = now - 2e3 * B;
  setFetch((u) => {
    const after = Number(u.searchParams.get("after"));
    const n = u.pathname.endsWith("/market/candles") ? 300 : 100;
    return json(Array.from({ length: n }, (_, i) => row9(after - (i + 1) * B, 5e3)));
  });
  const p = new OKXProvider2();
  p.subscribe("V3-USDT-SWAP", "5", () => void 0);
  await new Promise((r) => setTimeout(r, 5));
  push(now, 777);
  const out = await p.getBarsProgressive("V3-USDT-SWAP", "5", { limit: 400, to }, () => void 0);
  assert.ok(out.length > 0 && out.every((b) => b.time <= to));
});
await test("\u670D\u52A1\u7AEF\uFF1A\u7F13\u5B58\u4E2D\u7684\u6B8B\u7F3A\u6700\u65B0\u4E00\u6839\u6536\u76D8\u540E\u88AB\u8865\u62C9\u66FF\u6362\uFF0C\u4EC5 1 \u6B21\u8BF7\u6C42\uFF1B\u8865\u62C9\u5931\u8D25\u5219\u6574\u6BB5\u91CD\u62C9", async () => {
  const realNow = Date.now;
  let fakeNow = Math.floor(1793e9 / B) * B + 2e5;
  Date.now = () => fakeNow;
  try {
    const forming = Math.floor(fakeNow / B) * B;
    let firstPage = 0, history = 0, failTail = false;
    const row8 = (t, v) => [String(t), "100", "101", "99", "100", String(v), String(v), String(v * 100)];
    setFetch((u) => {
      const cur = Math.floor(fakeNow / B) * B;
      const partial = Math.round(5e3 * ((fakeNow - cur) / B));
      if (u.pathname.endsWith("/market/candles")) {
        firstPage++;
        if (failTail) {
          failTail = false;
          return new Response("{}", { status: 500 });
        }
        return json(Array.from({ length: 300 }, (_, i) => row8(cur - i * B, i === 0 ? partial : 5e3)));
      }
      history++;
      const after = Number(u.searchParams.get("after"));
      return json(Array.from({ length: 100 }, (_, i) => row8(after - (i + 1) * B, 5e3)));
    });
    await getCandles2("VS-USDT-SWAP", "5m", 600);
    const f0 = firstPage, h0 = history;
    fakeNow = forming + B + 1e3;
    const r = await getCandles2("VS-USDT-SWAP", "5m", 600);
    assert.equal(r.candles.find((c) => c.ts === forming).v, 5e5, "\u6536\u76D8\u540E\u4ECD\u8FD4\u56DE\u6B8B\u7F3A\u6210\u4EA4\u91CF");
    assert.equal(firstPage - f0, 1);
    assert.equal(history, h0, "\u4E0D\u5E94\u6574\u6BB5\u91CD\u62C9");
    assert.equal(r.candles.length, 600);
    assert.equal(r.candles.at(-1).ts, forming + B);
    fakeNow = forming + 2 * B + 1e3;
    failTail = true;
    const h1 = history;
    const r2 = await getCandles2("VS-USDT-SWAP", "5m", 600);
    assert.equal(r2.candles.find((c) => c.ts === forming + B).v, 5e5);
    assert.ok(history > h1, "\u8865\u62C9\u5931\u8D25\u65F6\u5FC5\u987B\u6574\u6BB5\u91CD\u62C9\uFF0C\u800C\u4E0D\u662F\u7EE7\u7EED\u7528\u6B8B\u7F3A\u7F13\u5B58");
  } finally {
    Date.now = realNow;
  }
});
await test("\u964D\u7EA7\u4EFF\u771F\uFF1A\u4EF7\u683C\u6709\u754C\u3001\u6210\u4EA4\u989D\u4E0E\u771F\u5B9E\u91CF\u7EA7\u4E00\u81F4\u3001OHLC \u5408\u6CD5", () => {
  const real = { "BTC-USDT-SWAP": 13e6, "ETH-USDT-SWAP": 14e6, "SOL-USDT-SWAP": 22e5 };
  for (const [id, ref] of Object.entries(real)) {
    for (let d = 0; d < 6; d++) {
      const cs = synthCandles2(id, "5m", 8640, 1793e9 + d * 864e5);
      const closes = cs.map((c) => c.c);
      const ratio = Math.max(...closes) / Math.min(...closes);
      assert.ok(ratio < 3, `${id} \u4EF7\u683C\u6F02\u79FB ${ratio.toExponential(2)}\xD7\uFF08\u4FEE\u590D\u524D\u53EF\u8FBE 1e28\uFF09`);
      const vols = cs.map((c) => c.v).sort((a, b) => a - b);
      const median = vols[Math.floor(vols.length / 2)];
      assert.ok(median > ref / 4 && median < ref * 4, `${id} \u6210\u4EA4\u989D\u4E2D\u4F4D\u6570 ${median.toExponential(2)} \u504F\u79BB\u771F\u5B9E\u91CF\u7EA7 ${ref.toExponential(2)}`);
      assert.ok(cs.every((c) => [c.o, c.h, c.l, c.c, c.v].every(Number.isFinite) && c.l > 0 && c.h >= Math.max(c.o, c.c) && c.l <= Math.min(c.o, c.c)));
    }
  }
});
globalThis.fetch = realFetch;
console.log(`
volume: ${passed} \u7EC4\u65AD\u8A00\u901A\u8FC7`);
process.exit(process.exitCode ?? 0);
