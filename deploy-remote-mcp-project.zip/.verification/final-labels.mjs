import { chromium } from 'playwright';
const browser = await chromium.launch({ args: ['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors=[]; page.on('pageerror',e=>errors.push(String(e))); page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
await page.addInitScript(()=>{
  localStorage.setItem('pulsedesk.signal-annotations.v2',JSON.stringify({enabled:true,version:2}));
  localStorage.setItem('pulsedesk.sessions.v1',JSON.stringify({enabled:true,mode:'macro',clockMode:'fixed',showBands:true,showBadges:true,bandOpacity:65,version:1}));
  // Simulate an old browser that had the retired audit panel open.
  localStorage.setItem('pulsedesk-vela-workspace',JSON.stringify({version:1,layout:'1',charts:[],panels:{open:'pulsedesk-price-action',pinned:['pulsedesk-price-action'],widths:{'pulsedesk-price-action':360}}}));
});
await page.goto('http://127.0.0.1:3000/',{waitUntil:'domcontentloaded'}); await page.waitForTimeout(15000);
const auditCount=await page.getByRole('button',{name:'逐棒审计',exact:true}).count();
const auditText=await page.locator('body').innerText().then(t=>t.includes('逐棒审计'));
const signal=page.getByRole('button',{name:'信号标注',exact:true});
if(await page.getByRole('region',{name:'信号标注设置'}).count()===0) await signal.click();
await page.waitForSelector('[data-testid="session-panel"]'); await page.waitForTimeout(1000);
await page.screenshot({path:'.verification/final-complete-labels.png'});
const text=await page.locator('.sx-panel').innerText();
const persisted=await page.evaluate(()=>localStorage.getItem('pulsedesk-vela-workspace'));
console.log(JSON.stringify({auditCount,auditText,hasFullName:text.includes('亚太交易时段'),hasFullLondon:text.includes('伦敦交易时段'),persisted,errors:errors.slice(0,6)}));
await browser.close();
