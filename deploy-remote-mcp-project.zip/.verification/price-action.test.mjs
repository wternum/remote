// tests/price-action.test.ts
import assert from "node:assert/strict";

// src/lib/types.ts
var SYMBOLS = [
  { id: "BTC-USDT-SWAP", base: "BTC", label: "BTC \u6C38\u7EED", ctVal: 0.01, minTick: 0.1 },
  { id: "ETH-USDT-SWAP", base: "ETH", label: "ETH \u6C38\u7EED", ctVal: 0.1, minTick: 0.01 },
  { id: "SOL-USDT-SWAP", base: "SOL", label: "SOL \u6C38\u7EED", ctVal: 1, minTick: 0.01 }
];
function ctValOf(symbol) {
  return SYMBOLS.find((s) => s.id === symbol)?.ctVal ?? 1;
}

// src/lib/okxVolume.ts
function quoteVolumeOfRow(row, symbol) {
  const finite2 = (v) => v !== "" && v != null && Number.isFinite(Number(v)) && Number(v) >= 0;
  const quote = Number(row[7]), base = Number(row[6]), contracts = Number(row[5]), close = Number(row[4]);
  if (finite2(row[7]) && (quote > 0 || contracts === 0 && (!finite2(row[6]) || base === 0))) return { value: quote, source: "quote" };
  if (!(close > 0) || !Number.isFinite(close)) return null;
  if (finite2(row[6]) && base > 0) return { value: base * close, source: "base_close_estimate" };
  if (finite2(row[5]) && contracts > 0) {
    const value = contracts * ctValOf(symbol) * close;
    return Number.isFinite(value) ? { value, source: "contracts_close_estimate" } : null;
  }
  return null;
}

// src/lib/okxCandles.ts
function parseOkxCandle(row, symbol) {
  if (!Array.isArray(row) || row.length < 6) return null;
  const [ts, o, h, l, c2] = row.slice(0, 5).map(Number);
  if (![ts, o, h, l, c2].every(Number.isFinite) || !Number.isSafeInteger(ts) || ts <= 0 || Math.min(o, h, l, c2) <= 0 || h < l || h < Math.max(o, c2) || l > Math.min(o, c2)) return null;
  const volume = quoteVolumeOfRow(row, symbol);
  if (!volume) return null;
  const rawConfirm = row[8];
  const confirm = rawConfirm === 1 || rawConfirm === "1" ? 1 : rawConfirm === 0 || rawConfirm === "0" ? 0 : void 0;
  return { ts, o, h, l, c: c2, v: volume.value, volumeSource: volume.source, ...confirm === void 0 ? {} : { confirm } };
}
function isClosedCandle(c2, intervalMs, now = Date.now(), legacyGraceMs = 1500) {
  if (c2.confirm === 1) return true;
  if (c2.confirm === 0) return false;
  return Number.isFinite(c2.ts) && c2.ts + intervalMs + legacyGraceMs <= now;
}
function preferCandle(existing, incoming, existingVolume, incomingVolume, expired = false) {
  if (!existing) return incoming;
  const rank = (c2) => c2.confirm === 1 ? 2 : c2.confirm === 0 || expired ? 1 : 0;
  const quality = (c2) => c2.volumeSource === "quote" ? 1 : 0;
  const a = rank(existing), b = rank(incoming);
  if (a !== b) return b > a ? incoming : existing;
  const qa = quality(existing), qb = quality(incoming);
  if (qa !== qb) return qb > qa ? incoming : existing;
  return incomingVolume >= existingVolume ? incoming : existing;
}

// src/quant/priceAction.ts
var PRICE_ACTION_RULES = "price-action-research-v1";
var DEFAULT_PA_OPTIONS = {
  barMs: 3e5,
  tickSz: 0.1,
  feeRate: 5e-4,
  slipRate: 1e-4,
  maxHold: 12,
  minBars: 60,
  requireConfirmed: true,
  now: 0
};
var finite = (v) => typeof v === "number" && Number.isFinite(v);
var validBar = (c2) => c2 && [c2.ts, c2.o, c2.h, c2.l, c2.c, c2.v].every(finite) && Number.isSafeInteger(c2.ts) && c2.ts > 0 && Math.min(c2.o, c2.h, c2.l, c2.c) > 0 && c2.v >= 0 && c2.h >= c2.l && c2.h >= Math.max(c2.o, c2.c) && c2.l <= Math.min(c2.o, c2.c);
var closed = (c2, o) => c2.confirm === 1 || !o.requireConfirmed && c2.confirm !== 0 && c2.ts + o.barMs + 1500 <= o.now;
function normalizeOptions(input = {}) {
  const o = { ...DEFAULT_PA_OPTIONS, ...input };
  if (![o.barMs, o.tickSz, o.feeRate, o.slipRate, o.maxHold, o.minBars, o.now].every(finite) || o.barMs < 6e4 || o.barMs > 864e5 || o.tickSz <= 0 || o.feeRate < 0 || o.feeRate > 0.01 || o.slipRate < 0 || o.slipRate > 0.01 || !Number.isInteger(o.maxHold) || o.maxHold < 1 || o.maxHold > 288 || !Number.isInteger(o.minBars) || o.minBars < 30 || o.minBars > 1e3 || o.now < 0) throw new Error("Invalid price-action options");
  return o;
}
function auditCandles(input, options) {
  const q = {
    input: input.length,
    invalid: 0,
    duplicates: 0,
    forming: 0,
    unconfirmed: 0,
    estimatedVolume: 0,
    missingBars: 0,
    excludedBeforeGap: 0,
    accepted: 0,
    contiguous: true,
    usable: false,
    issues: []
  };
  const map = /* @__PURE__ */ new Map();
  for (const c2 of input) {
    if (!validBar(c2)) {
      q.invalid++;
      continue;
    }
    if (c2.confirm === 0) {
      q.forming++;
      continue;
    }
    if (!closed(c2, options)) {
      q.unconfirmed++;
      continue;
    }
    if (c2.volumeSource && c2.volumeSource !== "quote") q.estimatedVolume++;
    const old = map.get(c2.ts);
    if (old) {
      q.duplicates++;
      if (old.o !== c2.o || old.h !== c2.h || old.l !== c2.l || old.c !== c2.c) {
        map.delete(c2.ts);
        q.invalid++;
      }
      continue;
    }
    map.set(c2.ts, c2);
  }
  let candles = [...map.values()].sort((a, b) => a.ts - b.ts);
  let start = 0;
  for (let i = 1; i < candles.length; i++) {
    const steps = (candles[i].ts - candles[i - 1].ts) / options.barMs;
    if (steps !== 1) {
      q.missingBars += Number.isInteger(steps) && steps > 1 ? steps - 1 : 1;
      q.contiguous = false;
      start = i;
    }
  }
  q.excludedBeforeGap = start;
  candles = candles.slice(start);
  q.accepted = candles.length;
  q.usable = candles.length >= options.minBars;
  if (q.invalid) q.issues.push(`${q.invalid} \u6839\u975E\u6CD5\u6216\u51B2\u7A81 K \u7EBF\u5DF2\u6392\u9664`);
  if (q.duplicates) q.issues.push(`${q.duplicates} \u6839\u91CD\u590D\u65F6\u95F4\u6233`);
  if (q.forming || q.unconfirmed) q.issues.push(`${q.forming + q.unconfirmed} \u6839\u672A\u786E\u8BA4\u6536\u76D8\uFF0C\u4E0D\u53C2\u4E0E\u7814\u7A76`);
  if (!q.contiguous) q.issues.push(`\u5B58\u5728\u65F6\u95F4\u7F3A\u53E3\uFF0C\u4EC5\u4F7F\u7528\u6700\u8FD1\u8FDE\u7EED ${candles.length} \u6839`);
  if (q.estimatedVolume) q.issues.push(`${q.estimatedVolume} \u6839\u6210\u4EA4\u989D\u4E3A\u4F30\u7B97/\u5408\u6210\uFF1B\u672C\u7814\u7A76\u53EA\u4F7F\u7528 OHLC\uFF0C\u4E0D\u636E\u6B64\u9A8C\u8BC1\u8BA2\u5355\u6D41`);
  if (!q.usable) q.issues.push(`\u8FDE\u7EED\u5DF2\u6536\u76D8\u6837\u672C\u4E0D\u8DB3 ${options.minBars} \u6839`);
  return { candles, quality: q };
}
function emaSeries(candles, period = 20) {
  let sum = 0, ema = null;
  const k = 2 / (period + 1);
  return candles.map((c2, i) => {
    sum += c2.c;
    if (i >= period) sum -= candles[i - period].c;
    if (i === period - 1) ema = sum / period;
    else if (i >= period && ema !== null) ema = c2.c * k + ema * (1 - k);
    return ema;
  });
}
function assessBars(cs, options) {
  const ema = emaSeries(cs);
  let anchorHigh = cs[0]?.h ?? 0, anchorLow = cs[0]?.l ?? 0;
  let hCount = 0, lCount = 0, hArmed = false, lArmed = false, untouched = 0;
  const out = [];
  for (let i = 0; i < cs.length; i++) {
    const c2 = cs[i], p = cs[i - 1], e = ema[i];
    const range = Math.max(c2.h - c2.l, options.tickSz);
    const body = Math.abs(c2.c - c2.o), bodyRatio = body / range;
    const overlap = p ? Math.max(0, Math.min(c2.h, p.h) - Math.max(c2.l, p.l)) / range : 0;
    const slope = i >= 24 && e !== null && ema[i - 5] !== null ? e - ema[i - 5] : 0;
    const context = e === null || i < 24 ? "unknown" : slope > options.tickSz ? "bull" : slope < -options.tickSz ? "bear" : "mixed";
    let attempt = null;
    if (p) {
      if (c2.h > anchorHigh) {
        anchorHigh = c2.h;
        hCount = 0;
        hArmed = false;
      } else if (c2.h < p.h) hArmed = true;
      else if (hArmed && c2.h > p.h) {
        hCount++;
        hArmed = false;
        attempt = { side: "long", count: hCount };
      }
      if (c2.l < anchorLow) {
        anchorLow = c2.l;
        lCount = 0;
        lArmed = false;
      } else if (c2.l > p.l) lArmed = true;
      else if (lArmed && c2.l < p.l) {
        lCount++;
        lArmed = false;
        attempt = { side: "short", count: lCount };
      }
    }
    const emaGap = e === null ? null : c2.h < e ? "below" : c2.l > e ? "above" : null;
    const emaTouch = e !== null && c2.l <= e && c2.h >= e;
    untouched = emaGap ? untouched + 1 : 0;
    const firstEmaTouchAfter20 = emaTouch && i > 0 && out[i - 1].untouchedEmaBars >= 20;
    const inside = !!p && c2.h <= p.h && c2.l >= p.l;
    const outside = !!p && c2.h > p.h && c2.l < p.l;
    const doji = bodyRatio <= 0.1;
    const facts = [doji ? "\u5C0F\u5B9E\u4F53/Doji\uFF08\u5DE5\u7A0B\u9608\u503C\uFF1A\u5B9E\u4F53\u226410%\uFF09" : c2.c >= c2.o ? "\u9633\u7EBF\u5B9E\u4F53" : "\u9634\u7EBF\u5B9E\u4F53"];
    if (inside) facts.push("\u5185\u5305\uFF1A\u505C\u987F\uFF0C\u4E0D\u5355\u72EC\u5224\u65B9\u5411");
    if (outside) facts.push("\u5916\u5305\uFF1A\u53CC\u5411\u6269\u5F20\uFF0C\u9700\u540E\u7EED\u89E6\u53D1");
    if (overlap >= 0.7) facts.push("\u4E0E\u524D\u68D2\u9AD8\u5EA6\u91CD\u53E0");
    if (emaGap) facts.push(`\u6574\u68D2\u4F4D\u4E8E EMA ${emaGap === "below" ? "\u4E0B" : "\u4E0A"}\u65B9\uFF08\u5747\u7EBF\u7F3A\u53E3\u68D2\uFF09`);
    if (firstEmaTouchAfter20) facts.push("\u8FDE\u7EED\u226520\u6839\u672A\u89E6 EMA \u540E\u9996\u6B21\u89E6\u78B0");
    if (attempt) facts.push(`${attempt.side === "long" ? "H" : "L"}${attempt.count}\uFF1A\u672C\u68D2\u5DF2\u53D1\u751F\u6062\u590D\u5C1D\u8BD5\uFF0C\u4E0D\u80FD\u56DE\u586B\u6210\u672C\u68D2\u5165\u573A`);
    out.push({
      ts: c2.ts,
      closeTime: c2.ts + options.barMs,
      index: i,
      bodyRatio,
      closePosition: (c2.c - c2.l) / range,
      upperWickRatio: (c2.h - Math.max(c2.o, c2.c)) / range,
      lowerWickRatio: (Math.min(c2.o, c2.c) - c2.l) / range,
      overlapRatio: overlap,
      inside,
      outside,
      doji,
      ema20: e,
      emaGap,
      emaTouch,
      untouchedEmaBars: untouched,
      firstEmaTouchAfter20,
      context,
      attempt,
      facts
    });
    out[i]._setup = context === "bull" && hArmed && hCount < 2 ? { side: "long", count: hCount + 1, anchor: anchorHigh } : context === "bear" && lArmed && lCount < 2 ? { side: "short", count: lCount + 1, anchor: anchorLow } : void 0;
  }
  return out;
}
var align = (price, tick, up) => Number(((up ? Math.ceil(price / tick) : Math.floor(price / tick)) * tick).toFixed(10));
function makePlan(c2, a, symbol, o) {
  const setup = a._setup;
  if (!setup) return null;
  const dir = setup.side === "long" ? 1 : -1;
  const entry = align(setup.side === "long" ? c2.h + o.tickSz : c2.l - o.tickSz, o.tickSz, setup.side === "long");
  const stop = align(setup.side === "long" ? c2.l - o.tickSz : c2.h + o.tickSz, o.tickSz, setup.side === "short");
  const target = setup.anchor;
  const risk = (entry - stop) * dir;
  if (risk <= 0 || (target - entry) * dir <= 0 || stop <= 0) return null;
  const stopAdj = stop * (1 - dir * o.slipRate);
  const netReward = (target - entry) * dir / risk - (entry + target) * o.feeRate / risk;
  const netLoss = (entry - stopAdj) * dir / risk + (entry + stopAdj) * o.feeRate / risk;
  const warnings = ["\u7814\u7A76\u67B6\u6784\uFF0C\u4E0D\u662F\u4EA4\u6613\u5EFA\u8BAE\uFF1B\u80CC\u666F\u5206\u7C7B\u4EC5\u4E3A EMA \u659C\u7387/\u4F4D\u7F6E\u7684\u7B80\u5316\u89C4\u5219", "\u6B62\u635F\u91C7\u7528\u4FE1\u53F7\u68D2\u53E6\u4E00\u7AEF\xB11 tick \u7684\u660E\u786E\u53D8\u4F53\uFF0C\u4E0D\u7B49\u540C\u5B8C\u6574\u7ED3\u6784\u6B62\u635F"];
  if (a.doji) warnings.push("\u4FE1\u53F7\u68D2\u4E3A\u5C0F\u5B9E\u4F53\uFF0C\u8D28\u91CF\u9700\u53E6\u884C\u8BC4\u4F30");
  if (a.overlapRatio >= 0.7) warnings.push("\u9AD8\u5EA6\u91CD\u53E0\uFF0C\u53EF\u80FD\u5904\u4E8E\u7A84\u533A\u95F4");
  if (netReward <= 0) warnings.push("\u76EE\u6807\u6BDB\u5229\u4E0D\u8DB3\u4EE5\u8986\u76D6\u5047\u8BBE\u6210\u672C");
  return {
    id: `${symbol}|${o.barMs}|${c2.ts}|${setup.side}|H/L${setup.count}`,
    side: setup.side,
    attempt: setup.count,
    signalTs: c2.ts,
    signalCloseTime: a.closeTime,
    entry,
    stop,
    target,
    expiresAfterTs: c2.ts + 2 * o.barMs,
    risk,
    breakEvenWinRate: netReward > 0 ? netLoss / (netReward + netLoss) : null,
    warnings
  };
}
function replayPlan(cs, index, p, o) {
  const base = { planId: p.id, status: "expired", entryTs: null, exitTs: null, fill: null, exit: null, netR: null, costR: null, note: "\u4E0B\u4E00\u6839\u672A\u89E6\u53D1\uFF0C\u8BA2\u5355\u5230\u671F" };
  const next = cs[index + 1];
  if (!next) return { ...base, status: "open", note: "\u5C1A\u65E0\u4E0B\u4E00\u6839\u5DF2\u6536\u76D8 K \u7EBF" };
  const dir = p.side === "long" ? 1 : -1;
  if ((next.o - p.stop) * dir <= 0) return { ...base, status: "skipped_gap", note: "\u5F00\u76D8\u5DF2\u8D8A\u8FC7\u5931\u6548\u4EF7\uFF0C\u4E0D\u8FFD\u5355" };
  if ((next.o - p.target) * dir >= 0) return { ...base, status: "skipped_target", note: "\u5F00\u76D8\u5DF2\u5230\u76EE\u6807\uFF0C\u5269\u4F59\u7A7A\u95F4\u4E0D\u8DB3" };
  const triggered = dir > 0 ? next.h >= p.entry : next.l <= p.entry;
  if (!triggered) return base;
  const rawFill = dir > 0 ? Math.max(next.o, p.entry) : Math.min(next.o, p.entry);
  const fill = rawFill * (1 + dir * o.slipRate);
  const risk = (fill - p.stop) * dir;
  if (!(risk > 0)) return { ...base, status: "skipped_gap", note: "\u6ED1\u70B9\u540E\u98CE\u9669\u65E0\u6548" };
  const end = Math.min(index + o.maxHold, cs.length - 1);
  for (let j = index + 1; j <= end; j++) {
    const b = cs[j];
    const hitStop = dir > 0 ? b.l <= p.stop : b.h >= p.stop;
    const hitTarget = dir > 0 ? b.h >= p.target : b.l <= p.target;
    if (hitStop && hitTarget) return { ...base, status: "ambiguous", entryTs: next.ts, fill, note: "\u540C\u4E00 OHLC \u68D2\u540C\u65F6\u89E6\u53CA\u6B62\u635F\u548C\u76EE\u6807\uFF0C\u65E0\u9010\u7B14\u8DEF\u5F84\uFF1B\u6392\u9664\u80DC\u8D1F\u7EDF\u8BA1" };
    if (hitStop || hitTarget || j === end) {
      const status = hitStop ? "sl" : hitTarget ? "tp" : "time";
      const rawExit = hitStop ? p.stop : hitTarget ? p.target : b.c;
      const exit = hitTarget ? rawExit : rawExit * (1 - dir * o.slipRate);
      const fee = (fill + exit) * o.feeRate / risk;
      const slipCost = (Math.abs(fill - rawFill) + Math.abs(exit - rawExit)) / risk;
      const netR = (exit - fill) * dir / risk - fee;
      return {
        planId: p.id,
        status,
        entryTs: next.ts,
        exitTs: b.ts + o.barMs,
        fill,
        exit,
        netR,
        costR: fee + slipCost,
        note: status === "tp" ? "\u76EE\u6807\u5148\u5230\uFF08\u9650\u4EF7\u6210\u4EA4\u5047\u8BBE\uFF09" : status === "sl" ? "\u6B62\u635F\u5148\u5230\uFF08\u542B\u4E0D\u5229\u6ED1\u70B9\uFF09" : "\u5230\u671F\u6536\u76D8\u9000\u51FA"
      };
    }
  }
  return { ...base, status: "open", entryTs: next.ts, fill, note: "\u6301\u4ED3\u5C1A\u672A\u7ED3\u675F" };
}
function fingerprint(value) {
  const text = JSON.stringify(value);
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}
function auditPriceAction(input, symbol, inputOptions = {}) {
  const options = normalizeOptions(inputOptions);
  const { candles, quality } = auditCandles(input, options);
  const bars = quality.usable ? assessBars(candles, options) : [];
  const plans = [], results = [];
  let causal = true;
  bars.forEach((a, i) => {
    const p = makePlan(candles[i], a, symbol, options);
    if (!p) return;
    plans.push(p);
    results.push(replayPlan(candles, i, p, options));
    const prefix = assessBars(candles.slice(0, i + 1), options).at(-1);
    const strip = (x) => {
      const { index: _i, ...rest } = x;
      void _i;
      return rest;
    };
    if (JSON.stringify(strip(prefix)) !== JSON.stringify(strip(a))) causal = false;
  });
  const resolved = results.filter((r) => r.netR !== null && (r.status === "tp" || r.status === "sl" || r.status === "time"));
  const wins = resolved.filter((r) => r.netR > 1e-9).length, losses = resolved.filter((r) => r.netR < -1e-9).length;
  let cum = 0, peak = 0, maxDD = 0;
  for (const r of resolved) {
    cum += r.netR;
    peak = Math.max(peak, cum);
    maxDD = Math.max(maxDD, peak - cum);
  }
  const summary = {
    setups: plans.length,
    triggered: results.filter((r) => r.entryTs !== null).length,
    resolved: resolved.length,
    ambiguous: results.filter((r) => r.status === "ambiguous").length,
    open: results.filter((r) => r.status === "open").length,
    expired: results.filter((r) => r.status === "expired").length,
    skipped: results.filter((r) => r.status.startsWith("skipped")).length,
    wins,
    losses,
    flat: resolved.length - wins - losses,
    winRate: resolved.length ? wins / resolved.length : null,
    avgR: resolved.length ? cum / resolved.length : null,
    totalR: cum,
    maxDrawdownR: maxDD
  };
  const canonicalOptions = { ...options, now: options.requireConfirmed ? 0 : options.now };
  return {
    rules: PRICE_ACTION_RULES,
    fingerprint: fingerprint({ candles, options: canonicalOptions, symbol }),
    options,
    quality,
    fromTs: candles[0]?.ts ?? null,
    toTs: candles.at(-1)?.ts ?? null,
    bars,
    plans,
    results,
    summary,
    latestPlan: plans.at(-1) ?? null,
    causalPrefixCheck: causal,
    limitations: [
      "\u72EC\u7ACB\u7814\u7A76\u56DE\u653E\uFF0C\u53EF\u4E0E\u65E7 M/W \u5F15\u64CE\u7ED3\u679C\u4E0D\u540C\uFF1B\u4E0D\u662F Brooks \u5168\u5957\u65B9\u6CD5\u7684\u8BA4\u8BC1\u5B9E\u73B0",
      "\u80CC\u666F/Doji \u9608\u503C\u4E3A\u516C\u5F00\u5DE5\u7A0B\u53C2\u6570\uFF0C\u4E0D\u662F\u80DC\u7387\uFF1B\u91CD\u53E0\u5019\u9009\u662F\u72EC\u7ACB\u5B9E\u9A8C\uFF0C\u4E0D\u662F\u53EF\u540C\u65F6\u6267\u884C\u7684\u8D26\u6237\u7EC4\u5408",
      "\u540C\u68D2\u6B62\u76C8\u6B62\u635F\u5148\u540E\u4E0D\u660E\u5219\u6392\u9664\uFF1B\u672A\u8BA1\u8D44\u91D1\u8D39\u7387\u3001\u771F\u5B9E\u6392\u961F\u3001\u90E8\u5206\u6210\u4EA4\u3001\u51B2\u51FB\u6210\u672C\u4E0E\u6760\u6746/\u5F3A\u5E73",
      "\u6837\u672C\u5185\u63CF\u8FF0\u7EDF\u8BA1\uFF0C\u4E0D\u662F\u6837\u672C\u5916\u9A8C\u8BC1\u6216\u672A\u6765\u6536\u76CA\u627F\u8BFA"
    ]
  };
}

// tests/price-action.test.ts
var B = 3e5;
var T0 = 17e11;
var opts = { barMs: B, tickSz: 0.1, feeRate: 5e-4, slipRate: 1e-4, maxHold: 4, minBars: 30, requireConfirmed: true, now: T0 + 1e3 * B };
var c = (i, o, h, l, cl, extra = {}) => ({ ts: T0 + i * B, o, h, l, c: cl, v: 1e3, confirm: 1, volumeSource: "quote", ...extra });
var rising = (n = 35) => Array.from({ length: n }, (_, i) => c(i, 100 + i * 0.5, 100.4 + i * 0.5, 99.8 + i * 0.5, 100.3 + i * 0.5));
{
  const row = [String(T0), "100", "102", "99", "101", "10", "1", "1015", "1"];
  const parsed = parseOkxCandle(row, "BTC-USDT-SWAP");
  assert.equal(parsed.v, 1015);
  assert.equal(parsed.volumeSource, "quote");
  assert.equal(parsed.confirm, 1);
  const estimate = parseOkxCandle([String(T0), "100", "102", "99", "101", "10", "1", "0", "1"], "BTC-USDT-SWAP");
  assert.equal(estimate.volumeSource, "base_close_estimate");
  assert.equal(preferCandle(parsed, { ...parsed, confirm: 0, v: 99999 }, parsed.v, 99999).confirm, 1);
  assert.equal(isClosedCandle({ ...parsed, confirm: 0 }, B, T0 + B + 99999), false);
  assert.equal(parseOkxCandle([String(T0), "0", "1", "0", "1", "1"], "BTC-USDT-SWAP"), null);
}
{
  const cs = rising(25), e = emaSeries(cs);
  assert.equal(e[18], null);
  assert.ok(e[19] !== null);
  assert.deepEqual(e.slice(0, 22), emaSeries(cs.slice(0, 22)));
}
{
  const cs = rising();
  const n = cs.length;
  const highs = [118, 116, 117, 114, 113, 115];
  highs.forEach((h, j) => cs.push(c(n + j, h - 0.5, h, h - 1.2, h - 0.2)));
  const a = assessBars(cs, opts);
  const attempts = a.flatMap((x) => x.attempt?.side === "long" ? [x.attempt.count] : []);
  assert.deepEqual(attempts.slice(-2), [1, 2]);
  assert.equal(a[n + 2].attempt?.count, 1);
  assert.equal(a[n + 5].attempt?.count, 2);
  const setup = a[n + 4];
  const p = makePlan(cs[n + 4], setup, "BTC-USDT-SWAP", opts);
  assert.ok(p);
  assert.equal(p.signalCloseTime, cs[n + 4].ts + B);
  assert.ok(p.entry > cs[n + 4].h);
}
{
  const cs = Array.from({ length: 35 }, (_, i) => c(i, 120 - i * 0.5, 120.4 - i * 0.5, 119.8 - i * 0.5, 119.9 - i * 0.5));
  const n = cs.length;
  [102, 104, 103, 106, 107, 105].forEach((l, j) => cs.push(c(n + j, l + 0.5, l + 1.2, l, l + 0.2)));
  const attempts = assessBars(cs, opts).flatMap((x) => x.attempt?.side === "short" ? [x.attempt.count] : []);
  assert.deepEqual(attempts.slice(-2), [1, 2]);
}
{
  const cs = rising(24).map((x) => ({ ...x, l: x.o + 2, h: x.h + 3 }));
  cs.push(c(24, 80, 81, 79, 80));
  const a = assessBars(cs, opts);
  assert.equal(a[24].emaGap, "below");
  assert.equal(a[24].firstEmaTouchAfter20, false);
  const above = Array.from({ length: 40 }, (_, i) => c(i, 100 + i, 101 + i, 99.8 + i, 100.5 + i));
  above.push(c(40, 140, 141, 130, 140.5));
  const b = assessBars(above, opts);
  assert.ok(b[39].untouchedEmaBars >= 20);
  assert.ok(b[40].firstEmaTouchAfter20);
  assert.equal(b[40].emaGap, null);
}
{
  const cs = rising(32);
  const p = { id: "x", side: "long", attempt: 2, signalTs: cs[31].ts, signalCloseTime: cs[31].ts + B, entry: 117, stop: 115, target: 121, expiresAfterTs: cs[31].ts + 2 * B, risk: 2, breakEvenWinRate: null, warnings: [] };
  const no = replayPlan([...cs, c(32, 116, 116.8, 115.5, 116)], 31, p, opts);
  assert.equal(no.status, "expired");
  assert.equal(no.fill, null);
  const gap = replayPlan([...cs, c(32, 114, 118, 113, 117)], 31, p, opts);
  assert.equal(gap.status, "skipped_gap");
  const amb = replayPlan([...cs, c(32, 116.5, 122, 114, 118)], 31, p, opts);
  assert.equal(amb.status, "ambiguous");
  assert.equal(amb.netR, null);
  const win = replayPlan([...cs, c(32, 116.5, 118, 116, 117), c(33, 117, 121.5, 116.8, 120)], 31, p, opts);
  assert.equal(win.status, "tp");
  assert.ok(win.netR > 1.8 && win.netR < 2);
  assert.ok(win.costR > 0);
  const gross = (win.exit - win.fill) / (win.fill - p.stop);
  const fees = (win.fill + win.exit) * opts.feeRate / (win.fill - p.stop);
  assert.ok(Math.abs(gross - fees - win.netR) < 1e-10);
}
{
  const cs = rising(90);
  cs[40] = c(42, 100, 101, 99, 100);
  cs.push(c(90, 100, 101, 99, 100, { confirm: 0 }));
  const r = auditPriceAction(cs, "BTC-USDT-SWAP", opts);
  assert.equal(r.quality.forming, 1);
  assert.ok(r.quality.missingBars > 0);
  assert.ok(r.quality.excludedBeforeGap > 0);
  assert.ok(r.quality.usable);
  assert.ok(r.causalPrefixCheck);
  assert.equal(r.bars.length, r.quality.accepted);
  const bad = auditPriceAction([c(0, 100, 101, 99, 100), c(0, 100, 102, 99, 101)], "BTC-USDT-SWAP", opts);
  assert.equal(bad.quality.duplicates, 1);
  assert.equal(bad.quality.usable, false);
  const est = auditPriceAction(rising(65).map((x) => ({ ...x, volumeSource: "base_close_estimate" })), "BTC-USDT-SWAP", opts);
  assert.equal(est.quality.estimatedVolume, 65);
  assert.ok(est.quality.issues.some((x) => x.includes("\u4F30\u7B97")));
}
{
  const cs = rising(90);
  const full = auditPriceAction(cs, "BTC-USDT-SWAP", opts);
  for (const p of full.plans) {
    const i = full.bars.findIndex((x) => x.ts === p.signalTs);
    const prefix = auditPriceAction(cs.slice(0, i + 1), "BTC-USDT-SWAP", opts);
    assert.deepEqual(prefix.latestPlan, p);
  }
  assert.throws(() => normalizeOptions({ tickSz: 0 }));
}
console.log("price-action: data provenance, H/L counts, EMA gaps, stop replay, costs, ambiguity and causality passed");
