// tests/trading-sessions.test.ts
import assert from "node:assert/strict";

// src/lib/lru.ts
function setBounded(map, key, value, max) {
  map.delete(key);
  map.set(key, value);
  while (map.size > max) {
    const oldest = map.keys().next().value;
    if (oldest === void 0) break;
    map.delete(oldest);
  }
}

// src/vela/sessions/sessionClock.ts
var formatters = /* @__PURE__ */ new Map();
function formatter(zone) {
  let f = formatters.get(zone);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", { timeZone: zone, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
    setBounded(formatters, zone, f, 8);
  }
  return f;
}
var parts = (zone, ms) => {
  const o = {};
  for (const p of formatter(zone).formatToParts(new Date(ms))) if (p.type !== "literal") o[p.type] = Number(p.value);
  return o;
};
function zoneOffsetMs(zone, ms) {
  const p = parts(zone, ms);
  return Date.UTC(p.year, p.month - 1, p.day, p.hour % 24, p.minute, p.second) - Math.floor(ms / 1e3) * 1e3;
}
var wallCache = /* @__PURE__ */ new Map();
function localWallToUtc(zone, dayMs, minutes) {
  const key = `${zone}|${dayMs}|${minutes}`;
  const hit = wallCache.get(key);
  if (hit !== void 0) return hit;
  const d = new Date(dayMs);
  const guess = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) + minutes * 6e4;
  let utc = guess - zoneOffsetMs(zone, guess);
  utc = guess - zoneOffsetMs(zone, utc);
  setBounded(wallCache, key, utc, 2048);
  return utc;
}
var hhmm = (ms) => new Date(ms).toISOString().slice(11, 16);
var windowsCache = /* @__PURE__ */ new Map();
function macroWindows(dayMs, mode) {
  const key = `${mode}|${dayMs}`;
  const hit = windowsCache.get(key);
  if (hit) return hit;
  const mk = (id, zone, startMin, endMin, localLabel) => {
    const startMs = mode === "local" && zone ? localWallToUtc(zone, dayMs, startMin) : dayMs + startMin * 6e4;
    const endMs = mode === "local" && zone ? localWallToUtc(zone, dayMs, endMin) : dayMs + endMin * 6e4;
    return Object.freeze({ id, startMs, endMs, label: `${hhmm(startMs)}\u2013${hhmm(endMs)} UTC`, localLabel });
  };
  const windows = Object.freeze(mode === "fixed" ? [
    mk("asia", null, 0, 480, "00:00\u201308:00 UTC \u5408\u6210\u4E9A\u592A\u4EA4\u6613\u65F6\u6BB5"),
    mk("london", null, 480, 960, "\u56FA\u5B9A UTC \u9884\u8BBE"),
    mk("ny", null, 780, 1260, "\u56FA\u5B9A UTC \u9884\u8BBE")
  ] : [
    mk("asia", null, 0, 480, "00:00\u201308:00 UTC \u5408\u6210\u4E9A\u592A\u4EA4\u6613\u65F6\u6BB5"),
    mk("london", "Europe/London", 480, 990, "\u4F26\u6566 08:00\u201316:30"),
    mk("ny", "America/New_York", 480, 1020, "\u7EBD\u7EA6 08:00\u201317:00")
  ]);
  setBounded(windowsCache, key, windows, 800);
  return windows;
}
function overlapWindow(windows) {
  const l = windows.find((w) => w.id === "london"), n = windows.find((w) => w.id === "ny");
  if (!l || !n) return null;
  const startMs = Math.max(l.startMs, n.startMs), endMs = Math.min(l.endMs, n.endMs);
  return endMs > startMs ? { id: "overlap", startMs, endMs, label: `${hhmm(startMs)}\u2013${hhmm(endMs)} UTC`, localLabel: "\u4F26\u6566/\u7EBD\u7EA6\u5B9E\u9645\u4EA4\u96C6" } : null;
}

// src/vela/sessions/sessionMath.ts
var DAY_MS = 864e5;
var MIN_MS = 6e4;
var SESSION_STYLES = {
  asia: {
    id: "asia",
    name: "\u4E9A\u592A\u4EA4\u6613\u65F6\u6BB5",
    shortLabel: "\u4E9A\u592A\u4EA4\u6613\u65F6\u6BB5",
    utcWindow: "00:00\u201308:00 UTC",
    cnWindow: "\u5317\u4EAC 08:00\u201316:00",
    description: "\u4E1C\u4EAC/\u9999\u6E2F/\u65B0\u52A0\u5761\u4E3B\u529B\u65F6\u6BB5\uFF0C\u901A\u5E38\u5448\u533A\u95F4\u9707\u8361\u84C4\u79EF\uFF0C\u6784\u5EFA\u65F6\u6BB5\u9AD8\u70B9\u4E0E\u65F6\u6BB5\u4F4E\u70B9\u53C2\u7167\u3002",
    hex: "#8b5cf6",
    bandFill: "rgba(139, 92, 246, 0.055)",
    bandTopBorder: "rgba(167, 139, 250, 0.48)",
    dividerStroke: "rgba(167, 139, 250, 0.24)",
    badgeBg: "rgba(24, 19, 42, 0.88)",
    badgeBorder: "rgba(139, 92, 246, 0.45)",
    badgeText: "#c4b5fd"
  },
  london: {
    id: "london",
    name: "\u4F26\u6566\u4EA4\u6613\u65F6\u6BB5",
    shortLabel: "\u4F26\u6566\u4EA4\u6613\u65F6\u6BB5",
    utcWindow: "08:00\u201316:00 UTC",
    cnWindow: "\u5317\u4EAC 16:00\u201324:00",
    description: "\u6B27\u6D32\u65F6\u6BB5\u89C2\u5BDF\u7A97\u53E3\uFF1B\u8D8A\u4F4D/\u6536\u56DE\u53EA\u63CF\u8FF0\u4EF7\u683C\u4E8B\u5B9E\uFF0C\u4E0D\u8BC1\u660E\u673A\u6784\u610F\u56FE\u6216\u6B62\u635F\u89E6\u53D1\u3002",
    hex: "#0ea5e9",
    bandFill: "rgba(14, 165, 233, 0.06)",
    bandTopBorder: "rgba(56, 189, 248, 0.52)",
    dividerStroke: "rgba(56, 189, 248, 0.26)",
    badgeBg: "rgba(12, 28, 44, 0.88)",
    badgeBorder: "rgba(14, 165, 233, 0.48)",
    badgeText: "#7dd3fc"
  },
  ny: {
    id: "ny",
    name: "\u7EBD\u7EA6\u4EA4\u6613\u65F6\u6BB5",
    shortLabel: "\u7EBD\u7EA6\u4EA4\u6613\u65F6\u6BB5",
    utcWindow: "13:00\u201321:00 UTC",
    cnWindow: "\u5317\u4EAC 21:00\u201305:00",
    description: "\u7F8E\u80A1\u4E0E\u5B8F\u89C2\u6570\u636E\u76F8\u5173\u89C2\u5BDF\u7A97\u53E3\uFF1B\u91CF\u80FD\u5CF0\u503C\u9700\u6309\u5F53\u65E5\u771F\u5B9E\u6570\u636E\u9A8C\u8BC1\u3002",
    hex: "#f59e0b",
    bandFill: "rgba(245, 158, 11, 0.06)",
    bandTopBorder: "rgba(251, 191, 36, 0.55)",
    dividerStroke: "rgba(251, 191, 36, 0.28)",
    badgeBg: "rgba(38, 25, 10, 0.88)",
    badgeBorder: "rgba(245, 158, 11, 0.48)",
    badgeText: "#fcd34d"
  },
  overlap: {
    id: "overlap",
    name: "\u4F26\u6566\u4E0E\u7EBD\u7EA6\u91CD\u53E0\u65F6\u6BB5",
    shortLabel: "\u4F26\u6566\u4E0E\u7EBD\u7EA6\u91CD\u53E0\u65F6\u6BB5",
    utcWindow: "13:00\u201316:00 UTC",
    cnWindow: "\u5317\u4EAC 21:00\u201324:00",
    description: "\u4F26\u6566\u4E0E\u7EBD\u7EA6\u7A97\u53E3\u4EA4\u96C6\uFF1B\u6DF1\u5EA6\u4E0E\u6210\u4EA4\u5CF0\u503C\u662F\u5F85\u9A8C\u8BC1\u5047\u8BBE\uFF0C\u4E0D\u662F\u65B9\u5411\u4FE1\u53F7\u3002",
    hex: "#10b981",
    bandFill: "rgba(16, 185, 129, 0.065)",
    bandTopBorder: "rgba(52, 211, 153, 0.65)",
    dividerStroke: "rgba(52, 211, 153, 0.32)",
    badgeBg: "rgba(11, 35, 29, 0.90)",
    badgeBorder: "rgba(16, 185, 129, 0.52)",
    badgeText: "#6ee7b7"
  },
  london_close: {
    id: "london_close",
    name: "\u4F26\u6566\u6536\u76D8\u89C2\u5BDF\u65F6\u6BB5",
    shortLabel: "\u4F26\u6566\u6536\u76D8\u89C2\u5BDF\u65F6\u6BB5",
    utcWindow: "15:00\u201317:00 UTC",
    cnWindow: "\u5317\u4EAC 23:00\u201301:00",
    description: "\u6B27\u76D8\u5934\u5BF8\u5E73\u4ED3\u7ED3\u7B97\u4E0E 16:00 UTC \u8D44\u91D1\u8D39\u7387\u8282\u70B9\uFF0C\u5E38\u89C1\u65E5\u5185\u8D8B\u52BF\u51CF\u901F\u6216\u56DE\u64A4\u518D\u5E73\u8861\u3002",
    hex: "#10b981",
    bandFill: "rgba(16, 185, 129, 0.055)",
    bandTopBorder: "rgba(52, 211, 153, 0.52)",
    dividerStroke: "rgba(52, 211, 153, 0.26)",
    badgeBg: "rgba(11, 35, 29, 0.88)",
    badgeBorder: "rgba(16, 185, 129, 0.45)",
    badgeText: "#6ee7b7"
  }
};
var MACRO_SESSIONS = [
  {
    ...SESSION_STYLES.asia,
    startMin: 0,
    endMin: 8 * 60
    // 00:00 - 08:00 UTC
  },
  {
    ...SESSION_STYLES.london,
    startMin: 8 * 60,
    endMin: 16 * 60
    // 08:00 - 16:00 UTC
  },
  {
    ...SESSION_STYLES.ny,
    startMin: 13 * 60,
    endMin: 21 * 60
    // 13:00 - 21:00 UTC
  },
  {
    ...SESSION_STYLES.overlap,
    startMin: 13 * 60,
    endMin: 16 * 60,
    // 13:00 - 16:00 UTC 欧美重叠
    isOverlay: true
  }
];
var KILLZONE_SESSIONS = [
  {
    ...SESSION_STYLES.asia,
    name: "\u4E9A\u592A\u4EA4\u6613\u89C2\u5BDF\u533A\u95F4",
    shortLabel: "\u4E9A\u592A\u4EA4\u6613\u89C2\u5BDF\u533A\u95F4",
    utcWindow: "00:00\u201308:00 UTC",
    cnWindow: "\u5317\u4EAC 08:00\u201316:00",
    description: "00:00\u201308:00 UTC \u5408\u6210\u4E9A\u592A\u4EA4\u6613\u533A\u95F4\uFF0C\u63D0\u4F9B\u65F6\u6BB5\u9AD8\u70B9\u4E0E\u65F6\u6BB5\u4F4E\u70B9\u53C2\u7167\u3002",
    startMin: 0,
    endMin: 8 * 60
    // 00:00 - 08:00 UTC
  },
  {
    ...SESSION_STYLES.london,
    name: "\u4F26\u6566\u5F00\u76D8\u89C2\u5BDF\u7A97\u53E3",
    shortLabel: "\u4F26\u6566\u5F00\u76D8\u89C2\u5BDF\u7A97\u53E3",
    utcWindow: "07:00\u201310:00 UTC",
    cnWindow: "\u5317\u4EAC 15:00\u201318:00",
    description: "\u56FA\u5B9A UTC \u6559\u5B66\u7A97\u53E3\uFF1B\u4E0D\u7B49\u540C\u5168\u5E74\u4F26\u6566\u672C\u5730\u5F00\u76D8\u65F6\u95F4\u3002",
    startMin: 7 * 60,
    endMin: 10 * 60
    // 07:00 - 10:00 UTC
  },
  {
    ...SESSION_STYLES.ny,
    name: "\u7EBD\u7EA6\u5F00\u76D8\u89C2\u5BDF\u7A97\u53E3",
    shortLabel: "\u7EBD\u7EA6\u5F00\u76D8\u89C2\u5BDF\u7A97\u53E3",
    utcWindow: "12:30\u201315:30 UTC",
    cnWindow: "\u5317\u4EAC 20:30\u201323:30",
    description: "\u7F8E\u56FD\u5B8F\u89C2\u6570\u636E\uFF0812:30/13:30\uFF09\u4E0E\u7F8E\u80A1\u5F00\u76D8\uFF0813:30/14:30\uFF09\u7A97\u53E3\uFF0C\u4E8C\u7EA7\u7A81\u7834\u4E0E\u6DF1\u5EA6\u56DE\u8E29\u9AD8\u53D1\u671F\u3002",
    startMin: 12 * 60 + 30,
    endMin: 15 * 60 + 30
    // 12:30 - 15:30 UTC
  },
  {
    ...SESSION_STYLES.london_close,
    startMin: 15 * 60,
    endMin: 17 * 60,
    // 15:00 - 17:00 UTC
    isOverlay: true
  }
];
function formatUtcMonthDay(ms) {
  const d = new Date(ms);
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${m}-${day}`;
}
function formatMinToHHMM(totalMin) {
  const h = Math.floor(totalMin / 60) % 24;
  const m = totalMin % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}
function utcDayFloor(ms) {
  return Math.floor(ms / DAY_MS) * DAY_MS;
}
function isIntradayTimeframe(bars) {
  if (bars.length < 2) return true;
  let minStep = Infinity;
  const sampleCount = Math.min(bars.length - 1, 25);
  for (let i = bars.length - sampleCount; i < bars.length; i++) {
    const dt = bars[i].time - bars[i - 1].time;
    if (dt > 0 && dt < minStep) minStep = dt;
  }
  if (!Number.isFinite(minStep)) return true;
  return minStep < 12 * 36e5;
}
function computeSessionSpans(minTimeMs, maxTimeMs, options) {
  if (!Number.isFinite(minTimeMs) || !Number.isFinite(maxTimeMs) || maxTimeMs < minTimeMs) {
    return [];
  }
  const defs = options.mode === "killzone" ? KILLZONE_SESSIONS : MACRO_SESSIONS;
  const firstDay = utcDayFloor(minTimeMs);
  const lastDay = utcDayFloor(maxTimeMs);
  const maxDays = 60;
  const startDay = Math.max(firstDay, lastDay - maxDays * DAY_MS);
  const spans = [];
  const clockMode = options.clockMode ?? "fixed";
  for (let dayMs = startDay; dayMs <= lastDay; dayMs += DAY_MS) {
    const windows = options.mode === "macro" ? macroWindows(dayMs, clockMode) : null;
    const ov = windows ? overlapWindow(windows) : null;
    for (const def of defs) {
      if (def.id === "asia" && !options.enabledSessions.asia) continue;
      if (def.id === "london" && !options.enabledSessions.london) continue;
      if (def.id === "ny" && !options.enabledSessions.ny) continue;
      if ((def.id === "overlap" || def.id === "london_close") && !options.showOverlap) continue;
      if (def.id === "overlap" && (!options.enabledSessions.london || !options.enabledSessions.ny)) continue;
      const w = windows ? def.id === "overlap" ? ov : windows.find((x) => x.id === def.id) : null;
      const startMs = w ? w.startMs : dayMs + def.startMin * MIN_MS;
      const endMs = w ? w.endMs : dayMs + def.endMin * MIN_MS;
      if (endMs < minTimeMs || startMs > maxTimeMs) continue;
      spans.push({
        key: `${options.mode}:${options.clockMode ?? "fixed"}:${def.id}:${dayMs}`,
        id: def.id,
        name: def.name,
        shortLabel: def.shortLabel,
        badgeLabel: `${def.name} ${w ? w.label.replace(/\s*UTC$/, "") : formatMinToHHMM(def.startMin) + "\u2013" + formatMinToHHMM(def.endMin)}`,
        utcWindow: w ? w.label : def.utcWindow,
        dayStartMs: dayMs,
        startMs,
        endMs,
        isOverlay: Boolean(def.isOverlay),
        style: def
      });
    }
  }
  return spans;
}
function computeDailyDividers(bars, minTimeMs, maxTimeMs) {
  if (!bars.length || maxTimeMs < minTimeMs) return [];
  const firstDay = utcDayFloor(minTimeMs);
  const lastDay = utcDayFloor(maxTimeMs);
  const startDay = Math.max(firstDay, lastDay - 60 * DAY_MS);
  const dividers = [];
  let barIdx = 0;
  for (let dayMs = startDay; dayMs <= lastDay; dayMs += DAY_MS) {
    if (dayMs < minTimeMs || dayMs > maxTimeMs) continue;
    while (barIdx < bars.length && bars[barIdx].time < dayMs) {
      barIdx++;
    }
    const openBar = barIdx < bars.length && bars[barIdx].time < dayMs + DAY_MS ? bars[barIdx] : null;
    dividers.push({
      dayStartMs: dayMs,
      dateLabel: `${formatUtcMonthDay(dayMs)} 00:00`,
      openPrice: openBar ? openBar.open : null
    });
  }
  return dividers;
}
function computeAsiaRangeLevels(bars, minTimeMs, maxTimeMs) {
  if (!bars.length || maxTimeMs < minTimeMs) return [];
  const firstDay = utcDayFloor(minTimeMs);
  const lastDay = utcDayFloor(maxTimeMs);
  const startDay = Math.max(firstDay, lastDay - 30 * DAY_MS);
  const lastBarTime = bars[bars.length - 1].time;
  const dayMap = /* @__PURE__ */ new Map();
  for (let i = 0; i < bars.length; i++) {
    const b = bars[i];
    if (b.time < startDay || b.time > lastDay + DAY_MS) continue;
    const d = utcDayFloor(b.time);
    let list = dayMap.get(d);
    if (!list) {
      list = [];
      dayMap.set(d, list);
    }
    list.push(b);
  }
  const summaries = [];
  for (const [dayStartMs, dayBars] of dayMap.entries()) {
    const asiaStartMs = dayStartMs;
    const asiaEndMs = dayStartMs + 8 * 36e5;
    const dayEndMs = dayStartMs + DAY_MS;
    let high = -Infinity;
    let highBarMs = asiaStartMs;
    let low = Infinity;
    let lowBarMs = asiaStartMs;
    let barCount = 0;
    const postAsiaBars = [];
    for (const b of dayBars) {
      if (b.time >= asiaStartMs && b.time < asiaEndMs) {
        barCount++;
        if (b.high > high) {
          high = b.high;
          highBarMs = b.time;
        }
        if (b.low < low) {
          low = b.low;
          lowBarMs = b.time;
        }
      } else if (b.time >= asiaEndMs && b.time < dayEndMs) {
        postAsiaBars.push(b);
      }
    }
    if (barCount < 2 || !Number.isFinite(high) || !Number.isFinite(low) || high <= 0 || low <= 0) {
      continue;
    }
    const defaultEndMs = Math.min(dayEndMs, Math.max(asiaEndMs, lastBarTime));
    let highLineEndMs = defaultEndMs;
    let highState = "untouched";
    let highTouchMs = null;
    let lowLineEndMs = defaultEndMs;
    let lowState = "untouched";
    let lowTouchMs = null;
    for (const b of postAsiaBars) {
      if (highState === "untouched" && b.high > high) {
        highTouchMs = b.time;
        highLineEndMs = b.time;
        highState = b.close <= high ? "swept_reject" : "broken";
      }
      if (lowState === "untouched" && b.low < low) {
        lowTouchMs = b.time;
        lowLineEndMs = b.time;
        lowState = b.close >= low ? "swept_reject" : "broken";
      }
      if (highState !== "untouched" && lowState !== "untouched") break;
    }
    const rangePct = (high - low) / low * 100;
    summaries.push({
      dayStartMs,
      dateLabel: formatUtcMonthDay(dayStartMs),
      asiaStartMs,
      asiaEndMs,
      dayEndMs,
      high,
      highBarMs,
      low,
      lowBarMs,
      rangePct,
      barCount,
      highLineEndMs,
      highState,
      highTouchMs,
      lowLineEndMs,
      lowState,
      lowTouchMs
    });
  }
  return summaries;
}
function getActiveSessionClock(nowMs = Date.now(), mode = "macro", clockMode = "fixed") {
  const d = new Date(nowMs);
  const h = d.getUTCHours();
  const m = d.getUTCMinutes();
  const utcMinutes = h * 60 + m;
  const utcHHMM = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")} UTC`;
  const dayProgressPct = Math.min(100, Math.max(0, utcMinutes / 1440 * 100));
  const defs = mode === "killzone" ? KILLZONE_SESSIONS : MACRO_SESSIONS;
  const day = utcDayFloor(nowMs);
  const windows = mode === "macro" ? macroWindows(day, clockMode) : defs.filter((d2) => !d2.isOverlay).map((d2) => ({ id: d2.id, startMs: day + d2.startMin * MIN_MS, endMs: day + d2.endMin * MIN_MS, label: d2.utcWindow, localLabel: "\u56FA\u5B9A UTC \u6559\u5B66\u7A97\u53E3" }));
  const overlap = mode === "macro" ? overlapWindow(windows) : null;
  const all = overlap ? [...windows, overlap] : windows;
  const activeSessions = defs.filter((def) => all.some((w) => w.id === def.id && nowMs >= w.startMs && nowMs < w.endMs));
  let bestDef = defs[0];
  let bestWait = Infinity;
  for (const offset of [-DAY_MS, 0, DAY_MS]) {
    const ws = mode === "macro" ? macroWindows(day + offset, clockMode) : defs.filter((d2) => !d2.isOverlay).map((d2) => ({ id: d2.id, startMs: day + offset + d2.startMin * MIN_MS }));
    for (const w of ws) {
      const wait = (w.startMs - nowMs) / MIN_MS;
      if (wait > 0 && wait < bestWait) {
        bestWait = wait;
        bestDef = defs.find((d2) => d2.id === w.id) ?? defs[0];
      }
    }
  }
  return { utcHHMM, utcMinutes, dayProgressPct, activeSessions, nextSession: { def: bestDef, inMinutes: bestWait }, windows, overlap };
}

// src/vela/sessions/sessionStore.ts
var SESSION_STORAGE_KEY = "pulsedesk.sessions.v1";
var DEFAULT_SESSION_PREFERENCES = {
  enabled: true,
  mode: "macro",
  clockMode: "fixed",
  showBands: true,
  bandOpacity: 65,
  showBadges: true,
  showAsiaRange: true,
  showDailyOpen: true,
  showOverlap: true,
  enabledSessions: {
    asia: true,
    london: true,
    ny: true
  }
};
var DEFAULT_SUMMARY = {
  intraday: true,
  latestAsia: null,
  visibleSpans: 0
};
function normalizeSessionPreferences(raw) {
  const obj = raw && typeof raw === "object" ? raw : {};
  const bool = (val, fallback) => typeof val === "boolean" ? val : fallback;
  const mode = obj.mode === "killzone" ? "killzone" : "macro";
  const rawSessions = obj.enabledSessions && typeof obj.enabledSessions === "object" ? obj.enabledSessions : void 0;
  return {
    enabled: bool(obj.enabled, DEFAULT_SESSION_PREFERENCES.enabled),
    mode,
    clockMode: obj.clockMode === "local" ? "local" : "fixed",
    showBands: bool(obj.showBands, DEFAULT_SESSION_PREFERENCES.showBands),
    bandOpacity: typeof obj.bandOpacity === "number" && Number.isFinite(obj.bandOpacity) ? Math.round(Math.min(100, Math.max(0, obj.bandOpacity))) : DEFAULT_SESSION_PREFERENCES.bandOpacity,
    showBadges: bool(obj.showBadges, DEFAULT_SESSION_PREFERENCES.showBadges),
    showAsiaRange: bool(obj.showAsiaRange, DEFAULT_SESSION_PREFERENCES.showAsiaRange),
    showDailyOpen: bool(obj.showDailyOpen, DEFAULT_SESSION_PREFERENCES.showDailyOpen),
    showOverlap: bool(obj.showOverlap, DEFAULT_SESSION_PREFERENCES.showOverlap),
    enabledSessions: {
      asia: bool(rawSessions?.asia, DEFAULT_SESSION_PREFERENCES.enabledSessions.asia),
      london: bool(rawSessions?.london, DEFAULT_SESSION_PREFERENCES.enabledSessions.london),
      ny: bool(rawSessions?.ny, DEFAULT_SESSION_PREFERENCES.enabledSessions.ny)
    }
  };
}
function createSessionStore(storage) {
  let saved = null;
  try {
    const text = storage?.getItem(SESSION_STORAGE_KEY);
    if (text) saved = JSON.parse(text);
  } catch {
  }
  let snapshot = {
    preferences: normalizeSessionPreferences(saved),
    summary: { ...DEFAULT_SUMMARY }
  };
  const listeners = /* @__PURE__ */ new Set();
  const publish = () => listeners.forEach((fn) => fn());
  const persist = () => {
    try {
      storage?.setItem(SESSION_STORAGE_KEY, JSON.stringify({ ...snapshot.preferences, version: 1 }));
    } catch {
    }
  };
  return {
    getSnapshot: () => snapshot,
    subscribe(fn) {
      listeners.add(fn);
      return () => {
        listeners.delete(fn);
      };
    },
    patch(partial) {
      snapshot = {
        ...snapshot,
        preferences: normalizeSessionPreferences({
          ...snapshot.preferences,
          ...partial,
          enabledSessions: partial.enabledSessions ? { ...snapshot.preferences.enabledSessions, ...partial.enabledSessions } : snapshot.preferences.enabledSessions
        })
      };
      persist();
      publish();
    },
    toggleSession(key) {
      const next = !snapshot.preferences.enabledSessions[key];
      snapshot = {
        ...snapshot,
        preferences: {
          ...snapshot.preferences,
          enabledSessions: {
            ...snapshot.preferences.enabledSessions,
            [key]: next
          }
        }
      };
      persist();
      publish();
    },
    reset() {
      snapshot = {
        ...snapshot,
        preferences: {
          ...DEFAULT_SESSION_PREFERENCES,
          enabledSessions: { ...DEFAULT_SESSION_PREFERENCES.enabledSessions }
        }
      };
      persist();
      publish();
    },
    updateSummary(next) {
      const prev = snapshot.summary;
      const sameAsia = prev.latestAsia?.dayStartMs === next.latestAsia?.dayStartMs && prev.latestAsia?.high === next.latestAsia?.high && prev.latestAsia?.low === next.latestAsia?.low && prev.latestAsia?.highState === next.latestAsia?.highState && prev.latestAsia?.lowState === next.latestAsia?.lowState;
      if (prev.intraday === next.intraday && prev.visibleSpans === next.visibleSpans && sameAsia) {
        return;
      }
      snapshot = { ...snapshot, summary: next };
      publish();
    }
  };
}

// tests/trading-sessions.test.ts
var BASE_DAY = Date.UTC(2026, 10, 7, 0, 0, 0);
{
  const spans = computeSessionSpans(BASE_DAY, BASE_DAY + DAY_MS - 1, {
    mode: "macro",
    enabledSessions: { asia: true, london: true, ny: true },
    showOverlap: true
  });
  const ids = spans.filter((s) => s.dayStartMs === BASE_DAY).map((s) => s.id);
  assert.deepEqual(ids, ["asia", "london", "ny", "overlap"]);
  const asia = spans.find((s) => s.dayStartMs === BASE_DAY && s.id === "asia");
  assert.equal(asia.startMs, BASE_DAY);
  assert.equal(asia.endMs, BASE_DAY + 8 * 36e5);
  assert.equal(asia.badgeLabel, "\u4E9A\u592A\u4EA4\u6613\u65F6\u6BB5 00:00\u201308:00");
  const london = spans.find((s) => s.dayStartMs === BASE_DAY && s.id === "london");
  assert.equal(london.startMs, BASE_DAY + 8 * 36e5);
  assert.equal(london.endMs, BASE_DAY + 16 * 36e5);
  assert.equal(london.badgeLabel, "\u4F26\u6566\u4EA4\u6613\u65F6\u6BB5 08:00\u201316:00");
  const ny = spans.find((s) => s.dayStartMs === BASE_DAY && s.id === "ny");
  assert.equal(ny.startMs, BASE_DAY + 13 * 36e5);
  assert.equal(ny.endMs, BASE_DAY + 21 * 36e5);
  assert.equal(ny.badgeLabel, "\u7EBD\u7EA6\u4EA4\u6613\u65F6\u6BB5 13:00\u201321:00");
  const overlap = spans.find((s) => s.dayStartMs === BASE_DAY && s.id === "overlap");
  assert.equal(overlap.startMs, BASE_DAY + 13 * 36e5);
  assert.equal(overlap.endMs, BASE_DAY + 16 * 36e5);
  assert.equal(overlap.isOverlay, true);
}
{
  const spans = computeSessionSpans(BASE_DAY, BASE_DAY + DAY_MS - 1, {
    mode: "killzone",
    enabledSessions: { asia: true, london: true, ny: true },
    showOverlap: true
  }).filter((s) => s.dayStartMs === BASE_DAY);
  assert.deepEqual(
    spans.map((s) => [s.id, (s.startMs - BASE_DAY) / MIN_MS, (s.endMs - BASE_DAY) / MIN_MS]),
    [
      ["asia", 0, 480],
      // 00:00 - 08:00 UTC
      ["london", 420, 600],
      // 07:00 - 10:00 UTC
      ["ny", 750, 930],
      // 12:30 - 15:30 UTC
      ["london_close", 900, 1020]
      // 15:00 - 17:00 UTC
    ]
  );
}
{
  const bars = [
    // 亚盘 00:00 - 08:00 UTC：高点 92000，低点 90000
    { time: BASE_DAY + 1 * 36e5, open: 90500, high: 91200, low: 9e4, close: 91e3 },
    { time: BASE_DAY + 3 * 36e5, open: 91e3, high: 92e3, low: 90800, close: 91500 },
    { time: BASE_DAY + 6 * 36e5, open: 91500, high: 91800, low: 90400, close: 91100 },
    // 伦盘 09:00 UTC：向上刺破 AH (92000) 到 92150 后收盘回到 91850（扫高收回 / 诱多候选）
    { time: BASE_DAY + 9 * 36e5, open: 91600, high: 92150, low: 91500, close: 91850 },
    // 美盘 14:00 UTC：向下实体跌破 AL (90000)，收盘在 89600（实体破低）
    { time: BASE_DAY + 14 * 36e5, open: 90200, high: 90300, low: 89500, close: 89600 }
  ];
  const summaries = computeAsiaRangeLevels(bars, BASE_DAY, BASE_DAY + DAY_MS);
  assert.equal(summaries.length, 1);
  const ar = summaries[0];
  assert.equal(ar.high, 92e3);
  assert.equal(ar.low, 9e4);
  assert.equal(ar.highState, "swept_reject");
  assert.equal(ar.highTouchMs, BASE_DAY + 9 * 36e5);
  assert.equal(ar.lowState, "broken");
  assert.equal(ar.lowTouchMs, BASE_DAY + 14 * 36e5);
}
{
  const bars5m = [
    { time: BASE_DAY - 3e5, open: 9e4, high: 90100, low: 89900, close: 90050 },
    { time: BASE_DAY, open: 90050, high: 90200, low: 9e4, close: 90150 },
    { time: BASE_DAY + 3e5, open: 90150, high: 90300, low: 90100, close: 90250 }
  ];
  assert.equal(isIntradayTimeframe(bars5m), true);
  const divs = computeDailyDividers(bars5m, BASE_DAY - 6e5, BASE_DAY + 6e5);
  assert.equal(divs.length, 1);
  assert.equal(divs[0].dayStartMs, BASE_DAY);
  assert.equal(divs[0].dateLabel, "11-07 00:00");
  assert.equal(divs[0].openPrice, 90050);
  const bars1D = [
    { time: BASE_DAY - DAY_MS, open: 89e3, high: 91e3, low: 88e3, close: 9e4 },
    { time: BASE_DAY, open: 9e4, high: 92e3, low: 89500, close: 91500 },
    { time: BASE_DAY + DAY_MS, open: 91500, high: 93e3, low: 91e3, close: 92500 }
  ];
  assert.equal(isIntradayTimeframe(bars1D), false);
}
{
  const clock = getActiveSessionClock(BASE_DAY + (14 * 60 + 15) * MIN_MS, "macro");
  assert.equal(clock.utcHHMM, "14:15 UTC");
  assert.deepEqual(
    clock.activeSessions.map((s) => s.id),
    ["london", "ny", "overlap"]
  );
}
{
  const mem = /* @__PURE__ */ new Map();
  const storage = {
    getItem: (k) => mem.get(k) ?? null,
    setItem: (k, v) => void mem.set(k, v)
  };
  const store = createSessionStore(storage);
  assert.deepEqual(store.getSnapshot().preferences, DEFAULT_SESSION_PREFERENCES);
  store.patch({ mode: "killzone", showBadges: false });
  store.toggleSession("asia");
  assert.equal(store.getSnapshot().preferences.mode, "killzone");
  assert.equal(store.getSnapshot().preferences.showBadges, false);
  assert.equal(store.getSnapshot().preferences.enabledSessions.asia, false);
  assert.ok(mem.has(SESSION_STORAGE_KEY));
  const restored = createSessionStore(storage);
  assert.equal(restored.getSnapshot().preferences.mode, "killzone");
  assert.equal(restored.getSnapshot().preferences.showBadges, false);
  assert.equal(restored.getSnapshot().preferences.enabledSessions.asia, false);
  assert.deepEqual(normalizeSessionPreferences("invalid-json"), DEFAULT_SESSION_PREFERENCES);
}
console.log("PASS trading-sessions.test.ts");
