import { chromium } from 'playwright';
const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on('pageerror', e => errors.push(String(e)));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
await page.addInitScript(() => {
  localStorage.setItem('pulsedesk.signal-annotations.v2', JSON.stringify({ enabled: true, version: 2 }));
  localStorage.setItem('pulsedesk.sessions.v1', JSON.stringify({ enabled: true, mode: 'macro', clockMode: 'fixed', showBands: true, bandOpacity: 65, version: 1 }));
});
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(13000);
if (await page.getByRole('region', { name: '信号标注设置' }).count() === 0) {
  await page.getByRole('button', { name: '信号标注', exact: true }).click();
}
await page.waitForSelector('[data-testid="session-panel"]');
// 切到本地夏令时
const t0 = Date.now();
await page.getByRole('button', { name: '本地夏令时' }).click();
await page.waitForTimeout(300);
const switchMs = Date.now() - t0;
// 连续拖动背景浓度并采样主线程长任务（>50ms 视为卡顿）
const result = await page.evaluate(async () => {
  const slider = document.querySelector('#sx-band-opacity');
  if (!slider) return { error: 'slider missing' };
  let longTasks = 0, maxTask = 0;
  const obs = new PerformanceObserver(list => {
    for (const e of list.getEntries()) { longTasks++; maxTask = Math.max(maxTask, e.duration); }
  });
  obs.observe({ entryTypes: ['longtask'] });
  const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  const start = performance.now();
  for (let i = 0; i <= 60; i++) {
    set.call(slider, String(20 + (i % 60)));
    slider.dispatchEvent(new Event('input', { bubbles: true }));
    slider.dispatchEvent(new Event('change', { bubbles: true }));
    await new Promise(r => setTimeout(r, 16));
  }
  const elapsed = performance.now() - start;
  await new Promise(r => setTimeout(r, 200));
  obs.disconnect();
  const saved = JSON.parse(localStorage.getItem('pulsedesk.sessions.v1') || '{}');
  return { dragElapsedMs: Math.round(elapsed), longTasks, maxTaskMs: Math.round(maxTask), clockMode: saved.clockMode, bandOpacity: saved.bandOpacity };
});
await page.screenshot({ path: '.verification/dst-after-fix.png' });
console.log(JSON.stringify({ switchMs, ...result, errors: errors.slice(0, 6) }));
await browser.close();
