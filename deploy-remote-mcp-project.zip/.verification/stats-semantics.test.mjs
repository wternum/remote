// tests/stats-semantics.test.ts
import assert from "node:assert/strict";

// src/quant/model.ts
var FACTORS = [
  {
    key: "touchFlow",
    label: "\u89E6\u9876\u8BA2\u5355\u6D41",
    short: "TOUCH",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.95,
    hint: "\u4EF7\u683C\u89E6\u53CA\uFF08\u6216\u903C\u8FD1\uFF09\u524D\u9AD8/\u524D\u4F4E\u65F6\uFF0C\u7528\u8BA2\u5355\u6D41\u5224\u65AD\u662F\u771F\u7A81\u7834\u8FD8\u662F\u5047\u7A81\u7834\uFF1A\u51B2\u5411\u5173\u952E\u4F4D\u7684\u4E3B\u52A8\u6210\u4EA4\u662F\u5426\u5F3A\u52B2\u3001\u89E6\u53CA\u90A3\u6839\u662F\u5426\u88AB\u5438\u6536\uFF08\u653E\u91CF\u6536\u5728\u4F4D\u5185\u3001\u7A81\u7834\u65B9\u6CA1\u8D62\u5F97\u4E3B\u52A8\u6210\u4EA4\uFF09\u3001\u62D2\u7EDD\u5F71\u7EBF\u3001\u7D2F\u8BA1\u4E3B\u52A8\u6210\u4EA4\uFF08CVD\uFF09\u662F\u5426\u8DDF\u4E0A\u4EF7\u683C\u3001\u89E6\u53CA\u4E4B\u540E\u53CD\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u662F\u5426\u63A5\u7BA1\u3002+1 = \u660E\u663E\u7684\u5047\u7A81\u7834/\u88AB\u62D2\u7EDD\uFF0C\u22121 = \u771F\u7A81\u7834\uFF08\u7A81\u7834\u65B9\u4E3B\u5BFC\u6216\u6536\u76D8\u5DF2\u7AD9\u5230\u5173\u952E\u4F4D\u5916\u4FA7\uFF09\u3002"
  },
  {
    key: "volDiverge",
    label: "\u4E8C\u6B21\u6D4B\u8BD5\u7F29\u91CF",
    short: "VOL DIV",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.55,
    hint: "\u7B2C\u4E8C\u817F\uFF08\u63A8\u5411\u4E8C\u9876/\u4E8C\u5E95\uFF09\u7684\u5355\u4F4D\u6210\u4EA4\u91CF\u660E\u663E\u5C0F\u4E8E\u7B2C\u4E00\u817F \u2192 \u63A8\u52A8\u52A8\u80FD\u8870\u7AED\uFF0C\u53CD\u8F6C\u6982\u7387\u4E0A\u5347\uFF1B\u653E\u91CF\u521B\u65B0\u9AD8/\u65B0\u4F4E\u5219\u66F4\u53EF\u80FD\u662F\u7A81\u7834\u800C\u975E\u53CC\u9876\u3002"
  },
  {
    key: "deltaDiverge",
    label: "\u4E3B\u52A8\u6210\u4EA4\u5DEE\u80CC\u79BB",
    short: "CVD DIV",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.7,
    hint: "\u7528\u9010\u6839\u4E3B\u52A8\u4E70\u5356\u5DEE\uFF08delta/\u6210\u4EA4\u91CF\uFF09\u8861\u91CF\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u9AD8\u4F46\u5DEE\u503C\u8D70\u5F31\uFF08\u9876\uFF09\u6216\u4EF7\u683C\u518D\u521B\u65B0\u4F4E\u4F46\u629B\u538B\u8D70\u5F31\uFF08\u5E95\uFF09= \u7ECF\u5178\u8BA2\u5355\u6D41\u80CC\u79BB\u3002"
  },
  {
    key: "absorption",
    label: "\u5173\u952E\u4F4D\u5438\u6536\u5019\u9009",
    short: "ABSORB",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.8,
    hint: "\u6D4B\u8BD5\u7A97\u53E3\u5185\u51FA\u73B0\u201C\u653E\u91CF\u523A\u7834\u5173\u952E\u4F4D\u4F46\u6536\u76D8\u6536\u56DE\u201D\u7684K\u7EBF\uFF08\u4EF7\u683C\u7ED3\u679C\u672A\u8DDF\u968F\u4E3B\u52A8\u63A8\u8FDB\uFF09\u8D8A\u591A\uFF0C\u8D8A\u652F\u6301\u627F\u63A5\u5019\u9009\uFF1B\u4E0D\u8BC1\u660E\u88AB\u52A8\u8BA2\u5355\u8EAB\u4EFD\uFF1B\u6536\u76D8\u505C\u5728\u5173\u952E\u4F4D\u5916\u4FA7\u5219\u89C6\u4E3A\u51FB\u7A7F\u3002"
  },
  {
    key: "wickReject",
    label: "\u62D2\u7EDD\u5F71\u7EBF",
    short: "REJECT",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.5,
    hint: "\u6700\u6DF1\u6D4B\u8BD5K\u7EBF\u7684\u5F71\u7EBF\u5360\u6BD4 + \u786E\u8BA4K\u7EBF\u6536\u76D8\u4F4D\u7F6E\uFF1A\u957F\u4E0B\u5F71/\u957F\u4E0A\u5F71\u4E14\u6536\u76D8\u6536\u56DE\u5F62\u6001\u5185\u4FA7\uFF0C\u8BF4\u660E\u8BE5\u4EF7\u4F4D\u6709\u771F\u5B9E\u5BF9\u6297\u3002"
  },
  {
    key: "thrustVolume",
    label: "\u786E\u8BA4K\u91CF\u80FD",
    short: "THRUST",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.45,
    liveOnly: true,
    hint: "\u786E\u8BA4K\u7EBF\u76F8\u5BF9\u8FD1 20 \u6839\u5747\u91CF\u7684\u653E\u5927\u500D\u6570\u3002<1 \u7684\u5F31\u786E\u8BA4\u7ECF\u5E38\u88AB\u518D\u6B21\u523A\u7834\uFF1B\u22651.5 \u7684\u62D2\u7EDD\u66F4\u53EF\u9760\u3002\u4EC5\u5B9E\u65F6\u884C\u60C5\u53EF\u7528\u3002"
  },
  {
    key: "bookImbalance",
    label: "\u76D8\u53E3\u5931\u8861",
    short: "BOOK",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.5,
    liveOnly: true,
    hint: "\u5341\u6863\u4E70\u5356\u6302\u5355\u91CF\u5931\u8861\u5EA6\uFF1A\u505A\u591A\u8981\u6C42\u4E70\u76D8\u66F4\u539A\uFF0C\u505A\u7A7A\u8981\u6C42\u5356\u76D8\u66F4\u539A\u3002\u4EC5\u5B9E\u65F6\u884C\u60C5\u53EF\u7528\uFF08\u56DE\u6D4B\u65E0\u5386\u53F2\u76D8\u53E3\uFF09\u3002"
  },
  {
    key: "tapeBias",
    label: "\u5927\u5355\u4E3B\u52A8\u65B9\u5411",
    short: "TAPE",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.4,
    liveOnly: true,
    hint: "\u6210\u4EA4\u6D41\u4E2D\u5927\u5355\u7684\u540D\u4E49\u91D1\u989D\u504F\u5411\u3002\u4E0E\u4EA4\u6613\u65B9\u5411\u4E00\u81F4\u4EC5\u8868\u793A\u5927\u5355\u4E3B\u52A8\u65B9\u5411\uFF1B\u4E0D\u8BC1\u660E\u673A\u6784\u8EAB\u4EFD\u6216\u610F\u56FE\u3002\u4EC5\u5B9E\u65F6\u53EF\u7528\u3002"
  },
  {
    key: "levelIntegrity",
    label: "\u5173\u952E\u4F4D\u5B8C\u6574\u5EA6",
    short: "LEVEL",
    group: "\u7ED3\u6784",
    weight: 0.4,
    hint: "\u540C\u4E00\u4EF7\u4F4D\u88AB\u6D4B\u8BD5\u6B21\u6570\u8D8A\u591A\u3001\u671F\u95F4\u662F\u5426\u51FA\u73B0\u8FC7\u201C\u6536\u76D8\u51FB\u7A7F\u201D\uFF0C\u51B3\u5B9A\u8FD9\u6761\u7EBF\u8FD8\u5269\u591A\u5C11\u9632\u5B88\u4EF7\u503C\uFF1B\u523A\u7834\u540E\u5FEB\u901F\u6536\u56DE\uFF08\u626B\u4F4D\u6536\u56DE\uFF09\u989D\u5916\u52A0\u5206\u3002"
  },
  {
    key: "patternHeight",
    label: "\u5F62\u6001\u9AD8\u5EA6",
    short: "HEIGHT",
    group: "\u7ED3\u6784",
    weight: 0.3,
    hint: "\u5173\u952E\u4F4D\u5230\u9888\u7EBF\u7684\u8DDD\u79BB\uFF08ATR \u500D\u6570\uFF09\u3002\u592A\u77EE\u5219\u7A7A\u95F4\u4E0D\u8DB3\u4EE5\u8986\u76D6\u6210\u672C\u4E0E\u6ED1\u70B9\uFF0C\u8FC7\u9AD8\u5219\u9700\u8981\u66F4\u4E45\u6301\u4ED3\u3002"
  },
  {
    key: "patternSpan",
    label: "\u5F62\u6001\u65F6\u95F4\u8DE8\u5EA6",
    short: "SPAN",
    group: "\u7ED3\u6784",
    weight: 0.25,
    hint: "\u4E24\u6B21\u6D4B\u8BD5\u4E4B\u95F4\u7684\u6839\u6570\u3002\u8FC7\u77ED\u662F\u566A\u97F3\u6296\u52A8\uFF0C\u8FC7\u957F\u5219\u5173\u952E\u4F4D\u5DF2\u7ECF\u949D\u5316\uFF1B\u5BF9\u6570\u5C3A\u5EA6\u4E0A\u4EE5\u7EA6 110 \u6839\u4E3A\u6700\u4F18\u3002"
  },
  {
    key: "trendExhaust",
    label: "\u8D8B\u52BF\u5DF2\u8F6C\u5E73",
    short: "FLATTEN",
    group: "\u7ED3\u6784",
    weight: 0.5,
    hint: "EMA20-EMA50 / ATR \u5EA6\u91CF\u9006\u52BF\u538B\u529B\u3002\u4E8C\u6B21\u6D4B\u8BD5\u8981\u6210\u7ACB\uFF0C\u9006\u7740\u4EA4\u6613\u65B9\u5411\u7684\u8D8B\u52BF\u5FC5\u987B\u5DF2\u7ECF\u8870\u7AED\uFF1A\u5747\u7EBF\u5DEE\u63A5\u8FD1\u8D70\u5E73\u6216\u8F7B\u5FAE\u8F6C\u5411\u65F6\u6700\u4F18\uFF1B\u4ECD\u5728\u5F3A\u9006\u52BF\u63A8\u8FDB\u65F6\u662F\u63A5\u98DE\u5200\uFF0C\u5F97\u5206\u6700\u4F4E\u3002"
  },
  {
    key: "legDecel",
    label: "\u63A8\u8FDB\u51CF\u901F",
    short: "DECEL",
    group: "\u7ED3\u6784",
    weight: 0.45,
    hint: "\u7B2C\u4E8C\u817F\u6BCF\u6839K\u7EBF\u7684\u63A8\u8FDB\u5E45\u5EA6\u76F8\u5BF9\u7B2C\u4E00\u817F\u7684\u8870\u51CF\u6BD4\u4F8B\u3002\u7B2C\u4E8C\u817F\u660E\u663E\u66F4\u6162 = \u8FB9\u9645\u4E70\u5BB6/\u5356\u5BB6\u51CF\u5C11\uFF0C\u53CD\u8F6C\u7ED3\u6784\u6210\u7ACB\u3002"
  },
  {
    key: "volRegime",
    label: "\u6CE2\u52A8\u73AF\u5883",
    short: "REGIME",
    group: "\u7ED3\u6784",
    weight: 0.2,
    hint: "\u5F53\u524D ATR \u5728\u8FD1 500 \u6839\u4E2D\u7684\u5206\u4F4D\u3002\u6CE2\u52A8\u8FC7\u4F4E\u6CA1\u6709\u8DDF\u968F\uFF0C\u8FC7\u9AD8\u5219\u6B62\u635F\u88AB\u968F\u673A\u626B\u51FA\uFF1B\u4E2D\u9AD8\u5206\u4F4D\u6700\u6709\u5229\u4E8E\u5F62\u6001\u5151\u73B0\u3002"
  },
  {
    key: "rrQuality",
    label: "\u76EE\u6807\u53EF\u8FBE\u6027",
    short: "REACH",
    group: "\u98CE\u9669",
    weight: 0.6,
    hint: "\u6A21\u578B\u9884\u6D4B\u7684\u662F\u300C\u80DC\u7387\u300D\u800C\u4E0D\u662F\u300C\u8D54\u7387\u300D\uFF1A\u76EE\u6807\u8D8A\u8FDC\uFF08R:R \u8D8A\u9AD8\uFF09\u8D8A\u96BE\u5728\u8D85\u65F6\u524D\u5151\u73B0\uFF0C\u56E0\u6B64\u9AD8 R:R \u5BF9\u80DC\u7387\u662F\u8D1F\u8BC1\u636E\u3002\u540C\u65F6\u6263\u9664\u5F80\u8FD4\u6210\u672C\u5360\u98CE\u9669\u8FC7\u9AD8\u7684\u5F62\u6001\u3002\u8D54\u7387\u7684\u4EF7\u503C\u5728\u671F\u671B\u503C\u4E00\u680F\u5355\u72EC\u4F53\u73B0\u3002"
  },
  // ── 真实订单流因子（OKX 主动买卖成交额 / 持仓量；无真实数据时按近似或记为无数据）──
  {
    key: "cvdDiverge",
    label: "CVD \u6781\u503C\u80CC\u79BB",
    short: "CVD",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.6,
    hint: "\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5356\u5DEE\uFF08CVD\uFF09\u5728\u4E8C\u9876/\u4E8C\u5E95\u5904\u4E0E\u4E00\u9876/\u4E00\u5E95\u5904\u7684\u5DEE\u503C\uFF1A\u4EF7\u683C\u518D\u521B\u7B49\u9AD8/\u7B49\u4F4E\u70B9\uFF0C\u4F46\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5165\uFF08\u9876\uFF09\u6216\u7D2F\u8BA1\u4E3B\u52A8\u5356\u51FA\uFF08\u5E95\uFF09\u6CA1\u6709\u540C\u6B65\u521B\u51FA\u6781\u503C\uFF0C\u8BF4\u660E\u63A8\u52A8\u65B9\u5DF2\u88AB\u52A8\uFF0C\u53CD\u8F6C\u6982\u7387\u4E0A\u5347\u3002"
  },
  {
    key: "sweepTrap",
    label: "\u626B\u4F4D\u9677\u9631\u5019\u9009",
    short: "TRAP",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.65,
    hint: "\u8BF1\u591A / \u8BF1\u7A7A\u5019\u9009\uFF1A\u4EF7\u683C\u523A\u7A7F\u524D\u9AD8/\u524D\u4F4E\u540E\u6536\u56DE\uFF0C\u4E14\u523A\u7A7F\u671F\u95F4\u4E3B\u52A8\u6210\u4EA4\u7AD9\u5728\u53CD\u8F6C\u4E00\u4FA7\u6216\u8FFD\u5355\u653E\u91CF\u88AB\u5438\u6536 \u2192 \u7A81\u7834\u8FFD\u968F\u8005\u53EF\u80FD\u5904\u4E8E\u4E0D\u5229\u4F4D\u7F6E\uFF08\u89E3\u91CA\u6A21\u578B\uFF0C\u975E\u8D26\u6237\u4E8B\u5B9E\uFF09\u3002\u6536\u76D8\u505C\u5728\u5173\u952E\u4F4D\u5916\u4FA7\u4E14\u7A81\u7834\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u5360\u4F18\u5219\u4E3A\u771F\u7A81\u7834\uFF0C\u8BB0\u8D1F\u5206\u3002"
  },
  {
    key: "testDelta",
    label: "\u786E\u8BA4K\u4E3B\u52A8\u65B9\u5411",
    short: "\u0394CONF",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.4,
    hint: "\u62D2\u7EDD / \u786E\u8BA4 K \u7EBF\u5185\u771F\u5B9E\u4E3B\u52A8\u4E70\u5356\u5DEE\u7684\u65B9\u5411\uFF1A\u505A\u7A7A\u8981\u6C42\u4E3B\u52A8\u5356\u51FA\u63A5\u7BA1\uFF0C\u505A\u591A\u8981\u6C42\u4E3B\u52A8\u4E70\u5165\u63A5\u7BA1\u3002\u4EC5\u5728\u8BE5\u6839\u6709\u771F\u5B9E\u4E3B\u52A8\u6210\u4EA4\u6570\u636E\u65F6\u53C2\u4E0E\u8BC4\u5206\u3002"
  },
  {
    key: "oiTrap",
    label: "\u6301\u4ED3\u91CF\u53D8\u5316",
    short: "OI",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.3,
    hint: "\u7B2C\u4E8C\u817F\uFF08\u51B2\u5411\u4E8C\u9876 / \u6740\u5411\u4E8C\u5E95\uFF09\u671F\u95F4\u6C38\u7EED\u6301\u4ED3\u91CF\u7684\u53D8\u5316\uFF1A\u6301\u4ED3\u589E\u52A0\u8BF4\u660E\u603B\u6301\u4ED3\u6269\u5F20\uFF0C\u4F46\u4E0D\u80FD\u8BC6\u522B\u591A\u7A7A\u8EAB\u4EFD\u6216\u8C01\u88AB\u5957\uFF1B\u6301\u4ED3\u51CF\u5C11\u5219\u662F\u5E73\u4ED3\u9A71\u52A8\u7684\u51B2\u523A\uFF0C\u53CD\u8F6C\u540E\u7F3A\u5C11\u71C3\u6599\u3002\u4EC5\u5728\u6709\u6301\u4ED3\u91CF\u6570\u636E\u65F6\u53C2\u4E0E\u8BC4\u5206\u3002"
  }
];
var FACTOR_INDEX = FACTORS.reduce(
  (acc, f, i) => ({ ...acc, [f.key]: i }),
  {}
);
var MODEL = {
  base: -0.15,
  gain: 0.42
};
var clamp = (v, lo = -1, hi = 1) => v < lo ? lo : v > hi ? hi : v;
function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}

// src/quant/stats.ts
var EMPTY = {
  detected: 0,
  traded: 0,
  wins: 0,
  losses: 0,
  flat: 0,
  flatRate: 0,
  winRate: 0,
  avgR: 0,
  totalR: 0,
  pf: 0,
  maxDD: 0,
  avgHold: 0,
  tpRate: 0,
  slRate: 0,
  timeRate: 0,
  beRate: 0,
  payoff: 0,
  volR: 0,
  sharpeR: 0
};
var tradable = (c) => !!c.outcome?.filled && Number.isFinite(c.outcome.r);
function summarize(cands, threshold = 0) {
  const detected = cands.filter(tradable);
  const done = detected.filter((c) => c.proba >= threshold).map((c) => c.outcome).sort((a, b) => a.exitTs - b.exitTs);
  if (!done.length) return { ...EMPTY, detected: detected.length };
  let grossWin = 0;
  let grossLoss = 0;
  let wins = 0;
  let losses = 0;
  let flat = 0;
  let tp = 0;
  let sl = 0;
  let time = 0;
  let be = 0;
  let hold = 0;
  let cum = 0;
  let peak = 0;
  let maxDD = 0;
  const rs = [];
  for (const o of done) {
    const r = o.r;
    rs.push(r);
    if (r > 0) {
      wins++;
      grossWin += r;
    } else if (r < 0) {
      losses++;
      grossLoss += -r;
    } else {
      flat++;
    }
    if (o.why === "tp") tp++;
    else if (o.why === "sl") sl++;
    else if (o.why === "be") be++;
    else time++;
    hold += o.holdingBars;
    cum += r;
    if (cum > peak) peak = cum;
    if (peak - cum > maxDD) maxDD = peak - cum;
  }
  const n = done.length;
  const avgR = cum / n;
  const sd = Math.sqrt(rs.reduce((s, r) => s + (r - avgR) ** 2, 0) / n);
  const avgWin = wins ? grossWin / wins : 0;
  const avgLoss = losses ? grossLoss / losses : 0;
  return {
    detected: detected.length,
    traded: n,
    wins,
    losses,
    flat,
    flatRate: flat / n * 100,
    winRate: wins / n * 100,
    avgR,
    totalR: cum,
    pf: grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? 99 : 0,
    maxDD,
    avgHold: hold / n,
    tpRate: tp / n * 100,
    slRate: sl / n * 100,
    timeRate: time / n * 100,
    beRate: be / n * 100,
    payoff: avgLoss > 0 ? avgWin / avgLoss : avgWin > 0 ? 99 : 0,
    volR: sd,
    sharpeR: sd > 0 ? avgR / sd : 0
  };
}
function calibration(cands, buckets = 8) {
  const pool = cands.filter(tradable);
  if (!pool.length) return [];
  let lo = 1;
  let hi = 0;
  for (const c of pool) {
    if (c.proba < lo) lo = c.proba;
    if (c.proba > hi) hi = c.proba;
  }
  if (hi - lo < 0.02) hi = Math.min(1, lo + 0.02);
  const step = (hi - lo) / buckets;
  const out = [];
  for (let b = 0; b < buckets; b++) {
    const from = lo + b * step;
    const to = b === buckets - 1 ? hi + 1e-9 : lo + (b + 1) * step;
    const slice = pool.filter((c) => c.proba >= from && c.proba < to);
    const stat = summarize(slice);
    out.push({
      ...stat,
      label: `${Math.round(from * 100)}\u2013${Math.round(to * 100)}%`,
      from,
      to,
      mid: (from + Math.min(to, hi)) / 2,
      ideal: (from + Math.min(to, hi)) / 2
    });
  }
  return out.filter((b) => b.traded > 0);
}
function thresholdSweep(cands, min = 0.42, max = 0.82, points = 21) {
  const step = (max - min) / (points - 1);
  const out = [];
  for (let i = 0; i < points; i++) {
    const thr = min + step * i;
    out.push({ thr, label: `${Math.round(thr * 100)}%`, ...summarize(cands, thr) });
  }
  return out;
}
function attribution(cands, threshold) {
  const pool = cands.filter(tradable);
  return FACTORS.map((f, i) => {
    let winSum = 0;
    let winN = 0;
    let lossSum = 0;
    let lossN = 0;
    let covered = 0;
    let used = 0;
    let killed = 0;
    for (const c of pool) {
      const e = c.evidence[i];
      if (e == null) continue;
      covered++;
      if (c.proba >= threshold) used++;
      else killed++;
      if (c.outcome.r > 0) {
        winSum += e;
        winN++;
      } else if (c.outcome.r < 0) {
        lossSum += e;
        lossN++;
      }
    }
    const avgWin = winN ? winSum / winN : 0;
    const avgLoss = lossN ? lossSum / lossN : 0;
    return {
      key: f.key,
      label: f.label,
      short: f.short,
      group: f.group,
      weight: f.weight,
      coverage: pool.length ? covered / pool.length : 0,
      avgWin,
      avgLoss,
      edge: avgWin - avgLoss,
      used,
      killed
    };
  }).sort((a, b) => b.edge - a.edge);
}
function equitySeries(cands, threshold = 0) {
  const done = cands.filter((c) => tradable(c) && c.proba >= threshold).sort((a, b) => a.outcome.exitTs - b.outcome.exitTs);
  let cum = 0;
  return done.map((c) => {
    cum += c.outcome.r;
    return { ts: c.outcome.exitTs, cumR: Number(cum.toFixed(2)), proba: c.proba, r: c.outcome.r };
  });
}
function topKillers(cands, threshold) {
  const rejected = cands.filter((c) => tradable(c) && c.proba < threshold);
  if (!rejected.length) return [];
  return FACTORS.map((f, i) => {
    let s = 0;
    let n = 0;
    for (const c of rejected) {
      const e = c.evidence[i];
      if (e == null) continue;
      s += e;
      n++;
    }
    return { key: f.key, label: f.label, short: f.short, avg: n ? s / n : 0, n };
  }).filter((k) => k.n > 0).sort((a, b) => a.avg - b.avg).slice(0, 6);
}
function gradeDistribution(cands) {
  const g = { A: 0, B: 0, C: 0, D: 0 };
  for (const c of cands) if (tradable(c) && c.grade in g) g[c.grade]++;
  const total = g.A + g.B + g.C + g.D || 1;
  return Object.keys(g).map((k) => ({ grade: k, n: g[k], pct: g[k] / total * 100 }));
}

// src/quant/scan.ts
var EXIT_PLANS = [
  { id: "neck", label: "\u9888\u7EBF\u76EE\u6807", hint: "\u539F\u65B9\u6848\uFF1A\u76EE\u6807\u770B\u9888\u7EBF\uFF08\u53D7 maxRR \u5C01\u9876\uFF09\uFF0C\u8D85\u65F6\u6309\u6536\u76D8\u4EF7\u5E73\u4ED3" },
  { id: "r15", label: "\u56FA\u5B9A 1.5R", hint: "\u76EE\u6807 = \u5165\u573A \xB1 1.5 \u500D\u98CE\u9669\uFF0C\u653E\u5F03\u8FDC\u7AEF\u9888\u7EBF\uFF0C\u6362\u53D6\u66F4\u9AD8\u5151\u73B0\u7387" },
  { id: "r10", label: "\u56FA\u5B9A 1.0R", hint: "\u76EE\u6807 = \u5165\u573A \xB1 1 \u500D\u98CE\u9669\uFF0C\u901A\u5E38\u5151\u73B0\u7387\u8F83\u9AD8\u4F46\u8D54\u4ED8\u6BD4\u8F83\u4F4E\uFF0C\u6210\u672C\u5360\u6BD4\u654F\u611F" },
  { id: "be", label: "1R \u4FDD\u672C", hint: "\u76C8\u5229\u8FBE\u5230 1R \u540E\u628A\u6B62\u635F\u79FB\u5230\u6210\u672C\u4EF7\uFF0C\u5269\u4F59\u4ED3\u4F4D\u7EE7\u7EED\u770B\u9888\u7EBF\uFF0C\u964D\u4F4E\u56DE\u5410\u98CE\u9669\uFF1B\u6ED1\u70B9/\u8DF3\u7A7A\u4ECD\u53EF\u80FD\u4E8F\u635F" },
  { id: "partial", label: "1R \u51CF\u534A + \u4FDD\u672C", hint: "1R \u5904\u5E73\u6389\u4E00\u534A\u5E76\u9501\u5B9A\u6210\u672C\uFF0C\u5269\u4F59\u4E00\u534A\u8DD1\u9888\u7EBF\u76EE\u6807" }
];

// src/quant/fit.ts
var priorWeights = () => FACTORS.map((f) => MODEL.gain * f.weight);
var fill = (row) => row.map((v) => v == null || !Number.isFinite(v) ? 0 : clamp(v));
function fitLogistic(rows, y, opts = {}) {
  const prior = opts.prior ?? priorWeights();
  const priorBase = opts.priorBase ?? MODEL.base;
  const l2 = opts.l2 ?? 6;
  const maxIter = opts.maxIter ?? 40;
  const d = FACTORS.length + 1;
  const X = rows.map((r) => [1, ...fill(r)]);
  const n = X.length;
  const center = [priorBase, ...prior];
  let w = [...center];
  if (n < 12) return { weights: prior, base: priorBase, iterations: 0, converged: false, n };
  let converged = false;
  let iter = 0;
  for (; iter < maxIter; iter++) {
    const grad = new Array(d).fill(0);
    const hess = Array.from({ length: d }, () => new Array(d).fill(0));
    for (let i = 0; i < n; i++) {
      const xi = X[i];
      let z = 0;
      for (let j = 0; j < d; j++) z += w[j] * xi[j];
      const p = sigmoid(z);
      const err = y[i] - p;
      const s = Math.max(1e-6, p * (1 - p));
      for (let j = 0; j < d; j++) {
        grad[j] += err * xi[j];
        for (let k = j; k < d; k++) hess[j][k] += s * xi[j] * xi[k];
      }
    }
    for (let j = 0; j < d; j++) {
      const lam = j === 0 ? l2 * 0.15 : l2;
      grad[j] -= lam * (w[j] - center[j]);
      hess[j][j] += lam;
    }
    for (let j = 0; j < d; j++) for (let k = 0; k < j; k++) hess[j][k] = hess[k][j];
    const step = solve(hess, grad);
    if (!step) break;
    let maxDelta = 0;
    for (let j = 0; j < d; j++) {
      const clipped = Math.max(-1, Math.min(1, step[j]));
      w[j] += clipped;
      maxDelta = Math.max(maxDelta, Math.abs(clipped));
    }
    if (maxDelta < 1e-6) {
      converged = true;
      break;
    }
  }
  return { weights: w.slice(1), base: w[0], iterations: iter + 1, converged, n };
}
function solve(A, b) {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  for (let c = 0; c < n; c++) {
    let piv = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[piv][c])) piv = r;
    if (Math.abs(M[piv][c]) < 1e-10) return null;
    [M[c], M[piv]] = [M[piv], M[c]];
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = M[r][c] / M[c][c];
      if (!f) continue;
      for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  return M.map((row, i) => row[n] / M[i][i]);
}
function predict(row, fit) {
  const x = fill(row);
  let z = fit.base;
  for (let i = 0; i < x.length; i++) z += (fit.weights[i] ?? 0) * x[i];
  return sigmoid(z);
}
function auc(scores, y) {
  const pos = [];
  const neg = [];
  for (let i = 0; i < y.length; i++) (y[i] > 0 ? pos : neg).push(scores[i]);
  if (!pos.length || !neg.length) return 0.5;
  let wins = 0;
  for (const p of pos) for (const q of neg) wins += p > q ? 1 : p === q ? 0.5 : 0;
  return wins / (pos.length * neg.length);
}
function brier(scores, y) {
  if (!scores.length) return 0.25;
  return scores.reduce((s, p, i) => s + (p - (y[i] > 0 ? 1 : 0)) ** 2, 0) / scores.length;
}
function wilson(wins, n, z = 1.96) {
  if (!n) return { lo: 0, hi: 1 };
  const p = wins / n;
  const d = 1 + z * z / n;
  const c = p + z * z / (2 * n);
  const m = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n));
  return { lo: Math.max(0, (c - m) / d), hi: Math.min(1, (c + m) / d) };
}
var tradable2 = (c) => !!c.outcome?.filled && Number.isFinite(c.outcome.r);
var knownBefore = (c, splitTs) => c.ts < splitTs && (c.outcome?.exitTs ?? c.ts) < splitTs;
function evaluate(rows, scores, threshold) {
  const idx = rows.map((_, i) => i).filter((i) => scores[i] >= threshold);
  const n = idx.length;
  const wins = idx.filter((i) => rows[i].outcome.r > 0).length;
  const totalR = idx.reduce((s, i) => s + rows[i].outcome.r, 0);
  const y = rows.map((c) => c.outcome.r > 0 ? 1 : 0);
  const ci = wilson(wins, n);
  return {
    n,
    wins,
    winRate: n ? wins / n * 100 : 0,
    avgR: n ? totalR / n : 0,
    totalR,
    auc: auc(scores, y),
    brier: brier(scores, y),
    ciLo: ci.lo * 100,
    ciHi: ci.hi * 100
  };
}
function evaluateTop(rows, scores, take) {
  const order = scores.map((s, i) => ({ s, i })).sort((a, b) => b.s - a.s);
  const chosen = new Set(order.slice(0, Math.max(0, take)).map((o) => o.i));
  const picked = rows.map((_, i) => chosen.has(i) ? 1 : 0);
  const selected = evaluate(rows, picked, 0.5);
  const y = rows.map((c) => c.outcome.r > 0 ? 1 : 0);
  return { ...selected, auc: auc(scores, y), brier: brier(scores, y) };
}
function factorDiagnostics(train, test2) {
  return FACTORS.map((f, i) => {
    const slice = (rows) => {
      const xs = [];
      const ys = [];
      for (const c of rows) {
        const e = c.evidence[i];
        if (e == null) continue;
        xs.push(e);
        ys.push(c.outcome.r > 0 ? 1 : 0);
      }
      return { xs, ys, n: xs.length };
    };
    const a = slice(train);
    const b = slice(test2);
    const trainAuc = a.n >= 8 ? auc(a.xs, a.ys) : 0.5;
    const testAuc = b.n >= 8 ? auc(b.xs, b.ys) : 0.5;
    const sameSide = (trainAuc - 0.5) * (testAuc - 0.5) > 0;
    return {
      key: f.key,
      label: f.label,
      group: f.group,
      liveOnly: !!f.liveOnly,
      trainAuc,
      testAuc,
      stable: sameSide && Math.abs(trainAuc - 0.5) >= 0.03 && Math.abs(testAuc - 0.5) >= 0.03,
      n: a.n + b.n
    };
  }).sort((x, y) => y.testAuc - x.testAuc);
}
function walkForward(cands, threshold, trainFrac = 0.7) {
  const pool = cands.filter(tradable2).sort((a, b) => a.ts - b.ts);
  if (pool.length < 40) return null;
  const cut = Math.floor(pool.length * trainFrac);
  const splitTs = pool[cut]?.ts ?? 0;
  const train = pool.slice(0, cut).filter((c) => knownBefore(c, splitTs));
  const test2 = pool.slice(cut);
  if (train.length < 20 || test2.length < 10) return null;
  const fit = fitLogistic(
    train.map((c) => c.evidence),
    train.map((c) => c.outcome.r > 0 ? 1 : 0),
    { l2: 6 }
  );
  const sparseFit = fitSparse(train);
  const priorScores = test2.map((c) => c.proba);
  const fittedScores = test2.map((c) => predict(c.evidence, fit));
  const sparseScores = test2.map((c) => predict(c.evidence, sparseFit));
  const trainScores = train.map((c) => predict(c.evidence, fit));
  const folds = [];
  const foldCount = 3;
  const foldSize = Math.floor(pool.length / (foldCount + 1));
  for (let k = 1; k <= foldCount; k++) {
    const end = foldSize * k;
    const te = pool.slice(end, end + foldSize);
    const foldSplitTs = te[0]?.ts ?? 0;
    const tr = pool.slice(0, end).filter((c) => knownBefore(c, foldSplitTs));
    if (tr.length < 20 || te.length < 8) continue;
    const f = fitLogistic(
      tr.map((c) => c.evidence),
      tr.map((c) => c.outcome.r > 0 ? 1 : 0),
      { l2: 6 }
    );
    folds.push({
      i: k,
      trainN: tr.length,
      testN: te.length,
      prior: evaluate(te, te.map((c) => c.proba), threshold),
      fitted: evaluate(te, te.map((c) => predict(c.evidence, f)), threshold)
    });
  }
  const pw = priorWeights();
  const diagnostics = factorDiagnostics(train, test2);
  const priorStat = evaluate(test2, priorScores, threshold);
  const take = priorStat.n;
  return {
    diagnostics,
    stableCount: diagnostics.filter((d) => d.stable).length,
    trainN: train.length,
    testN: test2.length,
    splitTs,
    fit,
    prior: priorStat,
    fitted: evaluateTop(test2, fittedScores, take),
    raw: evaluate(test2, test2.map(() => 0), 0),
    sparse: evaluateTop(test2, sparseScores, take),
    sparseKept: sparseFit.kept,
    trainStat: evaluate(train, trainScores, threshold),
    folds,
    coefficients: FACTORS.map((f, i) => ({
      key: f.key,
      label: f.label,
      group: f.group,
      prior: pw[i],
      fitted: fit.weights[i],
      delta: fit.weights[i] - pw[i]
    }))
  };
}
function fitSparse(train, l2 = 8) {
  const prior = priorWeights();
  const ys = train.map((c) => c.outcome.r > 0 ? 1 : 0);
  const kept = [];
  const mask = FACTORS.map((f, i) => {
    const xs = [];
    const yy = [];
    train.forEach((c, k) => {
      const e = c.evidence[i];
      if (e == null) return;
      xs.push(e);
      yy.push(ys[k]);
    });
    if (xs.length < 12) return false;
    const a = auc(xs, yy);
    const ok = Math.abs(a - 0.5) >= 0.04;
    if (ok) kept.push(f.label);
    return ok;
  });
  const centered = prior.map((w, i) => {
    if (!mask[i]) return 0;
    const xs = [];
    const yy = [];
    train.forEach((c, k) => {
      const e = c.evidence[i];
      if (e == null) return;
      xs.push(e);
      yy.push(ys[k]);
    });
    const a = auc(xs, yy);
    return Math.abs(w) * (a >= 0.5 ? 1 : -1);
  });
  const rows = train.map((c) => c.evidence.map((v, i) => mask[i] ? v : 0));
  const fit = fitLogistic(rows, ys, { l2, prior: centered });
  fit.weights = fit.weights.map((w, i) => mask[i] ? w : 0);
  return { ...fit, kept };
}

// src/quant/optimize.ts
var tradable3 = (c) => !!c.outcome?.filled && Number.isFinite(c.outcome.r);
var knownBefore2 = (c, splitTs) => c.ts < splitTs && (c.outcome?.exitTs ?? c.ts) < splitTs;
var applyPlan = (rows, plan) => rows.map((c) => ({ ...c, outcome: c.exits?.[plan] ?? c.outcome }));
function slim(rows, threshold) {
  const s = summarize(rows, threshold);
  const ci = wilson(s.wins, s.traded);
  return {
    n: s.traded,
    winRate: s.winRate,
    avgR: s.avgR,
    totalR: s.totalR,
    ciLo: ci.lo * 100,
    ciHi: ci.hi * 100
  };
}
function optimize(confirm, touch, oosFrac = 0.3) {
  const pools = {
    confirm: confirm.filter(tradable3),
    touch: touch.filter(tradable3)
  };
  const main = pools.confirm.length >= pools.touch.length ? pools.confirm : pools.touch;
  if (main.length < 30) return { combos: [], best: null, validated: 0, splitTs: 0, totalIs: 0, totalOos: 0 };
  const sorted = [...main].sort((a, b) => a.ts - b.ts);
  const cut = Math.floor(sorted.length * (1 - oosFrac));
  const splitTs = sorted[cut]?.ts ?? 0;
  const thresholds = [0.5, 0.55, 0.58, 0.62, 0.66, 0.7, 0.74];
  const combos = [];
  for (const entryMode of ["confirm", "touch"]) {
    const pool = pools[entryMode];
    if (pool.length < 20) continue;
    for (const plan of EXIT_PLANS) {
      const mapped = applyPlan(pool, plan.id).filter(tradable3);
      const isRows = mapped.filter((c) => knownBefore2(c, splitTs));
      const oosRows = mapped.filter((c) => c.ts >= splitTs);
      if (oosRows.length < 8) continue;
      for (const threshold of thresholds) {
        const is = summarize(isRows, threshold);
        const oos = slim(oosRows, threshold);
        if (is.traded < 8 || oos.n < 5) continue;
        const agree = Math.sign(is.avgR) === Math.sign(oos.avgR);
        const raw = oos.avgR * Math.sqrt(oos.n) + 0.35 * is.avgR * Math.sqrt(is.traded);
        const score = agree ? raw : raw - Math.abs(raw) - 0.5;
        const verdict = oos.avgR > 0.05 && is.avgR > 0 && oos.n >= 8 ? "validated" : oos.avgR > 0 || is.avgR > 0 ? "weak" : "rejected";
        combos.push({
          id: `${entryMode}|${plan.id}|${threshold}`,
          entryMode,
          exitPlan: plan.id,
          exitLabel: plan.label,
          threshold,
          is,
          oos,
          score,
          verdict
        });
      }
    }
  }
  const rank = (c) => c.verdict === "validated" ? 0 : c.verdict === "weak" ? 1 : 2;
  combos.sort((a, b) => rank(a) - rank(b) || b.score - a.score);
  const validated = combos.filter((c) => c.verdict === "validated").length;
  return {
    combos: combos.slice(0, 6),
    best: combos[0] ?? null,
    validated,
    splitTs,
    totalIs: cut,
    totalOos: sorted.length - cut
  };
}

// tests/stats-semantics.test.ts
var T0 = 1793e9;
var why = (r) => r > 0 ? "tp" : r < 0 ? "sl" : "be";
var mk = (r, proba = 0.7, w) => ({
  proba,
  ts: T0,
  grade: "B",
  outcome: { filled: true, r, why: w ?? why(r), exitTs: T0, entryTs: T0, holdingBars: 1, costR: 0, pnlPct: 0 },
  evidence: new Array(19).fill(0.5),
  exits: {}
});
var finite = (o) => Object.values(o).every((v) => typeof v !== "number" || Number.isFinite(v));
var passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`PASS ${name}`);
  } catch (e) {
    console.error(`FAIL ${name}
  ${e.message}`);
    process.exitCode = 1;
  }
}
test("r===0 \u8BB0\u4E3A flat\uFF0C\u4E0D\u8BA1\u5165\u4E8F\u635F\uFF1B\u80DC+\u8D1F+\u5E73 === \u6210\u4EA4", () => {
  const s = summarize([mk(1), mk(-1), mk(0), mk(2)], 0.5);
  assert.equal(s.wins, 2);
  assert.equal(s.losses, 1);
  assert.equal(s.flat, 1);
  assert.equal(s.wins + s.losses + s.flat, s.traded);
  assert.equal(s.flatRate, 25);
});
test("\u51FA\u573A\u673A\u5236 tp/sl/time/be \u4E92\u65A5\u4E14\u5408\u8BA1 100%\uFF08\u4E0E flat \u662F\u6B63\u4EA4\u7EF4\u5EA6\uFF09", () => {
  const s = summarize([mk(1, 0.7, "tp"), mk(-1, 0.7, "sl"), mk(0, 0.7, "be"), mk(2, 0.7, "tp"), mk(0.5, 0.7, "time")], 0.5);
  assert.ok(Math.abs(s.tpRate + s.slRate + s.timeRate + s.beRate - 100) < 1e-9);
});
test("PF / \u8D54\u4ED8\u6BD4\uFF1A\u6709\u4E8F\u635F\u4E3A\u771F\u5B9E\u6BD4\u503C\uFF0C\u65E0\u4E8F\u635F\u4E3A\u54E8\u5175 99\uFF08UI \u6E32\u67D3 \u221E\uFF09", () => {
  const real = summarize([mk(2), mk(-1)], 0.5);
  assert.equal(real.pf, 2);
  assert.equal(real.payoff, 2);
  const none = summarize([mk(1), mk(2)], 0.5);
  assert.equal(none.pf, 99);
  assert.equal(none.payoff, 99);
});
test("\u72EC\u7ACB\u590D\u7B97\uFF1A\u80DC\u7387 / \u7D2F\u8BA1 R / \u6700\u5927\u56DE\u64A4", () => {
  const rs = [1, -1, 2, -3, 1, 1, -1];
  const s = summarize(rs.map((r) => mk(r)), 0.5);
  let cum = 0, peak = 0, dd = 0;
  for (const r of rs) {
    cum += r;
    peak = Math.max(peak, cum);
    dd = Math.max(dd, peak - cum);
  }
  assert.equal(s.traded, 7);
  assert.ok(Math.abs(s.totalR - cum) < 1e-12);
  assert.ok(Math.abs(s.maxDD - dd) < 1e-12);
  assert.ok(Math.abs(s.winRate - 4 / 7 * 100) < 1e-9);
});
test("\u95E8\u69DB\u5355\u8C03\uFF1A\u66F4\u9AD8\u95E8\u69DB\u4E0D\u4F1A\u589E\u52A0\u6210\u4EA4\u7B14\u6570", () => {
  const pool = Array.from({ length: 50 }, (_, i) => mk(i % 3 === 0 ? -1 : 1, 0.42 + i / 50 * 0.4));
  let prev = Infinity;
  for (let t = 0.42; t <= 0.82; t += 0.04) {
    const n = summarize(pool, t).traded;
    assert.ok(n <= prev);
    prev = n;
  }
});
test("\u9000\u5316\u6837\u672C\uFF08\u7A7A / \u5355\u7B14 / \u5168\u8D62 / \u5168\u4E8F / r=0\uFF09\u6240\u6709\u8BCA\u65AD\u51FD\u6570\u65E0 NaN \u4E14\u4E0D\u629B\u9519", () => {
  const cases = [[], [mk(1)], [mk(1), mk(2)], [mk(-1), mk(-2)], [mk(0)]];
  for (const list of cases) {
    const all = [
      summarize(list, 0.5),
      ...calibration(list),
      ...thresholdSweep(list),
      ...attribution(list, 0.5),
      ...topKillers(list, 0.5),
      ...gradeDistribution(list),
      ...equitySeries(list, 0.5)
    ];
    assert.ok(all.every((o) => finite(o)), `\u6837\u672C ${list.length} \u7B14\u51FA\u73B0 NaN`);
  }
});
test("gradeDistribution \u9047\u5230\u672A\u77E5\u7B49\u7EA7\u4E0D\u4EA7\u751F NaN \u9879", () => {
  const g = gradeDistribution([{ ...mk(1), grade: void 0 }, mk(1)]);
  assert.equal(g.length, 4);
  assert.ok(g.every((o) => finite(o)));
  assert.equal(g.find((o) => o.grade === "B")?.n, 1);
});
test("attribution \u4E0D\u628A r=0 \u8BA1\u5165\u4E8F\u635F\u4FA7", () => {
  const mkE = (r, e) => ({ ...mk(r), evidence: new Array(19).fill(e) });
  const a = attribution([mkE(1, 0.9), mkE(-1, 0.1), mkE(0, 0.5)], 0.5);
  assert.ok(Math.abs(a[0].avgWin - 0.9) < 1e-12);
  assert.ok(Math.abs(a[0].avgLoss - 0.1) < 1e-12, `avgLoss=${a[0].avgLoss}\uFF0Cr=0 \u82E5\u88AB\u8BA1\u5165\u4E8F\u635F\u4F1A\u53D8\u6210 0.3`);
});
test("\u6837\u672C\u4E0D\u8DB3\u65F6 optimize \u8FD4\u56DE\u7A7A\u3001walkForward \u8FD4\u56DE null", () => {
  const o = optimize([mk(1), mk(-1)], []);
  assert.equal(o.combos.length, 0);
  assert.equal(o.best, null);
  assert.equal(walkForward([mk(1)], 0.5), null);
});
console.log(`
stats-semantics: ${passed} \u7EC4\u65AD\u8A00\u901A\u8FC7`);
