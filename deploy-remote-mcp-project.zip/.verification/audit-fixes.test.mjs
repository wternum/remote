var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// remote/setup-mcp-project-locally/src/lib/engine.ts
function atrSeries(cs, p = 14) {
  const n = cs.length;
  const out = new Array(n).fill(0);
  const tr = new Array(n).fill(0);
  for (let i = 1; i < n; i++) {
    const c = cs[i];
    const pc = cs[i - 1].c;
    tr[i] = Math.max(c.h - c.l, Math.abs(c.h - pc), Math.abs(c.l - pc));
  }
  let sum2 = 0;
  for (let i = 1; i < n; i++) {
    sum2 += tr[i];
    if (i - p >= 1) sum2 -= tr[i - p];
    out[i] = sum2 / Math.min(i, p);
  }
  return out;
}
function approxDeltaAt(cs, i) {
  const c = cs[i];
  const range = c.h - c.l;
  if (range <= 0) return c.c > c.o ? c.v / 2 : c.c < c.o ? -c.v / 2 : 0;
  return c.v * (2 * ((c.c - c.l) / range) - 1);
}
function approxDeltaSeries(cs) {
  const out = new Array(cs.length);
  for (let i = 0; i < cs.length; i++) out[i] = approxDeltaAt(cs, i);
  return out;
}
function scanSide(w, dw, atr, p, top) {
  const n = w.length;
  const L = Math.max(1, Math.round(p.pivotLeft));
  const R = Math.max(1, Math.round(p.pivotRight));
  const priorBars = Math.max(3 * L, 24);
  const active = [];
  const all = [];
  const sigs = [];
  const T = (b, t) => top ? t : b;
  const volAround = (k) => (w[Math.max(0, k - 1)].v + w[k].v + w[Math.min(n - 1, k + 1)].v) / 3;
  const legRatio = (from, to) => {
    let d = 0;
    let v = 0;
    for (let q = Math.max(0, from); q <= to; q++) {
      d += dw[q];
      v += w[q].v;
    }
    return v > 0 ? d / v : 0;
  };
  const avgVolBefore = (k) => {
    let s = 0;
    let m = 0;
    for (let q = Math.max(0, k - 20); q < k; q++) {
      s += w[q].v;
      m++;
    }
    return m ? s / m : 0;
  };
  const emaOf = (period) => {
    const k = 2 / (period + 1);
    const out = new Array(n);
    let e = w[0]?.c ?? 0;
    for (let q = 0; q < n; q++) {
      e = q === 0 ? w[0].c : w[q].c * k + e * (1 - k);
      out[q] = e;
    }
    return out;
  };
  const ef = emaOf(20);
  const es = emaOf(50);
  const trendOk = (i) => p.trendBlock >= 50 || !(atr[i] > 0) || (ef[i] - es[i]) / atr[i] >= -p.trendBlock;
  const avgVolRange = (from, to) => {
    let sv = 0;
    let m = 0;
    for (let q = Math.max(0, from); q <= to; q++) {
      sv += w[q].v;
      m++;
    }
    return m ? sv / m : 0;
  };
  const costOk = (entry, risk) => risk > 0 && Math.abs(entry) * 2 * (FEE_RATE + SLIP_RATE) / risk <= MAX_COST_RATIO;
  const rejectNow = (c, level, a) => {
    const range = Math.max(1e-12, c.h - c.l);
    const lowerWick = (Math.min(c.o, c.c) - c.l) / range;
    return c.c >= level + p.closeBufAtr * a && closePos(c) >= 0.5 && (c.c > c.o || lowerWick >= 0.35);
  };
  const basePts = (lv, t) => [
    { k: lv.priorIdx, price: lv.prior, label: T("\u8D77\u8DCC\u70B9", "\u8D77\u6DA8\u70B9"), low: false },
    { k: lv.j, price: lv.price, label: T("\u4E00\u5E95", "\u4E00\u9876"), low: true },
    { k: lv.frozenNeckIdx, price: lv.frozenNeck, label: "\u9888\u7EBF", low: false },
    { k: t, price: w[t].l, label: T("\u4E8C\u5E95", "\u4E8C\u9876"), low: true }
  ];
  const makeReject = (lv, t, i, a) => {
    const c = w[i];
    const testLow = Math.min(w[t].l, c.l);
    const entry = c.c;
    const stop = Math.min(lv.price, testLow) - p.stopAtr * a;
    const risk = entry - stop;
    if (!costOk(entry, risk)) return null;
    const room = (lv.frozenNeck - entry) * p.targetFrac;
    if (!(room > 0)) return null;
    const tp = entry + Math.min(room, p.maxRR * risk);
    const rr = (tp - entry) / risk;
    if (rr < p.minRR) return null;
    const tags = [];
    let s = 50;
    const height = lv.frozenNeck - lv.price;
    if (testLow < lv.price) {
      s += 6;
      tags.push(T("\u626B\u4F4E\u6536\u56DE", "\u626B\u9AD8\u56DE\u843D"));
    } else {
      tags.push(testLow - lv.price <= 0.1 * a ? T("\u7B49\u4F4E\u53CC\u5E95", "\u7B49\u9AD8\u53CC\u9876") : T("\u4E8C\u5E95\u62AC\u9AD8", "\u4E8C\u9876\u964D\u4F4E"));
    }
    if (volAround(t) < volAround(lv.j) * 0.9) {
      s += 10;
      tags.push(T("\u4E8C\u5E95\u7F29\u91CF", "\u4E8C\u9876\u7F29\u91CF"));
    }
    if (legRatio(lv.frozenNeckIdx + 1, t) > legRatio(lv.priorIdx + 1, lv.j) + 0.05) {
      s += 8;
      tags.push(T("\u5356\u538B\u8870\u7AED", "\u4E70\u76D8\u8870\u7AED"));
    }
    const tb = w[t];
    if ((Math.min(tb.o, tb.c) - tb.l) / Math.max(1e-12, tb.h - tb.l) >= 0.45) {
      s += 6;
      tags.push(T("\u4E0B\u5F71\u627F\u63A5", "\u4E0A\u5F71\u53D7\u538B"));
    }
    if (closePos(c) >= 0.7) {
      s += 5;
      tags.push(T("\u5F3A\u52BF\u6536\u76D8", "\u5F31\u52BF\u6536\u76D8"));
    }
    if (height >= 3 * a) {
      s += 6;
      tags.push("\u5F62\u6001\u9AD8\u5EA6\u5145\u8DB3");
    }
    if (i - lv.j >= 96) {
      s += 5;
      tags.push(T("\u5386\u53F2\u5E95\u90E8", "\u5386\u53F2\u9876\u90E8"));
    }
    if (rr >= 2) {
      s += 4;
      tags.push(`\u76C8\u4E8F\u6BD4 ${rr.toFixed(1)}`);
    }
    const pts = basePts(lv, t);
    if (t !== i) pts.push({ k: i, price: c.c, label: "\u786E\u8BA4", low: false });
    return {
      idx: i,
      kind: "reject",
      entry,
      stop,
      tp,
      strength: Math.min(100, s),
      tags,
      note: `${i - lv.j} \u6839\u524D\u7684${T("\u5E95\u90E8", "\u9876\u90E8")}\u88AB\u7B2C\u4E8C\u6B21\u6D4B\u8BD5\uFF0C${T("\u652F\u6491", "\u963B\u529B")}\u533A\u6536\u76D8\u62D2\u7EDD\u786E\u8BA4`,
      pts,
      line: { fromK: lv.j, toK: i, price: lv.price, label: T("\u53CC\u5E95\u652F\u6491", "\u53CC\u9876\u963B\u529B") }
    };
  };
  const makeLimit = (lv, i, a, entryPx) => {
    const c = w[i];
    const fill = Math.min(c.o, entryPx);
    const stop = lv.price - p.stopAtr * a;
    const risk0 = entryPx - stop;
    if (!costOk(entryPx, risk0) || fill <= stop) return null;
    const room = (lv.frozenNeck - entryPx) * p.targetFrac;
    if (!(room > 0)) return null;
    const tp = entryPx + Math.min(room, p.maxRR * risk0);
    const rr = (tp - entryPx) / risk0;
    if (rr < p.minRR) return null;
    const tags = [T("\u7B49\u4F4E\u652F\u6491\u6302\u5355", "\u7B49\u9AD8\u963B\u529B\u6302\u5355")];
    let s = 50;
    const height = lv.frozenNeck - lv.price;
    if (avgVolRange(lv.frozenNeckIdx + 1, i) < avgVolRange(lv.priorIdx + 1, lv.j) * 0.9) {
      s += 8;
      tags.push(T("\u56DE\u6D4B\u7F29\u91CF", "\u53CD\u5F39\u7F29\u91CF"));
    }
    if (legRatio(lv.frozenNeckIdx + 1, i) > legRatio(lv.priorIdx + 1, lv.j) + 0.05) {
      s += 8;
      tags.push(T("\u5356\u538B\u8870\u7AED", "\u4E70\u76D8\u8870\u7AED"));
    }
    if (height >= 3 * a) {
      s += 6;
      tags.push("\u5F62\u6001\u9AD8\u5EA6\u5145\u8DB3");
    }
    if (i - lv.j >= 96) {
      s += 5;
      tags.push(T("\u5386\u53F2\u5E95\u90E8", "\u5386\u53F2\u9876\u90E8"));
    }
    if (rr >= 2) {
      s += 4;
      tags.push(`\u76C8\u4E8F\u6BD4 ${rr.toFixed(1)}`);
    }
    return {
      idx: i,
      kind: "limit",
      entry: fill,
      stop,
      tp,
      strength: Math.min(100, s),
      tags,
      note: `${i - lv.j} \u6839\u524D\u7684${T("\u5E95\u90E8", "\u9876\u90E8")}\u88AB\u7B2C\u4E8C\u6B21\u6D4B\u8BD5\uFF0C${T("\u7B49\u4F4E\u652F\u6491", "\u7B49\u9AD8\u963B\u529B")}\u533A\u6302\u5355\u6210\u4EA4`,
      pts: basePts(lv, i),
      line: { fromK: lv.j, toK: i, price: lv.price, label: T("\u53CC\u5E95\u652F\u6491", "\u53CC\u9876\u963B\u529B") }
    };
  };
  const makeBreak = (lv, i, a) => {
    const c = w[i];
    const N = lv.frozenNeck;
    const height = N - lv.price;
    if (!(c.c > c.o) || closePos(c) < 0.55 || c.c - N > 0.5 * height) return null;
    const entry = c.c;
    const stop = entry - (0.5 * height + p.stopAtr * a);
    const risk = entry - stop;
    if (!costOk(entry, risk)) return null;
    const tp = N + height * p.targetFrac;
    const rr = (tp - entry) / risk;
    if (rr < p.minRR) return null;
    const tags = [T("\u9888\u7EBF\u7A81\u7834", "\u9888\u7EBF\u8DCC\u7834")];
    let s = 52;
    const av = avgVolBefore(i);
    const vr = av > 0 ? c.v / av : 1;
    if (vr >= 1.5) {
      s += 8;
      tags.push(`${T("\u7A81\u7834", "\u8DCC\u7834")}\u653E\u91CF ${vr.toFixed(1)}x`);
    } else if (vr < 1) s -= 4;
    if (closePos(c) >= 0.7) {
      s += 5;
      tags.push(T("\u5F3A\u52BF\u6536\u76D8", "\u5F31\u52BF\u6536\u76D8"));
    }
    if (c.v > 0 && dw[i] / c.v >= 0.2) {
      s += 5;
      tags.push(T("\u4E3B\u52A8\u4E70\u5165", "\u4E3B\u52A8\u5356\u51FA"));
    }
    if (height >= 3 * a) {
      s += 4;
      tags.push("\u5F62\u6001\u9AD8\u5EA6\u5145\u8DB3");
    }
    return {
      idx: i,
      kind: "break",
      entry,
      stop,
      tp,
      strength: Math.min(100, s),
      tags,
      note: `\u4E8C\u6B21\u6D4B\u8BD5\u540E\u7B2C ${i - lv.t} \u6839\u6536\u76D8${T("\u7AD9\u4E0A", "\u8DCC\u7834")}\u9888\u7EBF`,
      pts: [...basePts(lv, lv.t), { k: i, price: c.c, label: T("\u7A81\u7834", "\u8DCC\u7834"), low: false }],
      line: { fromK: lv.frozenNeckIdx, toK: i, price: N, label: "\u9888\u7EBF" }
    };
  };
  for (let i = 1; i < n; i++) {
    const a = atr[i];
    const c = w[i];
    if (a > 0) {
      const cands = [];
      for (const lv of active) {
        if (lv.state === "done") continue;
        const tol = Math.max(p.tolAtr * a, p.tolPct * Math.abs(lv.price));
        const qualified = lv.state === "fresh" && i - lv.j >= p.minGap && lv.neck - lv.price >= p.minHeightAtr * a;
        if (p.entryMode === "limit" && qualified) {
          const entryPx = lv.price + Math.min(p.limitOffsetAtr * a, tol);
          if (c.l <= entryPx) {
            lv.frozenNeck = lv.neck;
            lv.frozenNeckIdx = lv.neckIdx;
            lv.t = i;
            lv.tested = true;
            lv.state = "tested";
            if (trendOk(i)) {
              const s = makeLimit(lv, i, a, entryPx);
              if (s) cands.push(s);
            }
          }
        }
        if (c.l < lv.price - p.sweepAtr * a || c.c < lv.price - tol) {
          lv.state = "done";
          lv.brokenAt = i;
          continue;
        }
        const touch = c.l <= lv.price + tol;
        if (lv.state === "fresh") {
          if (touch && qualified) {
            lv.frozenNeck = lv.neck;
            lv.frozenNeckIdx = lv.neckIdx;
            lv.t = i;
            lv.tested = true;
            if (p.entryMode === "limit") {
              lv.state = "tested";
            } else if (rejectNow(c, lv.price, a)) {
              const s = trendOk(i) ? makeReject(lv, i, i, a) : null;
              if (s) cands.push(s);
              lv.state = "tested";
            } else {
              lv.state = "pending";
            }
          } else if (c.h > lv.neck) {
            lv.neck = c.h;
            lv.neckIdx = i;
          }
        } else if (lv.state === "pending") {
          const tb = w[lv.t];
          if (trendOk(i) && c.c > c.o && c.c > tb.c && c.c >= lv.price + p.closeBufAtr * a && closePos(c) >= 0.5) {
            const s = makeReject(lv, lv.t, i, a);
            if (s) cands.push(s);
          }
          lv.state = "tested";
        } else if (lv.state === "tested") {
          if (p.enableBreak && !lv.aboveNeck && i - lv.t <= p.breakWithin && c.c > lv.frozenNeck) {
            lv.aboveNeck = true;
            const s = trendOk(i) ? makeBreak(lv, i, a) : null;
            if (s) cands.push(s);
          }
        }
      }
      if (cands.length) {
        cands.sort((x, y) => y.strength - x.strength);
        sigs.push(cands[0]);
      }
      for (let q = active.length - 1; q >= 0; q--) {
        const lv = active[q];
        if (lv.state === "fresh" && i - lv.j > p.lookback) {
          lv.state = "done";
          lv.expired = true;
        } else if (lv.state === "tested" && i - lv.j > 3 * p.lookback) {
          lv.state = "done";
          lv.expired = true;
        }
        if (lv.state === "done") active.splice(q, 1);
      }
    }
    const j = i - R;
    if (j - L >= 0) {
      const lj = w[j].l;
      let ok2 = true;
      for (let k = j - L; k < j; k++)
        if (w[k].l <= lj) {
          ok2 = false;
          break;
        }
      if (ok2) {
        for (let k = j + 1; k <= i; k++)
          if (w[k].l < lj) {
            ok2 = false;
            break;
          }
      }
      const aj = atr[i] > 0 ? atr[i] : atr[j];
      if (ok2 && aj > 0) {
        let prior = -Infinity;
        let priorIdx = j;
        for (let k = Math.max(0, j - priorBars); k < j; k++)
          if (w[k].h > prior) {
            prior = w[k].h;
            priorIdx = k;
          }
        const tol = Math.max(p.tolAtr * aj, p.tolPct * Math.abs(lj));
        const dup = active.some((lv) => lv.state !== "done" && Math.abs(lv.price - lj) <= tol);
        if (!dup && prior - lj >= p.priorMoveAtr * aj) {
          let neck = -Infinity;
          let neckIdx = j;
          for (let k = j + 1; k <= i; k++)
            if (w[k].h > neck) {
              neck = w[k].h;
              neckIdx = k;
            }
          const lv = {
            j,
            price: lj,
            priorIdx,
            prior,
            neck,
            neckIdx,
            state: "fresh",
            t: -1,
            frozenNeck: neck,
            frozenNeckIdx: neckIdx,
            brokenAt: -1,
            aboveNeck: false,
            tested: false,
            expired: false
          };
          active.push(lv);
          all.push(lv);
        }
      }
    }
  }
  return { sigs, levels: all };
}
function scanDoubles(cs, p = DEFAULT_PARAMS) {
  const signals = [];
  const levels = [];
  if (cs.length < 30) return { signals, levels };
  const atr = atrSeries(cs);
  const delta = approxDeltaSeries(cs);
  const last = cs.length - 1;
  for (const sgn of [1, -1]) {
    const top = sgn === -1;
    const w = top ? cs.map((c) => ({ ts: c.ts, o: -c.o, h: -c.l, l: -c.h, c: -c.c, v: c.v })) : cs;
    const dw = top ? delta.map((d) => -d) : delta;
    const r = scanSide(w, dw, atr, p, top);
    const P = (x) => sgn * x;
    for (const s of r.sigs) {
      const pattern = s.kind === "break" ? top ? "dt_break" : "db_break" : top ? "dt_reject" : "db_reject";
      const pts = s.pts.map((pt) => ({
        ts: cs[pt.k].ts,
        price: P(pt.price),
        label: pt.label,
        pos: pt.low !== top ? "below" : "above"
      }));
      const path = [...pts].sort((a, b) => a.ts - b.ts).filter((pt, k, arr) => k === 0 || pt.ts !== arr[k - 1].ts).map((pt) => ({ ts: pt.ts, price: pt.price }));
      const strength = Math.round(s.strength);
      signals.push({
        idx: s.idx,
        ts: cs[s.idx].ts,
        side: top ? "short" : "long",
        pattern,
        entry: P(s.entry),
        stop: P(s.stop),
        tp: P(s.tp),
        conf: strength,
        confl: strength,
        fill: s.kind === "limit" ? "limit" : "close",
        strength,
        note: s.note,
        tags: s.tags,
        geo: {
          pts,
          path,
          neck: { from: cs[s.line.fromK].ts, to: cs[s.line.toK].ts, price: P(s.line.price), label: s.line.label }
        }
      });
    }
    for (const lv of r.levels) {
      if (lv.expired) continue;
      if (lv.brokenAt >= 0 && !lv.tested) continue;
      levels.push({
        from: cs[lv.j].ts,
        to: cs[lv.brokenAt >= 0 ? lv.brokenAt : last].ts,
        price: P(lv.price),
        side: top ? "top" : "bottom",
        tested: lv.tested,
        broken: lv.brokenAt >= 0
      });
    }
  }
  signals.sort((a, b) => a.idx - b.idx);
  return { signals, levels };
}
var FEE_RATE, SLIP_RATE, CONF_MIN, MAX_HOLD_5M, MAX_HOLD_15M, MAX_COST_RATIO, DEFAULT_PARAMS, PATTERN_META, closePos;
var init_engine = __esm({
  "remote/setup-mcp-project-locally/src/lib/engine.ts"() {
    "use strict";
    FEE_RATE = 5e-4;
    SLIP_RATE = 1e-4;
    CONF_MIN = 60;
    MAX_HOLD_5M = 96;
    MAX_HOLD_15M = 48;
    MAX_COST_RATIO = 0.3;
    DEFAULT_PARAMS = {
      pivotLeft: 8,
      pivotRight: 5,
      lookback: 288,
      minGap: 8,
      minHeightAtr: 2,
      priorMoveAtr: 1.5,
      tolAtr: 0.35,
      tolPct: 4e-4,
      sweepAtr: 0.5,
      closeBufAtr: 0.05,
      stopAtr: 0.75,
      targetFrac: 1,
      minRR: 1.2,
      maxRR: 4,
      enableBreak: false,
      breakWithin: 24,
      entryMode: "limit",
      limitOffsetAtr: 0.1,
      trendBlock: 1
    };
    PATTERN_META = {
      db_reject: {
        label: "W\u53CC\u5E95\xB7\u4E8C\u6B21\u6D4B\u8BD5",
        short: "W",
        hint: "\u5386\u53F2\u5E95\u90E8\uFF08\u53EF\u4EE5\u662F\u5F88\u4E45\u4E4B\u524D\u7684\u4F4E\u70B9\uFF09\u88AB\u7B2C\u4E8C\u6B21\u6D4B\u8BD5\uFF0C\u7B49\u4F4E\u652F\u6491\u533A\u6536\u76D8\u62D2\u7EDD\u540E\u505A\u591A\uFF1B\u6B62\u635F\u653E\u5728\u53CC\u5E95\u4E0B\u65B9\uFF0C\u76EE\u6807\u770B\u9888\u7EBF",
        family: "double"
      },
      dt_reject: {
        label: "M\u53CC\u9876\xB7\u4E8C\u6B21\u6D4B\u8BD5",
        short: "M",
        hint: "\u5386\u53F2\u9876\u90E8\u88AB\u7B2C\u4E8C\u6B21\u6D4B\u8BD5\uFF0C\u7B49\u9AD8\u963B\u529B\u533A\u6536\u76D8\u62D2\u7EDD\u540E\u505A\u7A7A\uFF1B\u6B62\u635F\u653E\u5728\u53CC\u9876\u4E0A\u65B9\uFF0C\u76EE\u6807\u770B\u9888\u7EBF",
        family: "double"
      },
      db_break: {
        label: "W\u53CC\u5E95\xB7\u9888\u7EBF\u7A81\u7834",
        short: "W\u2191",
        hint: "\u53CC\u5E95\u5B8C\u6210\u4E8C\u6B21\u6D4B\u8BD5\u540E\uFF0C\u6536\u76D8\u7AD9\u4E0A\u9888\u7EBF\u505A\u591A\uFF1B\u76EE\u6807\u4E3A\u5F62\u6001\u6D4B\u91CF\u9AD8\u5EA6",
        family: "double"
      },
      dt_break: {
        label: "M\u53CC\u9876\xB7\u9888\u7EBF\u8DCC\u7834",
        short: "M\u2193",
        hint: "\u53CC\u9876\u5B8C\u6210\u4E8C\u6B21\u6D4B\u8BD5\u540E\uFF0C\u6536\u76D8\u8DCC\u7834\u9888\u7EBF\u505A\u7A7A\uFF1B\u76EE\u6807\u4E3A\u5F62\u6001\u6D4B\u91CF\u9AD8\u5EA6",
        family: "double"
      }
    };
    closePos = (c) => c.h - c.l > 0 ? (c.c - c.l) / (c.h - c.l) : 0.5;
  }
});

// src/quant/model.ts
function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}
function scoreEvidence(evidence) {
  let logit = MODEL.base;
  const parts = new Array(FACTORS.length).fill(0);
  let covered = 0;
  for (let i = 0; i < FACTORS.length; i++) {
    const e = evidence[i];
    if (e == null || !Number.isFinite(e)) continue;
    const w = FACTORS[i].weight;
    const part = MODEL.gain * w * clamp(e);
    parts[i] = part;
    logit += part;
    covered += w;
  }
  const shrink = Math.min(1, covered / 4.5);
  logit = MODEL.base + (logit - MODEL.base) * shrink;
  return { proba: sigmoid(logit), logit, evidence, parts, covered };
}
function gradeOf(proba) {
  for (const b of GRADE_BANDS) if (proba >= b.min) return b.grade;
  return "D";
}
function gradeMeta(grade) {
  return GRADE_BANDS.find((b) => b.grade === grade) ?? GRADE_BANDS[GRADE_BANDS.length - 1];
}
var FACTORS, FACTOR_INDEX, MODEL, clamp, GRADE_BANDS;
var init_model = __esm({
  "src/quant/model.ts"() {
    "use strict";
    FACTORS = [
      {
        key: "touchFlow",
        label: "\u89E6\u9876\u8BA2\u5355\u6D41",
        short: "TOUCH",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.95,
        hint: "\u4EF7\u683C\u89E6\u53CA\uFF08\u6216\u903C\u8FD1\uFF09\u524D\u9AD8/\u524D\u4F4E\u65F6\uFF0C\u7528\u8BA2\u5355\u6D41\u5224\u65AD\u662F\u771F\u7A81\u7834\u8FD8\u662F\u5047\u7A81\u7834\uFF1A\u51B2\u5411\u5173\u952E\u4F4D\u7684\u4E3B\u52A8\u6210\u4EA4\u662F\u5426\u5F3A\u52B2\u3001\u89E6\u53CA\u90A3\u6839\u662F\u5426\u88AB\u5438\u6536\uFF08\u653E\u91CF\u6536\u5728\u4F4D\u5185\u3001\u7A81\u7834\u65B9\u6CA1\u8D62\u5F97\u4E3B\u52A8\u6210\u4EA4\uFF09\u3001\u62D2\u7EDD\u5F71\u7EBF\u3001\u7D2F\u8BA1\u4E3B\u52A8\u6210\u4EA4\uFF08CVD\uFF09\u662F\u5426\u8DDF\u4E0A\u4EF7\u683C\u3001\u89E6\u53CA\u4E4B\u540E\u53CD\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u662F\u5426\u63A5\u7BA1\u3002+1 = \u660E\u663E\u7684\u5047\u7A81\u7834/\u88AB\u62D2\u7EDD\uFF0C\u22121 = \u771F\u7A81\u7834\uFF08\u7A81\u7834\u65B9\u4E3B\u5BFC\u6216\u6536\u76D8\u5DF2\u7AD9\u5230\u5173\u952E\u4F4D\u5916\u4FA7\uFF09\u3002"
      },
      {
        key: "volDiverge",
        label: "\u4E8C\u6B21\u6D4B\u8BD5\u7F29\u91CF",
        short: "VOL DIV",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.55,
        hint: "\u7B2C\u4E8C\u817F\uFF08\u63A8\u5411\u4E8C\u9876/\u4E8C\u5E95\uFF09\u7684\u5355\u4F4D\u6210\u4EA4\u91CF\u660E\u663E\u5C0F\u4E8E\u7B2C\u4E00\u817F \u2192 \u63A8\u52A8\u52A8\u80FD\u8870\u7AED\uFF0C\u53CD\u8F6C\u6982\u7387\u4E0A\u5347\uFF1B\u653E\u91CF\u521B\u65B0\u9AD8/\u65B0\u4F4E\u5219\u66F4\u53EF\u80FD\u662F\u7A81\u7834\u800C\u975E\u53CC\u9876\u3002"
      },
      {
        key: "deltaDiverge",
        label: "\u4E3B\u52A8\u6210\u4EA4\u5DEE\u80CC\u79BB",
        short: "CVD DIV",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.7,
        hint: "\u7528\u9010\u6839\u4E3B\u52A8\u4E70\u5356\u5DEE\uFF08delta/\u6210\u4EA4\u91CF\uFF09\u8861\u91CF\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u9AD8\u4F46\u5DEE\u503C\u8D70\u5F31\uFF08\u9876\uFF09\u6216\u4EF7\u683C\u518D\u521B\u65B0\u4F4E\u4F46\u629B\u538B\u8D70\u5F31\uFF08\u5E95\uFF09= \u7ECF\u5178\u8BA2\u5355\u6D41\u80CC\u79BB\u3002"
      },
      {
        key: "absorption",
        label: "\u5173\u952E\u4F4D\u5438\u6536\u5019\u9009",
        short: "ABSORB",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.8,
        hint: "\u6D4B\u8BD5\u7A97\u53E3\u5185\u51FA\u73B0\u201C\u653E\u91CF\u523A\u7834\u5173\u952E\u4F4D\u4F46\u6536\u76D8\u6536\u56DE\u201D\u7684K\u7EBF\uFF08\u4EF7\u683C\u7ED3\u679C\u672A\u8DDF\u968F\u4E3B\u52A8\u63A8\u8FDB\uFF09\u8D8A\u591A\uFF0C\u8D8A\u652F\u6301\u627F\u63A5\u5019\u9009\uFF1B\u4E0D\u8BC1\u660E\u88AB\u52A8\u8BA2\u5355\u8EAB\u4EFD\uFF1B\u6536\u76D8\u505C\u5728\u5173\u952E\u4F4D\u5916\u4FA7\u5219\u89C6\u4E3A\u51FB\u7A7F\u3002"
      },
      {
        key: "wickReject",
        label: "\u62D2\u7EDD\u5F71\u7EBF",
        short: "REJECT",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.5,
        hint: "\u6700\u6DF1\u6D4B\u8BD5K\u7EBF\u7684\u5F71\u7EBF\u5360\u6BD4 + \u786E\u8BA4K\u7EBF\u6536\u76D8\u4F4D\u7F6E\uFF1A\u957F\u4E0B\u5F71/\u957F\u4E0A\u5F71\u4E14\u6536\u76D8\u6536\u56DE\u5F62\u6001\u5185\u4FA7\uFF0C\u8BF4\u660E\u8BE5\u4EF7\u4F4D\u6709\u771F\u5B9E\u5BF9\u6297\u3002"
      },
      {
        key: "thrustVolume",
        label: "\u786E\u8BA4K\u91CF\u80FD",
        short: "THRUST",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.45,
        liveOnly: true,
        hint: "\u786E\u8BA4K\u7EBF\u76F8\u5BF9\u8FD1 20 \u6839\u5747\u91CF\u7684\u653E\u5927\u500D\u6570\u3002<1 \u7684\u5F31\u786E\u8BA4\u7ECF\u5E38\u88AB\u518D\u6B21\u523A\u7834\uFF1B\u22651.5 \u7684\u62D2\u7EDD\u66F4\u53EF\u9760\u3002\u4EC5\u5B9E\u65F6\u884C\u60C5\u53EF\u7528\u3002"
      },
      {
        key: "bookImbalance",
        label: "\u76D8\u53E3\u5931\u8861",
        short: "BOOK",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.5,
        liveOnly: true,
        hint: "\u5341\u6863\u4E70\u5356\u6302\u5355\u91CF\u5931\u8861\u5EA6\uFF1A\u505A\u591A\u8981\u6C42\u4E70\u76D8\u66F4\u539A\uFF0C\u505A\u7A7A\u8981\u6C42\u5356\u76D8\u66F4\u539A\u3002\u4EC5\u5B9E\u65F6\u884C\u60C5\u53EF\u7528\uFF08\u56DE\u6D4B\u65E0\u5386\u53F2\u76D8\u53E3\uFF09\u3002"
      },
      {
        key: "tapeBias",
        label: "\u5927\u5355\u4E3B\u52A8\u65B9\u5411",
        short: "TAPE",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.4,
        liveOnly: true,
        hint: "\u6210\u4EA4\u6D41\u4E2D\u5927\u5355\u7684\u540D\u4E49\u91D1\u989D\u504F\u5411\u3002\u4E0E\u4EA4\u6613\u65B9\u5411\u4E00\u81F4\u4EC5\u8868\u793A\u5927\u5355\u4E3B\u52A8\u65B9\u5411\uFF1B\u4E0D\u8BC1\u660E\u673A\u6784\u8EAB\u4EFD\u6216\u610F\u56FE\u3002\u4EC5\u5B9E\u65F6\u53EF\u7528\u3002"
      },
      {
        key: "levelIntegrity",
        label: "\u5173\u952E\u4F4D\u5B8C\u6574\u5EA6",
        short: "LEVEL",
        group: "\u7ED3\u6784",
        weight: 0.4,
        hint: "\u540C\u4E00\u4EF7\u4F4D\u88AB\u6D4B\u8BD5\u6B21\u6570\u8D8A\u591A\u3001\u671F\u95F4\u662F\u5426\u51FA\u73B0\u8FC7\u201C\u6536\u76D8\u51FB\u7A7F\u201D\uFF0C\u51B3\u5B9A\u8FD9\u6761\u7EBF\u8FD8\u5269\u591A\u5C11\u9632\u5B88\u4EF7\u503C\uFF1B\u523A\u7834\u540E\u5FEB\u901F\u6536\u56DE\uFF08\u626B\u4F4D\u6536\u56DE\uFF09\u989D\u5916\u52A0\u5206\u3002"
      },
      {
        key: "patternHeight",
        label: "\u5F62\u6001\u9AD8\u5EA6",
        short: "HEIGHT",
        group: "\u7ED3\u6784",
        weight: 0.3,
        hint: "\u5173\u952E\u4F4D\u5230\u9888\u7EBF\u7684\u8DDD\u79BB\uFF08ATR \u500D\u6570\uFF09\u3002\u592A\u77EE\u5219\u7A7A\u95F4\u4E0D\u8DB3\u4EE5\u8986\u76D6\u6210\u672C\u4E0E\u6ED1\u70B9\uFF0C\u8FC7\u9AD8\u5219\u9700\u8981\u66F4\u4E45\u6301\u4ED3\u3002"
      },
      {
        key: "patternSpan",
        label: "\u5F62\u6001\u65F6\u95F4\u8DE8\u5EA6",
        short: "SPAN",
        group: "\u7ED3\u6784",
        weight: 0.25,
        hint: "\u4E24\u6B21\u6D4B\u8BD5\u4E4B\u95F4\u7684\u6839\u6570\u3002\u8FC7\u77ED\u662F\u566A\u97F3\u6296\u52A8\uFF0C\u8FC7\u957F\u5219\u5173\u952E\u4F4D\u5DF2\u7ECF\u949D\u5316\uFF1B\u5BF9\u6570\u5C3A\u5EA6\u4E0A\u4EE5\u7EA6 110 \u6839\u4E3A\u6700\u4F18\u3002"
      },
      {
        key: "trendExhaust",
        label: "\u8D8B\u52BF\u5DF2\u8F6C\u5E73",
        short: "FLATTEN",
        group: "\u7ED3\u6784",
        weight: 0.5,
        hint: "EMA20-EMA50 / ATR \u5EA6\u91CF\u9006\u52BF\u538B\u529B\u3002\u4E8C\u6B21\u6D4B\u8BD5\u8981\u6210\u7ACB\uFF0C\u9006\u7740\u4EA4\u6613\u65B9\u5411\u7684\u8D8B\u52BF\u5FC5\u987B\u5DF2\u7ECF\u8870\u7AED\uFF1A\u5747\u7EBF\u5DEE\u63A5\u8FD1\u8D70\u5E73\u6216\u8F7B\u5FAE\u8F6C\u5411\u65F6\u6700\u4F18\uFF1B\u4ECD\u5728\u5F3A\u9006\u52BF\u63A8\u8FDB\u65F6\u662F\u63A5\u98DE\u5200\uFF0C\u5F97\u5206\u6700\u4F4E\u3002"
      },
      {
        key: "legDecel",
        label: "\u63A8\u8FDB\u51CF\u901F",
        short: "DECEL",
        group: "\u7ED3\u6784",
        weight: 0.45,
        hint: "\u7B2C\u4E8C\u817F\u6BCF\u6839K\u7EBF\u7684\u63A8\u8FDB\u5E45\u5EA6\u76F8\u5BF9\u7B2C\u4E00\u817F\u7684\u8870\u51CF\u6BD4\u4F8B\u3002\u7B2C\u4E8C\u817F\u660E\u663E\u66F4\u6162 = \u8FB9\u9645\u4E70\u5BB6/\u5356\u5BB6\u51CF\u5C11\uFF0C\u53CD\u8F6C\u7ED3\u6784\u6210\u7ACB\u3002"
      },
      {
        key: "volRegime",
        label: "\u6CE2\u52A8\u73AF\u5883",
        short: "REGIME",
        group: "\u7ED3\u6784",
        weight: 0.2,
        hint: "\u5F53\u524D ATR \u5728\u8FD1 500 \u6839\u4E2D\u7684\u5206\u4F4D\u3002\u6CE2\u52A8\u8FC7\u4F4E\u6CA1\u6709\u8DDF\u968F\uFF0C\u8FC7\u9AD8\u5219\u6B62\u635F\u88AB\u968F\u673A\u626B\u51FA\uFF1B\u4E2D\u9AD8\u5206\u4F4D\u6700\u6709\u5229\u4E8E\u5F62\u6001\u5151\u73B0\u3002"
      },
      {
        key: "rrQuality",
        label: "\u76EE\u6807\u53EF\u8FBE\u6027",
        short: "REACH",
        group: "\u98CE\u9669",
        weight: 0.6,
        hint: "\u6A21\u578B\u9884\u6D4B\u7684\u662F\u300C\u80DC\u7387\u300D\u800C\u4E0D\u662F\u300C\u8D54\u7387\u300D\uFF1A\u76EE\u6807\u8D8A\u8FDC\uFF08R:R \u8D8A\u9AD8\uFF09\u8D8A\u96BE\u5728\u8D85\u65F6\u524D\u5151\u73B0\uFF0C\u56E0\u6B64\u9AD8 R:R \u5BF9\u80DC\u7387\u662F\u8D1F\u8BC1\u636E\u3002\u540C\u65F6\u6263\u9664\u5F80\u8FD4\u6210\u672C\u5360\u98CE\u9669\u8FC7\u9AD8\u7684\u5F62\u6001\u3002\u8D54\u7387\u7684\u4EF7\u503C\u5728\u671F\u671B\u503C\u4E00\u680F\u5355\u72EC\u4F53\u73B0\u3002"
      },
      // ── 真实订单流因子（OKX 主动买卖成交额 / 持仓量；无真实数据时按近似或记为无数据）──
      {
        key: "cvdDiverge",
        label: "CVD \u6781\u503C\u80CC\u79BB",
        short: "CVD",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.6,
        hint: "\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5356\u5DEE\uFF08CVD\uFF09\u5728\u4E8C\u9876/\u4E8C\u5E95\u5904\u4E0E\u4E00\u9876/\u4E00\u5E95\u5904\u7684\u5DEE\u503C\uFF1A\u4EF7\u683C\u518D\u521B\u7B49\u9AD8/\u7B49\u4F4E\u70B9\uFF0C\u4F46\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5165\uFF08\u9876\uFF09\u6216\u7D2F\u8BA1\u4E3B\u52A8\u5356\u51FA\uFF08\u5E95\uFF09\u6CA1\u6709\u540C\u6B65\u521B\u51FA\u6781\u503C\uFF0C\u8BF4\u660E\u63A8\u52A8\u65B9\u5DF2\u88AB\u52A8\uFF0C\u53CD\u8F6C\u6982\u7387\u4E0A\u5347\u3002"
      },
      {
        key: "sweepTrap",
        label: "\u626B\u4F4D\u9677\u9631\u5019\u9009",
        short: "TRAP",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.65,
        hint: "\u8BF1\u591A / \u8BF1\u7A7A\u5019\u9009\uFF1A\u4EF7\u683C\u523A\u7A7F\u524D\u9AD8/\u524D\u4F4E\u540E\u6536\u56DE\uFF0C\u4E14\u523A\u7A7F\u671F\u95F4\u4E3B\u52A8\u6210\u4EA4\u7AD9\u5728\u53CD\u8F6C\u4E00\u4FA7\u6216\u8FFD\u5355\u653E\u91CF\u88AB\u5438\u6536 \u2192 \u7A81\u7834\u8FFD\u968F\u8005\u53EF\u80FD\u5904\u4E8E\u4E0D\u5229\u4F4D\u7F6E\uFF08\u89E3\u91CA\u6A21\u578B\uFF0C\u975E\u8D26\u6237\u4E8B\u5B9E\uFF09\u3002\u6536\u76D8\u505C\u5728\u5173\u952E\u4F4D\u5916\u4FA7\u4E14\u7A81\u7834\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u5360\u4F18\u5219\u4E3A\u771F\u7A81\u7834\uFF0C\u8BB0\u8D1F\u5206\u3002"
      },
      {
        key: "testDelta",
        label: "\u786E\u8BA4K\u4E3B\u52A8\u65B9\u5411",
        short: "\u0394CONF",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.4,
        hint: "\u62D2\u7EDD / \u786E\u8BA4 K \u7EBF\u5185\u771F\u5B9E\u4E3B\u52A8\u4E70\u5356\u5DEE\u7684\u65B9\u5411\uFF1A\u505A\u7A7A\u8981\u6C42\u4E3B\u52A8\u5356\u51FA\u63A5\u7BA1\uFF0C\u505A\u591A\u8981\u6C42\u4E3B\u52A8\u4E70\u5165\u63A5\u7BA1\u3002\u4EC5\u5728\u8BE5\u6839\u6709\u771F\u5B9E\u4E3B\u52A8\u6210\u4EA4\u6570\u636E\u65F6\u53C2\u4E0E\u8BC4\u5206\u3002"
      },
      {
        key: "oiTrap",
        label: "\u6301\u4ED3\u91CF\u53D8\u5316",
        short: "OI",
        group: "\u8BA2\u5355\u6D41",
        weight: 0.3,
        hint: "\u7B2C\u4E8C\u817F\uFF08\u51B2\u5411\u4E8C\u9876 / \u6740\u5411\u4E8C\u5E95\uFF09\u671F\u95F4\u6C38\u7EED\u6301\u4ED3\u91CF\u7684\u53D8\u5316\uFF1A\u6301\u4ED3\u589E\u52A0\u8BF4\u660E\u603B\u6301\u4ED3\u6269\u5F20\uFF0C\u4F46\u4E0D\u80FD\u8BC6\u522B\u591A\u7A7A\u8EAB\u4EFD\u6216\u8C01\u88AB\u5957\uFF1B\u6301\u4ED3\u51CF\u5C11\u5219\u662F\u5E73\u4ED3\u9A71\u52A8\u7684\u51B2\u523A\uFF0C\u53CD\u8F6C\u540E\u7F3A\u5C11\u71C3\u6599\u3002\u4EC5\u5728\u6709\u6301\u4ED3\u91CF\u6570\u636E\u65F6\u53C2\u4E0E\u8BC4\u5206\u3002"
      }
    ];
    FACTOR_INDEX = FACTORS.reduce(
      (acc, f, i) => ({ ...acc, [f.key]: i }),
      {}
    );
    MODEL = {
      base: -0.15,
      gain: 0.42
    };
    clamp = (v, lo = -1, hi = 1) => v < lo ? lo : v > hi ? hi : v;
    GRADE_BANDS = [
      { grade: "A", min: 0.66, label: "\u9AD8\u6A21\u578B\u5206 \xB7 \u5F85\u9A8C\u8BC1", color: "#2ebd85" },
      { grade: "B", min: 0.58, label: "\u4E2D\u6A21\u578B\u5206 \xB7 \u5F85\u9A8C\u8BC1", color: "#37c8dd" },
      { grade: "C", min: 0.5, label: "\u8FB9\u7F18\u5206\u6570 \xB7 \u89C2\u5BDF", color: "#f0b90b" },
      { grade: "D", min: 0, label: "\u4F4E\u6A21\u578B\u5206 \xB7 \u4E0D\u91C7\u7EB3", color: "#f6465d" }
    ];
  }
});

// src/lib/types.ts
var barMs;
var init_types = __esm({
  "src/lib/types.ts"() {
    "use strict";
    barMs = (bar) => bar === "15m" ? 9e5 : bar === "1m" ? 6e4 : 3e5;
  }
});

// src/quant/flow.ts
function shouldRepairFlow(snap, needsRepair, now = Date.now()) {
  const stale = snap.to > 0 && now - snap.to > snap.barMs * 2;
  if (!needsRepair && !stale) return false;
  return now - (snap.repairedAt ?? 0) > snap.barMs;
}
function bigBiasOf(trades, now = Date.now(), windowMs = 12e4) {
  const win = trades.filter((t) => t.ts >= now - windowMs && t.notional > 0);
  if (win.length < 30) return { bias: null, count: 0, threshold: 0 };
  const sorted = win.map((t) => t.notional).sort((a, b) => a - b);
  const threshold = sorted[Math.min(sorted.length - 1, Math.floor(0.9 * (sorted.length - 1)))];
  let big = win.filter((t) => t.notional > threshold);
  if (big.length < 3) {
    big = [...win].sort((a, b) => b.notional - a.notional).slice(0, Math.max(3, Math.floor(win.length * 0.1)));
  }
  let buy = 0;
  let sell = 0;
  for (const t of big) {
    if (t.side === "buy") buy += t.notional;
    else sell += t.notional;
  }
  if (!big.length || buy + sell <= 0) return { bias: null, count: 0, threshold };
  return { bias: (buy - sell) / (buy + sell), count: big.length, threshold };
}
function hasRealFlow(bar, candleVol, volumeSource) {
  if (volumeSource && volumeSource !== "quote") return false;
  if (!bar || !Number.isFinite(bar.buy) || !Number.isFinite(bar.sell) || bar.buy < 0 || bar.sell < 0 || !(bar.buy + bar.sell > 0) || candleVol == null || !Number.isFinite(candleVol) || !(candleVol > 0)) return false;
  const coverage = (bar.buy + bar.sell) / candleVol;
  return coverage >= (bar.src === "rubik" ? 0.95 : 0.85) && coverage <= 1.1;
}
var init_flow = __esm({
  "src/quant/flow.ts"() {
    "use strict";
    init_types();
  }
});

// src/quant/context.ts
function emaSeries(cs, period) {
  const k = 2 / (period + 1);
  const out = new Array(cs.length);
  let e = cs[0]?.c ?? 0;
  for (let i = 0; i < cs.length; i++) {
    e = i === 0 ? cs[i].c : cs[i].c * k + e * (1 - k);
    out[i] = e;
  }
  return out;
}
function buildContext(cs, flow) {
  const n = cs.length;
  const atr = atrSeries(cs);
  const delta = new Array(n);
  const real = new Uint8Array(n);
  const oi = new Array(n).fill(NaN);
  const vols = new Array(n);
  const volMa = new Array(n).fill(0);
  const index = /* @__PURE__ */ new Map();
  let covered = 0;
  for (let i = 0; i < n; i++) {
    const fb = flow?.bars.get(cs[i].ts);
    if (hasRealFlow(fb, cs[i].v, cs[i].volumeSource)) {
      delta[i] = fb.buy - fb.sell;
      real[i] = 1;
      covered++;
    } else {
      delta[i] = approxDeltaAt(cs, i);
    }
    const position = fb?.oiContracts && fb.oiContracts > 0 ? fb.oiContracts : fb?.oiUsd;
    if (position && position > 0) oi[i] = position;
    vols[i] = cs[i].v;
    index.set(cs[i].ts, i);
  }
  let s = 0;
  for (let i = 0; i < n; i++) {
    if (i >= 1) s += cs[i - 1].v;
    if (i >= 21) s -= cs[i - 21].v;
    const m = Math.min(i, 20);
    volMa[i] = m ? s / m : cs[i].v;
  }
  return {
    cs,
    n,
    atr,
    delta,
    real,
    oi,
    vols,
    ema20: emaSeries(cs, 20),
    ema50: emaSeries(cs, 50),
    volMa,
    index,
    flowCoverage: n ? covered / n : 0
  };
}
var init_context = __esm({
  "src/quant/context.ts"() {
    "use strict";
    init_engine();
    init_flow();
  }
});

// src/quant/orderflow.ts
function windowFlow(ctx, from, to) {
  const a = Math.max(0, Math.min(from, to));
  const b = Math.min(ctx.n - 1, Math.max(from, to));
  let vol = 0;
  let delta = 0;
  let known = 0;
  let base = 0;
  let bars = 0;
  for (let i = a; i <= b; i++) {
    vol += ctx.vols[i];
    delta += ctx.delta[i];
    known += ctx.real[i];
    base += ctx.volMa[i];
    bars++;
  }
  return {
    from: a,
    to: b,
    bars,
    vol,
    delta,
    ratio: vol > 0 ? delta / vol : 0,
    known: bars ? known / bars : 0,
    volRatio: base > 0 ? vol / base : 1
  };
}
function pivotOf(ctx, sig) {
  const pts = sig.geo?.pts ?? [];
  const at = (label) => pts.find((p) => p.label.includes(label));
  const priorPt = at("\u8D77");
  const firstPt = at("\u4E00");
  const neckPt = at("\u9888\u7EBF");
  const secondPt = at("\u4E8C");
  const idxOf = (ts, fallback) => ctx.index.get(ts) ?? fallback;
  const i = sig.idx;
  const prior = idxOf(priorPt?.ts ?? -1, Math.max(0, i - 140));
  const first = idxOf(firstPt?.ts ?? -1, Math.max(0, i - 60));
  const neck = idxOf(neckPt?.ts ?? -1, Math.max(first + 1, i - 12));
  const second = idxOf(secondPt?.ts ?? -1, i);
  return {
    prior,
    first,
    neck,
    second: Math.max(first, second),
    level: firstPt?.price ?? (ctx.cs[first]?.c ?? sig.entry),
    neckPrice: neckPt?.price ?? sig.tp,
    secondPrice: secondPt?.price ?? sig.entry
  };
}
function legsOf(pv) {
  let l1a = Math.min(pv.prior, pv.first);
  let l1b = Math.max(pv.prior, pv.first);
  let l2a = Math.min(pv.neck, pv.second);
  let l2b = Math.max(pv.neck, pv.second);
  if (l1b - l1a < 2) {
    l1a = Math.max(0, pv.first - 24);
    l1b = pv.first;
  }
  if (l2b - l2a < 2) {
    l2a = Math.max(pv.first + 1, pv.second - 24);
    l2b = pv.second;
  }
  return { l1a, l1b, l2a, l2b };
}
function readTouch(ctx, level, idx, testIdx) {
  const { cs, n, atr, delta, vols, volMa } = ctx;
  const i = Math.max(0, Math.min(idx, n - 1));
  const a = Math.max(atr[i] || 0, 1e-9);
  const top = level.side === "top";
  const dir = top ? -1 : 1;
  const up = top ? 1 : -1;
  const px = level.price;
  const over = (v) => (top ? v - px : px - v) / a;
  let t = Math.max(0, Math.min(testIdx ?? i, n - 1));
  if (testIdx == null) {
    for (let q = Math.max(0, i - 5); q <= i; q++) if (top ? cs[q].h > cs[t].h : cs[q].l < cs[t].l) t = q;
  }
  const tb = cs[t];
  const depth = over(top ? tb.h : tb.l);
  const approach = windowFlow(ctx, Math.max(0, t - 4), t);
  const wide = windowFlow(ctx, Math.max(0, t - 12), t);
  const after = i > t ? windowFlow(ctx, t + 1, i) : null;
  const tvol = vols[t];
  const tRatio = tvol > 0 ? delta[t] / tvol : 0;
  const tVol = volMa[t] > 0 ? tvol / volMa[t] : 1;
  const range = Math.max(1e-9, tb.h - tb.l);
  const wick = top ? (tb.h - Math.max(tb.o, tb.c)) / range : (Math.min(tb.o, tb.c) - tb.l) / range;
  const known = ctx.real[t] === 1;
  const inside = over(tb.c) <= 0.05;
  let beyondCloses = 0;
  for (let q = t; q <= i; q++) if (over(cs[q].c) > 0.1) beyondCloses++;
  const accepted = over(cs[i].c) > 0.2 || beyondCloses >= 2;
  const near = depth > -0.5;
  const pressure = clampR(approach.ratio * up * 4);
  const thrust = clamp01((approach.volRatio - 1.2) / 1) * clamp01(pressure * 1.5);
  const e1 = clampR(-pressure - 0.6 * thrust) * approach.known;
  let e2 = 0;
  if (known) {
    if (inside && tVol >= 1.1 && tRatio * up <= 0.05) e2 = 0.8;
    else if (inside && tVol < 0.9) e2 = 0.4;
    else if (!inside && tRatio * up > 0.1 && tVol >= 1.2) e2 = -0.9;
    else if (!inside) e2 = -0.3;
  } else {
    if (inside && tVol < 0.9) e2 = 0.35;
    else if (!inside) e2 = -0.35;
  }
  const e3 = near ? clampR((wick - 0.3) * 2) : 0;
  const e4 = clampR(-wide.ratio * up * 5) * wide.known;
  const e5 = after ? clampR(-after.ratio * up * 4) * after.known : null;
  const wsum = 0.3 + 0.25 + 0.12 + 0.13 + (e5 == null ? 0 : 0.2);
  let ev = (0.3 * e1 + 0.25 * e2 + 0.12 * e3 + 0.13 * e4 + (e5 == null ? 0 : 0.2 * e5)) / wsum;
  if (accepted) ev = Math.min(ev, -0.6);
  ev = clampR(ev * 1.6);
  const buy = top ? "\u4E3B\u52A8\u4E70\u5165" : "\u4E3B\u52A8\u5356\u51FA";
  const sell = top ? "\u4E3B\u52A8\u5356\u51FA" : "\u4E3B\u52A8\u4E70\u5165";
  const word = top ? "\u524D\u9AD8" : "\u524D\u4F4E";
  const src = known ? "" : "\uFF08\u8FD1\u4F3C\uFF09";
  const reasons = [];
  if (accepted) reasons.push(`\u6536\u76D8\u5DF2\u7AD9\u5728${word}\u5916\u4FA7\uFF08${beyondCloses} \u6839\uFF09\uFF1A\u7A81\u7834\u88AB\u63A5\u53D7`);
  if (depth > 0.05 && !accepted) reasons.push(`\u523A\u7834${word} ${depth.toFixed(2)} ATR${inside ? "\u540E\u6536\u56DE" : "\uFF0C\u5C1A\u672A\u6536\u56DE"}`);
  if (pressure <= -0.15) reasons.push(`\u51B2\u5411${word}\u65F6${sell}\u5DF2\u5360\u4F18\uFF08${pct(approach.ratio * -up)}\uFF09\uFF1A\u63A8\u8FDB\u52A8\u80FD\u4E0D\u5728\u7A81\u7834\u65B9${src}`);
  else if (pressure < 0.2) reasons.push(`\u51B2\u5411${word}\u65F6${buy}\u504F\u5F31\uFF08${pct(approach.ratio * up)}\uFF09\uFF1A\u7F3A\u5C11\u7A81\u7834\u52A8\u80FD${src}`);
  else reasons.push(`\u51B2\u5411${word}\u7684${buy}\u5F3A\u52B2\uFF08${pct(approach.ratio * up)}${thrust > 0.3 ? `\uFF0C\u653E\u91CF ${approach.volRatio.toFixed(1)}x` : ""}\uFF09\uFF1A\u5B58\u5728\u771F\u7A81\u7834\u98CE\u9669${src}`);
  if (e2 >= 0.8) reasons.push(`\u89E6${word}\u90A3\u6839\u653E\u91CF ${tVol.toFixed(1)}x \u5374\u6536\u5728\u4F4D\u5185\u3001${buy}\u672A\u5360\u4F18\uFF1A\u7A81\u7834\u76D8\u88AB\u5438\u6536`);
  else if (e2 > 0) reasons.push(`\u89E6${word}\u90A3\u6839\u7F29\u91CF ${tVol.toFixed(1)}x \u4E14\u6536\u5728\u4F4D\u5185\uFF1A\u8FFD\u4EF7\u610F\u613F\u4E0D\u8DB3`);
  else if (e2 <= -0.9) reasons.push(`\u89E6${word}\u90A3\u6839\u653E\u91CF ${tVol.toFixed(1)}x\u3001${buy} ${pct(tRatio * up)} \u4E14\u6536\u5728\u4F4D\u5916\uFF1A\u7A81\u7834\u65B9\u4E3B\u5BFC`);
  if (near && wick >= 0.45) reasons.push(`\u89E6${word}\u90A3\u6839${top ? "\u4E0A" : "\u4E0B"}\u5F71\u7EBF\u5360 ${Math.round(wick * 100)}%\uFF1A\u62D2\u7EDD\u660E\u663E`);
  if (e4 > 0.3) reasons.push(`\u8FD1 12 \u6839\u7D2F\u8BA1${buy}\u6CA1\u6709\u8DDF\u4E0A\u4EF7\u683C\uFF1ACVD \u80CC\u79BB`);
  if (after && e5 != null && e5 > 0.25) reasons.push(`\u89E6\u53CA\u4E4B\u540E${sell}\u63A5\u7BA1\uFF08${pct(-after.ratio * up)}\uFF09`);
  else if (after && e5 != null && e5 < -0.25) reasons.push(`\u89E6\u53CA\u4E4B\u540E${buy}\u7EE7\u7EED\u5360\u4F18\uFF08${pct(after.ratio * up)}\uFF09`);
  const fakeProb = clamp01(logistic(ev * 1.6));
  const breakProb = 1 - fakeProb;
  const kind = accepted ? "accepted" : depth > 0.05 ? "sweep" : depth > -0.35 ? "touch" : "approach";
  const verdict = accepted ? "breakout" : fakeProb >= 0.62 ? "reject" : fakeProb <= 0.4 ? "breakout" : "uncertain";
  const pc = Math.round(fakeProb * 100);
  const act = top ? "\u505A\u7A7A" : "\u505A\u591A";
  const tag = top ? "\u89E6\u9876" : "\u89E6\u5E95";
  const headline = accepted ? top ? "\u6536\u76D8\u7AD9\u4E0A\u524D\u9AD8\uFF1A\u771F\u7A81\u7834\uFF0C\u4E0D\u505A\u7A7A" : "\u6536\u76D8\u8DCC\u7834\u524D\u4F4E\uFF1A\u771F\u8DCC\u7834\uFF0C\u4E0D\u505A\u591A" : verdict === "reject" ? kind === "approach" ? `\u63A5\u8FD1${word}\uFF1A\u8BA2\u5355\u6D41\u504F\u5411\u88AB\u62D2\u7EDD\uFF08\u5047\u7A81\u7834 ${pc}%\uFF09\uFF0C\u89E6\u53CA\u540E\u53EF${act}` : `${tag}\u8BA2\u5355\u6D41\uFF1A\u5047\u7A81\u7834\u6982\u7387 ${pc}% \u2192 \u53EF${act}` : verdict === "breakout" ? `${tag}\u8BA2\u5355\u6D41\uFF1A\u7A81\u7834\u6982\u7387 ${100 - pc}%\uFF08${buy}\u4ECD\u5728\u63A8\u8FDB\uFF09\uFF0C\u4E0D\u62A2${top ? "\u7A7A" : "\u591A"}` : `${tag}\u8BA2\u5355\u6D41\u4E0D\u660E\u6717\uFF08\u5047\u7A81\u7834 ${pc}%\uFF09\uFF1A\u7B49\u62D2\u7EDDK\u6216\u7A81\u7834\u786E\u8BA4`;
  let plan = null;
  if (!accepted) {
    let ext = px;
    for (let q = t; q <= i; q++) ext = top ? Math.max(ext, cs[q].h) : Math.min(ext, cs[q].l);
    const entry = px + dir * 0.1 * a;
    const stop = ext - dir * 0.75 * a;
    const risk = Math.abs(entry - stop);
    let neck = entry;
    for (let q = Math.max(0, level.idx ?? i - 60); q <= i; q++) neck = top ? Math.min(neck, cs[q].l) : Math.max(neck, cs[q].h);
    const dist = Math.min(Math.max(Math.abs(entry - neck), 1.2 * risk), 4 * risk);
    if (risk > 0) plan = { entry: roundPx(entry), stop: roundPx(stop), tp: roundPx(entry + dir * dist), rr: Number((dist / risk).toFixed(1)) };
  }
  return {
    side: level.side,
    dir,
    level: px,
    testIdx: t,
    kind,
    depthAtr: r3(depth),
    approach,
    pressure: r3(pressure),
    bar: { deltaRatio: r3(tRatio), volRatio: r3(tVol), wick: r3(wick), known },
    evidence: r3(ev),
    fakeProb: r3(fakeProb),
    breakProb: r3(breakProb),
    verdict,
    reasons,
    headline,
    plan
  };
}
function readSecondTest(ctx, sig) {
  const { cs, n, atr, delta, vols, volMa, oi } = ctx;
  const i = Math.min(sig.idx, n - 1);
  const a = Math.max(atr[i] || 0, 1e-9);
  const pv = pivotOf(ctx, sig);
  const dir = sig.side === "long" ? 1 : -1;
  const top = dir < 0;
  const { l1a, l1b, l2a, l2b } = legsOf(pv);
  const leg1 = windowFlow(ctx, l1a, l1b);
  const leg2 = windowFlow(ctx, l2a, l2b);
  let cvdFirst = 0;
  let cvdSecond = 0;
  let totalVol = 0;
  let betweenKnown = 0;
  let betweenBars = 0;
  for (let q = l1a; q <= Math.min(n - 1, pv.second); q++) {
    if (q <= pv.first) cvdFirst += delta[q];
    else {
      betweenKnown += ctx.real[q];
      betweenBars++;
    }
    cvdSecond += delta[q];
    totalVol += vols[q];
  }
  const norm = Math.max(1e-9, totalVol * 0.08);
  const cvdCov = betweenBars > 0 ? betweenKnown / betweenBars : 0;
  const flowCov = Math.min(leg1.known, leg2.known);
  const cvdDiv = clampR((cvdSecond - cvdFirst) * dir / norm * cvdCov);
  const legDeltaDiff = clampR((leg2.ratio - leg1.ratio) * dir * 6 * flowCov);
  const v1 = leg1.vol / Math.max(1, leg1.bars);
  const v2 = leg2.vol / Math.max(1, leg2.bars);
  const legVolRatio = v1 > 0 ? v2 / v1 : 1;
  const from = Math.max(0, Math.min(pv.second, i));
  const to = Math.min(n - 1, Math.max(i, pv.second));
  let absorb = 0;
  let breach = 0;
  let deepestIdx = from;
  let depth = 0;
  let sweepBars = 0;
  let sweepFrom = -1;
  let sweepTo = -1;
  for (let q = from; q <= to; q++) {
    const c = cs[q];
    const avg = volMa[q] > 0 ? volMa[q] : c.v || 1;
    const beyond = top ? c.h - pv.level : pv.level - c.l;
    if (beyond > depth) {
      depth = beyond;
    }
    if (top ? c.h > cs[deepestIdx].h : c.l < cs[deepestIdx].l) deepestIdx = q;
    if (beyond > 0.05 * a) {
      sweepBars++;
      if (sweepFrom < 0) sweepFrom = q;
      sweepTo = q;
    }
    if (top) {
      if (c.h >= pv.level - 0.1 * a && c.c <= pv.level - 0.25 * a && c.v >= avg * 1.1) absorb++;
      if (c.c > pv.level + 0.2 * a) breach++;
    } else {
      if (c.l <= pv.level + 0.1 * a && c.c >= pv.level + 0.25 * a && c.v >= avg * 1.1) absorb++;
      if (c.c < pv.level - 0.2 * a) breach++;
    }
  }
  const sweepFlow = sweepFrom >= 0 ? windowFlow(ctx, sweepFrom, sweepTo) : null;
  const last = cs[to];
  const closedInside = top ? last.c <= pv.level : last.c >= pv.level;
  const accepted = top ? last.c > pv.level + 0.2 * a : last.c < pv.level - 0.2 * a;
  const barOf = (q) => ({
    idx: q,
    deltaRatio: vols[q] > 0 ? delta[q] / vols[q] : 0,
    volRatio: volMa[q] > 0 ? vols[q] / volMa[q] : 1,
    known: ctx.real[q] === 1
  });
  const test = barOf(deepestIdx);
  const confirm = { ...barOf(to), closedInside };
  let oiPct = null;
  const oiStart = oi[l2a];
  const oiEnd = oi[Math.min(n - 1, pv.second)];
  if (Number.isFinite(oiStart) && Number.isFinite(oiEnd) && oiStart > 0) oiPct = oiEnd / oiStart - 1;
  const reasons = [];
  let score = 0;
  const depthAtr = depth / a;
  const occurred = sweepBars > 0 && depthAtr >= 0.05;
  const sideWord = top ? "\u963B\u529B" : "\u652F\u6491";
  if (occurred) {
    score += 0.3 + clamp01((depthAtr - 0.1) / 0.5) * 0.15;
    reasons.push(`${top ? "\u4E0A\u7A7F" : "\u4E0B\u7834"}${sideWord} ${depthAtr.toFixed(2)} ATR\uFF08\u626B\u635F\uFF09${closedInside ? "\u540E\u6536\u56DE" : "\uFF0C\u5C1A\u672A\u6536\u56DE"}`);
    if (sweepFlow) {
      const w = sweepFlow.known >= 0.5 ? 1 : 0.5;
      const against = sweepFlow.ratio * dir;
      if (against > 0.05) {
        score += 0.2 * w;
        reasons.push(top ? `\u626B\u9AD8\u671F\u95F4\u4E3B\u52A8\u5356\u51FA\u5360\u4F18\uFF08${pct(sweepFlow.ratio)}\uFF09\uFF1A\u8FFD\u591A\u76D8\u88AB\u53CD\u624B` : `\u626B\u4F4E\u671F\u95F4\u4E3B\u52A8\u4E70\u5165\u5360\u4F18\uFF08${pct(sweepFlow.ratio)}\uFF09\uFF1A\u7834\u4F4D\u5356\u76D8\u88AB\u627F\u63A5`);
      } else if (against < -0.12 && sweepFlow.volRatio >= 1.3 && closedInside) {
        score += 0.2 * w;
        reasons.push(top ? `\u8FFD\u591A\u6210\u4EA4\u653E\u91CF ${sweepFlow.volRatio.toFixed(1)}x \u5374\u88AB\u5438\u6536\uFF0C\u4EF7\u683C\u6536\u56DE` : `\u6050\u614C\u5356\u51FA\u653E\u91CF ${sweepFlow.volRatio.toFixed(1)}x \u5374\u88AB\u5438\u6536\uFF0C\u4EF7\u683C\u6536\u56DE`);
      } else if (against < -0.12 && !closedInside) {
        score -= 0.3;
        reasons.push(`\u7A81\u7834\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u5360\u4F18\uFF08${pct(sweepFlow.ratio)}\uFF09\u4E14\u672A\u6536\u56DE\uFF1A\u66F4\u50CF\u771F\u7A81\u7834`);
      }
    }
  }
  if (cvdDiv > 0.25) {
    score += 0.15;
    reasons.push(top ? "CVD \u80CC\u79BB\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u9AD8\uFF0C\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5165\u672A\u8DDF\u4E0A" : "CVD \u80CC\u79BB\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u4F4E\uFF0C\u7D2F\u8BA1\u4E3B\u52A8\u5356\u51FA\u672A\u8DDF\u4E0A");
  }
  if (legDeltaDiff > 0.3) {
    score += 0.1;
    reasons.push(top ? `\u7B2C\u4E8C\u817F\u4E3B\u52A8\u4E70\u5165 ${pct(leg2.ratio)} \u5F31\u4E8E\u7B2C\u4E00\u817F ${pct(leg1.ratio)}` : `\u7B2C\u4E8C\u817F\u4E3B\u52A8\u5356\u51FA ${pct(-leg2.ratio)} \u5F31\u4E8E\u7B2C\u4E00\u817F ${pct(-leg1.ratio)}`);
  }
  if (oiPct != null && oiPct > 3e-3) {
    score += 0.1;
    reasons.push(top ? `\u51B2\u9AD8\u6BB5\u6301\u4ED3 +${(oiPct * 100).toFixed(2)}%\uFF1A\u65B0\u591A\u5728\u9876\u90E8\u88AB\u5957` : `\u6740\u8DCC\u6BB5\u6301\u4ED3 +${(oiPct * 100).toFixed(2)}%\uFF1A\u65B0\u7A7A\u5728\u5E95\u90E8\u88AB\u5957`);
  }
  if (absorb > 0) {
    score += 0.1;
    reasons.push(`${sideWord}\u4F4D\u51FA\u73B0 ${absorb} \u6839\u653E\u91CF\u523A\u7834\u540E\u6536\u56DE\u7684\u5438\u6536K`);
  }
  if (breach > 0 && !closedInside) {
    score -= 0.25;
    reasons.push(`\u5DF2\u6709 ${breach} \u6839\u6536\u76D8\u505C\u5728${sideWord}\u5916\u4FA7`);
  }
  score = clamp01(score);
  const kind = !accepted && score >= 0.5 ? top ? "bullTrap" : "bearTrap" : null;
  const lean = clamp01(
    0.5 + 0.14 * cvdDiv + 0.1 * legDeltaDiff + 0.08 * clampR((1 - legVolRatio) * 2) + (sweepFlow ? 0.1 * clampR(sweepFlow.ratio * dir * 4) : 0) + 0.08 * clampR(confirm.deltaRatio * dir * 3) - (accepted ? 0.25 : 0)
  );
  const knownAll = (leg1.known * leg1.bars + leg2.known * leg2.bars) / Math.max(1, leg1.bars + leg2.bars);
  const flowSource = sourceOf(knownAll);
  const headline = accepted ? top ? "\u4EF7\u683C\u6536\u76D8\u7AD9\u4E0A\u963B\u529B\uFF1A\u53CC\u9876\u5931\u6548\uFF0C\u53EF\u80FD\u662F\u771F\u7A81\u7834" : "\u4EF7\u683C\u6536\u76D8\u8DCC\u7834\u652F\u6491\uFF1A\u53CC\u5E95\u5931\u6548\uFF0C\u53EF\u80FD\u662F\u771F\u8DCC\u7834" : kind ? top ? "\u8BF1\u591A\uFF1A\u626B\u8FC7\u524D\u9AD8\u540E\u6536\u56DE\uFF0C\u7A81\u7834\u4E70\u76D8\u88AB\u5957" : "\u8BF1\u7A7A\uFF1A\u626B\u8FC7\u524D\u4F4E\u540E\u6536\u56DE\uFF0C\u7834\u4F4D\u5356\u76D8\u88AB\u5957" : occurred ? `${top ? "\u626B\u9AD8" : "\u626B\u4F4E"}\u540E\u6536\u56DE\uFF0C\u4F46\u8BA2\u5355\u6D41\u786E\u8BA4\u4E0D\u8DB3` : top ? "\u7B49\u9AD8\u4E8C\u6B21\u6D4B\u8BD5\uFF1A\u672A\u626B\u524D\u9AD8" : "\u7B49\u4F4E\u4E8C\u6B21\u6D4B\u8BD5\uFF1A\u672A\u626B\u524D\u4F4E";
  return {
    scene: top ? "doubleTop" : "doubleBottom",
    dir,
    level: pv.level,
    neck: pv.neckPrice,
    leg1,
    leg2,
    cvdDiv: r3(cvdDiv),
    legDeltaDiff: r3(legDeltaDiff),
    legVolRatio: r3(legVolRatio),
    test,
    confirm,
    sweep: { occurred, depthAtr: r3(depthAtr), bars: sweepBars, flow: sweepFlow, accepted },
    absorption: { count: absorb, breach },
    oi: { pct: oiPct == null ? null : r3(oiPct) },
    trap: { kind, score: r3(score), reasons },
    touch: readTouch(ctx, { price: pv.level, side: top ? "top" : "bottom", idx: pv.first }, i, deepestIdx),
    lean: r3(lean),
    flowSource,
    headline
  };
}
var clamp01, clampR, r3, pct, logistic, roundPx, sourceOf;
var init_orderflow = __esm({
  "src/quant/orderflow.ts"() {
    "use strict";
    clamp01 = (v) => v < 0 ? 0 : v > 1 ? 1 : v;
    clampR = (v, lo = -1, hi = 1) => v < lo ? lo : v > hi ? hi : v;
    r3 = (v) => Number.isFinite(v) ? Number(v.toFixed(3)) : 0;
    pct = (v) => `${v >= 0 ? "+" : ""}${(v * 100).toFixed(0)}%`;
    logistic = (x) => 1 / (1 + Math.exp(-x));
    roundPx = (v) => Number.isFinite(v) ? Number(v.toFixed(v >= 1e3 ? 2 : 6)) : 0;
    sourceOf = (known) => known >= 0.95 ? "taker" : known <= 0.05 ? "approx" : "mixed";
  }
});

// src/quant/scan.ts
var scan_exports = {};
__export(scan_exports, {
  EXIT_PLANS: () => EXIT_PLANS,
  SCAN_BARS: () => SCAN_BARS,
  buildContext: () => buildContext,
  candidateFrom: () => candidateFrom,
  collectEvidence: () => collectEvidence,
  liveFlowOf: () => liveFlowOf,
  runScan: () => runScan,
  simulateOutcome: () => simulateOutcome,
  simulateWithPlan: () => simulateWithPlan
});
function collectEvidence(ctx, sig, live) {
  const { cs, n, atr, delta, vols, ema20, ema50, volMa } = ctx;
  const i = Math.min(sig.idx, n - 1);
  const a = Math.max(atr[i] || 0, 1e-9);
  const pv = pivotOf(ctx, sig);
  const dir = sig.side === "long" ? 1 : -1;
  const out = new Array(FACTORS.length).fill(null);
  const isTouch = sig.fill === "limit";
  const { l1a, l1b, l2a, l2b } = legsOf(pv);
  const read2 = readSecondTest(ctx, sig);
  const set = (key, v) => {
    out[FACTOR_INDEX[key]] = v == null || !Number.isFinite(v) ? null : clamp(v);
  };
  const v1 = sum(vols, l1a, l1b) / Math.max(1, l1b - l1a + 1);
  const v2 = sum(vols, l2a, l2b) / Math.max(1, l2b - l2a + 1);
  set("volDiverge", v1 + v2 > 0 ? (v1 - v2) / ((v1 + v2) / 2) * 1.1 : 0);
  set("deltaDiverge", read2.legDeltaDiff);
  set("absorption", (read2.absorption.count - read2.absorption.breach) / 2);
  const deepest = cs[read2.test.idx];
  const dr = Math.max(1e-9, deepest.h - deepest.l);
  const tail = dir > 0 ? (Math.min(deepest.o, deepest.c) - deepest.l) / dr : (deepest.h - Math.max(deepest.o, deepest.c)) / dr;
  const cb = cs[i];
  const cRange = Math.max(1e-9, cb.h - cb.l);
  const closePos2 = (cb.c - cb.l) / cRange;
  set(
    "wickReject",
    (tail - 0.3) * 1.8 + (isTouch ? 0 : (dir > 0 ? closePos2 - 0.5 : 0.5 - closePos2) * 1.6)
  );
  if (live) {
    set("thrustVolume", isTouch || live.volRatio == null ? null : ((live.volRatio || 0) - 1) / 1);
    set("bookImbalance", live.bookImb == null ? null : (live.bookImb || 0) * 2 * dir);
    set("tapeBias", live.bigBias == null ? null : (live.bigBias || 0) * 1.5 * dir);
  }
  const to = Math.min(n - 1, Math.max(i, pv.second));
  let touches = 0;
  let broken = false;
  for (let q = Math.max(0, pv.first); q <= to; q++) {
    const c = cs[q];
    const extreme = dir > 0 ? c.l : c.h;
    if (Math.abs(extreme - pv.level) <= 0.25 * a) touches++;
    if (dir > 0 ? c.c < pv.level - 0.15 * a : c.c > pv.level + 0.15 * a) broken = true;
  }
  const sweepReclaim = read2.sweep.occurred && read2.confirm.closedInside;
  set("levelIntegrity", 0.4 - (Math.min(touches, 5) - 2) * 0.3 + (sweepReclaim ? 0.35 : 0) - (broken ? 0.6 : 0));
  const height = (pv.neckPrice - pv.level) * dir;
  set("patternHeight", (height / a - 2.2) / 2.5);
  const span = Math.max(1, i - pv.first);
  set("patternSpan", 1 - clamp(Math.abs(Math.log(span / 110)) / Math.log(4), 0, 1) * 2);
  const stretch = (ema20[i] - ema50[i]) / a * -dir;
  set("trendExhaust", 1 - clamp(Math.abs(stretch + 0.3) / 1.9, 0, 1) * 2);
  const mag1 = Math.abs(pv.level - (dir > 0 ? cs[Math.min(l1a, n - 1)]?.h ?? pv.level : cs[Math.min(l1a, n - 1)]?.l ?? pv.level));
  const slope1 = mag1 / Math.max(1, l1b - l1a);
  const slope2 = Math.abs(pv.neckPrice - pv.secondPrice) / Math.max(1, l2b - l2a);
  set("legDecel", slope2 > 0 ? (slope1 / slope2 - 1) * 0.8 : 0);
  const look = 500;
  let below = 0;
  let seen = 0;
  for (let q = Math.max(1, i - look); q <= i; q++) {
    if (atr[q] <= 0) continue;
    seen++;
    if (atr[q] <= a) below++;
  }
  const pct2 = seen > 20 ? below / seen : 0.5;
  set("volRegime", 1 - clamp(Math.abs(pct2 - 0.6) / 0.42, 0, 1) * 1.7);
  const risk = Math.abs(sig.entry - sig.stop);
  const rr = risk > 0 ? Math.abs(sig.tp - sig.entry) / risk : 0;
  const costDrag = sig.entry > 0 && risk > 0 ? Math.abs(sig.entry) * 2 * (FEE_RATE + SLIP_RATE) / risk : 9;
  set("rrQuality", clamp((2.1 - rr) / 1.1) - clamp((costDrag - 0.18) / 0.5, 0, 1) * 0.8);
  set("cvdDiverge", read2.cvdDiv);
  if (read2.sweep.accepted) set("sweepTrap", -0.8);
  else if (read2.sweep.occurred) set("sweepTrap", (read2.trap.score - 0.35) / 0.45);
  else set("sweepTrap", 0);
  set("touchFlow", read2.touch.evidence);
  set("testDelta", !isTouch && read2.confirm.known ? read2.confirm.deltaRatio * dir * 3 : null);
  set("oiTrap", read2.oi.pct == null ? null : read2.oi.pct / 6e-3 * 1);
  void volMa;
  void delta;
  return out;
}
function simulateOutcome(ctx, sig, mode, maxHold) {
  const { cs, n } = ctx;
  const i = sig.idx;
  if (i < 30 || i > n - 2) return null;
  const limit = mode === "touch";
  const next = cs[i + 1];
  let entryPrice;
  let entryTs;
  if (limit) {
    entryPrice = sig.entry;
    entryTs = sig.ts;
  } else {
    if (sig.side === "long" ? next.o <= sig.stop || next.o >= sig.tp : next.o >= sig.stop || next.o <= sig.tp) {
      return {
        filled: false,
        why: "gap",
        entryPrice: 0,
        entryTs: 0,
        exitPrice: 0,
        exitTs: 0,
        r: 0,
        pnlPct: 0,
        holdingBars: 0,
        costR: 0
      };
    }
    entryPrice = sig.side === "long" ? next.o * (1 + SLIP_RATE) : next.o * (1 - SLIP_RATE);
    entryTs = next.ts;
  }
  let exitPrice = null;
  let exitTs = 0;
  let why = "time";
  let exitIdx = -1;
  const endJ = Math.min(i + maxHold, n - 1);
  for (let j = limit ? i : i + 1; j <= endJ; j++) {
    const k = cs[j];
    const hitSL = sig.side === "long" ? k.l <= sig.stop : k.h >= sig.stop;
    const hitTP = !(limit && j === i) && (sig.side === "long" ? k.h >= sig.tp : k.l <= sig.tp);
    if (hitSL) {
      exitPrice = sig.stop;
      why = "sl";
    } else if (hitTP) {
      exitPrice = sig.tp;
      why = "tp";
    }
    if (exitPrice != null) {
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
  }
  if (exitPrice == null) {
    exitPrice = cs[endJ].c;
    exitTs = cs[endJ].ts;
    exitIdx = endJ;
  }
  const exitAdj = sig.side === "long" ? exitPrice * (1 - SLIP_RATE) : exitPrice * (1 + SLIP_RATE);
  const gross = sig.side === "long" ? exitAdj - entryPrice : entryPrice - exitAdj;
  const fee = (entryPrice + exitAdj) * FEE_RATE;
  const slipCost = (limit ? exitPrice : next.o + exitPrice) * SLIP_RATE;
  const pnl = gross - fee;
  const risk = sig.side === "long" ? entryPrice - sig.stop : sig.stop - entryPrice;
  return {
    filled: true,
    why,
    entryPrice: r6(entryPrice),
    entryTs,
    exitPrice: r6(exitAdj),
    exitTs,
    r: r32(risk > 0 ? pnl / risk : 0),
    pnlPct: r32(pnl / entryPrice * 100),
    holdingBars: Math.max(1, exitIdx - i),
    costR: r32(risk > 0 ? (fee + slipCost) / risk : 0)
  };
}
function candidateFrom(ctx, sig, mode, maxHold, live, sym, bar, plan = "neck") {
  if (sig.idx < 30 || sig.idx > ctx.n - 1) return null;
  const evidence = collectEvidence(ctx, sig, sig.idx >= ctx.n - 1 ? live : void 0);
  const score = scoreEvidence(evidence);
  const pv = pivotOf(ctx, sig);
  const read2 = readSecondTest(ctx, sig);
  const risk = Math.abs(sig.entry - sig.stop);
  const rr = risk > 0 ? Math.abs(sig.tp - sig.entry) / risk : 0;
  const outcome = simulateWithPlan(ctx, sig, mode, maxHold, plan);
  const proba = r32(score.proba);
  const prefix = `${sym ? `${sym}_` : ""}${bar ? `${bar}_` : ""}`;
  return {
    id: `${prefix}${mode}_${sig.ts}_${sig.pattern}_${sig.side}`,
    idx: sig.idx,
    ts: sig.ts,
    side: sig.side,
    pattern: sig.pattern,
    mode,
    level: r6(pv.level),
    neck: r6(pv.neckPrice),
    firstTs: ctx.cs[pv.first]?.ts ?? sig.ts,
    secondTs: ctx.cs[pv.second]?.ts ?? sig.ts,
    entry: r6(sig.entry),
    stop: r6(sig.stop),
    tp: r6(sig.tp),
    structure: Math.round(sig.strength ?? sig.conf),
    proba,
    grade: gradeOf(proba),
    evidence: evidence.map((v) => v == null ? null : r32(v)),
    parts: score.parts.map((v) => r32(v)),
    tags: [...read2.trap.kind ? [read2.trap.kind === "bullTrap" ? "\u8BF1\u591A\xB7\u626B\u4F4D\u6536\u56DE\u5019\u9009" : "\u8BF1\u7A7A\xB7\u626B\u4F4D\u6536\u56DE\u5019\u9009"] : [], ...sig.tags ?? []],
    note: sig.note ?? "",
    trap: read2.trap.kind,
    trapScore: read2.trap.score,
    flowSource: read2.flowSource,
    headline: read2.headline,
    read: read2,
    rr: r1(rr),
    heightAtr: r1((pv.neckPrice - pv.level) * (sig.side === "long" ? 1 : -1) / Math.max(1e-9, ctx.atr[sig.idx])),
    spanBars: Math.max(0, sig.idx - pv.first),
    live: sig.idx >= ctx.n - 2,
    sym,
    bar,
    outcome,
    exits: {
      neck: plan === "neck" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "neck"),
      r15: plan === "r15" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "r15"),
      r10: plan === "r10" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "r10"),
      be: plan === "be" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "be"),
      partial: plan === "partial" ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, "partial")
    }
  };
}
function runScan(cs, bar, live, sym, plan = "neck", flow) {
  const ctx = buildContext(cs, flow);
  const maxHold = bar === "15m" ? MAX_HOLD_15M : MAX_HOLD_5M;
  const pick = (mode) => {
    const p = {
      ...DEFAULT_PARAMS,
      entryMode: mode === "touch" ? "limit" : "confirm",
      trendBlock: 50
    };
    return scanDoubles(cs, p).signals.map((s) => candidateFrom(ctx, s, mode, maxHold, live, sym, bar, plan)).filter((c) => !!c);
  };
  return { confirm: pick("confirm"), touch: pick("touch"), ctx };
}
function liveFlowOf(cs, bookImb, bigBias) {
  const n = cs.length;
  if (n < 2) return { bookImb: null, bigBias: null, volRatio: null };
  let av = 0;
  let m = 0;
  for (let q = Math.max(0, n - 21); q < n - 1; q++) {
    av += cs[q].v;
    m++;
  }
  const last = cs[n - 1];
  return { bookImb: bookImb ?? null, bigBias: bigBias ?? null, volRatio: m && av > 0 ? last.v / (av / m) : null };
}
function simulateWithPlan(ctx, sig, mode, maxHold, plan) {
  if (plan === "neck") return simulateOutcome(ctx, sig, mode, maxHold);
  const { cs, n, atr } = ctx;
  const i = sig.idx;
  if (i < 30 || i > n - 2) return null;
  const limit = mode === "touch";
  const next = cs[i + 1];
  const dir = sig.side === "long" ? 1 : -1;
  let entryPrice;
  let entryTs;
  if (limit) {
    entryPrice = sig.entry;
    entryTs = sig.ts;
  } else {
    if (dir > 0 ? next.o <= sig.stop : next.o >= sig.stop) {
      return { filled: false, why: "gap", entryPrice: 0, entryTs: 0, exitPrice: 0, exitTs: 0, r: 0, pnlPct: 0, holdingBars: 0, costR: 0 };
    }
    entryPrice = dir > 0 ? next.o * (1 + SLIP_RATE) : next.o * (1 - SLIP_RATE);
    entryTs = next.ts;
  }
  const risk = (entryPrice - sig.stop) * dir;
  if (!(risk > 0)) return null;
  const target = plan === "r10" ? entryPrice + dir * risk : plan === "r15" ? entryPrice + dir * 1.5 * risk : sig.tp;
  if (!limit && (dir > 0 ? next.o >= target : next.o <= target)) {
    return { filled: false, why: "gap", entryPrice: 0, entryTs: 0, exitPrice: 0, exitTs: 0, r: 0, pnlPct: 0, holdingBars: 0, costR: 0 };
  }
  const trigger = entryPrice + dir * risk;
  const targetBeforeTrigger = (target - entryPrice) * dir < risk;
  const useBe = plan === "be" || plan === "partial";
  const half = plan === "partial";
  let stop = sig.stop;
  let armed = false;
  let tookHalf = false;
  let halfExitAdj = 0;
  let lockedR = 0;
  let exitPrice = null;
  let exitTs = 0;
  let why = "time";
  let exitIdx = -1;
  const endJ = Math.min(i + maxHold, n - 1);
  const feePct = FEE_RATE;
  for (let j = limit ? i : i + 1; j <= endJ; j++) {
    const k = cs[j];
    const hitStop = dir > 0 ? k.l <= stop : k.h >= stop;
    const hitTrig = useBe && !armed && !(limit && j === i) && (dir > 0 ? k.h >= trigger : k.l <= trigger);
    const hitTarget = !(limit && j === i) && (dir > 0 ? k.h >= target : k.l <= target);
    if (hitStop) {
      exitPrice = stop;
      why = armed ? "be" : "sl";
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
    if (targetBeforeTrigger && hitTarget) {
      exitPrice = target;
      why = "tp";
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
    if (hitTrig) {
      armed = true;
      stop = entryPrice * (1 + dir * feePct * 2);
      if (half && !tookHalf) {
        tookHalf = true;
        const trigAdj = dir > 0 ? trigger * (1 - SLIP_RATE) : trigger * (1 + SLIP_RATE);
        halfExitAdj = trigAdj;
        const halfGross = (trigAdj - entryPrice) * dir;
        const halfFee = (entryPrice + trigAdj) * FEE_RATE;
        lockedR = 0.5 * ((halfGross - halfFee) / risk);
      }
    }
    if (hitTarget) {
      exitPrice = target;
      why = "tp";
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
  }
  if (exitPrice == null) {
    exitPrice = cs[endJ].c;
    exitTs = cs[endJ].ts;
    exitIdx = endJ;
  }
  const exitAdj = dir > 0 ? exitPrice * (1 - SLIP_RATE) : exitPrice * (1 + SLIP_RATE);
  const gross = (exitAdj - entryPrice) * dir;
  const fee = (entryPrice + exitAdj) * FEE_RATE;
  const pnl = gross - fee;
  const restR = pnl / risk;
  const r = tookHalf ? lockedR + 0.5 * restR : restR;
  const entrySlip = limit ? 0 : next.o * SLIP_RATE;
  const totalFees = entryPrice * FEE_RATE + (tookHalf ? 0.5 * halfExitAdj * FEE_RATE : 0) + (tookHalf ? 0.5 : 1) * exitAdj * FEE_RATE;
  const totalCost = totalFees + entrySlip + (tookHalf ? 0.5 * trigger * SLIP_RATE : 0) + (tookHalf ? 0.5 : 1) * exitPrice * SLIP_RATE;
  void atr;
  return {
    filled: true,
    // `be` describes the exit mechanism, not the sign of the final R.
    // Fees/slippage can make a break-even stop slightly negative; reclassifying
    // it as `sl` corrupts tp/sl/time/be statistics.
    why,
    entryPrice: r6(entryPrice),
    entryTs,
    exitPrice: r6(exitAdj),
    exitTs,
    r: r32(r),
    pnlPct: r32(tookHalf ? r * (risk / entryPrice) * 100 : pnl / entryPrice * 100),
    holdingBars: Math.max(1, exitIdx - i),
    costR: r32(totalCost / risk)
  };
}
var r6, r32, r1, sum, SCAN_BARS, EXIT_PLANS;
var init_scan = __esm({
  "src/quant/scan.ts"() {
    "use strict";
    init_engine();
    init_model();
    init_context();
    init_orderflow();
    r6 = (v) => Number.isFinite(v) ? Number(v.toFixed(v >= 1e3 ? 2 : 6)) : 0;
    r32 = (v) => Number.isFinite(v) ? Number(v.toFixed(3)) : 0;
    r1 = (v) => Number.isFinite(v) ? Number(v.toFixed(1)) : 0;
    sum = (arr, from, to) => {
      let s = 0;
      for (let i = Math.max(0, from); i <= Math.min(arr.length - 1, to); i++) s += arr[i];
      return s;
    };
    SCAN_BARS = (bar) => bar === "15m" ? 4320 : 8640;
    EXIT_PLANS = [
      { id: "neck", label: "\u9888\u7EBF\u76EE\u6807", hint: "\u539F\u65B9\u6848\uFF1A\u76EE\u6807\u770B\u9888\u7EBF\uFF08\u53D7 maxRR \u5C01\u9876\uFF09\uFF0C\u8D85\u65F6\u6309\u6536\u76D8\u4EF7\u5E73\u4ED3" },
      { id: "r15", label: "\u56FA\u5B9A 1.5R", hint: "\u76EE\u6807 = \u5165\u573A \xB1 1.5 \u500D\u98CE\u9669\uFF0C\u653E\u5F03\u8FDC\u7AEF\u9888\u7EBF\uFF0C\u6362\u53D6\u66F4\u9AD8\u5151\u73B0\u7387" },
      { id: "r10", label: "\u56FA\u5B9A 1.0R", hint: "\u76EE\u6807 = \u5165\u573A \xB1 1 \u500D\u98CE\u9669\uFF0C\u901A\u5E38\u5151\u73B0\u7387\u8F83\u9AD8\u4F46\u8D54\u4ED8\u6BD4\u8F83\u4F4E\uFF0C\u6210\u672C\u5360\u6BD4\u654F\u611F" },
      { id: "be", label: "1R \u4FDD\u672C", hint: "\u76C8\u5229\u8FBE\u5230 1R \u540E\u628A\u6B62\u635F\u79FB\u5230\u6210\u672C\u4EF7\uFF0C\u5269\u4F59\u4ED3\u4F4D\u7EE7\u7EED\u770B\u9888\u7EBF\uFF0C\u964D\u4F4E\u56DE\u5410\u98CE\u9669\uFF1B\u6ED1\u70B9/\u8DF3\u7A7A\u4ECD\u53EF\u80FD\u4E8F\u635F" },
      { id: "partial", label: "1R \u51CF\u534A + \u4FDD\u672C", hint: "1R \u5904\u5E73\u6389\u4E00\u534A\u5E76\u9501\u5B9A\u6210\u672C\uFF0C\u5269\u4F59\u4E00\u534A\u8DD1\u9888\u7EBF\u76EE\u6807" }
    ];
  }
});

// tests/audit-fixes.test.ts
import assert from "node:assert/strict";

// src/lib/engine.ts
init_engine();
init_engine();
init_scan();
init_model();

// src/quant/config.ts
var DEFAULT_CONFIG = {
  threshold: 0.58,
  entryMode: "confirm",
  replaceConfFilter: true
};
var KEY = "pulsedesk.confirm-engine.v1";
var current = { ...DEFAULT_CONFIG };
var listeners = /* @__PURE__ */ new Set();
function read() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_CONFIG };
    const parsed = JSON.parse(raw);
    return {
      threshold: typeof parsed.threshold === "number" ? parsed.threshold : DEFAULT_CONFIG.threshold,
      entryMode: parsed.entryMode === "touch" ? "touch" : "confirm",
      replaceConfFilter: parsed.replaceConfFilter ?? DEFAULT_CONFIG.replaceConfFilter
    };
  } catch {
    return { ...DEFAULT_CONFIG };
  }
}
function getConfig() {
  return current;
}
if (typeof window !== "undefined") {
  current = read();
  window.addEventListener("storage", (event) => {
    if (event.key === KEY) {
      current = read();
      listeners.forEach((fn) => fn(current));
    }
  });
}

// src/lib/candles.ts
init_types();

// src/lib/okxVolume.ts
init_types();

// src/lib/okxCandles.ts
function isClosedCandle(c, intervalMs, now = Date.now(), legacyGraceMs = 1500) {
  if (c.confirm === 1) return true;
  if (c.confirm === 0) return false;
  return Number.isFinite(c.ts) && c.ts + intervalMs + legacyGraceMs <= now;
}

// src/lib/candles.ts
function closedCandles(candles, bar, now = Date.now()) {
  const interval = barMs(bar);
  return candles.filter((c) => isClosedCandle(c, interval, now));
}

// src/lib/engine.ts
var maxHoldOf = (bar) => bar === "15m" ? MAX_HOLD_15M : MAX_HOLD_5M;
var paramsFor = (mode, base) => ({
  ...base ?? DEFAULT_PARAMS,
  entryMode: mode === "touch" ? "limit" : "confirm",
  trendBlock: 50
});
function annotate(sig, proba, mode) {
  const grade = gradeMeta(
    proba >= 0.66 ? "A" : proba >= 0.58 ? "B" : proba >= 0.5 ? "C" : "D"
  );
  const pct2 = Math.round(proba * 100);
  const entryTag = mode === "confirm" ? "\u7B49\u786E\u8BA4K" : "\u89E6\u4EF7\u6302\u5355";
  return {
    conf: sig.conf,
    confl: pct2,
    tags: [`\u786E\u8BA4 ${pct2}% \xB7 ${grade.grade}\u7EA7`, entryTag, ...sig.tags ?? []],
    note: `${sig.note ?? PATTERN_META[sig.pattern].label} \xB7 \u8BA2\u5355\u6D41\u786E\u8BA4\u6982\u7387 ${pct2}%\uFF08${grade.label}\uFF09`
  };
}
function simulate(cs, symbol, bar, opts, p = DEFAULT_PARAMS, confMin = CONF_MIN, flow) {
  cs = closedCandles(cs, bar);
  const cfg = getConfig();
  const mode = opts.entryMode ?? cfg.entryMode;
  const baseThreshold = opts.threshold ?? cfg.threshold;
  const replaceConf = opts.replaceConfFilter ?? cfg.replaceConfFilter;
  const threshold = opts.flowFilter ? Math.min(0.9, baseThreshold + 0.05) : baseThreshold;
  const ctx = buildContext(cs, flow);
  const maxHold = maxHoldOf(bar);
  const { signals } = scanDoubles(cs, paramsFor(mode, p));
  const recs = [];
  for (const s of signals) {
    const cand = candidateFrom(ctx, s, mode, maxHold);
    if (!cand) continue;
    const meta = annotate(s, cand.proba, mode);
    const base = {
      id: `${symbol}_${bar}_${s.ts}_${s.pattern}_${s.side}`,
      sym: symbol,
      ts: s.ts,
      side: s.side,
      pattern: s.pattern,
      entry: s.entry,
      stop: s.stop,
      tp: s.tp,
      conf: meta.conf,
      confl: meta.confl,
      note: meta.note,
      tags: meta.tags,
      geo: s.geo,
      status: "skipped"
    };
    if (opts.flowFilter && !replaceConf && s.conf < confMin) continue;
    if (!cand.outcome) continue;
    if (cand.proba < threshold || !cand.outcome.filled) {
      recs.push({
        ...base,
        ...{
          proba: cand.proba,
          grade: cand.grade,
          evidence: cand.evidence,
          rejectReason: cand.outcome ? cand.proba < threshold ? "confirm" : "unfilled" : "noNextBar"
        }
      });
      continue;
    }
    const o = cand.outcome;
    recs.push({
      ...base,
      status: "done",
      entryTs: o.entryTs,
      entryPrice: o.entryPrice,
      exitPrice: o.exitPrice,
      exitTs: o.exitTs,
      r: o.r,
      pnlPct: o.pnlPct,
      costR: o.costR,
      holdingBars: o.holdingBars,
      // 原始 TradedSignal.exitReason 只有 tp/sl/time；保本(be)归入 time 以兼容 remote 统计，
      // 真实退出原因通过 exitWhy 保留（quant 层 Outcome.why 本身就区分 be）。
      exitReason: o.why === "gap" || o.why === "be" ? "time" : o.why,
      ...{ proba: cand.proba, grade: cand.grade, evidence: cand.evidence, rr: cand.rr, exitWhy: o.why }
    });
  }
  return recs;
}

// tests/audit-fixes.test.ts
init_scan();

// src/quant/stats.ts
init_model();
var EMPTY = {
  detected: 0,
  traded: 0,
  wins: 0,
  losses: 0,
  flat: 0,
  flatRate: 0,
  winRate: 0,
  avgR: 0,
  totalR: 0,
  pf: 0,
  maxDD: 0,
  avgHold: 0,
  tpRate: 0,
  slRate: 0,
  timeRate: 0,
  beRate: 0,
  payoff: 0,
  volR: 0,
  sharpeR: 0
};
var tradable = (c) => !!c.outcome?.filled && Number.isFinite(c.outcome.r);
function summarize(cands, threshold = 0) {
  const detected = cands.filter(tradable);
  const done = detected.filter((c) => c.proba >= threshold).map((c) => c.outcome).sort((a, b) => a.exitTs - b.exitTs);
  if (!done.length) return { ...EMPTY, detected: detected.length };
  let grossWin = 0;
  let grossLoss = 0;
  let wins = 0;
  let losses = 0;
  let flat = 0;
  let tp = 0;
  let sl = 0;
  let time = 0;
  let be = 0;
  let hold = 0;
  let cum = 0;
  let peak = 0;
  let maxDD = 0;
  const rs = [];
  for (const o of done) {
    const r = o.r;
    rs.push(r);
    if (r > 0) {
      wins++;
      grossWin += r;
    } else if (r < 0) {
      losses++;
      grossLoss += -r;
    } else {
      flat++;
    }
    if (o.why === "tp") tp++;
    else if (o.why === "sl") sl++;
    else if (o.why === "be") be++;
    else time++;
    hold += o.holdingBars;
    cum += r;
    if (cum > peak) peak = cum;
    if (peak - cum > maxDD) maxDD = peak - cum;
  }
  const n = done.length;
  const avgR = cum / n;
  const sd = Math.sqrt(rs.reduce((s, r) => s + (r - avgR) ** 2, 0) / n);
  const avgWin = wins ? grossWin / wins : 0;
  const avgLoss = losses ? grossLoss / losses : 0;
  return {
    detected: detected.length,
    traded: n,
    wins,
    losses,
    flat,
    flatRate: flat / n * 100,
    winRate: wins / n * 100,
    avgR,
    totalR: cum,
    pf: grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? 99 : 0,
    maxDD,
    avgHold: hold / n,
    tpRate: tp / n * 100,
    slRate: sl / n * 100,
    timeRate: time / n * 100,
    beRate: be / n * 100,
    payoff: avgLoss > 0 ? avgWin / avgLoss : avgWin > 0 ? 99 : 0,
    volR: sd,
    sharpeR: sd > 0 ? avgR / sd : 0
  };
}

// tests/legacy-synth.ts
init_types();
function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = a + 1831565813 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
var SYNTH_BASE = {
  "BTC-USDT-SWAP": { price: 97400, vol: 11e-4, volUnit: 9200 },
  "ETH-USDT-SWAP": { price: 3625, vol: 16e-4, volUnit: 26e3 },
  "SOL-USDT-SWAP": { price: 214, vol: 22e-4, volUnit: 42e3 }
};
function legacyTrendCandles(symbol, bar, count, endTs) {
  const cfg = SYNTH_BASE[symbol] ?? { price: 100, vol: 2e-3, volUnit: 1e3 };
  const bm = barMs(bar);
  const dayKey = Math.floor((endTs ?? Date.now()) / 864e5);
  const rng = mulberry32(hashStr(`${symbol}|${bar}|${dayKey}`));
  const lastStart = Math.floor((endTs ?? Date.now()) / bm) * bm - bm;
  const start = lastStart - (count - 1) * bm;
  const out = [];
  let price = cfg.price * (0.97 + rng() * 0.06);
  let regime = 0;
  for (let i = 0; i < count; i++) {
    regime = regime * 0.982 + (rng() - 0.5) * 0.09;
    if (rng() < 0.012) regime += (rng() - 0.5) * 0.9;
    const vScale = 1 + 1.6 * Math.abs(regime) + (rng() < 0.06 ? rng() * 2.4 : 0);
    const ret = regime * 0.16 + (rng() + rng() - 1) * cfg.vol * vScale;
    const o = price * (rng() < 0.02 ? 1 + (rng() - 0.5) * cfg.vol * 6 : 1);
    let p = o;
    let hi = o;
    let lo = o;
    let pc = o;
    for (let s = 0; s < 4; s++) {
      pc = p * (1 + ret / 4 + (rng() - 0.5) * cfg.vol * 0.55 * vScale);
      p = pc;
      hi = Math.max(hi, p);
      lo = Math.min(lo, p);
    }
    const c = p;
    hi = Math.max(hi, o, c) * (1 + rng() * cfg.vol * 0.5 * vScale);
    lo = Math.min(lo, o, c) * (1 - rng() * cfg.vol * 0.5 * vScale);
    const bodyPct = Math.abs(c - o) / o;
    const v = cfg.volUnit * (0.45 + rng() * 0.8) * (1 + bodyPct / cfg.vol / 2.2) * c;
    out.push({ ts: start + i * bm, o, h: hi, l: lo, c, v });
    price = c;
  }
  return out;
}

// tests/audit-fixes.test.ts
init_flow();
var keyOf = (s) => `${s.ts}|${s.pattern}|${s.side}`;
var passed = 0;
var ok = (name) => {
  passed++;
  console.log(`  \u2713 ${name}`);
};
{
  let discriminating = 0;
  let checked = 0;
  for (const seed of [1, 2, 3, 4, 5, 6]) {
    const cs = legacyTrendCandles("BTC-USDT-SWAP", "5m", 2400, 176e10 + seed * 864e5);
    const hardBlock = scanDoubles(cs, { ...DEFAULT_PARAMS, entryMode: "confirm" });
    const softBlock = scanDoubles(cs, { ...DEFAULT_PARAMS, entryMode: "confirm", trendBlock: 50 });
    console.log(`    seed=${seed} trendBlock=1 \u2192 ${hardBlock.signals.length} \u4FE1\u53F7 / trendBlock=50 \u2192 ${softBlock.signals.length} \u4FE1\u53F7`);
    if (hardBlock.signals.length === softBlock.signals.length) continue;
    discriminating++;
    const scan = runScan(cs, "5m");
    const expect = softBlock.signals.map(keyOf).sort();
    const actual = scan.confirm.map((c) => keyOf({ ts: c.ts, pattern: c.pattern, side: c.side })).sort();
    assert.deepEqual(actual, expect, "runScan \u5FC5\u987B\u4E0E trendBlock=50 \u7684\u626B\u63CF\u7ED3\u679C\u5B8C\u5168\u4E00\u81F4");
    assert.ok(actual.length > hardBlock.signals.length, "\u5173\u95ED\u786C\u5C4F\u853D\u540E\u5E94\u6062\u590D\u88AB\u8BEF\u6740\u7684\u4FE1\u53F7");
    checked++;
    if (checked >= 2) break;
  }
  assert.ok(discriminating > 0, "\u5408\u6210\u6570\u636E\u672A\u80FD\u89E6\u53D1 trendBlock \u5DEE\u5F02\uFF0C\u6D4B\u8BD5\u5931\u53BB\u533A\u5206\u5EA6");
  ok(`T3 \u4E24\u6761\u7B56\u7565\u8DEF\u5F84\u4FE1\u53F7\u96C6\u5408\u4E00\u81F4\uFF08${checked} \u7EC4\u6709\u533A\u5206\u5EA6\u7684\u6570\u636E\uFF09`);
}
{
  const cs = legacyTrendCandles("BTC-USDT-SWAP", "5m", 8640, 176e10 + 3 * 864e5);
  const base = { flowFilter: false, maxHold: 96 };
  const loose = simulate(cs, "BTC-USDT-SWAP", "5m", { ...base, threshold: 0.42, entryMode: "confirm" });
  const strict = simulate(cs, "BTC-USDT-SWAP", "5m", { ...base, threshold: 0.82, entryMode: "confirm" });
  const done = (r) => r.filter((x) => x.status === "done").length;
  assert.ok(done(loose) > 0, "\u5408\u6210\u6570\u636E\u5E94\u4EA7\u751F\u53EF\u6210\u4EA4\u6837\u672C");
  assert.ok(done(strict) < done(loose), `\u63D0\u9AD8\u95E8\u69DB\u5FC5\u987B\u51CF\u5C11\u6210\u4EA4\u7B14\u6570\uFF08${done(strict)} !< ${done(loose)}\uFF09`);
  assert.ok(
    strict.filter((x) => x.status === "done").every((x) => Number(x.proba) >= 0.82),
    "\u9AD8\u95E8\u69DB\u4E0B\u4E0D\u5141\u8BB8\u4F4E\u6982\u7387\u5355\u6210\u4EA4"
  );
  ok(`T4a \u663E\u5F0F threshold \u751F\u6548\uFF1A42% \u2192 ${done(loose)} \u7B14\uFF0C82% \u2192 ${done(strict)} \u7B14`);
  const confirmMode = simulate(cs, "BTC-USDT-SWAP", "5m", { ...base, threshold: 0.42, entryMode: "confirm" });
  const touchMode = simulate(cs, "BTC-USDT-SWAP", "5m", { ...base, threshold: 0.42, entryMode: "touch" });
  assert.notEqual(done(confirmMode), done(touchMode), "\u5165\u573A\u6A21\u5F0F\u5FC5\u987B\u6539\u53D8\u6210\u4EA4\u96C6\u5408");
  ok(`T4b entryMode \u751F\u6548\uFF1Aconfirm ${done(confirmMode)} \u7B14 / touch ${done(touchMode)} \u7B14`);
  const replaced = simulate(cs, "BTC-USDT-SWAP", "5m", {
    flowFilter: true,
    maxHold: 96,
    threshold: 0.42,
    entryMode: "confirm",
    replaceConfFilter: true
  });
  const kept = simulate(cs, "BTC-USDT-SWAP", "5m", {
    flowFilter: true,
    maxHold: 96,
    threshold: 0.42,
    entryMode: "confirm",
    replaceConfFilter: false
  });
  assert.ok(
    kept.filter((x) => x.status === "done").every((x) => x.conf >= 60),
    "replaceConfFilter=false \u65F6\u5FC5\u987B\u6062\u590D CONF_MIN=60 \u7ED3\u6784\u8D28\u91CF\u8FC7\u6EE4"
  );
  assert.ok(done(replaced) >= done(kept), "\u5173\u95ED\u7ED3\u6784\u8FC7\u6EE4\u540E\u6210\u4EA4\u7B14\u6570\u4E0D\u5E94\u66F4\u5C11");
  ok(`T4c replaceConfFilter \u751F\u6548\uFF1Atrue ${done(replaced)} \u7B14 / false ${done(kept)} \u7B14\uFF08conf\u226560\uFF09`);
}
{
  const mk = (why, r) => ({
    id: `${why}_${r}`,
    proba: 0.7,
    outcome: {
      filled: true,
      why,
      entryPrice: 100,
      entryTs: 1,
      exitPrice: 100,
      exitTs: 2,
      r,
      pnlPct: 0,
      holdingBars: 3,
      costR: 0.05
    }
  });
  const s = summarize([mk("be", 0.02), mk("tp", 1.4), mk("sl", -1), mk("time", 0.1)]);
  assert.equal(s.traded, 4);
  assert.equal(s.tpRate, 25);
  assert.equal(s.slRate, 25);
  assert.equal(s.timeRate, 25, "\u4FDD\u672C\u5355\u4E0D\u5F97\u8BA1\u5165\u8D85\u65F6");
  assert.equal(s.beRate, 25, "\u4FDD\u672C\u5355\u5FC5\u987B\u5355\u72EC\u7EDF\u8BA1");
  ok("T7 \u4FDD\u672C\u51FA\u573A\u72EC\u7ACB\u5206\u6876\uFF08tp/sl/time/be \u5404 25%\uFF09");
}
{
  const now = 18e11;
  const trades = [];
  for (let i = 0; i < 90; i++) trades.push({ ts: now - i * 100, side: i % 2 ? "buy" : "sell", notional: 100 });
  for (let i = 0; i < 8; i++) trades.push({ ts: now - i * 100, side: "buy", notional: 1e4 });
  for (let i = 0; i < 2; i++) trades.push({ ts: now - i * 100, side: "sell", notional: 1e4 });
  const r = bigBiasOf(trades, now);
  assert.equal(r.count, 10, "\u53EA\u6709\u8D85\u8FC7\u5206\u4F4D\u503C\u7684 10 \u7B14\u5927\u989D\u6210\u4EA4\u624D\u7B97\u5927\u5355\uFF08\u4E0D\u5F97\u9000\u5316\u4E3A\u5168\u91CF\uFF09");
  assert.ok(Math.abs((r.bias ?? 0) - 0.6) < 1e-9, `8 \u4E70 2 \u5356\u7B49\u989D\u5927\u5355\u5E94\u5F97\u5230 0.6\uFF0C\u5B9E\u9645 ${r.bias}`);
  assert.equal(bigBiasOf(trades.slice(0, 10), now).bias, null, "\u6837\u672C\u4E0D\u8DB3\u5FC5\u987B\u8FD4\u56DE null \u800C\u4E0D\u662F\u81C6\u6D4B");
  assert.equal(bigBiasOf(trades.map((t) => ({ ...t, ts: t.ts - 6e5 })), now).bias, null, "\u7A97\u53E3\u5916\u7684\u65E7\u6210\u4EA4\u4E0D\u53C2\u4E0E");
  ok(`T5 \u5927\u5355\u4E3B\u52A8\u65B9\u5411\uFF1Abias=${r.bias?.toFixed(2)}\uFF0Ccount=${r.count}\uFF0C\u6837\u672C\u4E0D\u8DB3/\u8D85\u7A97\u53E3\u5747\u4E3A null`);
}
{
  const now = 18e11;
  const barMs2 = 3e5;
  assert.equal(shouldRepairFlow({ to: now - barMs2, barMs: barMs2 }, false, now), false, "\u5FEB\u7167\u65B0\u9C9C\u4E14\u672A\u65AD\u7EBF\uFF1A\u4E0D\u56DE\u8865");
  assert.equal(shouldRepairFlow({ to: now - 3 * barMs2, barMs: barMs2 }, false, now), true, "\u5FEB\u7167\u6EDE\u540E\u8D85\u8FC7 2 \u4E2A\u5468\u671F\uFF1A\u56DE\u8865");
  assert.equal(shouldRepairFlow({ to: now - barMs2, barMs: barMs2 }, true, now), true, "WS \u65AD\u5F00\u8FC7\uFF1A\u56DE\u8865");
  assert.equal(
    shouldRepairFlow({ to: now - 3 * barMs2, barMs: barMs2, repairedAt: now - 1e3 }, true, now),
    false,
    "\u521A\u56DE\u8865\u8FC7\uFF1A\u4E00\u4E2A\u5468\u671F\u5185\u4E0D\u91CD\u590D\u56DE\u8865"
  );
  ok("T6 \u4FEE\u590D\u6027\u56DE\u8865\u89E6\u53D1\u6761\u4EF6\u4E0E\u6700\u5C0F\u95F4\u9694\u6B63\u786E");
}
{
  const cs = legacyTrendCandles("BTC-USDT-SWAP", "5m", 8640, 176e10 + 3 * 864e5);
  const scan = runScan(cs, "5m");
  assert.ok(scan.touch.length > 0, "\u9700\u8981\u89E6\u4EF7\u5019\u9009\u6837\u672C");
  const passable = scan.touch.filter((c) => c.proba >= 0.42).length;
  assert.ok(passable > 0, `\u89E6\u4EF7\u6C60\u4ECD\u5168\u90E8\u4F4E\u4E8E 42% \u95E8\u69DB\uFF08${passable}/${scan.touch.length}\uFF09\uFF0CA/B \u5BF9\u7167\u4F9D\u65E7\u65E0\u6548`);
  assert.equal(scan.confirm.length, 2, "confirm \u8DEF\u5F84\u5019\u9009\u6570\u4E0D\u5F97\u88AB\u89E6\u4EF7\u4FEE\u590D\u5F71\u54CD");
  ok(`T10 \u89E6\u4EF7\u6C60\u6062\u590D\u53EF\u6210\u4EA4\u5019\u9009\uFF1A${passable}/${scan.touch.length} \u901A\u8FC7 42% \u95E8\u69DB\uFF0Cconfirm \u5019\u9009\u4ECD\u4E3A ${scan.confirm.length}`);
}
{
  const { simulateWithPlan: simulateWithPlan2, buildContext: buildContext2 } = await Promise.resolve().then(() => (init_scan(), scan_exports));
  const cs = Array.from({ length: 40 }, (_, i) => ({ ts: 17e11 + i * 3e5, o: 100, h: 100.5, l: 99.5, c: 100, v: 1e3 }));
  cs[31] = { ...cs[31], h: 101.2, l: 99.8, c: 101 };
  cs[32] = { ...cs[32], o: 101, h: 103.2, l: 100.8, c: 102 };
  const ctx = buildContext2(cs);
  const sig = { idx: 30, ts: cs[30].ts, side: "long", entry: 100, stop: 99, tp: 103 };
  let checked = 0;
  for (const mode of ["confirm", "touch"]) {
    const o = simulateWithPlan2(ctx, sig, mode, 10, "partial");
    const c = { id: mode, side: "long", stop: 99, mode };
    if (!o?.filled || o.why !== "tp") continue;
    const dir = c.side === "long" ? 1 : -1;
    const risk = Math.abs(o.entryPrice - c.stop);
    const slip = 1e-4, feeRate = 5e-4;
    const rawEntry = c.mode === "touch" ? o.entryPrice : o.entryPrice / (1 + dir * slip);
    const trigger = o.entryPrice + dir * risk;
    const halfExit = trigger * (1 - dir * slip);
    const finalRaw = o.exitPrice / (1 - dir * slip);
    const gross = (0.5 * (trigger - rawEntry) * dir + 0.5 * (finalRaw - rawEntry) * dir) / risk;
    const fees = (o.entryPrice + 0.5 * halfExit + 0.5 * o.exitPrice) * feeRate / risk;
    const slips = ((c.mode === "touch" ? 0 : rawEntry * slip) + 0.5 * trigger * slip + 0.5 * finalRaw * slip) / risk;
    assert.ok(Math.abs(gross - fees - slips - o.r) < 6e-3, `\u51C0R\u5BF9\u8D26\u5931\u8D25 ${c.id}: expected=${gross - fees - slips} actual=${o.r} entry=${o.entryPrice} exit=${o.exitPrice}`);
    assert.ok(Math.abs(fees + slips - o.costR) < 6e-3, `\u6210\u672CR\u5BF9\u8D26\u5931\u8D25 ${c.id}: ${fees + slips} != ${o.costR}`);
    checked++;
  }
  assert.ok(checked > 0, "\u9700\u8981\u53EF\u6210\u4EA4\u7684\u5206\u6279\u6B62\u76C8\u6837\u672C");
  ok(`T11 \u5206\u6279\u51FA\u573A\u6210\u672C\u5BF9\u8D26\uFF1A${checked} \u7B14\uFF0C\u8BEF\u5DEE\u5728\u53D1\u5E03\u7CBE\u5EA6\u5185`);
}
console.log(`
audit-fixes: ${passed} \u7EC4\u65AD\u8A00\u5168\u90E8\u901A\u8FC7`);
