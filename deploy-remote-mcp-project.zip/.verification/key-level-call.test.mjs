// tests/key-level-call.test.ts
import assert from "node:assert/strict";

// remote/setup-mcp-project-locally/src/lib/engine.ts
var DEFAULT_PARAMS = {
  pivotLeft: 8,
  pivotRight: 5,
  lookback: 288,
  minGap: 8,
  minHeightAtr: 2,
  priorMoveAtr: 1.5,
  tolAtr: 0.35,
  tolPct: 4e-4,
  sweepAtr: 0.5,
  closeBufAtr: 0.05,
  stopAtr: 0.75,
  targetFrac: 1,
  minRR: 1.2,
  maxRR: 4,
  enableBreak: false,
  breakWithin: 24,
  entryMode: "limit",
  limitOffsetAtr: 0.1,
  trendBlock: 1
};
function atrSeries(cs, p2 = 14) {
  const n2 = cs.length;
  const out = new Array(n2).fill(0);
  const tr = new Array(n2).fill(0);
  for (let i = 1; i < n2; i++) {
    const c = cs[i];
    const pc = cs[i - 1].c;
    tr[i] = Math.max(c.h - c.l, Math.abs(c.h - pc), Math.abs(c.l - pc));
  }
  let sum = 0;
  for (let i = 1; i < n2; i++) {
    sum += tr[i];
    if (i - p2 >= 1) sum -= tr[i - p2];
    out[i] = sum / Math.min(i, p2);
  }
  return out;
}
function approxDeltaAt(cs, i) {
  const c = cs[i];
  const range = c.h - c.l;
  if (range <= 0) return c.c > c.o ? c.v / 2 : c.c < c.o ? -c.v / 2 : 0;
  return c.v * (2 * ((c.c - c.l) / range) - 1);
}

// src/quant/flow.ts
function hasRealFlow(bar2, candleVol, volumeSource) {
  if (volumeSource && volumeSource !== "quote") return false;
  if (!bar2 || !Number.isFinite(bar2.buy) || !Number.isFinite(bar2.sell) || bar2.buy < 0 || bar2.sell < 0 || !(bar2.buy + bar2.sell > 0) || candleVol == null || !Number.isFinite(candleVol) || !(candleVol > 0)) return false;
  const coverage = (bar2.buy + bar2.sell) / candleVol;
  return coverage >= (bar2.src === "rubik" ? 0.95 : 0.85) && coverage <= 1.1;
}

// src/quant/context.ts
function emaSeries(cs, period) {
  const k = 2 / (period + 1);
  const out = new Array(cs.length);
  let e = cs[0]?.c ?? 0;
  for (let i = 0; i < cs.length; i++) {
    e = i === 0 ? cs[i].c : cs[i].c * k + e * (1 - k);
    out[i] = e;
  }
  return out;
}
function buildContext(cs, flow) {
  const n2 = cs.length;
  const atr = atrSeries(cs);
  const delta = new Array(n2);
  const real = new Uint8Array(n2);
  const oi = new Array(n2).fill(NaN);
  const vols = new Array(n2);
  const volMa = new Array(n2).fill(0);
  const index = /* @__PURE__ */ new Map();
  let covered = 0;
  for (let i = 0; i < n2; i++) {
    const fb = flow?.bars.get(cs[i].ts);
    if (hasRealFlow(fb, cs[i].v, cs[i].volumeSource)) {
      delta[i] = fb.buy - fb.sell;
      real[i] = 1;
      covered++;
    } else {
      delta[i] = approxDeltaAt(cs, i);
    }
    const position = fb?.oiContracts && fb.oiContracts > 0 ? fb.oiContracts : fb?.oiUsd;
    if (position && position > 0) oi[i] = position;
    vols[i] = cs[i].v;
    index.set(cs[i].ts, i);
  }
  let s = 0;
  for (let i = 0; i < n2; i++) {
    if (i >= 1) s += cs[i - 1].v;
    if (i >= 21) s -= cs[i - 21].v;
    const m = Math.min(i, 20);
    volMa[i] = m ? s / m : cs[i].v;
  }
  return {
    cs,
    n: n2,
    atr,
    delta,
    real,
    oi,
    vols,
    ema20: emaSeries(cs, 20),
    ema50: emaSeries(cs, 50),
    volMa,
    index,
    flowCoverage: n2 ? covered / n2 : 0
  };
}

// src/vela/annotTypes.ts
var decimalsFor = (price) => {
  const p2 = Math.abs(price);
  return p2 >= 1e3 ? 1 : p2 >= 10 ? 2 : p2 >= 1 ? 3 : 5;
};

// src/vela/signals/patterns.ts
var p = DEFAULT_PARAMS;
var L = p.pivotLeft;
var R = p.pivotRight;
var MAX_TOL_ATR = 0.7;
function annotationTolerance(price, atr) {
  if (!(atr > 0) || !Number.isFinite(price)) return 0;
  return Math.min(Math.max(p.tolAtr * atr, p.tolPct * Math.abs(price)), MAX_TOL_ATR * atr);
}

// src/vela/signals/evidence.ts
function takerObservation(ctx, flow, i) {
  const c = ctx.cs[i], b = c && flow?.bars.get(c.ts);
  if (!c || !b || ctx.real[i] !== 1 || !(b.buy + b.sell > 0)) return null;
  const total = b.buy + b.sell;
  return {
    buy: b.buy,
    sell: b.sell,
    total,
    delta: b.buy - b.sell,
    ratio: (b.buy - b.sell) / total,
    src: b.src,
    coverage: c.v > 0 ? total / c.v : 0,
    volRatio: volumeRatio(ctx, i) ?? 0
  };
}
function volumeRatio(ctx, i) {
  return ctx.cs[i] && ctx.volMa[i] > 0 ? ctx.cs[i].v / ctx.volMa[i] : null;
}
function legFlow(ctx, flow, from, to, barMs) {
  const start = Math.max(0, Math.min(from, to)), end = Math.min(ctx.n - 1, Math.max(from, to));
  let covered = 0, buy = 0, sell = 0, continuous = end >= start;
  for (let i = start; i <= end; i++) {
    if (i > start && ctx.cs[i].ts - ctx.cs[i - 1].ts !== barMs) continuous = false;
    const obs = takerObservation(ctx, flow, i);
    if (!obs) {
      continuous = false;
      continue;
    }
    covered++;
    buy += obs.buy;
    sell += obs.sell;
  }
  const bars = Math.max(0, end - start + 1), total = buy + sell;
  const complete = continuous && covered === bars && total > 0;
  return { from: start, to: end, bars, covered, complete, buy, sell, total, delta: buy - sell, ratio: complete ? (buy - sell) / total : null };
}

// src/vela/signals/scenario.ts
var BREAK_ATR = 0.2;
var RETEST_WINDOW = 48;
var RECLAIM_WINDOW = 12;
function evaluateLine(ctx, barMs, price, dir, startIdx, kind, flow) {
  const { cs, atr, n: n2 } = ctx;
  if (startIdx < 0 || startIdx >= n2 - 1 || !(barMs > 0)) return null;
  const a = (i) => Math.max(atr[i] || 0, 1e-9);
  const beyond = (i) => i >= 0 && dir * (cs[i].c - price) > BREAK_ATR * a(i);
  const inside = (i) => dir * (cs[i].c - price) < -BREAK_ATR * a(i);
  const events = [];
  let latest = null, pending = -1;
  const emit = (r, event, i) => {
    events.push({ kind: event, idx: i, at: cs[i].ts + barMs });
    r.lastEventIdx = i;
  };
  const make = (i, acceptedAt) => {
    const anchor = acceptedAt >= 0 ? acceptedAt : i;
    const tol = Math.max(annotationTolerance(price, a(anchor)), 0.15 * a(anchor));
    const w = acceptedAt >= 0 ? legFlow(ctx, flow, i, acceptedAt, barMs) : null;
    return {
      kind,
      price,
      dir,
      state: acceptedAt >= 0 ? "broken" : "pending",
      firstBreak: i,
      acceptedAt,
      reachedIdx: -1,
      retestConfirmedAt: -1,
      failedAt: -1,
      expiredAt: -1,
      lastEventIdx: anchor,
      flowComplete: !!w?.complete,
      flowAligned: w?.ratio != null && w.ratio * dir >= 0.04,
      flowRatio: w?.ratio ?? null,
      waited: 0,
      distAtr: 0,
      lo: price - tol,
      hi: price + tol,
      events
    };
  };
  for (let i = startIdx + 1; i < n2; i++) {
    if (cs[i].ts - cs[i - 1].ts !== barMs) {
      pending = -1;
      if (latest && !["expired", "failed"].includes(latest.state)) {
        latest.state = "expired";
        latest.expiredAt = i;
        emit(latest, "expired", i);
      }
      continue;
    }
    const active = latest && !["expired", "failed", "pending"].includes(latest.state);
    if (active && latest) {
      const r = latest;
      r.waited = i - r.acceptedAt;
      if (inside(i)) {
        r.state = "failed";
        r.failedAt = i;
        emit(r, "failed", i);
        continue;
      }
      if (r.reachedIdx < 0 && cs[i].h >= r.lo && cs[i].l <= r.hi) {
        r.reachedIdx = i;
        emit(r, "touch", i);
      }
      if (r.reachedIdx < 0 && r.waited >= RETEST_WINDOW || r.reachedIdx >= 0 && i - r.reachedIdx > RECLAIM_WINDOW) {
        r.state = "expired";
        r.expiredAt = i;
        emit(r, "expired", i);
        continue;
      }
      if (r.reachedIdx >= 0) {
        const old = r.state;
        if (!beyond(i)) r.state = "touch";
        else {
          r.state = "retest";
          if (r.retestConfirmedAt < 0) {
            r.retestConfirmedAt = i;
            emit(r, "held", i);
          }
          if (i > r.retestConfirmedAt && dir * (cs[i].c - price) > (r.hi - r.lo) / 2 + 0.4 * a(i)) r.state = "continued";
          if (r.state === "continued" && old !== "continued") emit(r, "continued", i);
        }
      }
      r.distAtr = cs[i].c < r.lo ? (r.lo - cs[i].c) / a(i) : cs[i].c > r.hi ? (cs[i].c - r.hi) / a(i) : 0;
      continue;
    }
    if (pending === i - 1 && beyond(i)) {
      latest = make(pending, i);
      emit(latest, "accepted", i);
      pending = -1;
      continue;
    }
    pending = -1;
    if (beyond(i) && (i === startIdx + 1 || !beyond(i - 1))) {
      pending = i;
      events.push({ kind: "crossing", idx: i, at: cs[i].ts + barMs });
    }
  }
  if (pending === n2 - 1) return make(pending, -1);
  return latest;
}

// src/vela/signals/mwStory.ts
function selectMwStories(items, max = 3) {
  const ranked = items.filter((i) => i.story?.active && i.story.distanceAtr <= 12).sort((a, b) => b.story.priority - a.story.priority || b.story.lastActivityAt - a.story.lastActivityAt || a.story.distanceAtr - b.story.distanceAtr);
  const kept = [], directions = /* @__PURE__ */ new Set();
  for (const item of ranked) {
    const s = item.story, direction = s.bias ?? "wait";
    if (directions.has(direction)) continue;
    if (kept.some((k) => k.story.side === s.side && Math.abs(k.story.level - s.level) <= Math.max(k.story.referenceAtr, s.referenceAtr))) continue;
    kept.push(item);
    directions.add(direction);
    if (kept.length >= max) break;
  }
  return kept;
}

// src/vela/signals/store.ts
var SIGNAL_TYPES = [
  { id: "doubleTop", name: "\u53CC\u9876\u5224\u8BFB", group: "mw", flow: true, description: "\u4E00\u4E2A\u53CC\u9876\u4E00\u6761\u5B8C\u6574\u8BB0\u5F55\uFF1A\u5173\u952E\u4F4D\u529B\u91CF\u3001\u771F\u5B9E\u6210\u4EA4\u3001\u8BF1\u591A\u5019\u9009\u4E0E\u9888\u7EBF\u53CD\u62BD\u3002", rule: "\u53EA\u7528\u5DF2\u6536\u76D8K\u7EBF\uFF0C\u4FDD\u7559\u73B0\u6709\u4EF7\u683C\u5F62\u6001\u8BC6\u522B\u51E0\u4F55\u3002\u540C\u533A\u91CD\u53E0\u7ED3\u6784\u5F52\u5E76\uFF1B\u529B\u91CF\u662F\u8BC1\u636E\u8BA1\u6570\uFF0C\u4E0D\u662F\u80DC\u7387\u3002\u65E0\u771F\u5B9E\u6210\u4EA4\u8986\u76D6\u5C31\u660E\u786E\u7F3A\u5931\uFF0C\u4E0D\u7528OHLC\u8865\u9020\u4E3B\u52A8\u4E70\u5356\u3002" },
  { id: "doubleBottom", name: "\u53CC\u5E95\u5224\u8BFB", group: "mw", flow: true, description: "\u4E00\u4E2A\u53CC\u5E95\u4E00\u6761\u5B8C\u6574\u8BB0\u5F55\uFF1A\u5173\u952E\u4F4D\u529B\u91CF\u3001\u771F\u5B9E\u6210\u4EA4\u3001\u8BF1\u7A7A\u5019\u9009\u4E0E\u7A81\u7834\u56DE\u8E29\u3002", rule: "\u53CC\u9876\u7684\u955C\u50CF\u3002\u9996\u6839\u8D8A\u4F4D\u3001\u4E24\u6839\u6536\u76D8\u786E\u8BA4\u3001\u9996\u6B21\u89E6\u5E26\u3001\u6536\u76D8\u5B88\u4F4F\u548C\u5931\u8D25\u5206\u5F00\u8BB0\u65F6\uFF1B\u53EA\u89E6\u5E26\u4E0D\u7B49\u4E8E\u56DE\u8E29\u786E\u8BA4\u3002\u672A\u6536\u76D8\u4EF7\u683C\u53EA\u63D0\u4F9B\u72EC\u7ACB\u63D0\u793A\u3002" },
  { id: "keyLevelScenario", name: "\u7A81\u7834\u56DE\u8E29\u533A", group: "mw", flow: false, description: "\u663E\u793A\u540C\u4E00\u5F62\u6001\u7684\u5173\u952E\u4F4D/\u9888\u7EBF\u89C2\u5BDF\u5E26\uFF0C\u4E0D\u65B0\u589E\u4E00\u5F20\u4FE1\u53F7\u5361\u3002", rule: "\u4E24\u6839\u6536\u76D8\u8D8A\u8FC70.2 ATR\u786E\u8BA4\u4EF7\u683C\u7834\u4F4D\uFF1B\u653E\u91CF\u22651.5\xD7\u5747\u91CF\uFF0C\u6216\u91CF\u22651.2\xD7\u4E14\u771F\u5B9E\u6210\u4EA4\u540C\u5411\u3002\u56DE\u8E29\u6536\u76D8\u5B88\u4F4F\u3001\u56DE\u64A4\u226461.8%\u3001\u91CF\u22640.9\xD7\u624D\u5347\u7EA7\uFF1B\u6700\u591A\u4E24\u5757\u4E0D\u540C\u65B9\u5411\u533A\u5E26\u3002\u4E0D\u9884\u6D4B\u4E00\u5B9A\u4F1A\u56DE\u8E29\u6216\u5230\u8FBE\u65F6\u95F4\u3002" },
  { id: "keyLevels", name: "\u652F\u6491 / \u963B\u529B", group: "context", flow: true, description: "\u53EF\u9009\u76D8\u9762\u80CC\u666F\uFF0C\u9ED8\u8BA4\u5173\u95ED\uFF1B\u4E0D\u62A2\u53CC\u9876/\u53CC\u5E95\u7684\u4E3B\u8981\u6807\u7B7E\u3002", rule: "\u6700\u8FD1288\u6839\u4E2D\u672A\u7834\u7684\u6446\u52A8\u4F4D\uFF0C\u6309\u8DDD\u79BB\u9009\u62E9\u5E76\u53BB\u91CD\uFF0C\u6700\u591A6\u6761\u3002\u6700\u8FD1\u89E6\u78B0\u6709\u5B8C\u6574\u771F\u5B9E\u6210\u4EA4\u65F6\u9644\u5355\u6839\u89C2\u5BDF\uFF0C\u65E0\u8986\u76D6\u4E0D\u9020\u65B9\u5411\uFF1B\u4E0E\u4E3B\u5F62\u6001\u540C\u4EF7\u7EBF\u4E0D\u91CD\u590D\u7ED8\u5236\u3002" },
  { id: "retest", name: "\u5176\u4ED6\u7A81\u7834\u56DE\u8E29", group: "context", flow: true, description: "\u666E\u901A\u6446\u52A8\u4F4D\u7684\u4EF7\u683C\u56DE\u8E29\uFF0C\u72EC\u7ACB\u4E8E\u53CC\u9876/\u53CC\u5E95\u9888\u7EBF\uFF0C\u9ED8\u8BA4\u5173\u95ED\u3002", rule: "\u7B2C\u4E00\u6B21\u5B9E\u9645\u56DE\u8E29\u5E76\u6536\u76D8\u5B88\u4F4F\u624D\u6807\uFF0C\u65F6\u95F4\u662F\u786E\u8BA4\u90A3\u6839\uFF1B\u4EC5\u7A81\u7834K\u4E0E\u786E\u8BA4K\u90FD\u6709\u5B8C\u6574\u771F\u5B9E\u6210\u4EA4\u65F6\u9644\u4E24\u6839\u4F50\u8BC1\uFF0C\u4E0D\u80FD\u5192\u5145\u6574\u6BB5\u8FDE\u7EED\u8BA2\u5355\u6D41\u3002" },
  { id: "smartMoney", name: "\u7ED3\u6784\u8865\u5145", group: "context", flow: false, description: "\u5728\u53CC\u9876/\u53CC\u5E95\u8BE6\u60C5\u4E2D\u8865\u5145SMC\u7ED3\u6784\uFF0C\u4E0D\u518D\u989D\u5916\u751F\u6210\u591A\u5F20\u8BB0\u5F55\u3002", rule: "\u6CBF\u7528\u73B0\u6709\u806A\u660E\u94B1\u7ED3\u6784\u68C0\u6D4B\u3002\u547D\u4E2D\u8BA1\u6570\u53EA\u89E3\u91CA\u4EF7\u683C\u4E8B\u5B9E\uFF0C\u4E0D\u63A8\u65AD\u673A\u6784\u3001\u6B62\u635F\u6216\u76C8\u5229\uFF1B\u8BE5\u5F00\u5173\u53EA\u63A7\u5236\u9644\u52A0\u8BE6\u60C5\uFF0C\u4E0D\u5F71\u54CD\u4E3B\u5224\u8BFB\u3002" },
  { id: "deltaImpulse", name: "\u6210\u4EA4\u529B\u5EA6", group: "context", flow: true, description: "\u53EF\u9009\u76D8\u9762\u80CC\u666F\uFF0C\u9ED8\u8BA4\u5173\u95ED\uFF1B\u771F\u5B9E\u6210\u4EA4\u653E\u91CF\u65F6\u624D\u7ED9\u4E3B\u52A8\u65B9\u5411\u3002", rule: "\u4FDD\u7559\u65E2\u6709\u653E\u91CF\u3001\u4E3B\u52A8\u5DEE\u3001\u6536\u76D8\u4F4D\u7F6E\u89C2\u5BDF\uFF1B\u753B\u5E03\u6700\u591A4\u4E2A\u5DF2\u6536\u76D8\u6807\u7B7E\uFF0C\u5F62\u6210\u4E2D\u9884\u89C8\u5355\u72EC\u6807\u8BC6\u3002\u2248 \u4E3AOHLC\u4EE3\u7406\uFF0C\u7EDD\u4E0D\u7528\u4E8E\u53CC\u9876\u53CC\u5E95\u7684\u6210\u4EA4\u8BC1\u636E\u6216CVD\u3002" }
];
var DEFAULT_PREFERENCES = {
  enabled: true,
  selected: { doubleTop: true, doubleBottom: true, keyLevelScenario: true, keyLevels: false, retest: false, smartMoney: false, deltaImpulse: false },
  labels: true,
  geometry: true,
  allowApprox: false,
  preview: false,
  lookback: 600
};
var emptyCounts = () => Object.fromEntries(SIGNAL_TYPES.map((t) => [t.id, 0]));
var EMPTY_RUNTIME = { symbol: "", timeframe: "", status: "loading", message: "", bars: 0, requested: 600, gapTruncated: false, historyShort: false, covered: 0, flowSupported: true, flowConnected: false, flowSyncing: false, updatedAt: 0, counts: emptyCounts(), visible: [], total: 0 };
function normalizePreferences(value) {
  const raw = value && typeof value === "object" ? value : {};
  const selected = { ...DEFAULT_PREFERENCES.selected };
  for (const { id } of SIGNAL_TYPES) if (typeof raw.selected?.[id] === "boolean") selected[id] = raw.selected[id];
  const flag = (key) => typeof raw[key] === "boolean" ? raw[key] : DEFAULT_PREFERENCES[key];
  return { enabled: flag("enabled"), selected, labels: flag("labels"), geometry: flag("geometry"), allowApprox: flag("allowApprox"), preview: flag("preview"), lookback: raw.lookback === 300 || raw.lookback === 1200 ? raw.lookback : 600 };
}
function emptySignalPayload() {
  return { events: [], levels: [], zones: [], paths: [], position: null, obstacles: [], decimals: 2, rev: 0 };
}

// src/vela/signals/analyze.ts
function projectSignals(analysis, preferences, focusId = null) {
  const eligible = analysis.items.filter((i) => (i.source === "price" || i.source === "real" || preferences.allowApprox) && (i.confirmed || preferences.preview));
  const counts = emptyCounts();
  for (const i of eligible) {
    counts[i.type]++;
    if (i.story?.active && i.zone) counts.keyLevelScenario++;
    if (i.story?.smc && i.story.smc.hits >= 2) counts.smartMoney++;
  }
  const visible = preferences.enabled ? eligible.filter((i) => preferences.selected[i.type]).sort((a, b) => Number(!!b.story) - Number(!!a.story) || b.ts - a.ts).slice(0, 160) : [];
  const payload = emptySignalPayload();
  payload.decimals = decimalsFor(analysis.lastPrice);
  const selected = visible.find((i) => i.story && i.id === focusId);
  const rankedStories = selectMwStories(visible.filter((i) => i.story));
  const paintedStories = selected ? [selected, ...rankedStories.filter((i) => i.id !== selected.id && Math.abs(i.price - selected.price) > Math.max(i.story.referenceAtr, selected.story.referenceAtr))].slice(0, 3) : rankedStories;
  const storyIds = new Set(paintedStories.map((i) => i.id));
  const directions = /* @__PURE__ */ new Set();
  const byText = /* @__PURE__ */ new Map();
  for (const item of visible) {
    if (item.paint === false || item.story && !storyIds.has(item.id)) continue;
    if (item.type === "keyLevels" && paintedStories.some((i) => Math.min(Math.abs(i.story.level - item.price), Math.abs(i.story.neck - item.price)) <= annotationTolerance(item.price, i.story.referenceAtr))) continue;
    const approximate = item.source === "mixed" || item.source === "approx";
    if (item.event) {
      const event = { ...item.event, text: preferences.labels ? `${approximate ? "\u2248 " : ""}${item.event.text}` : "" };
      const key = `${event.ts}|${event.text || event.id}`;
      const prev = byText.get(key);
      if (!prev || event.priority > prev.priority) byText.set(key, event);
    }
    if (item.levels) {
      const levels = item.story ? item.levels.filter((l) => preferences.geometry || l.id.endsWith(":level")) : item.type === "keyLevels" || preferences.geometry ? item.levels : [];
      payload.levels.push(...levels.map((l) => ({ ...l, ...item.id === focusId ? { rank: "focus", priority: 100 } : {}, label: l.label && preferences.labels })));
    }
    if (item.zone && (!item.story || preferences.selected.keyLevelScenario)) {
      const direction = item.story?.bias ?? item.story?.side ?? item.id;
      if (!item.story || !directions.has(direction) && directions.size < 2) {
        payload.zones.push({ ...item.zone, text: preferences.labels ? `${approximate ? "\u2248 " : ""}${item.zone.text}` : "" });
        if (item.story) directions.add(direction);
      }
    }
    if (item.path && preferences.geometry) payload.paths.push({ id: `${item.id}:path`, ...item.path });
  }
  payload.events.push(...byText.values());
  return { payload, visible, counts };
}

// src/vela/signals/keyLevelCall.ts
var fmt = (v) => v.toLocaleString("en-US", {
  minimumFractionDigits: decimalsFor(v),
  maximumFractionDigits: decimalsFor(v)
});
var volX = (v) => `${v.toFixed(1)}\xD7`;
function clusterPatterns(patterns, atrNow) {
  const gap = Math.max(atrNow * 1, 1e-9);
  const sorted = [...patterns].sort((a, b) => a.level - b.level || a.idx - b.idx);
  const out = [];
  for (const p2 of sorted) {
    const hit = out.findIndex((q) => q.side === p2.side && Math.abs(q.level - p2.level) <= gap);
    if (hit < 0) {
      out.push(p2);
      continue;
    }
    if (p2.idx > out[hit].idx) out[hit] = p2;
  }
  return out;
}
function unitVolume(ctx, from, to) {
  const a = Math.max(0, Math.min(from, to));
  const b = Math.min(ctx.n - 1, Math.max(from, to));
  if (b < a) return 0;
  let sum = 0;
  for (let i = a; i <= b; i++) sum += ctx.cs[i].v;
  return sum / (b - a + 1);
}
function buildKeyLevelCalls(input) {
  const { patterns, ctx, flow, barMs, livePrice, maxCalls = 3 } = input;
  const { cs, atr, volMa } = ctx;
  const last = ctx.n - 1;
  if (!cs.length) return [];
  const atrNow = Math.max(atr[last] || 0, 1e-9);
  const today = cs[last].c;
  const current = livePrice != null && Number.isFinite(livePrice) ? livePrice : today;
  const calls = [];
  for (const pattern of clusterPatterns(patterns, atrNow)) {
    const top = pattern.side === "top";
    const level = pattern.level;
    const neck = pattern.neck;
    const testBar = cs[pattern.second];
    const confBar = cs[pattern.idx];
    const a = Math.max(atr[pattern.idx] || 0, 1e-9);
    const tol = Math.max(annotationTolerance(level, atrNow), 0.15 * atrNow);
    const distanceAtr = Math.abs(current - level) / atrNow;
    const ageBars = last - pattern.idx;
    const leg1 = unitVolume(ctx, pattern.firstLegStart, pattern.first);
    const leg2 = unitVolume(ctx, pattern.secondLegStart, pattern.second);
    const secondRatio = leg1 > 0 && leg2 > 0 ? leg2 / leg1 : null;
    const testVol = volMa[pattern.second] > 0 ? testBar.v / volMa[pattern.second] : 0;
    const testRange = Math.max(testBar.h - testBar.l, 1e-9);
    const upperWick = (testBar.h - Math.max(testBar.o, testBar.c)) / testRange;
    const lowerWick = (Math.min(testBar.o, testBar.c) - testBar.l) / testRange;
    const rejectionWick = top ? upperWick : lowerWick;
    const swept = top ? testBar.h - level >= 0.05 * a && confBar.c < level : level - testBar.l >= 0.05 * a && confBar.c > level;
    const closedInside = top ? confBar.c < level : confBar.c > level;
    const flowAt = (i) => {
      const b = flow?.bars.get(cs[i].ts);
      if (!b || ctx.real[i] !== 1 || !(b.buy + b.sell > 0)) return null;
      return { ratio: (b.buy - b.sell) / (b.buy + b.sell), src: b.src };
    };
    const testFlow = flowAt(pattern.second);
    const confFlow = flowAt(pattern.idx);
    const rev = top ? -1 : 1;
    const up = evaluateLine(ctx, barMs, level, 1, pattern.idx, "level", flow);
    const down = evaluateLine(ctx, barMs, level, -1, pattern.idx, "level", flow);
    const held = (r) => !!r && r.acceptedAt >= 0 && (r.state === "broken" || r.state === "touch" || r.state === "retest" || r.state === "continued");
    const recentFail = (r) => !!r && r.state === "failed" && r.failedAt >= last - 24;
    const trap = top ? recentFail(up) ? "bull" : null : recentFail(down) ? "bear" : null;
    const accepted = top ? held(up) : held(down);
    let score = 0;
    const reasons = [];
    if (secondRatio != null && secondRatio <= 0.9) {
      score += 1;
      reasons.push(`\u7B2C\u4E8C\u817F\u7F29\u91CF ${volX(secondRatio)} \u7B2C\u4E00\u817F\uFF08\u63A8\u52A8\u529B\u8870\u51CF\uFF09`);
    } else if (secondRatio != null && secondRatio >= 1.1) {
      score -= 1;
      reasons.push(`\u7B2C\u4E8C\u817F\u653E\u91CF ${volX(secondRatio)} \u7B2C\u4E00\u817F\uFF08\u66F4\u50CF\u5EF6\u7EED\uFF0C\u4E0D\u662F\u53CD\u8F6C\uFF09`);
    }
    if (rejectionWick >= 0.35) {
      score += 1;
      reasons.push(`\u6D4B\u8BD5 K ${top ? "\u4E0A" : "\u4E0B"}\u5F71 ${Math.round(rejectionWick * 100)}%\uFF08\u6709\u5173\u952E\u4F4D\u62D2\u7EDD\uFF09`);
    }
    if (swept && closedInside) {
      score += 1;
      reasons.push(top ? "\u523A\u7834\u963B\u529B\u540E\u6536\u76D8\u6536\u56DE\uFF08\u8FFD\u591A\u88AB\u5957\uFF09" : "\u523A\u7834\u652F\u6491\u540E\u6536\u76D8\u6536\u56DE\uFF08\u8FFD\u7A7A\u88AB\u5957\uFF09");
    }
    if (testFlow && testFlow.ratio * rev >= 0.06) {
      score += 1;
      reasons.push(`\u6D4B\u8BD5 K \u4E3B\u52A8${top ? "\u5356" : "\u4E70"}\u5360\u4F18\uFF08${Math.round((1 + testFlow.ratio) * 50)}% \u4E3B\u52A8\u4E70 / ${Math.round((1 - testFlow.ratio) * 50)}% \u4E3B\u52A8\u5356\uFF09`);
    } else if (testFlow && testFlow.ratio * rev <= -0.12) {
      score -= 1;
      reasons.push(`\u6D4B\u8BD5 K \u4E3B\u52A8\u6210\u4EA4\u4ECD\u5728\u7A81\u7834\u4FA7\uFF08${Math.round((1 + testFlow.ratio) * 50)}% \u4E3B\u52A8\u4E70\uFF09`);
    }
    if (trap === "bull") {
      score += 2;
      reasons.unshift("\u963B\u529B\u88AB\u4E0A\u7834\u540E\u6536\u76D8\u6536\u56DE\uFF1A\u8FFD\u591A\u88AB\u5957\uFF08\u8BF1\u591A\uFF09");
    }
    if (trap === "bear") {
      score += 2;
      reasons.unshift("\u652F\u6491\u88AB\u4E0B\u7834\u540E\u6536\u76D8\u6536\u56DE\uFF1A\u8FFD\u7A7A\u88AB\u5957\uFF08\u8BF1\u7A7A\uFF09");
    }
    if (accepted) score -= 3;
    const limit = 12;
    if (distanceAtr > limit && !trap && !accepted) continue;
    if (distanceAtr > 4 && !trap && !accepted && !(rev * (current - level) > 0)) continue;
    if (ageBars > 96 && !trap && !accepted) continue;
    const traveled = rev * (current - level) / atrNow;
    const realized = traveled > 1.5 && ageBars > 12;
    const pullback = trap || score >= 3 ? "strong" : score >= 1 ? "medium" : "weak";
    const moveWord = top ? "\u56DE\u8C03" : "\u53CD\u5F39";
    let bias;
    let shortLabel;
    let title;
    let marker;
    let verdictText;
    if (realized && !accepted) {
      bias = "wait";
      verdictText = `${moveWord}\u5DF2\u8D70\u51FA ${traveled.toFixed(1)} ATR\uFF0C\u4E0D\u8FFD${moveWord}`;
      shortLabel = top ? "\u5DF2\u56DE\u8C03\xB7\u4E0D\u8FFD" : "\u5DF2\u53CD\u5F39\xB7\u4E0D\u8FFD";
      marker = "\u5DF2\u5151\u73B0";
      title = `${top ? "\u53CC\u9876\u963B\u529B" : "\u53CC\u5E95\u652F\u6491"} ${fmt(level)} \xB7 ${moveWord}\u5DF2\u5151\u73B0 ${traveled.toFixed(1)} ATR`;
    } else if (trap === "bull") {
      bias = "sell";
      verdictText = "\u504F\u7A7A\uFF08\u5356\uFF09\uFF0C\u7B49\u56DE\u8C03";
      shortLabel = "\u8BF1\u591A\xB7\u7B49\u56DE\u8C03";
      marker = "\u8BF1\u591A";
      title = `\u53CC\u9876 ${fmt(level)} \u8BF1\u591A \xB7 \u51B2\u9AD8\u6536\u56DE\uFF0C\u591A\u5934\u88AB\u5957\uFF08\u504F\u7A7A\uFF09`;
    } else if (trap === "bear") {
      bias = "buy";
      verdictText = "\u504F\u591A\uFF08\u4E70\uFF09\uFF0C\u7B49\u53CD\u5F39";
      shortLabel = "\u8BF1\u7A7A\xB7\u7B49\u53CD\u5F39";
      marker = "\u8BF1\u7A7A";
      title = `\u53CC\u5E95 ${fmt(level)} \u8BF1\u7A7A \xB7 \u8DCC\u7834\u6536\u56DE\uFF0C\u7A7A\u5934\u88AB\u5957\uFF08\u504F\u591A\uFF09`;
    } else if (accepted) {
      bias = "wait";
      verdictText = top ? "\u89C2\u671B\uFF1A\u539F\u5F62\u6001\u5931\u6548\uFF0C\u4E0D\u5728\u8FD9\u91CC\u505A\u7A7A" : "\u89C2\u671B\uFF1A\u539F\u5F62\u6001\u5931\u6548\uFF0C\u4E0D\u5728\u8FD9\u91CC\u505A\u591A";
      shortLabel = top ? "\u4E0A\u7834\xB7\u4E0D\u505A\u7A7A" : "\u8DCC\u7834\xB7\u4E0D\u505A\u591A";
      marker = top ? "\u4E0A\u7834" : "\u8DCC\u7834";
      title = `${top ? "\u53CC\u9876" : "\u53CC\u5E95"} ${fmt(level)} \u5173\u952E\u4F4D\u5DF2\u7834 \xB7 \u53CD\u624B\u65B9\u5411\uFF0C\u539F\u5F62\u6001\u5931\u6548`;
    } else if (pullback === "strong") {
      bias = rev === 1 ? "buy" : "sell";
      verdictText = rev === 1 ? "\u504F\u591A\uFF08\u4E70\uFF09" : "\u504F\u7A7A\uFF08\u5356\uFF09";
      shortLabel = top ? "\u53CC\u9876\xB7\u7B49\u56DE\u8C03" : "\u53CC\u5E95\xB7\u770B\u53CD\u5F39";
      marker = top ? "\u770B\u56DE\u8C03" : "\u770B\u53CD\u5F39";
      title = `${top ? "\u53CC\u9876\u963B\u529B" : "\u53CC\u5E95\u652F\u6491"} ${fmt(level)} \xB7 ${moveWord}\u503E\u5411\u5F3A\uFF08${rev === 1 ? "\u504F\u591A" : "\u504F\u7A7A"}\uFF09`;
    } else if (pullback === "medium") {
      bias = rev === 1 ? "buy" : "sell";
      verdictText = rev === 1 ? "\u504F\u591A\uFF08\u4E70\uFF09\u4F46\u8BC1\u636E\u4E00\u822C" : "\u504F\u7A7A\uFF08\u5356\uFF09\u4F46\u8BC1\u636E\u4E00\u822C";
      shortLabel = top ? "\u53CC\u9876\xB7\u56DE\u8C03\u4E00\u822C" : "\u53CC\u5E95\xB7\u53CD\u5F39\u4E00\u822C";
      marker = top ? "\u56DE\u8C03" : "\u53CD\u5F39";
      title = `${top ? "\u53CC\u9876\u963B\u529B" : "\u53CC\u5E95\u652F\u6491"} ${fmt(level)} \xB7 ${moveWord}\u503E\u5411\u4E00\u822C`;
    } else {
      bias = "wait";
      verdictText = "\u89C2\u671B\uFF1A\u8BC1\u636E\u4E0D\u8DB3";
      shortLabel = top ? "\u53CC\u9876\xB7\u89C2\u671B" : "\u53CC\u5E95\xB7\u89C2\u671B";
      marker = "\u89C2\u671B";
      title = `${top ? "\u53CC\u9876\u963B\u529B" : "\u53CC\u5E95\u652F\u6491"} ${fmt(level)} \xB7 \u8BC1\u636E\u4E0D\u8DB3\uFF0C\u89C2\u671B`;
    }
    const tone = bias === "buy" ? "long" : bias === "sell" ? "short" : "warn";
    const flowLine = testFlow ? `\u6D4B\u8BD5 K \u4E3B\u52A8\u6210\u4EA4\uFF1A\u4E3B\u52A8\u4E70 ${Math.round((1 + testFlow.ratio) * 50)}% / \u4E3B\u52A8\u5356 ${Math.round((1 - testFlow.ratio) * 50)}%\uFF08${testFlow.src === "rubik" ? "OKX \u5B98\u65B9\u7EDF\u8BA1" : "\u9010\u7B14\u805A\u5408"}\uFF09\uFF1B\u4EC5\u6210\u4EA4\u65B9\u5411\uFF0C\u4E0D\u662F\u8BA2\u5355\u7C3F OFI` : "\u6D4B\u8BD5 K \u4E70\u5356\u989D\u672A\u5B8C\u6574\u8986\u76D6\uFF1A\u4E0D\u5224\u65AD\u4E3B\u52A8\u65B9\u5411\uFF0C\u53EA\u7528\u4EF7\u683C\u4E0E\u6210\u4EA4\u91CF";
    const target1 = neck;
    const target2 = 2 * neck - level;
    const invalidate = top ? `\u6536\u76D8\u7AD9\u7A33 ${fmt(level + 0.3 * atrNow)} \u4E0A\u65B9` : `\u6536\u76D8\u8DCC\u7834 ${fmt(level - 0.3 * atrNow)}`;
    const targetAtr = Math.abs(target1 - level) / atrNow;
    const targetNote = targetAtr > 4 ? `\uFF08\u8DDD\u5173\u952E\u4F4D ${targetAtr.toFixed(1)} ATR\uFF0C\u504F\u8FDC\uFF09` : "";
    const detail = [
      `\u7ED3\u8BBA\uFF1A${verdictText} \xB7 ${moveWord}\u503E\u5411 ${pullback === "strong" ? "\u5F3A" : pullback === "medium" ? "\u4E00\u822C" : "\u5F31"}${bias === "wait" ? "" : `\uFF1B\u7B2C\u4E00\u76EE\u6807 ${fmt(target1)}${targetNote}\uFF0C\u5EF6\u4F38 ${fmt(target2)}`}`,
      `${top ? "\u963B\u529B" : "\u652F\u6491"} ${fmt(level)} \xB7 \u4E8C\u6B21\u6D4B\u8BD5 ${fmt(pattern.secondPrice)} \xB7 \u9888\u7EBF(\u7B2C\u4E00\u76EE\u6807) ${fmt(neck)} \xB7 \u8DDD\u73B0\u4EF7 ${distanceAtr.toFixed(1)} ATR`,
      `\u8BC1\u636E\uFF1A${reasons.join("\uFF1B") || "\u7F29\u91CF/\u62D2\u7EDD\u5F71\u7EBF/\u53CD\u5411\u6210\u4EA4\u5747\u672A\u51FA\u73B0"}`,
      flowLine,
      `\u5931\u6548\u6761\u4EF6\uFF1A${invalidate}\uFF08\u6536\u76D8\u624D\u7B97\uFF09`
    ];
    const id = `keycall:${pattern.side}:${cs[pattern.first].ts}:${cs[pattern.idx].ts}`;
    const item = {
      id,
      type: "keyLevelScenario",
      ts: cs[pattern.idx].ts,
      fromTs: cs[pattern.first].ts,
      price: level,
      title,
      detail,
      source: testFlow ? "real" : "price",
      confirmed: true,
      tone,
      event: {
        id: `${id}:mark`,
        ts: cs[pattern.idx].ts,
        side: top ? "above" : "below",
        tone,
        text: marker,
        marker: "diamond",
        priority: 96,
        title,
        detail
      },
      levels: [{
        id: `${id}:level`,
        name: shortLabel,
        fromTs: cs[pattern.first].ts,
        toTs: null,
        price: level,
        tone,
        style: "solid",
        rank: "read",
        priority: 98,
        label: true,
        detail
      }]
    };
    calls.push({
      patternKey: `${pattern.side}:${cs[pattern.first].ts}:${cs[pattern.idx].ts}`,
      item,
      side: pattern.side,
      level,
      neck,
      trap,
      bias,
      pullback,
      score,
      reasons,
      distanceAtr,
      patternIdx: pattern.idx,
      source: item.source
    });
  }
  const priority = (c) => c.item.event?.text === "\u5DF2\u5151\u73B0" ? 3 : c.trap ? 0 : c.bias === "wait" ? 2 : 1;
  const ranked = calls.sort((a, b) => priority(a) - priority(b) || a.distanceAtr - b.distanceAtr || b.patternIdx - a.patternIdx);
  const kept = [];
  const seenSide = /* @__PURE__ */ new Set();
  for (const c of ranked) {
    const key = `${c.side}:${c.item.tone}`;
    if (c.bias !== "wait" && seenSide.has(key)) continue;
    seenSide.add(key);
    kept.push(c);
    if (kept.length >= maxCalls) break;
  }
  return kept;
}

// tests/key-level-call.test.ts
var MS = 3e5;
var T0 = 17e11;
var n = 0;
var pass = (name) => {
  n++;
  console.log(`  \u2713 ${name}`);
};
var bar = (i, o, h, l, c, v = 1e3) => ({ ts: T0 + i * MS, o, h, l, c, v });
var M = {
  side: "top",
  idx: 60,
  first: 40,
  second: 60,
  neckIdx: 50,
  firstLegStart: 35,
  secondLegStart: 50,
  level: 104,
  neck: 100,
  secondPrice: 104.5
};
var W = {
  side: "bottom",
  idx: 60,
  first: 40,
  second: 60,
  neckIdx: 50,
  firstLegStart: 35,
  secondLegStart: 50,
  level: 96,
  neck: 100,
  secondPrice: 95.5
};
var flat = (len = 76, px = 100) => Array.from({ length: len }, (_, i) => bar(i, px, px + 0.5, px - 0.5, px));
var call = (cs, p2, flow = null) => buildKeyLevelCalls({ patterns: [p2], ctx: buildContext(cs, flow), flow, barMs: MS, maxCalls: 3 })[0];
var flowOf = (cs, ratio) => {
  const bars = new Map(cs.map((c, i) => [c.ts, { ts: c.ts, buy: c.v * (1 + ratio(i)) / 2, sell: c.v * (1 - ratio(i)) / 2, src: "rubik" }]));
  return { instId: "TEST", period: "5m", barMs: MS, bars, from: cs[0].ts, to: cs.at(-1).ts, oiFrom: Infinity, updatedAt: 0, complete: true, tape: { connected: true, trades: 1, bootstrapped: true } };
};
{
  const cs = flat(72);
  cs[40] = bar(40, 103.4, 104.6, 103.2, 104);
  cs[55] = bar(55, 100.4, 100.8, 99.6, 100);
  cs[60] = bar(60, 104, 104.5, 103.6, 103.4);
  for (let i = 51; i <= 60; i++) cs[i] = { ...cs[i], v: 700 };
  const r = call(cs, M, flowOf(cs, (i) => i === 60 ? -0.3 : 0));
  assert.equal(r.side, "top");
  assert.equal(r.bias, "sell");
  assert.equal(r.pullback, "strong");
  assert.equal(r.item.event?.text, "\u770B\u56DE\u8C03");
  assert.equal(r.item.levels?.[0]?.name, "\u53CC\u9876\xB7\u7B49\u56DE\u8C03");
  assert.equal(r.item.levels?.[0]?.price, 104, "annotation sits exactly on the double-top resistance");
  assert.equal(r.item.levels?.[0]?.label, true);
  assert.ok(r.item.detail[0].startsWith("\u7ED3\u8BBA\uFF1A\u504F\u7A7A"));
  assert.ok(r.item.detail.some((l) => l.includes("\u4E3B\u52A8\u5356") || l.includes("\u4E3B\u52A8\u4E70")));
  pass("\u53CC\u9876\u5173\u952E\u4F4D\uFF1A\u7F29\u91CF+\u62D2\u7EDD\u5F71\u7EBF+\u4E3B\u52A8\u5356 \u2192 \u504F\u7A7A / \u56DE\u8C03\u5F3A\uFF0C\u6807\u7B7E\u5728 104");
}
{
  const cs = flat(72);
  cs[40] = bar(40, 103.4, 104.6, 103.2, 104);
  cs[55] = bar(55, 100.4, 100.8, 99.6, 100);
  cs[60] = bar(60, 104, 104.5, 103.6, 103.4);
  cs[64] = bar(64, 104, 105.4, 103.9, 105.1, 2600);
  cs[65] = bar(65, 105.1, 105.5, 104.8, 105.2, 2600);
  cs[66] = bar(66, 105.2, 105.3, 103.2, 103.3, 2400);
  for (let i = 67; i < 76; i++) cs[i] = bar(i, 103.3, 103.7, 103, 103.2);
  const r = call(cs, M);
  assert.equal(r.trap, "bull");
  assert.equal(r.bias, "sell");
  assert.equal(r.item.event?.text, "\u8BF1\u591A");
  assert.equal(r.item.levels?.[0]?.name, "\u8BF1\u591A\xB7\u7B49\u56DE\u8C03");
  assert.ok(r.item.title.includes("\u8BF1\u591A"));
  pass("\u53CC\u9876\u8BF1\u591A\uFF08\u4E0A\u7834\u540E\u6536\u56DE\uFF09\u2192 \u660E\u786E\u504F\u7A7A / \u7B49\u56DE\u8C03");
}
{
  const cs = flat(72);
  cs[40] = bar(40, 96.6, 96.8, 95.4, 96);
  cs[55] = bar(55, 99.6, 100.4, 99.2, 100);
  cs[60] = bar(60, 96, 96.4, 95.5, 96.6);
  for (let i = 51; i <= 60; i++) cs[i] = { ...cs[i], v: 700 };
  cs[64] = bar(64, 96, 96.1, 94.6, 94.9, 2600);
  cs[65] = bar(65, 94.9, 95.2, 94.5, 94.8, 2600);
  cs[66] = bar(66, 94.8, 96.6, 94.7, 96.4, 2400);
  for (let i = 67; i < 76; i++) cs[i] = bar(i, 96.4, 96.7, 96.1, 96.5);
  const r = call(cs, W);
  assert.equal(r.trap, "bear");
  assert.equal(r.bias, "buy");
  assert.equal(r.item.event?.text, "\u8BF1\u7A7A");
  assert.equal(r.item.levels?.[0]?.name, "\u8BF1\u7A7A\xB7\u7B49\u53CD\u5F39");
  assert.ok(r.item.title.includes("\u8BF1\u7A7A"));
  pass("\u53CC\u5E95\u8BF1\u7A7A\uFF08\u8DCC\u7834\u540E\u6536\u56DE\uFF09\u2192 \u660E\u786E\u504F\u591A / \u7B49\u53CD\u5F39");
}
{
  const cs = flat(90);
  cs[40] = bar(40, 96.6, 96.8, 95.4, 96);
  cs[55] = bar(55, 99.6, 100.4, 99.2, 100);
  cs[60] = bar(60, 96, 96.4, 95.5, 96.6);
  for (let i = 61; i < 90; i++) {
    const px = 96.6 + (i - 61) * 0.04;
    cs[i] = bar(i, px, px + 0.4, px - 0.4, px);
  }
  const calls = buildKeyLevelCalls({ patterns: [W], ctx: buildContext(cs), barMs: MS });
  assert.equal(calls.length, 1, "the finished move stays visible as a record");
  assert.equal(calls[0].bias, "wait");
  assert.equal(calls[0].item.event?.text, "\u5DF2\u5151\u73B0");
  assert.equal(calls[0].item.levels?.[0]?.name, "\u5DF2\u53CD\u5F39\xB7\u4E0D\u8FFD");
  assert.ok(calls[0].item.detail[0].includes("\u4E0D\u8FFD"));
  pass("\u53CD\u5F39\u5DF2\u8D70\u5B8C \u2192 \u6807\u201C\u5DF2\u5151\u73B0\xB7\u4E0D\u8FFD\u201D\uFF0C\u65E2\u4E0D\u8FFD\u9AD8\u4E5F\u4E0D\u5047\u88C5\u8FD8\u5728\u7B49");
}
{
  const cs = flat(72);
  cs[40] = bar(40, 103.4, 104.6, 103.2, 104);
  cs[55] = bar(55, 100.4, 100.8, 99.6, 100);
  cs[60] = bar(60, 104, 104.5, 103.6, 103.4);
  cs[64] = bar(64, 104, 105.4, 103.9, 105.1, 2600);
  cs[65] = bar(65, 105.1, 105.5, 104.8, 105.2, 2600);
  for (let i = 66; i < 72; i++) cs[i] = bar(i, 105.2, 105.6, 105, 105.4);
  const r = call(cs, M);
  assert.equal(r.trap, null);
  assert.equal(r.bias, "wait");
  assert.equal(r.item.levels?.[0]?.name, "\u4E0A\u7834\xB7\u4E0D\u505A\u7A7A");
  assert.ok(r.item.detail[0].includes("\u4E0D\u5728\u8FD9\u91CC\u505A\u7A7A"));
  pass("\u963B\u529B\u88AB\u6709\u6548\u4E0A\u7834 \u2192 \u660E\u786E\u201C\u4E0D\u5728\u8FD9\u91CC\u505A\u7A7A\u201D\uFF0C\u4E0D\u786C\u7ED9\u7A7A\u5355");
}
{
  const cs = flat(80);
  cs[40] = bar(40, 103.4, 104.6, 103.2, 104);
  cs[55] = bar(55, 100.4, 100.8, 99.6, 100);
  cs[60] = bar(60, 104, 104.5, 103.6, 103.4);
  const dup = { ...M, first: 30, idx: 58, second: 58, level: 104.1 };
  const other = { ...M, level: 106, neck: 101 };
  const calls = buildKeyLevelCalls({ patterns: [M, dup, other], ctx: buildContext(cs), barMs: MS, maxCalls: 3 });
  assert.ok(calls.length <= 3);
  const levels = calls.map((c) => c.level);
  assert.ok(new Set(levels).size === levels.length);
  pass("\u540C\u4EF7\u4F4D\u5F62\u6001\u5408\u5E76\u3001\u6761\u6570\u53D7\u9650\uFF0C\u753B\u9762\u4E0D\u518D\u5806\u6EE1\u53CC\u9876");
}
{
  const cs = flat(72);
  cs[40] = bar(40, 103.4, 104.6, 103.2, 104);
  cs[55] = bar(55, 100.4, 100.8, 99.6, 100);
  cs[60] = bar(60, 104, 104.5, 103.6, 103.4);
  for (let i = 51; i <= 60; i++) cs[i] = { ...cs[i], v: 700 };
  const ctx = buildContext(cs);
  const calls = buildKeyLevelCalls({ patterns: [M], ctx, barMs: MS });
  assert.equal(calls.length, 1);
  const prefs = normalizePreferences({ ...DEFAULT_PREFERENCES, selected: Object.fromEntries(SIGNAL_TYPES.map((t) => [t.id, true])) });
  const structure = {
    id: "doubleTop:x",
    type: "doubleTop",
    ts: cs[60].ts,
    fromTs: cs[40].ts,
    price: 104,
    title: "\u53CC\u9876",
    detail: ["\u7ED3\u6784"],
    source: "price",
    confirmed: true,
    tone: "short",
    paint: false,
    event: { id: "dt", ts: cs[60].ts, side: "above", tone: "short", text: "\u53CC\u9876", marker: "tri", priority: 80 }
  };
  const projected = projectSignals({ items: [...calls.map((c) => c.item), structure], covered: 60, bars: 60, lastPrice: 100 }, prefs);
  const texts = projected.payload.events.map((e) => e.text);
  assert.ok(!texts.includes("\u53CC\u9876"), "structure marker stays in the sidebar");
  assert.ok(texts.includes("\u770B\u56DE\u8C03"), "the verdict is painted at the key level");
  const labels = projected.payload.levels.filter((l) => l.label).map((l) => `${l.name}@${l.price}`);
  assert.ok(labels.includes("\u53CC\u9876\xB7\u7B49\u56DE\u8C03@104"), `label sits on the key level: ${labels.join(" | ")}`);
  pass("\u7AEF\u5230\u7AEF\uFF1A\u5173\u952E\u4F4D\u6807\u7B7E=\u53CC\u9876\xB7\u7B49\u56DE\u8C03@104\uFF0C\u53CC\u9876\u7ED3\u6784\u6807\u8BB0\u4E0D\u4E0A\u56FE");
}
console.log(`
key-level-call: ${n} \u7EC4\u65AD\u8A00\u5168\u90E8\u901A\u8FC7`);
