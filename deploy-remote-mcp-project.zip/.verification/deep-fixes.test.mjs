// tests/deep-fixes.test.ts
import assert from "node:assert/strict";

// remote/setup-mcp-project-locally/src/lib/engine.ts
var FEE_RATE = 5e-4;
var SLIP_RATE = 1e-4;
function atrSeries(cs, p = 14) {
  const n = cs.length;
  const out = new Array(n).fill(0);
  const tr = new Array(n).fill(0);
  for (let i = 1; i < n; i++) {
    const c = cs[i];
    const pc = cs[i - 1].c;
    tr[i] = Math.max(c.h - c.l, Math.abs(c.h - pc), Math.abs(c.l - pc));
  }
  let sum = 0;
  for (let i = 1; i < n; i++) {
    sum += tr[i];
    if (i - p >= 1) sum -= tr[i - p];
    out[i] = sum / Math.min(i, p);
  }
  return out;
}
function approxDeltaAt(cs, i) {
  const c = cs[i];
  const range = c.h - c.l;
  if (range <= 0) return c.c > c.o ? c.v / 2 : c.c < c.o ? -c.v / 2 : 0;
  return c.v * (2 * ((c.c - c.l) / range) - 1);
}

// src/lib/types.ts
var SYMBOLS = [
  { id: "BTC-USDT-SWAP", base: "BTC", label: "BTC \u6C38\u7EED", ctVal: 0.01, minTick: 0.1 },
  { id: "ETH-USDT-SWAP", base: "ETH", label: "ETH \u6C38\u7EED", ctVal: 0.1, minTick: 0.01 },
  { id: "SOL-USDT-SWAP", base: "SOL", label: "SOL \u6C38\u7EED", ctVal: 1, minTick: 0.01 }
];
function ctValOf(symbol) {
  return SYMBOLS.find((s) => s.id === symbol)?.ctVal ?? 1;
}
var barMs = (bar) => bar === "15m" ? 9e5 : bar === "1m" ? 6e4 : 3e5;

// src/quant/flow.ts
var REST = "https://www.okx.com";
var WS_PUBLIC = "wss://ws.okx.com/ws/v5/public";
var PAGE = 100;
var cache = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var inflight = /* @__PURE__ */ new Map();
var PERIOD_MS = { "5m": 3e5, "15m": 9e5, "30m": 18e5, "1H": 36e5, "2H": 72e5, "4H": 144e5 };
var flowKey = (instId, period) => `${instId}|${period}`;
function getFlow(instId, period) {
  return cache.get(flowKey(instId, period));
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var notify = (snap) => {
  snap.updatedAt = Date.now();
  listeners.forEach((fn) => fn(snap));
};
function emptySnapshot(instId, period) {
  return {
    instId,
    period,
    barMs: PERIOD_MS[period] ?? 3e5,
    bars: /* @__PURE__ */ new Map(),
    recent: [],
    from: Infinity,
    to: 0,
    oiFrom: Infinity,
    updatedAt: 0,
    complete: false,
    rubikComplete: false,
    rubikFailedAt: 0,
    tape: { connected: false, trades: 0, bootstrapped: false }
  };
}
function rubikBase() {
  if (typeof window === "undefined") return REST;
  try {
    const v = localStorage.getItem("pulsedesk.okx-proxy");
    if (v && /^https?:\/\//.test(v)) return v.replace(/\/$/, "");
  } catch {
  }
  return `${window.location.origin}/api/okx`;
}
async function okxGet(base, path, params, signal) {
  const url = new URL(base + path);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch(url.toString(), { signal, cache: "no-store" });
    if (res.status === 429) {
      if (attempt === 2) throw new Error("OKX rate limited (429)");
      await sleep(900 * (attempt + 1));
      continue;
    }
    if (!res.ok) throw new Error(`OKX HTTP ${res.status}`);
    const json = await res.json();
    if (json.code && json.code !== "0") throw new Error(`OKX code ${json.code}`);
    return json.data ?? [];
  }
  return [];
}
var seenBySnapshot = /* @__PURE__ */ new WeakMap();
var seenMaxBySnapshot = /* @__PURE__ */ new WeakMap();
var SEEN_KEEP = 15e4;
var SEEN_TRIM_AT = 25e4;
function aggregateFlowTrades(snap, trades, ctVal) {
  let seen = seenBySnapshot.get(snap);
  if (!seen) {
    seen = /* @__PURE__ */ new Set();
    seenBySnapshot.set(snap, seen);
  }
  let maxId = seenMaxBySnapshot.get(snap) ?? 0;
  const recentStart = Math.floor(Date.now() / snap.barMs) * snap.barMs - 2 * snap.barMs;
  for (const t of trades) {
    if (!(t.px > 0 && t.sz > 0 && ctVal > 0) || !Number.isSafeInteger(t.tradeId) || !(t.ts > 0) || !Number.isFinite(t.ts) || t.side !== "buy" && t.side !== "sell") continue;
    if (seen.has(t.tradeId)) continue;
    seen.add(t.tradeId);
    if (t.tradeId > maxId) maxId = t.tradeId;
    const ts = Math.floor(t.ts / snap.barMs) * snap.barMs;
    const notional = t.px * t.sz * ctVal;
    if (!Number.isFinite(notional)) continue;
    const current = snap.bars.get(ts);
    if (current?.src === "rubik" && ts < recentStart) continue;
    let tapeBar;
    if (ts >= recentStart) {
      const tapeBars = snap.tapeBars ??= /* @__PURE__ */ new Map();
      tapeBar = tapeBars.get(ts) ?? (current?.src === "tape" ? { ...current } : { ts, buy: 0, sell: 0, src: "tape", trades: 0 });
      tapeBars.set(ts, tapeBar);
      if (current?.oiContracts) tapeBar.oiContracts = current.oiContracts;
      if (current?.oiUsd) tapeBar.oiUsd = current.oiUsd;
    } else {
      tapeBar = current?.src === "tape" ? current : { ts, buy: 0, sell: 0, src: "tape", trades: 0 };
    }
    if (t.side === "buy") tapeBar.buy += notional;
    else tapeBar.sell += notional;
    tapeBar.trades = (tapeBar.trades ?? 0) + 1;
    if (!current || current.src === "tape" || tapeBar.buy + tapeBar.sell > current.buy + current.sell) {
      snap.bars.set(ts, tapeBar);
    }
    const recent = snap.recent ??= [];
    recent.push({ ts: t.ts, side: t.side, notional });
    if (recent.length > 5e3) {
      const cutoff = Date.now() - 18e4;
      let drop = 0;
      while (drop < recent.length && recent[drop].ts < cutoff) drop++;
      if (drop > 0) recent.splice(0, drop);
      if (recent.length > 5e3) recent.splice(0, recent.length - 5e3);
    }
    snap.tape.trades++;
    snap.from = Math.min(snap.from, ts);
    snap.to = Math.max(snap.to, ts);
  }
  if (snap.tapeBars) {
    for (const ts of snap.tapeBars.keys()) if (ts < recentStart) snap.tapeBars.delete(ts);
  }
  seenMaxBySnapshot.set(snap, maxId);
  if (seen.size > SEEN_TRIM_AT) {
    const cutoff = maxId - SEEN_KEEP;
    for (const id of seen) if (id < cutoff) seen.delete(id);
  }
}
var parseTrades = (rows) => rows.filter((r) => r && (r.side === "buy" || r.side === "sell")).map((r) => ({ ts: Number(r.ts), px: Number(r.px), sz: Number(r.sz), side: r.side, tradeId: Number(r.tradeId) })).filter((t) => t.ts > 0 && t.px > 0 && t.sz > 0 && Number.isSafeInteger(t.tradeId) && Number.isFinite(t.ts));
var tapes = /* @__PURE__ */ new Map();
function ensureTape(instId, snap) {
  let tape = tapes.get(instId);
  if (!tape) {
    tape = { instId, ws: null, closed: false, snaps: /* @__PURE__ */ new Set(), retry: null, ping: null, rollover: null, needsRepair: false };
    tapes.set(instId, tape);
    openTape(tape);
  }
  tape.snaps.add(snap);
  if (snap.tape.bootstrapped && !snap.tape.connected) tape.needsRepair = true;
  return tape;
}
function openTape(tape) {
  if (tape.closed || typeof WebSocket === "undefined") return;
  let ws;
  try {
    ws = new WebSocket(WS_PUBLIC);
  } catch {
    tape.retry = setTimeout(() => openTape(tape), 3e3);
    return;
  }
  tape.ws = ws;
  const ctVal = ctValOf(tape.instId);
  ws.onopen = () => {
    if (tape.closed) {
      ws.close();
      return;
    }
    ws.send(JSON.stringify({ op: "subscribe", args: [{ channel: "trades", instId: tape.instId }] }));
    tape.ping = setInterval(() => ws.readyState === WebSocket.OPEN && ws.send("ping"), 25e3);
    tape.snaps.forEach((s) => {
      s.tape.connected = true;
      notify(s);
    });
  };
  ws.onmessage = (ev) => {
    if (tape.closed || ev.data === "pong") return;
    try {
      const msg = JSON.parse(ev.data);
      if (msg.arg?.channel !== "trades" || !Array.isArray(msg.data)) return;
      const trades = parseTrades(msg.data);
      for (const s of tape.snaps) {
        aggregateFlowTrades(s, trades, ctVal);
        if (trades.length && !tape.rollover) {
          tape.rollover = setTimeout(() => {
            tape.rollover = null;
            tape.snaps.forEach(notify);
          }, 250);
        }
      }
    } catch {
    }
  };
  ws.onclose = () => {
    if (tape.ping) clearInterval(tape.ping);
    tape.ping = null;
    tape.snaps.forEach((s) => {
      s.tape.connected = false;
      notify(s);
    });
    if (!tape.closed) {
      tape.needsRepair = true;
      tape.retry = setTimeout(() => openTape(tape), 2e3);
    }
  };
  ws.onerror = () => ws.close();
}
async function bootstrapTape(snap, tape, minTs, maxPages, signal) {
  const ctVal = ctValOf(snap.instId);
  let after;
  for (let p = 0; p < maxPages; p++) {
    if (signal?.aborted || tape.closed) return;
    const params = { instId: snap.instId, limit: String(PAGE), type: "1" };
    if (after) params.after = String(after);
    const rows = await okxGet(REST, "/api/v5/market/history-trades", params, signal);
    const trades = parseTrades(rows);
    if (!trades.length) break;
    if (signal?.aborted || tape.closed) return;
    aggregateFlowTrades(snap, trades, ctVal);
    const oldest = trades.reduce((m, t) => t.tradeId < m.tradeId ? t : m, trades[0]);
    after = oldest.tradeId;
    if (oldest.ts <= minTs) break;
    if (p % 15 === 14) notify(snap);
    await sleep(220);
  }
  snap.tape.bootstrapped = true;
}
var MAX_FLOW_BARS = 12e3;
function trimFlowBars(snap) {
  if (snap.bars.size <= MAX_FLOW_BARS) return;
  const keys = [...snap.bars.keys()].sort((a, b) => a - b);
  const drop = keys.length - MAX_FLOW_BARS;
  for (let i = 0; i < drop; i++) snap.bars.delete(keys[i]);
  if (keys.length > drop) snap.from = Math.max(snap.from, keys[drop]);
}
async function syncRubik(snap, base, minTs, maxPages, oiPages, signal) {
  const { instId, period } = snap;
  const takerStopTs = snap.rubikComplete && (snap.syncedPages ?? 0) >= maxPages && snap.to > 0 ? Math.max(minTs, snap.to - snap.barMs) : minTs;
  const oiStopTs = snap.rubikComplete && (snap.syncedOiPages ?? 0) >= oiPages && (snap.oiTo ?? 0) > 0 ? Math.max(minTs, snap.oiTo - snap.barMs) : Math.max(minTs, snap.from);
  const syncTaker = async () => {
    let end;
    for (let pages = 0; pages < maxPages; pages++) {
      const params = { instId, period, unit: "2", limit: String(PAGE) };
      if (end) params.end = String(end);
      const rows = await okxGet(base, "/api/v5/rubik/stat/taker-volume-contract", params, signal);
      if (!rows.length) break;
      let nonZero = 0;
      let oldest = Infinity;
      for (const r of rows) {
        const ts = Number(r[0]);
        const sell = Number(r[1]);
        const buy = Number(r[2]);
        if (!Number.isFinite(ts)) continue;
        oldest = Math.min(oldest, ts);
        if (!(buy > 0 || sell > 0)) continue;
        if (ts + snap.barMs > Date.now()) continue;
        nonZero++;
        const prev = snap.bars.get(ts);
        const tapeTotal = prev && prev.src === "tape" ? prev.buy + prev.sell : 0;
        if (tapeTotal > buy + sell) continue;
        snap.bars.set(ts, { ts, buy, sell, oiContracts: prev?.oiContracts, oiUsd: prev?.oiUsd, src: "rubik" });
        snap.from = Math.min(snap.from, ts);
        snap.to = Math.max(snap.to, ts);
      }
      if (!nonZero || !Number.isFinite(oldest) || oldest <= takerStopTs) break;
      end = oldest;
      if (pages + 1 < maxPages) await sleep(410);
    }
    snap.syncedPages = Math.max(snap.syncedPages ?? 0, maxPages);
  };
  const syncOi = async () => {
    let oiEnd;
    for (let p = 0; p < oiPages; p++) {
      const params = { instId, period, limit: String(PAGE) };
      if (oiEnd) params.end = String(oiEnd);
      const rows = await okxGet(base, "/api/v5/rubik/stat/contracts/open-interest-history", params, signal);
      if (!rows.length) break;
      let oldest = Infinity;
      for (const r of rows) {
        const ts = Number(r[0]);
        const oiContracts = Number(r[1]);
        const oiUsd = Number(r[3]);
        if (!Number.isFinite(ts) || !(oiContracts > 0) && !(oiUsd > 0)) continue;
        oldest = Math.min(oldest, ts);
        const prev = snap.bars.get(ts);
        if (prev) {
          prev.oiContracts = oiContracts > 0 ? oiContracts : void 0;
          prev.oiUsd = oiUsd > 0 ? oiUsd : void 0;
        } else {
          snap.bars.set(ts, {
            ts,
            buy: 0,
            sell: 0,
            oiContracts: oiContracts > 0 ? oiContracts : void 0,
            oiUsd: oiUsd > 0 ? oiUsd : void 0,
            src: "rubik"
          });
        }
        snap.oiFrom = Math.min(snap.oiFrom, ts);
        snap.oiTo = Math.max(snap.oiTo ?? 0, ts);
      }
      const stop = oiStopTs > 0 ? oiStopTs : Math.max(minTs, snap.from);
      if (!Number.isFinite(oldest) || oldest <= stop) break;
      oiEnd = oldest;
      if (p + 1 < oiPages) await sleep(410);
    }
    snap.syncedOiPages = Math.max(snap.syncedOiPages ?? 0, oiPages);
  };
  await Promise.all([syncTaker(), syncOi()]);
  trimFlowBars(snap);
}
function syncFlow(instId, period, opts) {
  const key = flowKey(instId, period);
  const running = inflight.get(key);
  if (running && !running.signal?.aborted) return running.promise;
  const job = (async () => {
    const snap = cache.get(key) ?? emptySnapshot(instId, period);
    cache.set(key, snap);
    if (opts.signal?.aborted) return snap;
    const liveTape = typeof window !== "undefined" ? ensureTape(instId, snap) : null;
    const base = rubikBase();
    try {
      const rubikCooling = !!snap.rubikFailedAt && Date.now() - snap.rubikFailedAt < 5 * 6e4;
      if (base && !rubikCooling) {
        try {
          await syncRubik(snap, base, opts.minTs, opts.maxPages ?? 16, opts.oiPages ?? 12, opts.signal);
          snap.rubikComplete = true;
          snap.rubikFailedAt = 0;
          snap.complete = true;
        } catch (e) {
          if (!opts.signal?.aborted) {
            snap.rubikFailedAt = Date.now();
            console.warn("[\u8BA2\u5355\u6D41] rubik \u7EDF\u8BA1\u4E0D\u53EF\u7528\uFF0C\u6539\u7528\u9010\u7B14\u6210\u4EA4\uFF1A", e);
          }
        }
      }
      if (opts.signal?.aborted) return snap;
      if (liveTape) {
        const tape = liveTape;
        if (snap.tape.bootstrapped && shouldRepairFlow(snap, tape.needsRepair)) {
          const repairMin = Math.floor(Date.now() / snap.barMs) * snap.barMs - 2 * snap.barMs;
          await bootstrapTape(snap, tape, repairMin, 24, opts.signal);
          tape.needsRepair = false;
          snap.repairedAt = Date.now();
        }
        if (!snap.tape.bootstrapped) {
          const rawBars = opts.bootstrapBars ?? 8;
          const targetBars = snap.rubikComplete ? Math.min(rawBars, 2) : rawBars;
          const recent = Math.floor(Date.now() / snap.barMs) * snap.barMs - targetBars * snap.barMs;
          await bootstrapTape(snap, tape, Math.max(opts.minTs, recent), opts.bootstrapPages ?? 220, opts.signal);
        }
        snap.complete = true;
      }
    } catch (e) {
      if (!opts.signal?.aborted) console.warn("[\u8BA2\u5355\u6D41] OKX \u540C\u6B65\u5931\u8D25\uFF1A", e);
    }
    notify(snap);
    return snap;
  })();
  inflight.set(key, { promise: job, signal: opts.signal });
  job.finally(() => {
    if (inflight.get(key)?.promise === job) inflight.delete(key);
  });
  return job;
}
function shouldRepairFlow(snap, needsRepair, now = Date.now()) {
  const stale = snap.to > 0 && now - snap.to > snap.barMs * 2;
  if (!needsRepair && !stale) return false;
  return now - (snap.repairedAt ?? 0) > snap.barMs;
}
function hasRealFlow(bar, candleVol, volumeSource) {
  if (volumeSource && volumeSource !== "quote") return false;
  if (!bar || !Number.isFinite(bar.buy) || !Number.isFinite(bar.sell) || bar.buy < 0 || bar.sell < 0 || !(bar.buy + bar.sell > 0) || candleVol == null || !Number.isFinite(candleVol) || !(candleVol > 0)) return false;
  const coverage = (bar.buy + bar.sell) / candleVol;
  return coverage >= (bar.src === "rubik" ? 0.95 : 0.85) && coverage <= 1.1;
}

// src/quant/context.ts
function emaSeries(cs, period) {
  const k = 2 / (period + 1);
  const out = new Array(cs.length);
  let e = cs[0]?.c ?? 0;
  for (let i = 0; i < cs.length; i++) {
    e = i === 0 ? cs[i].c : cs[i].c * k + e * (1 - k);
    out[i] = e;
  }
  return out;
}
function buildContext(cs, flow) {
  const n = cs.length;
  const atr = atrSeries(cs);
  const delta = new Array(n);
  const real = new Uint8Array(n);
  const oi = new Array(n).fill(NaN);
  const vols = new Array(n);
  const volMa = new Array(n).fill(0);
  const index = /* @__PURE__ */ new Map();
  let covered = 0;
  for (let i = 0; i < n; i++) {
    const fb = flow?.bars.get(cs[i].ts);
    if (hasRealFlow(fb, cs[i].v, cs[i].volumeSource)) {
      delta[i] = fb.buy - fb.sell;
      real[i] = 1;
      covered++;
    } else {
      delta[i] = approxDeltaAt(cs, i);
    }
    const position = fb?.oiContracts && fb.oiContracts > 0 ? fb.oiContracts : fb?.oiUsd;
    if (position && position > 0) oi[i] = position;
    vols[i] = cs[i].v;
    index.set(cs[i].ts, i);
  }
  let s = 0;
  for (let i = 0; i < n; i++) {
    if (i >= 1) s += cs[i - 1].v;
    if (i >= 21) s -= cs[i - 21].v;
    const m = Math.min(i, 20);
    volMa[i] = m ? s / m : cs[i].v;
  }
  return {
    cs,
    n,
    atr,
    delta,
    real,
    oi,
    vols,
    ema20: emaSeries(cs, 20),
    ema50: emaSeries(cs, 50),
    volMa,
    index,
    flowCoverage: n ? covered / n : 0
  };
}

// src/quant/orderflow.ts
var clamp01 = (v) => v < 0 ? 0 : v > 1 ? 1 : v;
var clampR = (v, lo = -1, hi = 1) => v < lo ? lo : v > hi ? hi : v;
var r3 = (v) => Number.isFinite(v) ? Number(v.toFixed(3)) : 0;
var pct = (v) => `${v >= 0 ? "+" : ""}${(v * 100).toFixed(0)}%`;
function windowFlow(ctx, from, to) {
  const a = Math.max(0, Math.min(from, to));
  const b = Math.min(ctx.n - 1, Math.max(from, to));
  let vol = 0;
  let delta = 0;
  let known = 0;
  let base = 0;
  let bars = 0;
  for (let i = a; i <= b; i++) {
    vol += ctx.vols[i];
    delta += ctx.delta[i];
    known += ctx.real[i];
    base += ctx.volMa[i];
    bars++;
  }
  return {
    from: a,
    to: b,
    bars,
    vol,
    delta,
    ratio: vol > 0 ? delta / vol : 0,
    known: bars ? known / bars : 0,
    volRatio: base > 0 ? vol / base : 1
  };
}
function pivotOf(ctx, sig) {
  const pts = sig.geo?.pts ?? [];
  const at = (label) => pts.find((p) => p.label.includes(label));
  const priorPt = at("\u8D77");
  const firstPt = at("\u4E00");
  const neckPt = at("\u9888\u7EBF");
  const secondPt = at("\u4E8C");
  const idxOf = (ts, fallback) => ctx.index.get(ts) ?? fallback;
  const i = sig.idx;
  const prior = idxOf(priorPt?.ts ?? -1, Math.max(0, i - 140));
  const first = idxOf(firstPt?.ts ?? -1, Math.max(0, i - 60));
  const neck = idxOf(neckPt?.ts ?? -1, Math.max(first + 1, i - 12));
  const second = idxOf(secondPt?.ts ?? -1, i);
  return {
    prior,
    first,
    neck,
    second: Math.max(first, second),
    level: firstPt?.price ?? (ctx.cs[first]?.c ?? sig.entry),
    neckPrice: neckPt?.price ?? sig.tp,
    secondPrice: secondPt?.price ?? sig.entry
  };
}
function legsOf(pv) {
  let l1a = Math.min(pv.prior, pv.first);
  let l1b = Math.max(pv.prior, pv.first);
  let l2a = Math.min(pv.neck, pv.second);
  let l2b = Math.max(pv.neck, pv.second);
  if (l1b - l1a < 2) {
    l1a = Math.max(0, pv.first - 24);
    l1b = pv.first;
  }
  if (l2b - l2a < 2) {
    l2a = Math.max(pv.first + 1, pv.second - 24);
    l2b = pv.second;
  }
  return { l1a, l1b, l2a, l2b };
}
var logistic = (x) => 1 / (1 + Math.exp(-x));
var roundPx = (v) => Number.isFinite(v) ? Number(v.toFixed(v >= 1e3 ? 2 : 6)) : 0;
function readTouch(ctx, level, idx, testIdx) {
  const { cs, n, atr, delta, vols, volMa } = ctx;
  const i = Math.max(0, Math.min(idx, n - 1));
  const a = Math.max(atr[i] || 0, 1e-9);
  const top = level.side === "top";
  const dir = top ? -1 : 1;
  const up = top ? 1 : -1;
  const px = level.price;
  const over = (v) => (top ? v - px : px - v) / a;
  let t = Math.max(0, Math.min(testIdx ?? i, n - 1));
  if (testIdx == null) {
    for (let q = Math.max(0, i - 5); q <= i; q++) if (top ? cs[q].h > cs[t].h : cs[q].l < cs[t].l) t = q;
  }
  const tb = cs[t];
  const depth = over(top ? tb.h : tb.l);
  const approach = windowFlow(ctx, Math.max(0, t - 4), t);
  const wide = windowFlow(ctx, Math.max(0, t - 12), t);
  const after = i > t ? windowFlow(ctx, t + 1, i) : null;
  const tvol = vols[t];
  const tRatio = tvol > 0 ? delta[t] / tvol : 0;
  const tVol = volMa[t] > 0 ? tvol / volMa[t] : 1;
  const range = Math.max(1e-9, tb.h - tb.l);
  const wick = top ? (tb.h - Math.max(tb.o, tb.c)) / range : (Math.min(tb.o, tb.c) - tb.l) / range;
  const known = ctx.real[t] === 1;
  const inside = over(tb.c) <= 0.05;
  let beyondCloses = 0;
  for (let q = t; q <= i; q++) if (over(cs[q].c) > 0.1) beyondCloses++;
  const accepted = over(cs[i].c) > 0.2 || beyondCloses >= 2;
  const near = depth > -0.5;
  const pressure = clampR(approach.ratio * up * 4);
  const thrust = clamp01((approach.volRatio - 1.2) / 1) * clamp01(pressure * 1.5);
  const e1 = clampR(-pressure - 0.6 * thrust) * approach.known;
  let e2 = 0;
  if (known) {
    if (inside && tVol >= 1.1 && tRatio * up <= 0.05) e2 = 0.8;
    else if (inside && tVol < 0.9) e2 = 0.4;
    else if (!inside && tRatio * up > 0.1 && tVol >= 1.2) e2 = -0.9;
    else if (!inside) e2 = -0.3;
  } else {
    if (inside && tVol < 0.9) e2 = 0.35;
    else if (!inside) e2 = -0.35;
  }
  const e3 = near ? clampR((wick - 0.3) * 2) : 0;
  const e4 = clampR(-wide.ratio * up * 5) * wide.known;
  const e5 = after ? clampR(-after.ratio * up * 4) * after.known : null;
  const wsum = 0.3 + 0.25 + 0.12 + 0.13 + (e5 == null ? 0 : 0.2);
  let ev = (0.3 * e1 + 0.25 * e2 + 0.12 * e3 + 0.13 * e4 + (e5 == null ? 0 : 0.2 * e5)) / wsum;
  if (accepted) ev = Math.min(ev, -0.6);
  ev = clampR(ev * 1.6);
  const buy = top ? "\u4E3B\u52A8\u4E70\u5165" : "\u4E3B\u52A8\u5356\u51FA";
  const sell = top ? "\u4E3B\u52A8\u5356\u51FA" : "\u4E3B\u52A8\u4E70\u5165";
  const word = top ? "\u524D\u9AD8" : "\u524D\u4F4E";
  const src = known ? "" : "\uFF08\u8FD1\u4F3C\uFF09";
  const reasons = [];
  if (accepted) reasons.push(`\u6536\u76D8\u5DF2\u7AD9\u5728${word}\u5916\u4FA7\uFF08${beyondCloses} \u6839\uFF09\uFF1A\u7A81\u7834\u88AB\u63A5\u53D7`);
  if (depth > 0.05 && !accepted) reasons.push(`\u523A\u7834${word} ${depth.toFixed(2)} ATR${inside ? "\u540E\u6536\u56DE" : "\uFF0C\u5C1A\u672A\u6536\u56DE"}`);
  if (pressure <= -0.15) reasons.push(`\u51B2\u5411${word}\u65F6${sell}\u5DF2\u5360\u4F18\uFF08${pct(approach.ratio * -up)}\uFF09\uFF1A\u63A8\u8FDB\u52A8\u80FD\u4E0D\u5728\u7A81\u7834\u65B9${src}`);
  else if (pressure < 0.2) reasons.push(`\u51B2\u5411${word}\u65F6${buy}\u504F\u5F31\uFF08${pct(approach.ratio * up)}\uFF09\uFF1A\u7F3A\u5C11\u7A81\u7834\u52A8\u80FD${src}`);
  else reasons.push(`\u51B2\u5411${word}\u7684${buy}\u5F3A\u52B2\uFF08${pct(approach.ratio * up)}${thrust > 0.3 ? `\uFF0C\u653E\u91CF ${approach.volRatio.toFixed(1)}x` : ""}\uFF09\uFF1A\u5B58\u5728\u771F\u7A81\u7834\u98CE\u9669${src}`);
  if (e2 >= 0.8) reasons.push(`\u89E6${word}\u90A3\u6839\u653E\u91CF ${tVol.toFixed(1)}x \u5374\u6536\u5728\u4F4D\u5185\u3001${buy}\u672A\u5360\u4F18\uFF1A\u7A81\u7834\u76D8\u88AB\u5438\u6536`);
  else if (e2 > 0) reasons.push(`\u89E6${word}\u90A3\u6839\u7F29\u91CF ${tVol.toFixed(1)}x \u4E14\u6536\u5728\u4F4D\u5185\uFF1A\u8FFD\u4EF7\u610F\u613F\u4E0D\u8DB3`);
  else if (e2 <= -0.9) reasons.push(`\u89E6${word}\u90A3\u6839\u653E\u91CF ${tVol.toFixed(1)}x\u3001${buy} ${pct(tRatio * up)} \u4E14\u6536\u5728\u4F4D\u5916\uFF1A\u7A81\u7834\u65B9\u4E3B\u5BFC`);
  if (near && wick >= 0.45) reasons.push(`\u89E6${word}\u90A3\u6839${top ? "\u4E0A" : "\u4E0B"}\u5F71\u7EBF\u5360 ${Math.round(wick * 100)}%\uFF1A\u62D2\u7EDD\u660E\u663E`);
  if (e4 > 0.3) reasons.push(`\u8FD1 12 \u6839\u7D2F\u8BA1${buy}\u6CA1\u6709\u8DDF\u4E0A\u4EF7\u683C\uFF1ACVD \u80CC\u79BB`);
  if (after && e5 != null && e5 > 0.25) reasons.push(`\u89E6\u53CA\u4E4B\u540E${sell}\u63A5\u7BA1\uFF08${pct(-after.ratio * up)}\uFF09`);
  else if (after && e5 != null && e5 < -0.25) reasons.push(`\u89E6\u53CA\u4E4B\u540E${buy}\u7EE7\u7EED\u5360\u4F18\uFF08${pct(after.ratio * up)}\uFF09`);
  const fakeProb = clamp01(logistic(ev * 1.6));
  const breakProb = 1 - fakeProb;
  const kind = accepted ? "accepted" : depth > 0.05 ? "sweep" : depth > -0.35 ? "touch" : "approach";
  const verdict = accepted ? "breakout" : fakeProb >= 0.62 ? "reject" : fakeProb <= 0.4 ? "breakout" : "uncertain";
  const pc = Math.round(fakeProb * 100);
  const act = top ? "\u505A\u7A7A" : "\u505A\u591A";
  const tag = top ? "\u89E6\u9876" : "\u89E6\u5E95";
  const headline = accepted ? top ? "\u6536\u76D8\u7AD9\u4E0A\u524D\u9AD8\uFF1A\u771F\u7A81\u7834\uFF0C\u4E0D\u505A\u7A7A" : "\u6536\u76D8\u8DCC\u7834\u524D\u4F4E\uFF1A\u771F\u8DCC\u7834\uFF0C\u4E0D\u505A\u591A" : verdict === "reject" ? kind === "approach" ? `\u63A5\u8FD1${word}\uFF1A\u8BA2\u5355\u6D41\u504F\u5411\u88AB\u62D2\u7EDD\uFF08\u5047\u7A81\u7834 ${pc}%\uFF09\uFF0C\u89E6\u53CA\u540E\u53EF${act}` : `${tag}\u8BA2\u5355\u6D41\uFF1A\u5047\u7A81\u7834\u6982\u7387 ${pc}% \u2192 \u53EF${act}` : verdict === "breakout" ? `${tag}\u8BA2\u5355\u6D41\uFF1A\u7A81\u7834\u6982\u7387 ${100 - pc}%\uFF08${buy}\u4ECD\u5728\u63A8\u8FDB\uFF09\uFF0C\u4E0D\u62A2${top ? "\u7A7A" : "\u591A"}` : `${tag}\u8BA2\u5355\u6D41\u4E0D\u660E\u6717\uFF08\u5047\u7A81\u7834 ${pc}%\uFF09\uFF1A\u7B49\u62D2\u7EDDK\u6216\u7A81\u7834\u786E\u8BA4`;
  let plan = null;
  if (!accepted) {
    let ext = px;
    for (let q = t; q <= i; q++) ext = top ? Math.max(ext, cs[q].h) : Math.min(ext, cs[q].l);
    const entry = px + dir * 0.1 * a;
    const stop = ext - dir * 0.75 * a;
    const risk = Math.abs(entry - stop);
    let neck = entry;
    for (let q = Math.max(0, level.idx ?? i - 60); q <= i; q++) neck = top ? Math.min(neck, cs[q].l) : Math.max(neck, cs[q].h);
    const dist = Math.min(Math.max(Math.abs(entry - neck), 1.2 * risk), 4 * risk);
    if (risk > 0) plan = { entry: roundPx(entry), stop: roundPx(stop), tp: roundPx(entry + dir * dist), rr: Number((dist / risk).toFixed(1)) };
  }
  return {
    side: level.side,
    dir,
    level: px,
    testIdx: t,
    kind,
    depthAtr: r3(depth),
    approach,
    pressure: r3(pressure),
    bar: { deltaRatio: r3(tRatio), volRatio: r3(tVol), wick: r3(wick), known },
    evidence: r3(ev),
    fakeProb: r3(fakeProb),
    breakProb: r3(breakProb),
    verdict,
    reasons,
    headline,
    plan
  };
}
var sourceOf = (known) => known >= 0.95 ? "taker" : known <= 0.05 ? "approx" : "mixed";
function readSecondTest(ctx, sig) {
  const { cs, n, atr, delta, vols, volMa, oi } = ctx;
  const i = Math.min(sig.idx, n - 1);
  const a = Math.max(atr[i] || 0, 1e-9);
  const pv = pivotOf(ctx, sig);
  const dir = sig.side === "long" ? 1 : -1;
  const top = dir < 0;
  const { l1a, l1b, l2a, l2b } = legsOf(pv);
  const leg1 = windowFlow(ctx, l1a, l1b);
  const leg2 = windowFlow(ctx, l2a, l2b);
  let cvdFirst = 0;
  let cvdSecond = 0;
  let totalVol = 0;
  let betweenKnown = 0;
  let betweenBars = 0;
  for (let q = l1a; q <= Math.min(n - 1, pv.second); q++) {
    if (q <= pv.first) cvdFirst += delta[q];
    else {
      betweenKnown += ctx.real[q];
      betweenBars++;
    }
    cvdSecond += delta[q];
    totalVol += vols[q];
  }
  const norm = Math.max(1e-9, totalVol * 0.08);
  const cvdCov = betweenBars > 0 ? betweenKnown / betweenBars : 0;
  const flowCov = Math.min(leg1.known, leg2.known);
  const cvdDiv = clampR((cvdSecond - cvdFirst) * dir / norm * cvdCov);
  const legDeltaDiff = clampR((leg2.ratio - leg1.ratio) * dir * 6 * flowCov);
  const v1 = leg1.vol / Math.max(1, leg1.bars);
  const v2 = leg2.vol / Math.max(1, leg2.bars);
  const legVolRatio = v1 > 0 ? v2 / v1 : 1;
  const from = Math.max(0, Math.min(pv.second, i));
  const to = Math.min(n - 1, Math.max(i, pv.second));
  let absorb = 0;
  let breach = 0;
  let deepestIdx = from;
  let depth = 0;
  let sweepBars = 0;
  let sweepFrom = -1;
  let sweepTo = -1;
  for (let q = from; q <= to; q++) {
    const c = cs[q];
    const avg = volMa[q] > 0 ? volMa[q] : c.v || 1;
    const beyond = top ? c.h - pv.level : pv.level - c.l;
    if (beyond > depth) {
      depth = beyond;
    }
    if (top ? c.h > cs[deepestIdx].h : c.l < cs[deepestIdx].l) deepestIdx = q;
    if (beyond > 0.05 * a) {
      sweepBars++;
      if (sweepFrom < 0) sweepFrom = q;
      sweepTo = q;
    }
    if (top) {
      if (c.h >= pv.level - 0.1 * a && c.c <= pv.level - 0.25 * a && c.v >= avg * 1.1) absorb++;
      if (c.c > pv.level + 0.2 * a) breach++;
    } else {
      if (c.l <= pv.level + 0.1 * a && c.c >= pv.level + 0.25 * a && c.v >= avg * 1.1) absorb++;
      if (c.c < pv.level - 0.2 * a) breach++;
    }
  }
  const sweepFlow = sweepFrom >= 0 ? windowFlow(ctx, sweepFrom, sweepTo) : null;
  const last = cs[to];
  const closedInside = top ? last.c <= pv.level : last.c >= pv.level;
  const accepted = top ? last.c > pv.level + 0.2 * a : last.c < pv.level - 0.2 * a;
  const barOf = (q) => ({
    idx: q,
    deltaRatio: vols[q] > 0 ? delta[q] / vols[q] : 0,
    volRatio: volMa[q] > 0 ? vols[q] / volMa[q] : 1,
    known: ctx.real[q] === 1
  });
  const test2 = barOf(deepestIdx);
  const confirm = { ...barOf(to), closedInside };
  let oiPct = null;
  const oiStart = oi[l2a];
  const oiEnd = oi[Math.min(n - 1, pv.second)];
  if (Number.isFinite(oiStart) && Number.isFinite(oiEnd) && oiStart > 0) oiPct = oiEnd / oiStart - 1;
  const reasons = [];
  let score = 0;
  const depthAtr = depth / a;
  const occurred = sweepBars > 0 && depthAtr >= 0.05;
  const sideWord = top ? "\u963B\u529B" : "\u652F\u6491";
  if (occurred) {
    score += 0.3 + clamp01((depthAtr - 0.1) / 0.5) * 0.15;
    reasons.push(`${top ? "\u4E0A\u7A7F" : "\u4E0B\u7834"}${sideWord} ${depthAtr.toFixed(2)} ATR\uFF08\u626B\u635F\uFF09${closedInside ? "\u540E\u6536\u56DE" : "\uFF0C\u5C1A\u672A\u6536\u56DE"}`);
    if (sweepFlow) {
      const w = sweepFlow.known >= 0.5 ? 1 : 0.5;
      const against = sweepFlow.ratio * dir;
      if (against > 0.05) {
        score += 0.2 * w;
        reasons.push(top ? `\u626B\u9AD8\u671F\u95F4\u4E3B\u52A8\u5356\u51FA\u5360\u4F18\uFF08${pct(sweepFlow.ratio)}\uFF09\uFF1A\u8FFD\u591A\u76D8\u88AB\u53CD\u624B` : `\u626B\u4F4E\u671F\u95F4\u4E3B\u52A8\u4E70\u5165\u5360\u4F18\uFF08${pct(sweepFlow.ratio)}\uFF09\uFF1A\u7834\u4F4D\u5356\u76D8\u88AB\u627F\u63A5`);
      } else if (against < -0.12 && sweepFlow.volRatio >= 1.3 && closedInside) {
        score += 0.2 * w;
        reasons.push(top ? `\u8FFD\u591A\u6210\u4EA4\u653E\u91CF ${sweepFlow.volRatio.toFixed(1)}x \u5374\u88AB\u5438\u6536\uFF0C\u4EF7\u683C\u6536\u56DE` : `\u6050\u614C\u5356\u51FA\u653E\u91CF ${sweepFlow.volRatio.toFixed(1)}x \u5374\u88AB\u5438\u6536\uFF0C\u4EF7\u683C\u6536\u56DE`);
      } else if (against < -0.12 && !closedInside) {
        score -= 0.3;
        reasons.push(`\u7A81\u7834\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u5360\u4F18\uFF08${pct(sweepFlow.ratio)}\uFF09\u4E14\u672A\u6536\u56DE\uFF1A\u66F4\u50CF\u771F\u7A81\u7834`);
      }
    }
  }
  if (cvdDiv > 0.25) {
    score += 0.15;
    reasons.push(top ? "CVD \u80CC\u79BB\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u9AD8\uFF0C\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5165\u672A\u8DDF\u4E0A" : "CVD \u80CC\u79BB\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u4F4E\uFF0C\u7D2F\u8BA1\u4E3B\u52A8\u5356\u51FA\u672A\u8DDF\u4E0A");
  }
  if (legDeltaDiff > 0.3) {
    score += 0.1;
    reasons.push(top ? `\u7B2C\u4E8C\u817F\u4E3B\u52A8\u4E70\u5165 ${pct(leg2.ratio)} \u5F31\u4E8E\u7B2C\u4E00\u817F ${pct(leg1.ratio)}` : `\u7B2C\u4E8C\u817F\u4E3B\u52A8\u5356\u51FA ${pct(-leg2.ratio)} \u5F31\u4E8E\u7B2C\u4E00\u817F ${pct(-leg1.ratio)}`);
  }
  if (oiPct != null && oiPct > 3e-3) {
    score += 0.1;
    reasons.push(top ? `\u51B2\u9AD8\u6BB5\u6301\u4ED3 +${(oiPct * 100).toFixed(2)}%\uFF1A\u65B0\u591A\u5728\u9876\u90E8\u88AB\u5957` : `\u6740\u8DCC\u6BB5\u6301\u4ED3 +${(oiPct * 100).toFixed(2)}%\uFF1A\u65B0\u7A7A\u5728\u5E95\u90E8\u88AB\u5957`);
  }
  if (absorb > 0) {
    score += 0.1;
    reasons.push(`${sideWord}\u4F4D\u51FA\u73B0 ${absorb} \u6839\u653E\u91CF\u523A\u7834\u540E\u6536\u56DE\u7684\u5438\u6536K`);
  }
  if (breach > 0 && !closedInside) {
    score -= 0.25;
    reasons.push(`\u5DF2\u6709 ${breach} \u6839\u6536\u76D8\u505C\u5728${sideWord}\u5916\u4FA7`);
  }
  score = clamp01(score);
  const kind = !accepted && score >= 0.5 ? top ? "bullTrap" : "bearTrap" : null;
  const lean = clamp01(
    0.5 + 0.14 * cvdDiv + 0.1 * legDeltaDiff + 0.08 * clampR((1 - legVolRatio) * 2) + (sweepFlow ? 0.1 * clampR(sweepFlow.ratio * dir * 4) : 0) + 0.08 * clampR(confirm.deltaRatio * dir * 3) - (accepted ? 0.25 : 0)
  );
  const knownAll = (leg1.known * leg1.bars + leg2.known * leg2.bars) / Math.max(1, leg1.bars + leg2.bars);
  const flowSource = sourceOf(knownAll);
  const headline = accepted ? top ? "\u4EF7\u683C\u6536\u76D8\u7AD9\u4E0A\u963B\u529B\uFF1A\u53CC\u9876\u5931\u6548\uFF0C\u53EF\u80FD\u662F\u771F\u7A81\u7834" : "\u4EF7\u683C\u6536\u76D8\u8DCC\u7834\u652F\u6491\uFF1A\u53CC\u5E95\u5931\u6548\uFF0C\u53EF\u80FD\u662F\u771F\u8DCC\u7834" : kind ? top ? "\u8BF1\u591A\uFF1A\u626B\u8FC7\u524D\u9AD8\u540E\u6536\u56DE\uFF0C\u7A81\u7834\u4E70\u76D8\u88AB\u5957" : "\u8BF1\u7A7A\uFF1A\u626B\u8FC7\u524D\u4F4E\u540E\u6536\u56DE\uFF0C\u7834\u4F4D\u5356\u76D8\u88AB\u5957" : occurred ? `${top ? "\u626B\u9AD8" : "\u626B\u4F4E"}\u540E\u6536\u56DE\uFF0C\u4F46\u8BA2\u5355\u6D41\u786E\u8BA4\u4E0D\u8DB3` : top ? "\u7B49\u9AD8\u4E8C\u6B21\u6D4B\u8BD5\uFF1A\u672A\u626B\u524D\u9AD8" : "\u7B49\u4F4E\u4E8C\u6B21\u6D4B\u8BD5\uFF1A\u672A\u626B\u524D\u4F4E";
  return {
    scene: top ? "doubleTop" : "doubleBottom",
    dir,
    level: pv.level,
    neck: pv.neckPrice,
    leg1,
    leg2,
    cvdDiv: r3(cvdDiv),
    legDeltaDiff: r3(legDeltaDiff),
    legVolRatio: r3(legVolRatio),
    test: test2,
    confirm,
    sweep: { occurred, depthAtr: r3(depthAtr), bars: sweepBars, flow: sweepFlow, accepted },
    absorption: { count: absorb, breach },
    oi: { pct: oiPct == null ? null : r3(oiPct) },
    trap: { kind, score: r3(score), reasons },
    touch: readTouch(ctx, { price: pv.level, side: top ? "top" : "bottom", idx: pv.first }, i, deepestIdx),
    lean: r3(lean),
    flowSource,
    headline
  };
}

// src/quant/model.ts
var FACTORS = [
  {
    key: "touchFlow",
    label: "\u89E6\u9876\u8BA2\u5355\u6D41",
    short: "TOUCH",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.95,
    hint: "\u4EF7\u683C\u89E6\u53CA\uFF08\u6216\u903C\u8FD1\uFF09\u524D\u9AD8/\u524D\u4F4E\u65F6\uFF0C\u7528\u8BA2\u5355\u6D41\u5224\u65AD\u662F\u771F\u7A81\u7834\u8FD8\u662F\u5047\u7A81\u7834\uFF1A\u51B2\u5411\u5173\u952E\u4F4D\u7684\u4E3B\u52A8\u6210\u4EA4\u662F\u5426\u5F3A\u52B2\u3001\u89E6\u53CA\u90A3\u6839\u662F\u5426\u88AB\u5438\u6536\uFF08\u653E\u91CF\u6536\u5728\u4F4D\u5185\u3001\u7A81\u7834\u65B9\u6CA1\u8D62\u5F97\u4E3B\u52A8\u6210\u4EA4\uFF09\u3001\u62D2\u7EDD\u5F71\u7EBF\u3001\u7D2F\u8BA1\u4E3B\u52A8\u6210\u4EA4\uFF08CVD\uFF09\u662F\u5426\u8DDF\u4E0A\u4EF7\u683C\u3001\u89E6\u53CA\u4E4B\u540E\u53CD\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u662F\u5426\u63A5\u7BA1\u3002+1 = \u660E\u663E\u7684\u5047\u7A81\u7834/\u88AB\u62D2\u7EDD\uFF0C\u22121 = \u771F\u7A81\u7834\uFF08\u7A81\u7834\u65B9\u4E3B\u5BFC\u6216\u6536\u76D8\u5DF2\u7AD9\u5230\u5173\u952E\u4F4D\u5916\u4FA7\uFF09\u3002"
  },
  {
    key: "volDiverge",
    label: "\u4E8C\u6B21\u6D4B\u8BD5\u7F29\u91CF",
    short: "VOL DIV",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.55,
    hint: "\u7B2C\u4E8C\u817F\uFF08\u63A8\u5411\u4E8C\u9876/\u4E8C\u5E95\uFF09\u7684\u5355\u4F4D\u6210\u4EA4\u91CF\u660E\u663E\u5C0F\u4E8E\u7B2C\u4E00\u817F \u2192 \u63A8\u52A8\u52A8\u80FD\u8870\u7AED\uFF0C\u53CD\u8F6C\u6982\u7387\u4E0A\u5347\uFF1B\u653E\u91CF\u521B\u65B0\u9AD8/\u65B0\u4F4E\u5219\u66F4\u53EF\u80FD\u662F\u7A81\u7834\u800C\u975E\u53CC\u9876\u3002"
  },
  {
    key: "deltaDiverge",
    label: "\u4E3B\u52A8\u6210\u4EA4\u5DEE\u80CC\u79BB",
    short: "CVD DIV",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.7,
    hint: "\u7528\u9010\u6839\u4E3B\u52A8\u4E70\u5356\u5DEE\uFF08delta/\u6210\u4EA4\u91CF\uFF09\u8861\u91CF\uFF1A\u4EF7\u683C\u518D\u521B\u65B0\u9AD8\u4F46\u5DEE\u503C\u8D70\u5F31\uFF08\u9876\uFF09\u6216\u4EF7\u683C\u518D\u521B\u65B0\u4F4E\u4F46\u629B\u538B\u8D70\u5F31\uFF08\u5E95\uFF09= \u7ECF\u5178\u8BA2\u5355\u6D41\u80CC\u79BB\u3002"
  },
  {
    key: "absorption",
    label: "\u5173\u952E\u4F4D\u5438\u6536\u5019\u9009",
    short: "ABSORB",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.8,
    hint: "\u6D4B\u8BD5\u7A97\u53E3\u5185\u51FA\u73B0\u201C\u653E\u91CF\u523A\u7834\u5173\u952E\u4F4D\u4F46\u6536\u76D8\u6536\u56DE\u201D\u7684K\u7EBF\uFF08\u4EF7\u683C\u7ED3\u679C\u672A\u8DDF\u968F\u4E3B\u52A8\u63A8\u8FDB\uFF09\u8D8A\u591A\uFF0C\u8D8A\u652F\u6301\u627F\u63A5\u5019\u9009\uFF1B\u4E0D\u8BC1\u660E\u88AB\u52A8\u8BA2\u5355\u8EAB\u4EFD\uFF1B\u6536\u76D8\u505C\u5728\u5173\u952E\u4F4D\u5916\u4FA7\u5219\u89C6\u4E3A\u51FB\u7A7F\u3002"
  },
  {
    key: "wickReject",
    label: "\u62D2\u7EDD\u5F71\u7EBF",
    short: "REJECT",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.5,
    hint: "\u6700\u6DF1\u6D4B\u8BD5K\u7EBF\u7684\u5F71\u7EBF\u5360\u6BD4 + \u786E\u8BA4K\u7EBF\u6536\u76D8\u4F4D\u7F6E\uFF1A\u957F\u4E0B\u5F71/\u957F\u4E0A\u5F71\u4E14\u6536\u76D8\u6536\u56DE\u5F62\u6001\u5185\u4FA7\uFF0C\u8BF4\u660E\u8BE5\u4EF7\u4F4D\u6709\u771F\u5B9E\u5BF9\u6297\u3002"
  },
  {
    key: "thrustVolume",
    label: "\u786E\u8BA4K\u91CF\u80FD",
    short: "THRUST",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.45,
    liveOnly: true,
    hint: "\u786E\u8BA4K\u7EBF\u76F8\u5BF9\u8FD1 20 \u6839\u5747\u91CF\u7684\u653E\u5927\u500D\u6570\u3002<1 \u7684\u5F31\u786E\u8BA4\u7ECF\u5E38\u88AB\u518D\u6B21\u523A\u7834\uFF1B\u22651.5 \u7684\u62D2\u7EDD\u66F4\u53EF\u9760\u3002\u4EC5\u5B9E\u65F6\u884C\u60C5\u53EF\u7528\u3002"
  },
  {
    key: "bookImbalance",
    label: "\u76D8\u53E3\u5931\u8861",
    short: "BOOK",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.5,
    liveOnly: true,
    hint: "\u5341\u6863\u4E70\u5356\u6302\u5355\u91CF\u5931\u8861\u5EA6\uFF1A\u505A\u591A\u8981\u6C42\u4E70\u76D8\u66F4\u539A\uFF0C\u505A\u7A7A\u8981\u6C42\u5356\u76D8\u66F4\u539A\u3002\u4EC5\u5B9E\u65F6\u884C\u60C5\u53EF\u7528\uFF08\u56DE\u6D4B\u65E0\u5386\u53F2\u76D8\u53E3\uFF09\u3002"
  },
  {
    key: "tapeBias",
    label: "\u5927\u5355\u4E3B\u52A8\u65B9\u5411",
    short: "TAPE",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.4,
    liveOnly: true,
    hint: "\u6210\u4EA4\u6D41\u4E2D\u5927\u5355\u7684\u540D\u4E49\u91D1\u989D\u504F\u5411\u3002\u4E0E\u4EA4\u6613\u65B9\u5411\u4E00\u81F4\u4EC5\u8868\u793A\u5927\u5355\u4E3B\u52A8\u65B9\u5411\uFF1B\u4E0D\u8BC1\u660E\u673A\u6784\u8EAB\u4EFD\u6216\u610F\u56FE\u3002\u4EC5\u5B9E\u65F6\u53EF\u7528\u3002"
  },
  {
    key: "levelIntegrity",
    label: "\u5173\u952E\u4F4D\u5B8C\u6574\u5EA6",
    short: "LEVEL",
    group: "\u7ED3\u6784",
    weight: 0.4,
    hint: "\u540C\u4E00\u4EF7\u4F4D\u88AB\u6D4B\u8BD5\u6B21\u6570\u8D8A\u591A\u3001\u671F\u95F4\u662F\u5426\u51FA\u73B0\u8FC7\u201C\u6536\u76D8\u51FB\u7A7F\u201D\uFF0C\u51B3\u5B9A\u8FD9\u6761\u7EBF\u8FD8\u5269\u591A\u5C11\u9632\u5B88\u4EF7\u503C\uFF1B\u523A\u7834\u540E\u5FEB\u901F\u6536\u56DE\uFF08\u626B\u4F4D\u6536\u56DE\uFF09\u989D\u5916\u52A0\u5206\u3002"
  },
  {
    key: "patternHeight",
    label: "\u5F62\u6001\u9AD8\u5EA6",
    short: "HEIGHT",
    group: "\u7ED3\u6784",
    weight: 0.3,
    hint: "\u5173\u952E\u4F4D\u5230\u9888\u7EBF\u7684\u8DDD\u79BB\uFF08ATR \u500D\u6570\uFF09\u3002\u592A\u77EE\u5219\u7A7A\u95F4\u4E0D\u8DB3\u4EE5\u8986\u76D6\u6210\u672C\u4E0E\u6ED1\u70B9\uFF0C\u8FC7\u9AD8\u5219\u9700\u8981\u66F4\u4E45\u6301\u4ED3\u3002"
  },
  {
    key: "patternSpan",
    label: "\u5F62\u6001\u65F6\u95F4\u8DE8\u5EA6",
    short: "SPAN",
    group: "\u7ED3\u6784",
    weight: 0.25,
    hint: "\u4E24\u6B21\u6D4B\u8BD5\u4E4B\u95F4\u7684\u6839\u6570\u3002\u8FC7\u77ED\u662F\u566A\u97F3\u6296\u52A8\uFF0C\u8FC7\u957F\u5219\u5173\u952E\u4F4D\u5DF2\u7ECF\u949D\u5316\uFF1B\u5BF9\u6570\u5C3A\u5EA6\u4E0A\u4EE5\u7EA6 110 \u6839\u4E3A\u6700\u4F18\u3002"
  },
  {
    key: "trendExhaust",
    label: "\u8D8B\u52BF\u5DF2\u8F6C\u5E73",
    short: "FLATTEN",
    group: "\u7ED3\u6784",
    weight: 0.5,
    hint: "EMA20-EMA50 / ATR \u5EA6\u91CF\u9006\u52BF\u538B\u529B\u3002\u4E8C\u6B21\u6D4B\u8BD5\u8981\u6210\u7ACB\uFF0C\u9006\u7740\u4EA4\u6613\u65B9\u5411\u7684\u8D8B\u52BF\u5FC5\u987B\u5DF2\u7ECF\u8870\u7AED\uFF1A\u5747\u7EBF\u5DEE\u63A5\u8FD1\u8D70\u5E73\u6216\u8F7B\u5FAE\u8F6C\u5411\u65F6\u6700\u4F18\uFF1B\u4ECD\u5728\u5F3A\u9006\u52BF\u63A8\u8FDB\u65F6\u662F\u63A5\u98DE\u5200\uFF0C\u5F97\u5206\u6700\u4F4E\u3002"
  },
  {
    key: "legDecel",
    label: "\u63A8\u8FDB\u51CF\u901F",
    short: "DECEL",
    group: "\u7ED3\u6784",
    weight: 0.45,
    hint: "\u7B2C\u4E8C\u817F\u6BCF\u6839K\u7EBF\u7684\u63A8\u8FDB\u5E45\u5EA6\u76F8\u5BF9\u7B2C\u4E00\u817F\u7684\u8870\u51CF\u6BD4\u4F8B\u3002\u7B2C\u4E8C\u817F\u660E\u663E\u66F4\u6162 = \u8FB9\u9645\u4E70\u5BB6/\u5356\u5BB6\u51CF\u5C11\uFF0C\u53CD\u8F6C\u7ED3\u6784\u6210\u7ACB\u3002"
  },
  {
    key: "volRegime",
    label: "\u6CE2\u52A8\u73AF\u5883",
    short: "REGIME",
    group: "\u7ED3\u6784",
    weight: 0.2,
    hint: "\u5F53\u524D ATR \u5728\u8FD1 500 \u6839\u4E2D\u7684\u5206\u4F4D\u3002\u6CE2\u52A8\u8FC7\u4F4E\u6CA1\u6709\u8DDF\u968F\uFF0C\u8FC7\u9AD8\u5219\u6B62\u635F\u88AB\u968F\u673A\u626B\u51FA\uFF1B\u4E2D\u9AD8\u5206\u4F4D\u6700\u6709\u5229\u4E8E\u5F62\u6001\u5151\u73B0\u3002"
  },
  {
    key: "rrQuality",
    label: "\u76EE\u6807\u53EF\u8FBE\u6027",
    short: "REACH",
    group: "\u98CE\u9669",
    weight: 0.6,
    hint: "\u6A21\u578B\u9884\u6D4B\u7684\u662F\u300C\u80DC\u7387\u300D\u800C\u4E0D\u662F\u300C\u8D54\u7387\u300D\uFF1A\u76EE\u6807\u8D8A\u8FDC\uFF08R:R \u8D8A\u9AD8\uFF09\u8D8A\u96BE\u5728\u8D85\u65F6\u524D\u5151\u73B0\uFF0C\u56E0\u6B64\u9AD8 R:R \u5BF9\u80DC\u7387\u662F\u8D1F\u8BC1\u636E\u3002\u540C\u65F6\u6263\u9664\u5F80\u8FD4\u6210\u672C\u5360\u98CE\u9669\u8FC7\u9AD8\u7684\u5F62\u6001\u3002\u8D54\u7387\u7684\u4EF7\u503C\u5728\u671F\u671B\u503C\u4E00\u680F\u5355\u72EC\u4F53\u73B0\u3002"
  },
  // ── 真实订单流因子（OKX 主动买卖成交额 / 持仓量；无真实数据时按近似或记为无数据）──
  {
    key: "cvdDiverge",
    label: "CVD \u6781\u503C\u80CC\u79BB",
    short: "CVD",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.6,
    hint: "\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5356\u5DEE\uFF08CVD\uFF09\u5728\u4E8C\u9876/\u4E8C\u5E95\u5904\u4E0E\u4E00\u9876/\u4E00\u5E95\u5904\u7684\u5DEE\u503C\uFF1A\u4EF7\u683C\u518D\u521B\u7B49\u9AD8/\u7B49\u4F4E\u70B9\uFF0C\u4F46\u7D2F\u8BA1\u4E3B\u52A8\u4E70\u5165\uFF08\u9876\uFF09\u6216\u7D2F\u8BA1\u4E3B\u52A8\u5356\u51FA\uFF08\u5E95\uFF09\u6CA1\u6709\u540C\u6B65\u521B\u51FA\u6781\u503C\uFF0C\u8BF4\u660E\u63A8\u52A8\u65B9\u5DF2\u88AB\u52A8\uFF0C\u53CD\u8F6C\u6982\u7387\u4E0A\u5347\u3002"
  },
  {
    key: "sweepTrap",
    label: "\u626B\u4F4D\u9677\u9631\u5019\u9009",
    short: "TRAP",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.65,
    hint: "\u8BF1\u591A / \u8BF1\u7A7A\u5019\u9009\uFF1A\u4EF7\u683C\u523A\u7A7F\u524D\u9AD8/\u524D\u4F4E\u540E\u6536\u56DE\uFF0C\u4E14\u523A\u7A7F\u671F\u95F4\u4E3B\u52A8\u6210\u4EA4\u7AD9\u5728\u53CD\u8F6C\u4E00\u4FA7\u6216\u8FFD\u5355\u653E\u91CF\u88AB\u5438\u6536 \u2192 \u7A81\u7834\u8FFD\u968F\u8005\u53EF\u80FD\u5904\u4E8E\u4E0D\u5229\u4F4D\u7F6E\uFF08\u89E3\u91CA\u6A21\u578B\uFF0C\u975E\u8D26\u6237\u4E8B\u5B9E\uFF09\u3002\u6536\u76D8\u505C\u5728\u5173\u952E\u4F4D\u5916\u4FA7\u4E14\u7A81\u7834\u65B9\u5411\u4E3B\u52A8\u6210\u4EA4\u5360\u4F18\u5219\u4E3A\u771F\u7A81\u7834\uFF0C\u8BB0\u8D1F\u5206\u3002"
  },
  {
    key: "testDelta",
    label: "\u786E\u8BA4K\u4E3B\u52A8\u65B9\u5411",
    short: "\u0394CONF",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.4,
    hint: "\u62D2\u7EDD / \u786E\u8BA4 K \u7EBF\u5185\u771F\u5B9E\u4E3B\u52A8\u4E70\u5356\u5DEE\u7684\u65B9\u5411\uFF1A\u505A\u7A7A\u8981\u6C42\u4E3B\u52A8\u5356\u51FA\u63A5\u7BA1\uFF0C\u505A\u591A\u8981\u6C42\u4E3B\u52A8\u4E70\u5165\u63A5\u7BA1\u3002\u4EC5\u5728\u8BE5\u6839\u6709\u771F\u5B9E\u4E3B\u52A8\u6210\u4EA4\u6570\u636E\u65F6\u53C2\u4E0E\u8BC4\u5206\u3002"
  },
  {
    key: "oiTrap",
    label: "\u6301\u4ED3\u91CF\u53D8\u5316",
    short: "OI",
    group: "\u8BA2\u5355\u6D41",
    weight: 0.3,
    hint: "\u7B2C\u4E8C\u817F\uFF08\u51B2\u5411\u4E8C\u9876 / \u6740\u5411\u4E8C\u5E95\uFF09\u671F\u95F4\u6C38\u7EED\u6301\u4ED3\u91CF\u7684\u53D8\u5316\uFF1A\u6301\u4ED3\u589E\u52A0\u8BF4\u660E\u603B\u6301\u4ED3\u6269\u5F20\uFF0C\u4F46\u4E0D\u80FD\u8BC6\u522B\u591A\u7A7A\u8EAB\u4EFD\u6216\u8C01\u88AB\u5957\uFF1B\u6301\u4ED3\u51CF\u5C11\u5219\u662F\u5E73\u4ED3\u9A71\u52A8\u7684\u51B2\u523A\uFF0C\u53CD\u8F6C\u540E\u7F3A\u5C11\u71C3\u6599\u3002\u4EC5\u5728\u6709\u6301\u4ED3\u91CF\u6570\u636E\u65F6\u53C2\u4E0E\u8BC4\u5206\u3002"
  }
];
var FACTOR_INDEX = FACTORS.reduce(
  (acc, f, i) => ({ ...acc, [f.key]: i }),
  {}
);

// src/quant/scan.ts
var r6 = (v) => Number.isFinite(v) ? Number(v.toFixed(v >= 1e3 ? 2 : 6)) : 0;
var r32 = (v) => Number.isFinite(v) ? Number(v.toFixed(3)) : 0;
function simulateOutcome(ctx, sig, mode, maxHold) {
  const { cs, n } = ctx;
  const i = sig.idx;
  if (i < 30 || i > n - 2) return null;
  const limit = mode === "touch";
  const next = cs[i + 1];
  let entryPrice;
  let entryTs;
  if (limit) {
    entryPrice = sig.entry;
    entryTs = sig.ts;
  } else {
    if (sig.side === "long" ? next.o <= sig.stop || next.o >= sig.tp : next.o >= sig.stop || next.o <= sig.tp) {
      return {
        filled: false,
        why: "gap",
        entryPrice: 0,
        entryTs: 0,
        exitPrice: 0,
        exitTs: 0,
        r: 0,
        pnlPct: 0,
        holdingBars: 0,
        costR: 0
      };
    }
    entryPrice = sig.side === "long" ? next.o * (1 + SLIP_RATE) : next.o * (1 - SLIP_RATE);
    entryTs = next.ts;
  }
  let exitPrice = null;
  let exitTs = 0;
  let why = "time";
  let exitIdx = -1;
  const endJ = Math.min(i + maxHold, n - 1);
  for (let j = limit ? i : i + 1; j <= endJ; j++) {
    const k = cs[j];
    const hitSL = sig.side === "long" ? k.l <= sig.stop : k.h >= sig.stop;
    const hitTP = !(limit && j === i) && (sig.side === "long" ? k.h >= sig.tp : k.l <= sig.tp);
    if (hitSL) {
      exitPrice = sig.stop;
      why = "sl";
    } else if (hitTP) {
      exitPrice = sig.tp;
      why = "tp";
    }
    if (exitPrice != null) {
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
  }
  if (exitPrice == null) {
    exitPrice = cs[endJ].c;
    exitTs = cs[endJ].ts;
    exitIdx = endJ;
  }
  const exitAdj = sig.side === "long" ? exitPrice * (1 - SLIP_RATE) : exitPrice * (1 + SLIP_RATE);
  const gross = sig.side === "long" ? exitAdj - entryPrice : entryPrice - exitAdj;
  const fee = (entryPrice + exitAdj) * FEE_RATE;
  const slipCost = (limit ? exitPrice : next.o + exitPrice) * SLIP_RATE;
  const pnl = gross - fee;
  const risk = sig.side === "long" ? entryPrice - sig.stop : sig.stop - entryPrice;
  return {
    filled: true,
    why,
    entryPrice: r6(entryPrice),
    entryTs,
    exitPrice: r6(exitAdj),
    exitTs,
    r: r32(risk > 0 ? pnl / risk : 0),
    pnlPct: r32(pnl / entryPrice * 100),
    holdingBars: Math.max(1, exitIdx - i),
    costR: r32(risk > 0 ? (fee + slipCost) / risk : 0)
  };
}
function simulateWithPlan(ctx, sig, mode, maxHold, plan) {
  if (plan === "neck") return simulateOutcome(ctx, sig, mode, maxHold);
  const { cs, n, atr } = ctx;
  const i = sig.idx;
  if (i < 30 || i > n - 2) return null;
  const limit = mode === "touch";
  const next = cs[i + 1];
  const dir = sig.side === "long" ? 1 : -1;
  let entryPrice;
  let entryTs;
  if (limit) {
    entryPrice = sig.entry;
    entryTs = sig.ts;
  } else {
    if (dir > 0 ? next.o <= sig.stop : next.o >= sig.stop) {
      return { filled: false, why: "gap", entryPrice: 0, entryTs: 0, exitPrice: 0, exitTs: 0, r: 0, pnlPct: 0, holdingBars: 0, costR: 0 };
    }
    entryPrice = dir > 0 ? next.o * (1 + SLIP_RATE) : next.o * (1 - SLIP_RATE);
    entryTs = next.ts;
  }
  const risk = (entryPrice - sig.stop) * dir;
  if (!(risk > 0)) return null;
  const target = plan === "r10" ? entryPrice + dir * risk : plan === "r15" ? entryPrice + dir * 1.5 * risk : sig.tp;
  if (!limit && (dir > 0 ? next.o >= target : next.o <= target)) {
    return { filled: false, why: "gap", entryPrice: 0, entryTs: 0, exitPrice: 0, exitTs: 0, r: 0, pnlPct: 0, holdingBars: 0, costR: 0 };
  }
  const trigger = entryPrice + dir * risk;
  const targetBeforeTrigger = (target - entryPrice) * dir < risk;
  const useBe = plan === "be" || plan === "partial";
  const half = plan === "partial";
  let stop = sig.stop;
  let armed = false;
  let tookHalf = false;
  let halfExitAdj = 0;
  let lockedR = 0;
  let exitPrice = null;
  let exitTs = 0;
  let why = "time";
  let exitIdx = -1;
  const endJ = Math.min(i + maxHold, n - 1);
  const feePct = FEE_RATE;
  for (let j = limit ? i : i + 1; j <= endJ; j++) {
    const k = cs[j];
    const hitStop = dir > 0 ? k.l <= stop : k.h >= stop;
    const hitTrig = useBe && !armed && !(limit && j === i) && (dir > 0 ? k.h >= trigger : k.l <= trigger);
    const hitTarget = !(limit && j === i) && (dir > 0 ? k.h >= target : k.l <= target);
    if (hitStop) {
      exitPrice = stop;
      why = armed ? "be" : "sl";
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
    if (targetBeforeTrigger && hitTarget) {
      exitPrice = target;
      why = "tp";
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
    if (hitTrig) {
      armed = true;
      stop = entryPrice * (1 + dir * feePct * 2);
      if (half && !tookHalf) {
        tookHalf = true;
        const trigAdj = dir > 0 ? trigger * (1 - SLIP_RATE) : trigger * (1 + SLIP_RATE);
        halfExitAdj = trigAdj;
        const halfGross = (trigAdj - entryPrice) * dir;
        const halfFee = (entryPrice + trigAdj) * FEE_RATE;
        lockedR = 0.5 * ((halfGross - halfFee) / risk);
      }
    }
    if (hitTarget) {
      exitPrice = target;
      why = "tp";
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
  }
  if (exitPrice == null) {
    exitPrice = cs[endJ].c;
    exitTs = cs[endJ].ts;
    exitIdx = endJ;
  }
  const exitAdj = dir > 0 ? exitPrice * (1 - SLIP_RATE) : exitPrice * (1 + SLIP_RATE);
  const gross = (exitAdj - entryPrice) * dir;
  const fee = (entryPrice + exitAdj) * FEE_RATE;
  const pnl = gross - fee;
  const restR = pnl / risk;
  const r = tookHalf ? lockedR + 0.5 * restR : restR;
  const entrySlip = limit ? 0 : next.o * SLIP_RATE;
  const totalFees = entryPrice * FEE_RATE + (tookHalf ? 0.5 * halfExitAdj * FEE_RATE : 0) + (tookHalf ? 0.5 : 1) * exitAdj * FEE_RATE;
  const totalCost = totalFees + entrySlip + (tookHalf ? 0.5 * trigger * SLIP_RATE : 0) + (tookHalf ? 0.5 : 1) * exitPrice * SLIP_RATE;
  void atr;
  return {
    filled: true,
    // `be` describes the exit mechanism, not the sign of the final R.
    // Fees/slippage can make a break-even stop slightly negative; reclassifying
    // it as `sl` corrupts tp/sl/time/be statistics.
    why,
    entryPrice: r6(entryPrice),
    entryTs,
    exitPrice: r6(exitAdj),
    exitTs,
    r: r32(r),
    pnlPct: r32(tookHalf ? r * (risk / entryPrice) * 100 : pnl / entryPrice * 100),
    holdingBars: Math.max(1, exitIdx - i),
    costR: r32(totalCost / risk)
  };
}

// src/lib/okxVolume.ts
function quoteVolumeOfRow(row, symbol) {
  const finite = (v) => v !== "" && v != null && Number.isFinite(Number(v)) && Number(v) >= 0;
  const quote = Number(row[7]), base = Number(row[6]), contracts = Number(row[5]), close = Number(row[4]);
  if (finite(row[7]) && (quote > 0 || contracts === 0 && (!finite(row[6]) || base === 0))) return { value: quote, source: "quote" };
  if (!(close > 0) || !Number.isFinite(close)) return null;
  if (finite(row[6]) && base > 0) return { value: base * close, source: "base_close_estimate" };
  if (finite(row[5]) && contracts > 0) {
    const value = contracts * ctValOf(symbol) * close;
    return Number.isFinite(value) ? { value, source: "contracts_close_estimate" } : null;
  }
  return null;
}

// src/lib/okxCandles.ts
function parseOkxCandle(row, symbol) {
  if (!Array.isArray(row) || row.length < 6) return null;
  const [ts, o, h, l, c] = row.slice(0, 5).map(Number);
  if (![ts, o, h, l, c].every(Number.isFinite) || !Number.isSafeInteger(ts) || ts <= 0 || Math.min(o, h, l, c) <= 0 || h < l || h < Math.max(o, c) || l > Math.min(o, c)) return null;
  const volume = quoteVolumeOfRow(row, symbol);
  if (!volume) return null;
  const rawConfirm = row[8];
  const confirm = rawConfirm === 1 || rawConfirm === "1" ? 1 : rawConfirm === 0 || rawConfirm === "0" ? 0 : void 0;
  return { ts, o, h, l, c, v: volume.value, volumeSource: volume.source, ...confirm === void 0 ? {} : { confirm } };
}
function isClosedCandle(c, intervalMs, now = Date.now(), legacyGraceMs = 1500) {
  if (c.confirm === 1) return true;
  if (c.confirm === 0) return false;
  return Number.isFinite(c.ts) && c.ts + intervalMs + legacyGraceMs <= now;
}
function preferCandle(existing, incoming, existingVolume, incomingVolume, expired = false) {
  if (!existing) return incoming;
  const rank = (c) => c.confirm === 1 ? 2 : c.confirm === 0 || expired ? 1 : 0;
  const quality = (c) => c.volumeSource === "quote" ? 1 : 0;
  const a = rank(existing), b = rank(incoming);
  if (a !== b) return b > a ? incoming : existing;
  const qa = quality(existing), qb = quality(incoming);
  if (qa !== qb) return qb > qa ? incoming : existing;
  return incomingVolume >= existingVolume ? incoming : existing;
}
function mergeCandles(base, incoming, intervalMs, now = Date.now()) {
  const out = /* @__PURE__ */ new Map();
  for (const c of base) out.set(c.ts, c);
  for (const c of incoming) {
    const old = out.get(c.ts);
    out.set(c.ts, preferCandle(old, c, old?.v ?? 0, c.v, isClosedCandle(c, intervalMs, now)));
  }
  return [...out.values()].sort((a, b) => a.ts - b.ts);
}

// src/server/okx.ts
var BASE = "https://www.okx.com";
var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
function makeGate(gapMs) {
  let chain = Promise.resolve();
  return () => {
    const next = chain.then(() => sleep2(gapMs));
    chain = next.catch(() => void 0);
    return next;
  };
}
var candlesGate = makeGate(55);
var historyGate = makeGate(105);
var OkxError = class extends Error {
  constructor(message, retryable = true) {
    super(message);
    this.retryable = retryable;
    this.name = "OkxError";
  }
};
async function okxGet2(path, params, timeoutMs = 5e3) {
  if (path.includes("history-candles")) await historyGate();
  else if (path.includes("candles")) await candlesGate();
  const url = new URL(BASE + path);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(url.toString(), { signal: ctl.signal });
    if (!res.ok) throw new OkxError("HTTP " + res.status, res.status === 429 || res.status >= 500);
    const json = await res.json();
    if (json.code && json.code !== "0") throw new OkxError("OKX code " + json.code);
    return json.data;
  } finally {
    clearTimeout(t);
  }
}
async function okxGetRetry(path, params, tries = 3) {
  let lastErr = null;
  for (let t = 0; t < tries; t++) {
    try {
      const d = await okxGet2(path, params, 8e3);
      return d ?? [];
    } catch (e) {
      lastErr = e;
      if (e instanceof OkxError && !e.retryable) break;
      if (t < tries - 1) await sleep2(300 * (t + 1));
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("OKX request failed");
}
function parseCandleRow(row, symbol) {
  return parseOkxCandle(row, symbol);
}
async function fetchCandlesWithMeta(symbol, bar, count) {
  const want = Math.max(1, Math.min(count, 12e3));
  const bm = barMs(bar);
  const map = /* @__PURE__ */ new Map();
  const add = (rows) => {
    for (const r of rows ?? []) {
      const c = parseCandleRow(r, symbol);
      if (c) map.set(c.ts, c);
    }
  };
  const first = await okxGetRetry("/api/v5/market/candles", {
    instId: symbol,
    bar,
    limit: String(Math.min(300, want))
  });
  add(first);
  if (map.size === 0) throw new OkxError("empty candles", false);
  if (map.size < want) {
    const oldest = Math.min(...map.keys());
    let step = 100;
    let startK = 0;
    const failed = [];
    if (want > 1200) {
      try {
        const probe = await okxGetRetry("/api/v5/market/history-candles", {
          instId: symbol,
          bar,
          after: String(oldest),
          limit: "300"
        });
        add(probe);
        if (probe.length >= 200) step = 300;
        startK = 1;
      } catch {
      }
    }
    if (map.size < want) {
      const remPages = Math.ceil((want - map.size) / step);
      const limitStr = String(step);
      const loadPage = async (k) => {
        const rows = await okxGetRetry("/api/v5/market/history-candles", {
          instId: symbol,
          bar,
          after: String(oldest - k * step * bm),
          limit: limitStr
        });
        add(rows);
      };
      await Promise.all(
        Array.from({ length: remPages }, (_, idx) => {
          const k = startK + idx;
          return loadPage(k).catch(() => {
            failed.push(k);
          });
        })
      );
      if (failed.length) {
        await Promise.all(
          [...new Set(failed)].map(
            (k) => loadPage(k).catch(() => {
            })
          )
        );
      }
    }
    if (want > 1200 && map.size < want && map.size >= want - 600 && failed.length === 0) {
      for (let extra = 0; extra < 2 && map.size < want; extra++) {
        const curOldest = Math.min(...map.keys());
        const rows = await okxGetRetry("/api/v5/market/history-candles", {
          instId: symbol,
          bar,
          after: String(curOldest),
          limit: String(step)
        }).catch(() => []);
        const before = map.size;
        add(rows);
        if (map.size === before) break;
      }
    }
  }
  const sorted = [...map.values()].sort((a, b) => a.ts - b.ts);
  const candles = sorted.slice(-want);
  let missingBars = 0;
  for (let i = 1; i < candles.length; i++) {
    const step = Math.round((candles[i].ts - candles[i - 1].ts) / bm);
    if (step > 1) missingBars += step - 1;
  }
  return { candles, missingBars, short: candles.length < want };
}
function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = a + 1831565813 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
var SYNTH_BASE = {
  "BTC-USDT-SWAP": { price: 97400, vol: 11e-4, volUnit: 9200 },
  "ETH-USDT-SWAP": { price: 3625, vol: 16e-4, volUnit: 26e3 },
  "SOL-USDT-SWAP": { price: 214, vol: 22e-4, volUnit: 9e3 }
};
function synthCandles(symbol, bar, count, endTs) {
  const cfg = SYNTH_BASE[symbol] ?? { price: 100, vol: 2e-3, volUnit: 1e3 };
  const bm = barMs(bar);
  const dayKey = Math.floor((endTs ?? Date.now()) / 864e5);
  const rng = mulberry32(hashStr(`${symbol}|${bar}|${dayKey}`));
  const lastStart = Math.floor((endTs ?? Date.now()) / bm) * bm - bm;
  const start = lastStart - (count - 1) * bm;
  const out = [];
  let price = cfg.price * (0.97 + rng() * 0.06);
  let regime = 0;
  for (let i = 0; i < count; i++) {
    regime = regime * 0.982 + (rng() - 0.5) * 0.09;
    if (rng() < 0.012) regime += (rng() - 0.5) * 0.9;
    const vScale = 1 + 1.6 * Math.abs(regime) + (rng() < 0.06 ? rng() * 2.4 : 0);
    const pull = -15e-4 * Math.log(price / cfg.price);
    const ret = regime * cfg.vol * 1.6 + pull + (rng() + rng() - 1) * cfg.vol * vScale;
    const o = price * (rng() < 0.02 ? 1 + (rng() - 0.5) * cfg.vol * 6 : 1);
    let p = o;
    let hi = o;
    let lo = o;
    let pc = o;
    for (let s = 0; s < 4; s++) {
      pc = p * (1 + ret / 4 + (rng() - 0.5) * cfg.vol * 0.55 * vScale);
      p = pc;
      hi = Math.max(hi, p);
      lo = Math.min(lo, p);
    }
    const c = p;
    hi = Math.max(hi, o, c) * (1 + rng() * cfg.vol * 0.5 * vScale);
    lo = Math.min(lo, o, c) * (1 - rng() * cfg.vol * 0.5 * vScale);
    const bodyPct = Math.abs(c - o) / o;
    const v = cfg.volUnit * ctValOf(symbol) * (0.45 + rng() * 0.8) * (1 + bodyPct / cfg.vol / 2.2) * c;
    out.push({ ts: start + i * bm, o, h: hi, l: lo, c, v, volumeSource: "synthetic" });
    price = c;
  }
  return out;
}
var CACHE_MAX = 12;
var TTL_LIVE = 12e4;
var TTL_DEGRADED = 15e3;
var cache2 = /* @__PURE__ */ new Map();
var inflight2 = /* @__PURE__ */ new Map();
var tailRefresh = /* @__PURE__ */ new Map();
function mergeByTs(base, incoming, intervalMs) {
  return mergeCandles(base, incoming, intervalMs);
}
function holesOf(cs, bm) {
  let n = 0;
  for (let i = 1; i < cs.length; i++) {
    const step = Math.round((cs[i].ts - cs[i - 1].ts) / bm);
    if (step > 1) n += step - 1;
  }
  return n;
}
function refreshTail(key, entry, symbol, bar) {
  const running = tailRefresh.get(key);
  if (running) return running;
  const job = (async () => {
    try {
      const rows = await okxGetRetry("/api/v5/market/candles", { instId: symbol, bar, limit: "300" });
      const fresh = [];
      for (const r of rows) {
        const c = parseCandleRow(r, symbol);
        if (c) fresh.push(c);
      }
      if (!fresh.length) return false;
      const bm = barMs(bar);
      const merged = mergeByTs(entry.data, fresh, bm).slice(-Math.max(entry.data.length, 1));
      if (holesOf(merged, bm) > holesOf(entry.data, bm)) return false;
      entry.data = merged;
      const now = Date.now();
      entry.tailAt = now;
      entry.tailAttemptAt = now;
      return true;
    } catch {
      entry.tailAttemptAt = Date.now();
      return false;
    }
  })().finally(() => {
    if (tailRefresh.get(key) === job) tailRefresh.delete(key);
  });
  tailRefresh.set(key, job);
  return job;
}
function remember(key, entry) {
  cache2.delete(key);
  cache2.set(key, entry);
  while (cache2.size > CACHE_MAX) {
    const oldest = cache2.keys().next().value;
    if (oldest === void 0) break;
    cache2.delete(oldest);
  }
}
async function getCandles(symbol, bar, count, fresh = false) {
  const key = `${symbol}|${bar}`;
  if (!fresh) {
    const hit = cache2.get(key);
    if (hit && (hit.data.length >= count || hit.want >= count)) {
      const ttl = hit.live && !hit.gapped ? TTL_LIVE : TTL_DEGRADED;
      if (Date.now() - hit.at < ttl) {
        const last = hit.data[hit.data.length - 1];
        const bm = barMs(bar);
        const now = Date.now();
        const needsTail = hit.live && !!last && last.ts + bm <= now && now - hit.tailAttemptAt >= 2e3;
        const usable = !needsTail || await refreshTail(key, hit, symbol, bar);
        if (usable) return { live: hit.live, gapped: hit.gapped, candles: hit.data.slice(-count) };
      }
    }
    const pending = inflight2.get(key);
    if (pending && pending.count >= count) {
      const r = await pending.promise;
      return { live: r.live, gapped: r.gapped, candles: r.candles.slice(-count) };
    }
  }
  const job = (async () => {
    try {
      const { candles, missingBars, short } = await fetchCandlesWithMeta(symbol, bar, count);
      if (candles.length < Math.min(count, 200)) throw new Error("insufficient live data");
      const gapped = missingBars > 0 || short;
      const now = Date.now();
      remember(key, { at: now, live: true, gapped, data: candles, want: count, tailAt: now, tailAttemptAt: now });
      return { live: true, gapped, candles };
    } catch {
      const candles = synthCandles(symbol, bar, count);
      const now = Date.now();
      remember(key, { at: now, live: false, gapped: false, data: candles, want: count, tailAt: now, tailAttemptAt: now });
      return { live: false, gapped: false, candles };
    }
  })();
  inflight2.set(key, { promise: job, count });
  try {
    return await job;
  } finally {
    if (inflight2.get(key)?.promise === job) inflight2.delete(key);
  }
}

// tests/deep-fixes.test.ts
var B = 3e5;
var T0 = 1793e9;
var passed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`PASS ${name}`);
  } catch (e) {
    console.error(`FAIL ${name}
  ${e.stack ?? String(e)}`);
    process.exitCode = 1;
  }
}
await test("partial \u51FA\u573A\u65B9\u6848\u6263\u9664\u534A\u4ED3 1R \u5E73\u4ED3\u6ED1\u70B9\u4E0E\u624B\u7EED\u8D39\uFF0C\u4E0D\u518D\u865A\u9AD8", () => {
  const cs = Array.from({ length: 40 }, (_, i) => ({
    ts: T0 + i * B,
    o: 100,
    h: 100.2,
    l: 99.8,
    c: 100,
    v: 1e3
  }));
  cs[31] = { ts: T0 + 31 * B, o: 100, h: 101.2, l: 99.9, c: 100.8, v: 1200 };
  cs[32] = { ts: T0 + 32 * B, o: 100.8, h: 100.8, l: 100, c: 100.05, v: 1e3 };
  const sig = {
    idx: 30,
    ts: cs[30].ts,
    side: "long",
    pattern: "db_reject",
    entry: 100,
    stop: 99,
    tp: 103,
    conf: 70,
    confl: 70,
    strength: 70,
    note: "partial-cost",
    fill: "close"
  };
  const out = simulateWithPlan(buildContext(cs), sig, "confirm", 96, "partial");
  assert.equal(out.filled, true);
  assert.equal(out.why, "be");
  const entry = 100 * (1 + SLIP_RATE);
  const risk = entry - 99;
  const trigger = entry + risk;
  const trigAdj = trigger * (1 - SLIP_RATE);
  const expectedLocked = 0.5 * ((trigAdj - entry - (entry + trigAdj) * FEE_RATE) / risk);
  assert.ok(expectedLocked < 0.45 && out.r <= expectedLocked + 0.01, `\u5B9E\u9645 r=${out.r}\uFF0C\u671F\u671B\u7EA6 ${expectedLocked.toFixed(3)}`);
});
await test("\u540C\u6839\u7A81\u7834 1R \u5E76\u89E6\u53CA\u6B62\u76C8\u76EE\u6807\u65F6\uFF0C\u5F53\u6839\u7ACB\u5373\u6309\u76EE\u6807\u6B62\u76C8\u800C\u975E\u5EF6\u540E\u4FDD\u672C\u626B\u51FA", () => {
  const cs = Array.from({ length: 40 }, (_, i) => ({
    ts: T0 + i * B,
    o: 100,
    h: 100.2,
    l: 99.8,
    c: 100,
    v: 1e3
  }));
  cs[31] = { ts: T0 + 31 * B, o: 100, h: 102, l: 99.5, c: 101.2, v: 1500 };
  cs[32] = { ts: T0 + 32 * B, o: 101.2, h: 101.2, l: 100.05, c: 100.05, v: 1200 };
  const sig = {
    idx: 30,
    ts: cs[30].ts,
    side: "long",
    pattern: "db_reject",
    entry: 100,
    stop: 99,
    tp: 101.5,
    conf: 70,
    confl: 70,
    strength: 70,
    note: "same-bar-tp",
    fill: "close"
  };
  const ctx = buildContext(cs);
  const beOut = simulateWithPlan(ctx, sig, "confirm", 96, "be");
  assert.equal(beOut.why, "tp");
  assert.equal(beOut.holdingBars, 1);
  assert.ok(beOut.r > 1.3, `be \u5E94\u5728\u5F53\u6839\u89E6\u53CA\u76EE\u6807\u6B62\u76C8\uFF0C\u5B9E\u9645 r=${beOut.r}`);
  const partialOut = simulateWithPlan(ctx, sig, "confirm", 96, "partial");
  assert.equal(partialOut.why, "tp");
  assert.equal(partialOut.holdingBars, 1);
  assert.ok(partialOut.r > 1.1, `partial \u5E94\u5728\u5F53\u6839\u5151\u73B0\u534A\u4ED3 1R + \u534A\u4ED3 1.5R\uFF0C\u5B9E\u9645 r=${partialOut.r}`);
});
await test("touch \u6302\u5355\u6210\u4EA4\u5F53\u6839\u4E0D\u63D0\u524D\u89E6\u53D1 1R \u4FDD\u672C\u6216\u534A\u4ED3\u6B62\u76C8", () => {
  const cs = Array.from({ length: 40 }, (_, i) => ({
    ts: T0 + i * B,
    o: 100,
    h: 100.2,
    l: 99.8,
    c: 100,
    v: 1e3
  }));
  cs[30] = { ts: T0 + 30 * B, o: 101, h: 101.5, l: 100, c: 100.2, v: 1200 };
  cs[31] = { ts: T0 + 31 * B, o: 100.2, h: 100.3, l: 98.8, c: 98.9, v: 1200 };
  const sig = {
    idx: 30,
    ts: cs[30].ts,
    side: "long",
    pattern: "db_reject",
    entry: 100,
    stop: 99,
    tp: 103,
    conf: 70,
    confl: 70,
    strength: 70,
    note: "touch-intrabar",
    fill: "limit"
  };
  const out = simulateWithPlan(buildContext(cs), sig, "touch", 96, "partial");
  assert.equal(out.why, "sl", "\u6210\u4EA4\u5F53\u6839\u4E0D\u5F97\u63D0\u524D\u9501\u534A\u4ED3\u6216\u79FB\u4FDD\u672C");
  assert.ok(out.r < -0.9, `\u5E94\u6B63\u5E38\u89E6\u53D1\u6B62\u635F\uFF0C\u5B9E\u9645 r=${out.r}`);
});
await test("confirm \u6A21\u5F0F\u4E0B\u4E00\u6839\u5F00\u76D8\u8DF3\u7A7A\u8D8A\u8FC7\u6B62\u76C8\u76EE\u6807\uFF0C\u8BB0\u4E3A gap \u672A\u6210\u4EA4", () => {
  const cs = Array.from({ length: 40 }, (_, i) => ({
    ts: T0 + i * B,
    o: 100,
    h: 100.2,
    l: 99.8,
    c: 100,
    v: 1e3
  }));
  cs[31] = { ts: T0 + 31 * B, o: 102.5, h: 102.8, l: 101.8, c: 102, v: 1500 };
  const sig = {
    idx: 30,
    ts: cs[30].ts,
    side: "long",
    pattern: "db_reject",
    entry: 100,
    stop: 99,
    tp: 102,
    conf: 70,
    confl: 70,
    strength: 70,
    note: "gap-tp",
    fill: "close"
  };
  const ctx = buildContext(cs);
  assert.equal(simulateOutcome(ctx, sig, "confirm", 96).filled, false);
  assert.equal(simulateWithPlan(ctx, sig, "confirm", 96, "partial").filled, false);
});
await test("readTouch \u65E0\u771F\u5B9E\u6210\u4EA4\u65F6\u4FDD\u7559\u5BA2\u89C2\u91CF\u4EF7\u5F71\u7EBF\u8BC1\u636E\uFF0CreadSecondTest CVD \u6309\u533A\u95F4\u8986\u76D6\u7F29\u653E", () => {
  const cs = Array.from({ length: 60 }, (_, i) => ({
    ts: T0 + i * B,
    o: 100,
    h: 100.3,
    l: 99.7,
    c: 100,
    v: 1e3
  }));
  cs[59] = { ts: T0 + 59 * B, o: 100.1, h: 100.9, l: 100, c: 100.05, v: 500 };
  const rd = readTouch(buildContext(cs, null), { price: 100.8, side: "top", idx: 20 }, 59, 59);
  assert.ok(rd.evidence > 0.1, `\u7F29\u91CF\u957F\u4E0A\u5F71\u89E6\u9876\u65E0 taker \u6570\u636E\u65F6\u4ECD\u5E94\u7ED9\u51FA\u6B63\u62D2\u7EDD\u8BC1\u636E\uFF0C\u5B9E\u9645 ${rd.evidence}`);
  const bars = /* @__PURE__ */ new Map();
  for (let i = 21; i <= 50; i++) {
    bars.set(cs[i].ts, { ts: cs[i].ts, buy: 300, sell: 700, src: "rubik" });
  }
  const flow = {
    instId: "TEST",
    period: "5m",
    barMs: B,
    bars,
    from: cs[21].ts,
    to: cs[50].ts,
    oiFrom: Infinity,
    updatedAt: 0,
    complete: true,
    tape: { connected: false, trades: 0, bootstrapped: true }
  };
  const sig = {
    idx: 50,
    ts: cs[50].ts,
    side: "short",
    pattern: "dt_reject",
    entry: 100,
    stop: 101.5,
    tp: 97,
    conf: 70,
    confl: 70,
    strength: 70,
    note: "cvd-cov",
    fill: "close",
    geo: {
      pts: [
        { ts: cs[10].ts, price: 97, label: "\u8D77\u6DA8\u70B9", pos: "below" },
        { ts: cs[20].ts, price: 101, label: "\u4E00\u9876", pos: "above" },
        { ts: cs[35].ts, price: 98, label: "\u9888\u7EBF", pos: "below" },
        { ts: cs[50].ts, price: 101, label: "\u4E8C\u9876", pos: "above" }
      ]
    }
  };
  const st = readSecondTest(buildContext(cs, flow), sig);
  assert.ok(st.cvdDiv > 0.2, `(first, second] \u533A\u95F4\u5B8C\u6574\u8986\u76D6\u65F6\u5E94\u8BA1\u7B97 CVD \u80CC\u79BB\uFF0C\u5B9E\u9645 ${st.cvdDiv}`);
});
await test("fetchCandlesWithMeta \u4EC5\u6821\u9A8C\u88C1\u526A\u540E\u7A97\u53E3\u7F3A\u53E3\uFF0C\u6DF1\u62C9\u81EA\u9002\u5E94 300 \u6B65\u957F", async () => {
  const realFetch = globalThis.fetch;
  const now = Math.floor(17935e8 / B) * B;
  let maxLimitSeen = 0;
  globalThis.fetch = (async (input) => {
    const u = new URL(String(input));
    const limit = Number(u.searchParams.get("limit") ?? "100");
    maxLimitSeen = Math.max(maxLimitSeen, limit);
    const makeRow = (ts) => [String(ts), "100", "101", "99", "100", "10", "10", "1000", "1"];
    if (u.pathname.endsWith("/market/candles")) {
      return new Response(JSON.stringify({ code: "0", data: Array.from({ length: 300 }, (_, i) => makeRow(now - i * B)) }));
    }
    const after = Number(u.searchParams.get("after"));
    const rows = [];
    for (let i = 0; i < limit; i++) {
      const ts = after - (i + 1) * B;
      if (ts === now - 8665 * B) continue;
      rows.push(makeRow(ts));
    }
    return new Response(JSON.stringify({ code: "0", data: rows }));
  });
  try {
    const r = await getCandles("DEEP-USDT-SWAP", "5m", 8640, true);
    assert.equal(maxLimitSeen, 300, "\u6DF1\u62C9\u5E94\u63A2\u6D4B\u5E76\u4F7F\u7528 300 \u6B65\u957F");
    assert.equal(r.candles.length, 8640);
    assert.equal(r.gapped, false, "\u88AB slice(-want) \u88C1\u6389\u7684\u6700\u8001\u524D\u7F00\u7F3A\u53E3\u4E0D\u5F97\u6C61\u67D3\u8FD4\u56DE\u7684\u8FDE\u7EED 8640 \u6839");
  } finally {
    globalThis.fetch = realFetch;
  }
});
await test("syncRubik \u589E\u91CF\u5237\u65B0\u4E0D\u91CD\u590D\u62C9\u5386\u53F2\uFF0C\u4E14 snap.bars \u6709\u4E0A\u9650\u4FDD\u62A4", async () => {
  const realFetch = globalThis.fetch;
  const g = globalThis;
  const origWin = g.window;
  delete g.window;
  let takerCalls = 0;
  const now = Math.floor(Date.now() / B) * B - 2 * B;
  globalThis.fetch = (async (input) => {
    const u = new URL(String(input));
    if (u.pathname.includes("taker-volume-contract")) {
      takerCalls++;
      const end = Number(u.searchParams.get("end") ?? String(now + B));
      const rows = Array.from({ length: 100 }, (_, i) => [String(end - (i + 1) * B), "5000", "6000"]);
      return new Response(JSON.stringify({ code: "0", data: rows }));
    }
    if (u.pathname.includes("open-interest-history")) {
      const end = Number(u.searchParams.get("end") ?? String(now + B));
      const rows = Array.from({ length: 100 }, (_, i) => [String(end - (i + 1) * B), "1000", "10", "100000"]);
      return new Response(JSON.stringify({ code: "0", data: rows }));
    }
    return new Response(JSON.stringify({ code: "0", data: [] }));
  });
  try {
    await syncFlow("INC-USDT-SWAP", "5m", { minTs: 0, maxPages: 4, oiPages: 2 });
    assert.equal(takerCalls, 4, "\u9996\u6B21\u540C\u6B65\u5E94\u62C9\u6EE1 4 \u9875");
    takerCalls = 0;
    await syncFlow("INC-USDT-SWAP", "5m", { minTs: 0, maxPages: 4, oiPages: 2 });
    assert.equal(takerCalls, 1, "\u70ED\u5237\u65B0\u5E94\u589E\u91CF\u505C\u6B62\u5728 1 \u9875\u800C\u975E\u91CD\u62C9 4 \u9875");
    const snap = getFlow("INC-USDT-SWAP", "5m");
    assert.ok(snap.bars.size <= 12e3);
  } finally {
    if (origWin !== void 0) g.window = origWin;
    globalThis.fetch = realFetch;
  }
});
console.log(`
deep-fixes: ${passed} \u7EC4\u65AD\u8A00\u5168\u90E8\u901A\u8FC7`);
if (process.exitCode) process.exit(process.exitCode);
