// tests/flow-markers.test.ts
import assert from "node:assert/strict";

// src/lib/types.ts
var SYMBOLS = [
  { id: "BTC-USDT-SWAP", base: "BTC", label: "BTC \u6C38\u7EED", ctVal: 0.01, minTick: 0.1 },
  { id: "ETH-USDT-SWAP", base: "ETH", label: "ETH \u6C38\u7EED", ctVal: 0.1, minTick: 0.01 },
  { id: "SOL-USDT-SWAP", base: "SOL", label: "SOL \u6C38\u7EED", ctVal: 1, minTick: 0.01 }
];
function ctValOf(symbol) {
  return SYMBOLS.find((s) => s.id === symbol)?.ctVal ?? 1;
}

// src/lib/okxVolume.ts
function quoteVolumeOfRow(row, symbol) {
  const finite = (v) => v !== "" && v != null && Number.isFinite(Number(v)) && Number(v) >= 0;
  const quote = Number(row[7]), base = Number(row[6]), contracts = Number(row[5]), close = Number(row[4]);
  if (finite(row[7]) && (quote > 0 || contracts === 0 && (!finite(row[6]) || base === 0))) return { value: quote, source: "quote" };
  if (!(close > 0) || !Number.isFinite(close)) return null;
  if (finite(row[6]) && base > 0) return { value: base * close, source: "base_close_estimate" };
  if (finite(row[5]) && contracts > 0) {
    const value = contracts * ctValOf(symbol) * close;
    return Number.isFinite(value) ? { value, source: "contracts_close_estimate" } : null;
  }
  return null;
}

// src/lib/okxCandles.ts
function parseOkxCandle(row, symbol) {
  if (!Array.isArray(row) || row.length < 6) return null;
  const [ts, o, h, l, c] = row.slice(0, 5).map(Number);
  if (![ts, o, h, l, c].every(Number.isFinite) || !Number.isSafeInteger(ts) || ts <= 0 || Math.min(o, h, l, c) <= 0 || h < l || h < Math.max(o, c) || l > Math.min(o, c)) return null;
  const volume = quoteVolumeOfRow(row, symbol);
  if (!volume) return null;
  const rawConfirm = row[8];
  const confirm = rawConfirm === 1 || rawConfirm === "1" ? 1 : rawConfirm === 0 || rawConfirm === "0" ? 0 : void 0;
  return { ts, o, h, l, c, v: volume.value, volumeSource: volume.source, ...confirm === void 0 ? {} : { confirm } };
}
function preferCandle(existing, incoming, existingVolume, incomingVolume, expired = false) {
  if (!existing) return incoming;
  const rank = (c) => c.confirm === 1 ? 2 : c.confirm === 0 || expired ? 1 : 0;
  const quality = (c) => c.volumeSource === "quote" ? 1 : 0;
  const a = rank(existing), b = rank(incoming);
  if (a !== b) return b > a ? incoming : existing;
  const qa = quality(existing), qb = quality(incoming);
  if (qa !== qb) return qb > qa ? incoming : existing;
  return incomingVolume >= existingVolume ? incoming : existing;
}

// src/vela/okxProvider.ts
var REST = "https://www.okx.com";
var WS = "wss://ws.okx.com/ws/v5/business";
function toOkxBar(tf) {
  if (tf === "D" || tf === "1D") return "1Dutc";
  if (tf === "W" || tf === "1W") return "1Wutc";
  if (tf === "M" || tf === "1M") return "1Mutc";
  const m = Number(tf);
  if (!Number.isFinite(m)) return "5m";
  if (m >= 60 && m % 60 === 0) return `${m / 60}H`;
  return `${m}m`;
}
function tfMs(tf) {
  if (tf === "D" || tf === "1D") return 864e5;
  if (tf === "W" || tf === "1W") return 7 * 864e5;
  if (tf === "M" || tf === "1M") return 30 * 864e5;
  const m = Number(tf);
  return (Number.isFinite(m) ? m : 5) * 6e4;
}
var OKX_TIMEFRAMES = ["1", "3", "5", "15", "30", "60", "240", "D", "W"];
var SWAPS = [
  { ticker: "BTC-USDT-SWAP", description: "Bitcoin / USDT \u6C38\u7EED", type: "swap" },
  { ticker: "ETH-USDT-SWAP", description: "Ethereum / USDT \u6C38\u7EED", type: "swap" },
  { ticker: "SOL-USDT-SWAP", description: "Solana / USDT \u6C38\u7EED", type: "swap" }
];
var BRAND_MARKS = {
  btc: `<circle cx="16" cy="16" r="16" fill="#F7931A"/>
    <path fill="#fff" d="M22.4 13.9c.3-2.1-1.3-3.2-3.4-4l.7-2.7-1.7-.4-.7 2.6c-.4-.1-.9-.2-1.4-.3l.7-2.7-1.6-.4-.7 2.7c-.3-.1-.7-.2-1-.2l-2.4-.6-.5 1.8 1.3.3c.7.2.9.6.8 1l-.8 3.2-.2.7-1.1 4.4c-.1.2-.3.6-.8.5l-1.2-.3-.9 1.9 2.2.6c.4.1.8.2 1.2.3l-.7 2.8 1.7.4.7-2.8c.5.1.9.3 1.4.4l-.7 2.8 1.7.4.7-2.8c2.9.6 5 .4 5.9-2.2.7-2.1 0-3.3-1.5-4.1 1.1-.3 1.9-1 2.1-2.5Zm-3.8 5.4c-.5 2.1-4 1-5.2.7l.9-3.7c1.1.3 4.8.8 4.3 3Zm.5-5.4c-.5 1.9-3.4.9-4.3.7l.8-3.4c1 .2 4 .6 3.5 2.7Z"/>`,
  eth: `<circle cx="16" cy="16" r="16" fill="#627EEA"/>
    <g fill="#fff">
      <path d="M16.1 3.9v9.3l7.8 3.5-7.8-12.8Z" fill-opacity=".6"/>
      <path d="M16.1 3.9 8.2 16.7l7.9-3.5V3.9Z"/>
      <path d="M16.1 22.1v6l7.9-10.9-7.9 4.9Z" fill-opacity=".6"/>
      <path d="M16.1 28.1v-6l-7.9-4.9 7.9 10.9Z"/>
      <path d="m16.1 20.7 7.8-4.4-7.8-3.5v7.9Z" fill-opacity=".25"/>
      <path d="m8.2 16.3 7.9 4.4v-7.9l-7.9 3.5Z" fill-opacity=".6"/>
    </g>`,
  sol: `<circle cx="16" cy="16" r="16" fill="#9945FF"/>
    <path fill="#14F195" d="M12.9 9.4h11.2c.5 0 .8.6.4.9l-2.8 2.8c-.2.2-.5.3-.8.3H9.7c-.5 0-.8-.6-.4-.9l2.8-2.8c.2-.2.5-.3.8-.3Z"/>
    <path fill="#FFFFFF" d="M19.1 13.9H7.9c-.5 0-.8.6-.4.9l2.8 2.8c.2.2.5.3.8.3h11.2c.5 0 .8-.6.4-.9l-2.8-2.8c-.2-.2-.5-.3-.8-.3Z"/>
    <path fill="#00D8FF" d="M12.9 18.4h11.2c.5 0 .8.6.4.9l-2.8 2.8c-.2.2-.5.3-.8.3H9.7c-.5 0-.8-.6-.4-.9l2.8-2.8c.2-.2.5-.3.8-.3Z"/>
  `
};
var brandIcon = (base) => {
  const mark = BRAND_MARKS[base];
  if (!mark) return void 0;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" role="img">${mark}</svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
};
var TICK = { BTC: 0.1, ETH: 0.01, SOL: 0.01 };
function parseRow(r, symbol) {
  const c = parseOkxCandle(r, symbol);
  if (!c) return null;
  return { time: c.ts, open: c.o, high: c.h, low: c.l, close: c.c, volume: c.v, confirm: c.confirm, volumeSource: c.volumeSource };
}
async function okxGet(path, params, signal) {
  const url = new URL(REST + path);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  for (let attempt = 0; attempt < 4; attempt++) {
    const res = await fetch(url.toString(), { signal, cache: "no-store" });
    if (res.status === 429) {
      if (attempt === 3) throw new Error("OKX rate limited (429)");
      await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
      continue;
    }
    if (!res.ok) throw new Error(`OKX HTTP ${res.status}`);
    const json = await res.json();
    if (json.code && json.code !== "0") throw new Error(`OKX code ${json.code}`);
    return json.data ?? [];
  }
  return [];
}
var store = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var keyOf = (ticker, tf) => `${ticker}|${tf}`;
var MAX_STORE_BARS = 12e3;
function newer(existing, incoming) {
  return preferCandle(existing, incoming, existing?.volume ?? 0, incoming.volume ?? 0);
}
function mergeFull(key, cur, incoming) {
  const map = /* @__PURE__ */ new Map();
  for (const b of cur) map.set(b.time, b);
  for (const b of incoming) map.set(b.time, newer(map.get(b.time), b));
  const next = [...map.values()].sort((a, b) => a.time - b.time).slice(-MAX_STORE_BARS);
  store.set(key, next);
  listeners.forEach((fn) => fn(key));
}
function merge(key, incoming) {
  if (!incoming.length) return;
  const cur = store.get(key) ?? [];
  const tail = cur[cur.length - 1];
  const head = incoming[0];
  const ordered = !tail || !head || head.time >= tail.time;
  if (!ordered) {
    mergeFull(key, cur, incoming);
    return;
  }
  const next = cur.length ? cur.slice() : [];
  for (const b of incoming) {
    const last = next[next.length - 1];
    if (last && b.time === last.time) next[next.length - 1] = newer(last, b);
    else if (!last || b.time > last.time) next.push(b);
    else {
      mergeFull(key, cur, incoming);
      return;
    }
  }
  if (next.length > MAX_STORE_BARS) next.splice(0, next.length - MAX_STORE_BARS);
  store.set(key, next);
  listeners.forEach((fn) => fn(key));
}
var OKXProvider = class {
  info() {
    return {
      name: "okx",
      displayName: "OKX",
      supportedTimeframes: OKX_TIMEFRAMES,
      capabilities: { enumerate: true, stream: true, symbolInfo: true }
    };
  }
  async listSymbols() {
    return SWAPS;
  }
  async getSymbolInfo(ticker) {
    const base = ticker.split("-")[0];
    const tick = TICK[base] ?? 0.01;
    return {
      ticker,
      description: SWAPS.find((s) => s.ticker === ticker)?.description ?? ticker,
      type: "swap",
      currency: "USDT",
      // Vela's price axis reads `mintick`. Without it the axis falls back to a
      // zoom-range formula, so a freshly loaded SOL chart can show only one
      // decimal (e.g. 93.1 instead of 93.10) until the user zooms.
      mintick: tick,
      pricescale: Math.round(1 / tick),
      minmove: 1,
      timezone: "Etc/UTC"
    };
  }
  resolveSymbolIcon(symbol) {
    const base = symbol.ticker.split("-")[0]?.toLowerCase();
    return base ? brandIcon(base) : void 0;
  }
  /** 默认回看深度：短周期更深（双顶/双底需要足够多的历史关键位） */
  depthFor(timeframe, range) {
    const m = Number(timeframe);
    const base = !Number.isFinite(m) ? 800 : m <= 5 ? 6e3 : m <= 15 ? 4e3 : m <= 60 ? 2500 : 1500;
    return Math.min(Math.max(range.limit ?? 0, base, 100), 12e3);
  }
  async getBars(ticker, timeframe, range) {
    return this.getBarsProgressive(ticker, timeframe, range, () => void 0);
  }
  /**
   * 渐进历史：第一页（最新 300 根）立刻交给图表绘制，随后分页向前补齐并逐批推送——
   * 与参考站一致：先出图，再变深。
   */
  async getBarsProgressive(ticker, timeframe, range, onBatch, opts) {
    const bar = toOkxBar(timeframe);
    const want = this.depthFor(timeframe, range);
    const map = /* @__PURE__ */ new Map();
    const snapshot = () => [...map.values()].sort((a, b) => a.time - b.time).slice(-want);
    const marketKey = keyOf(ticker, timeframe);
    const emit = () => {
      const snap = snapshot();
      merge(marketKey, snap);
      const latest = new Map((store.get(marketKey) ?? []).map((b) => [b.time, b]));
      const out = snap.map((b) => latest.get(b.time) ?? b);
      onBatch(out);
      return out;
    };
    const firstParams = { instId: ticker, bar, limit: "300", ...range.to ? { after: String(range.to + tfMs(timeframe)) } : {} };
    let first = await okxGet("/api/v5/market/candles", firstParams, opts?.signal);
    if (!first.length && range.to) {
      first = await okxGet("/api/v5/market/history-candles", firstParams, opts?.signal);
    }
    for (const r of first) {
      const b = parseRow(r, ticker);
      if (b) map.set(b.time, b);
    }
    emit();
    let oldest = Math.min(...map.keys());
    let guard = 0;
    while (map.size < want && Number.isFinite(oldest) && guard++ < 160) {
      if (opts?.signal?.aborted) break;
      if (range.from && oldest <= range.from) break;
      let page = [];
      try {
        page = await okxGet("/api/v5/market/history-candles", { instId: ticker, bar, after: String(oldest), limit: "300" }, opts?.signal);
      } catch {
        break;
      }
      if (!page.length) break;
      let added = 0;
      for (const r of page) {
        const b = parseRow(r, ticker);
        if (b && !map.has(b.time)) {
          map.set(b.time, b);
          added++;
        }
      }
      if (!added) break;
      oldest = Math.min(oldest, ...page.map((r) => Number(r[0])));
      if (guard % 2 === 0) {
        emit();
        await new Promise((r) => setTimeout(r, 120));
      }
    }
    return emit();
  }
  subscribe(ticker, timeframe, onBar) {
    const channel = `candle${toOkxBar(timeframe)}`;
    const bar = toOkxBar(timeframe);
    const marketKey = keyOf(ticker, timeframe);
    let ws = null;
    let stopped = false;
    let timer = null;
    let ping = null;
    let opened = false;
    const backfill = async () => {
      try {
        const page = await okxGet("/api/v5/market/candles", { instId: ticker, bar, limit: "300" });
        const fresh = [];
        for (const r of page) {
          const parsed = parseRow(r, ticker);
          if (parsed) fresh.push(parsed);
        }
        if (!fresh.length || stopped) return;
        merge(marketKey, fresh);
        const last = fresh[fresh.length - 1];
        if (last) onBar(last);
      } catch {
      }
    };
    const open = () => {
      if (stopped) return;
      try {
        ws = new WebSocket(WS);
      } catch {
        timer = window.setTimeout(open, 3e3);
        return;
      }
      ws.onopen = () => {
        ws?.send(JSON.stringify({ op: "subscribe", args: [{ channel, instId: ticker }] }));
        ping = window.setInterval(() => ws?.readyState === 1 && ws.send("ping"), 2e4);
        if (opened) void backfill();
        opened = true;
      };
      ws.onmessage = (ev) => {
        if (ev.data === "pong") return;
        try {
          const msg = JSON.parse(ev.data);
          if (msg.arg?.channel !== channel || !msg.data) return;
          const fresh = [];
          for (const r of msg.data) {
            const b = parseRow(r, ticker);
            if (b) {
              onBar(b);
              fresh.push(b);
            }
          }
          if (fresh.length) merge(keyOf(ticker, timeframe), fresh);
        } catch {
        }
      };
      ws.onclose = () => {
        if (ping) window.clearInterval(ping);
        if (!stopped) timer = window.setTimeout(open, 2e3);
      };
      ws.onerror = () => ws?.close();
    };
    open();
    return () => {
      stopped = true;
      if (timer) window.clearTimeout(timer);
      if (ping) window.clearInterval(ping);
      ws?.close();
    };
  }
};

// src/app/api/okx/[...path]/route.ts
var ALLOWED = /* @__PURE__ */ new Set([
  "api/v5/rubik/stat/taker-volume-contract",
  "api/v5/rubik/stat/contracts/open-interest-history"
]);
var ALLOWED_PARAMS = /* @__PURE__ */ new Set(["instId", "period", "unit", "end", "begin", "limit"]);
var CACHE = /* @__PURE__ */ new Map();
var TTL = 15e3;
async function GET(req, ctx) {
  const { path } = await ctx.params;
  const target = (path ?? []).join("/");
  if (!ALLOWED.has(target)) return Response.json({ code: "404", msg: "not allowed", data: [] }, { status: 404 });
  const incoming = new URL(req.url);
  const url = new URL(`https://www.okx.com/${target}`);
  for (const [k, v] of incoming.searchParams) {
    if (ALLOWED_PARAMS.has(k) && /^[A-Za-z0-9-]{1,40}$/.test(v)) url.searchParams.set(k, v);
  }
  const key = url.toString();
  const hit = CACHE.get(key);
  if (hit && Date.now() - hit.at < TTL) {
    return new Response(hit.body, { status: hit.status, headers: { "content-type": "application/json" } });
  }
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), 6e3);
  try {
    const res = await fetch(key, { signal: ac.signal, cache: "no-store" });
    const body = await res.text();
    if (res.ok) {
      CACHE.set(key, { at: Date.now(), status: res.status, body });
      if (CACHE.size > 300) {
        const oldest = CACHE.keys().next().value;
        if (oldest) CACHE.delete(oldest);
      }
    }
    return new Response(body, { status: res.status, headers: { "content-type": "application/json" } });
  } catch {
    return Response.json({ code: "502", msg: "upstream unavailable", data: [] }, { status: 502 });
  } finally {
    clearTimeout(timer);
  }
}

// remote/setup-mcp-project-locally/src/lib/engine.ts
var DEFAULT_PARAMS = {
  pivotLeft: 8,
  pivotRight: 5,
  lookback: 288,
  minGap: 8,
  minHeightAtr: 2,
  priorMoveAtr: 1.5,
  tolAtr: 0.35,
  tolPct: 4e-4,
  sweepAtr: 0.5,
  closeBufAtr: 0.05,
  stopAtr: 0.75,
  targetFrac: 1,
  minRR: 1.2,
  maxRR: 4,
  enableBreak: false,
  breakWithin: 24,
  entryMode: "limit",
  limitOffsetAtr: 0.1,
  trendBlock: 1
};
function atrSeries(cs, p2 = 14) {
  const n = cs.length;
  const out = new Array(n).fill(0);
  const tr = new Array(n).fill(0);
  for (let i = 1; i < n; i++) {
    const c = cs[i];
    const pc = cs[i - 1].c;
    tr[i] = Math.max(c.h - c.l, Math.abs(c.h - pc), Math.abs(c.l - pc));
  }
  let sum = 0;
  for (let i = 1; i < n; i++) {
    sum += tr[i];
    if (i - p2 >= 1) sum -= tr[i - p2];
    out[i] = sum / Math.min(i, p2);
  }
  return out;
}
function approxDeltaAt(cs, i) {
  const c = cs[i];
  const range = c.h - c.l;
  if (range <= 0) return c.c > c.o ? c.v / 2 : c.c < c.o ? -c.v / 2 : 0;
  return c.v * (2 * ((c.c - c.l) / range) - 1);
}

// src/quant/flow.ts
function hasRealFlow(bar, candleVol, volumeSource) {
  if (volumeSource && volumeSource !== "quote") return false;
  if (!bar || !Number.isFinite(bar.buy) || !Number.isFinite(bar.sell) || bar.buy < 0 || bar.sell < 0 || !(bar.buy + bar.sell > 0) || candleVol == null || !Number.isFinite(candleVol) || !(candleVol > 0)) return false;
  const coverage = (bar.buy + bar.sell) / candleVol;
  return coverage >= (bar.src === "rubik" ? 0.95 : 0.85) && coverage <= 1.1;
}

// src/quant/context.ts
function emaSeries(cs, period) {
  const k = 2 / (period + 1);
  const out = new Array(cs.length);
  let e = cs[0]?.c ?? 0;
  for (let i = 0; i < cs.length; i++) {
    e = i === 0 ? cs[i].c : cs[i].c * k + e * (1 - k);
    out[i] = e;
  }
  return out;
}
function buildContext(cs, flow) {
  const n = cs.length;
  const atr = atrSeries(cs);
  const delta = new Array(n);
  const real = new Uint8Array(n);
  const oi = new Array(n).fill(NaN);
  const vols = new Array(n);
  const volMa = new Array(n).fill(0);
  const index = /* @__PURE__ */ new Map();
  let covered = 0;
  for (let i = 0; i < n; i++) {
    const fb = flow?.bars.get(cs[i].ts);
    if (hasRealFlow(fb, cs[i].v, cs[i].volumeSource)) {
      delta[i] = fb.buy - fb.sell;
      real[i] = 1;
      covered++;
    } else {
      delta[i] = approxDeltaAt(cs, i);
    }
    const position = fb?.oiContracts && fb.oiContracts > 0 ? fb.oiContracts : fb?.oiUsd;
    if (position && position > 0) oi[i] = position;
    vols[i] = cs[i].v;
    index.set(cs[i].ts, i);
  }
  let s = 0;
  for (let i = 0; i < n; i++) {
    if (i >= 1) s += cs[i - 1].v;
    if (i >= 21) s -= cs[i - 21].v;
    const m = Math.min(i, 20);
    volMa[i] = m ? s / m : cs[i].v;
  }
  return {
    cs,
    n,
    atr,
    delta,
    real,
    oi,
    vols,
    ema20: emaSeries(cs, 20),
    ema50: emaSeries(cs, 50),
    volMa,
    index,
    flowCoverage: n ? covered / n : 0
  };
}

// src/quant/orderflow.ts
var clamp01 = (v) => v < 0 ? 0 : v > 1 ? 1 : v;
var clampR = (v, lo = -1, hi = 1) => v < lo ? lo : v > hi ? hi : v;
var r3 = (v) => Number.isFinite(v) ? Number(v.toFixed(3)) : 0;
var pct = (v) => `${v >= 0 ? "+" : ""}${(v * 100).toFixed(0)}%`;
function windowFlow(ctx, from, to) {
  const a = Math.max(0, Math.min(from, to));
  const b = Math.min(ctx.n - 1, Math.max(from, to));
  let vol = 0;
  let delta = 0;
  let known = 0;
  let base = 0;
  let bars = 0;
  for (let i = a; i <= b; i++) {
    vol += ctx.vols[i];
    delta += ctx.delta[i];
    known += ctx.real[i];
    base += ctx.volMa[i];
    bars++;
  }
  return {
    from: a,
    to: b,
    bars,
    vol,
    delta,
    ratio: vol > 0 ? delta / vol : 0,
    known: bars ? known / bars : 0,
    volRatio: base > 0 ? vol / base : 1
  };
}
var sourceOf = (known) => known >= 0.95 ? "taker" : known <= 0.05 ? "approx" : "mixed";
var swingCache = /* @__PURE__ */ new WeakMap();
function findSwingLevels(ctx, opts = {}) {
  const isDefault = opts.left == null && opts.right == null && opts.priorAtr == null && opts.maxAge == null;
  if (isDefault) {
    const hit = swingCache.get(ctx);
    if (hit) return hit.map((l) => ({ ...l }));
  }
  const { cs, n, atr } = ctx;
  const L2 = opts.left ?? 8;
  const R2 = opts.right ?? 5;
  const priorAtr = opts.priorAtr ?? 1.5;
  const maxAge = opts.maxAge ?? 576;
  const out = [];
  const active = [];
  for (let i = L2 + R2; i < n; i++) {
    const a = atr[i];
    if (!(a > 0)) continue;
    for (let q = active.length - 1; q >= 0; q--) {
      const lv = active[q];
      const c = cs[i];
      const broke = lv.side === "top" ? c.c > lv.price + 0.1 * a : c.c < lv.price - 0.1 * a;
      if (broke) {
        lv.breakIdx = i;
        active.splice(q, 1);
      } else if (i - lv.idx > maxAge) {
        active.splice(q, 1);
      }
    }
    const j = i - R2;
    for (const side of ["top", "bottom"]) {
      const ext = side === "top" ? cs[j].h : cs[j].l;
      let ok = true;
      for (let k = j - L2; k < j && ok; k++) {
        if (side === "top" ? cs[k].h >= ext : cs[k].l <= ext) ok = false;
      }
      for (let k = j + 1; k <= i && ok; k++) {
        if (side === "top" ? cs[k].h > ext : cs[k].l < ext) ok = false;
      }
      if (!ok) continue;
      let prior = side === "top" ? Infinity : -Infinity;
      for (let k = Math.max(0, j - 24); k < j; k++) prior = side === "top" ? Math.min(prior, cs[k].l) : Math.max(prior, cs[k].h);
      if (!(Math.abs(ext - prior) >= priorAtr * a)) continue;
      const tol = Math.max(0.35 * a, 4e-4 * Math.abs(ext));
      if (active.some((lv2) => lv2.side === side && Math.abs(lv2.price - ext) <= tol)) continue;
      const lv = { idx: j, ts: cs[j].ts, price: ext, side, breakIdx: null };
      active.push(lv);
      out.push(lv);
    }
  }
  if (isDefault) swingCache.set(ctx, out.map((l) => ({ ...l })));
  return out;
}
function readBreakout(ctx, level, breakIdx, uptoIdx, stats) {
  const { cs, n, atr, oi } = ctx;
  const upto = Math.min(n - 1, Math.max(breakIdx, uptoIdx));
  const dir = level.side === "top" ? 1 : -1;
  const a = Math.max(atr[breakIdx] || atr[upto] || 0, 1e-9);
  const L2 = level.price;
  const up = dir > 0;
  const brk = cs[breakIdx];
  const breakFlow = windowFlow(ctx, breakIdx, breakIdx);
  const extensionAtr = (brk.c - L2) * dir / a;
  let peak = up ? brk.h : brk.l;
  let peakIdx = breakIdx;
  for (let q = breakIdx + 1; q <= upto; q++) {
    const c = cs[q];
    if (up ? c.h > peak : c.l < peak) {
      peak = up ? c.h : c.l;
      peakIdx = q;
    }
  }
  const impulseFlow = windowFlow(ctx, breakIdx, peakIdx);
  const climax = breakFlow.volRatio >= 2.5 || extensionAtr >= 1.2;
  const legSize = Math.max((peak - L2) * dir, 0.5 * a);
  let extreme = peak;
  let touched = false;
  let held = false;
  let failed = false;
  let touchIdx = -1;
  let runPeak = up ? brk.h : brk.l;
  let runPeakIdx = breakIdx;
  for (let q = breakIdx + 1; q <= upto; q++) {
    const c = cs[q];
    if (q > peakIdx) {
      const e = up ? c.l : c.h;
      if (up ? e < extreme : e > extreme) extreme = e;
    }
    const madeHigh = up ? c.h > runPeak : c.l < runPeak;
    if (madeHigh) {
      runPeak = up ? c.h : c.l;
      runPeakIdx = q;
    }
    const near = up ? c.l <= L2 + 0.3 * a : c.h >= L2 - 0.3 * a;
    if (near && !madeHigh && q > runPeakIdx && (runPeak - L2) * dir >= 0.4 * a) {
      touched = true;
      if (touchIdx < 0) touchIdx = q;
    }
    const back = up ? c.c < L2 - 0.2 * a : c.c > L2 + 0.2 * a;
    if (back) failed = true;
    if (touched && !failed && (up ? c.c >= L2 + 0.1 * a : c.c <= L2 - 0.1 * a)) {
      const range = Math.max(1e-9, c.h - c.l);
      const pos = (c.c - c.l) / range;
      if (up ? pos >= 0.5 : pos <= 0.5) held = true;
    }
  }
  const pullbackBars = upto > peakIdx ? upto - peakIdx : 0;
  const pullbackFlow = pullbackBars > 0 ? windowFlow(ctx, peakIdx + 1, upto) : null;
  const depth = clamp01((peak - extreme) * dir / legSize);
  const started = pullbackBars > 0 && (depth >= 0.25 || touched);
  const impulsePer = impulseFlow.vol / Math.max(1, impulseFlow.bars);
  const pullPer = pullbackFlow ? pullbackFlow.vol / Math.max(1, pullbackFlow.bars) : 0;
  const pbVolRatio = pullbackFlow && impulsePer > 0 ? pullPer / impulsePer : 0;
  const pbDelta = pullbackFlow ? pullbackFlow.ratio : 0;
  const healthy = started && pbVolRatio <= 0.8 && pbDelta * dir > -0.15;
  const heavy = started && (pbVolRatio > 0.8 && pbDelta * dir < -0.05);
  let oiPct = null;
  const oi0 = oi[Math.max(0, breakIdx - 1)];
  const oi1 = oi[peakIdx];
  if (Number.isFinite(oi0) && Number.isFinite(oi1) && oi0 > 0) oiPct = oi1 / oi0 - 1;
  const bucket = touched ? healthy || held ? "retest_hold" : "retest_heavy" : "no_retest";
  const reasons = [];
  let p2 = 0.5;
  const dConf = clampR(breakFlow.ratio * dir / 0.15);
  p2 += 0.1 * dConf;
  reasons.push(
    breakFlow.ratio * dir >= 0.08 ? `\u7A81\u7834K\u4E3B\u52A8${up ? "\u4E70\u5165" : "\u5356\u51FA"}\u5360\u4F18\uFF08${pct(breakFlow.ratio)}\uFF09` : breakFlow.ratio * dir <= -0.05 ? `\u7A81\u7834K\u4E3B\u52A8\u6210\u4EA4\u53CD\u5411\uFF08${pct(breakFlow.ratio)}\uFF09\uFF1A\u9760\u88AB\u52A8\u76D8\u63A8\u52A8\uFF0C\u53EF\u4FE1\u5EA6\u4F4E` : `\u7A81\u7834K\u4E3B\u52A8\u6210\u4EA4\u5747\u8861\uFF08${pct(breakFlow.ratio)}\uFF09`
  );
  if (breakFlow.volRatio >= 1.3 && breakFlow.volRatio < 2.5) {
    p2 += 0.08;
    reasons.push(`\u7A81\u7834\u653E\u91CF ${breakFlow.volRatio.toFixed(1)}x`);
  } else if (breakFlow.volRatio < 1) {
    p2 -= 0.06;
    reasons.push(`\u7A81\u7834\u7F29\u91CF ${breakFlow.volRatio.toFixed(1)}x\uFF1A\u53C2\u4E0E\u4E0D\u8DB3`);
  }
  if (climax) {
    p2 -= 0.08;
    reasons.push(`\u51B2\u9AD8${up ? "" : "/\u6740\u8DCC"}\u8FC7\u6025\uFF08${breakFlow.volRatio.toFixed(1)}x \u91CF \xB7 \u79BB\u4F4D ${extensionAtr.toFixed(1)} ATR\uFF09\uFF1A\u8FFD\u5355\u591A\u534A\u8981\u88AB\u56DE\u8C03\u6D17`);
  }
  if (oiPct != null && oiPct > 2e-3) {
    p2 += 0.04;
    reasons.push(`\u7A81\u7834\u6BB5\u6301\u4ED3 +${(oiPct * 100).toFixed(2)}%\uFF1A\u6709\u65B0\u8D44\u91D1\u8DDF\u8FDB`);
  }
  if (started) {
    if (healthy) {
      p2 += 0.12;
      reasons.push(`\u56DE\u8C03\u7F29\u91CF ${pbVolRatio.toFixed(2)}x \xB7 \u56DE\u8C03\u4E2D\u4E3B\u52A8${up ? "\u5356" : "\u4E70"}\u538B\u4E0D\u91CD\uFF08${pct(pbDelta)}\uFF09`);
    } else if (heavy) {
      p2 -= 0.12;
      reasons.push(`\u56DE\u8C03\u653E\u91CF ${pbVolRatio.toFixed(2)}x \u4E14\u4E3B\u52A8${up ? "\u5356\u51FA" : "\u4E70\u5165"}\u5360\u4F18\uFF08${pct(pbDelta)}\uFF09`);
    } else {
      reasons.push(`\u56DE\u8C03\u91CF\u80FD ${pbVolRatio.toFixed(2)}x \xB7 \u4E3B\u52A8\u5DEE ${pct(pbDelta)}`);
    }
  }
  if (held) {
    p2 += 0.15;
    reasons.push(`\u56DE\u8E29 ${L2} \u540E\u6536\u76D8\u7AD9\u56DE${up ? "\u4E0A\u65B9" : "\u4E0B\u65B9"}\uFF1A${up ? "\u963B\u529B\u8F6C\u652F\u6491" : "\u652F\u6491\u8F6C\u963B\u529B"}\u6210\u7ACB`);
  }
  if (failed) {
    p2 = 0.15;
    reasons.push(`\u5DF2\u6709\u6536\u76D8\u56DE\u5230\u5173\u952E\u4F4D${up ? "\u4E0B\u65B9" : "\u4E0A\u65B9"}\uFF1A\u7A81\u7834\u5931\u8D25\uFF0C${up ? "\u8FFD\u591A" : "\u8FFD\u7A7A"}\u76D8\u88AB\u5957`);
  }
  let empiricalN = 0;
  let chaseRate = null;
  if (stats && !failed) {
    const b = stats.buckets[bucket];
    if (b.n >= 8) {
      empiricalN = b.n;
      p2 = (p2 * 8 + b.win / b.n * b.n) / (8 + b.n);
    }
    if (stats.chase.n >= 8) chaseRate = stats.chase.win / stats.chase.n;
  }
  const followProb = failed ? 0.15 : r3(clampR(p2, 0.08, empiricalN ? 0.92 : 0.85));
  let verdict;
  if (failed) verdict = "failed";
  else if (held) verdict = followProb >= 0.5 ? "follow" : "follow_weak";
  else if (started) verdict = heavy ? "avoid" : "wait_pullback";
  else if (climax || extensionAtr >= 0.8) verdict = "chase_risk";
  else if (upto - breakIdx >= 6 && depth < 0.25) verdict = "strong_hold";
  else verdict = "chase_risk";
  const headline = verdict === "failed" ? up ? "\u5047\u7A81\u7834 / \u8BF1\u591A\uFF1A\u4E0D\u8DDF\uFF0C\u53CD\u5411\u673A\u4F1A" : "\u5047\u8DCC\u7834 / \u8BF1\u7A7A\uFF1A\u4E0D\u8DDF\uFF0C\u53CD\u5411\u673A\u4F1A" : verdict === "follow" ? `\u56DE\u8E29\u786E\u8BA4\uFF0C\u53EF\u8DDF\u968F\uFF08${Math.round(followProb * 100)}%\uFF09` : verdict === "follow_weak" ? `\u56DE\u8E29\u5B88\u4F4F\uFF0C\u4F46\u672C\u56FE\u5386\u53F2\u5151\u73B0\u7387\u4EC5 ${Math.round(followProb * 100)}%\uFF1A\u8F7B\u4ED3\u6216\u89C2\u671B` : verdict === "wait_pullback" ? "\u7F29\u91CF\u56DE\u8C03\u4E2D\uFF1A\u7B49\u56DE\u8E29\u5230\u4F4D\u518D\u8DDF" : verdict === "avoid" ? "\u56DE\u8C03\u653E\u91CF\u629B\u538B\u91CD\uFF1A\u6682\u4E0D\u8DDF\u968F" : verdict === "strong_hold" ? "\u5F3A\u52BF\u4E0D\u56DE\u8C03\uFF1A\u53EA\u80FD\u8F7B\u4ED3\u6216\u7B49\u9996\u6B21\u7F29\u91CF\u56DE\u8E29" : "\u521A\u7A81\u7834\u4E0D\u8FFD\uFF1A\u7B49\u56DE\u8E29";
  const known = (impulseFlow.known * impulseFlow.bars + (pullbackFlow?.known ?? 0) * pullbackBars) / Math.max(1, impulseFlow.bars + pullbackBars);
  return {
    dir,
    level: L2,
    levelTs: level.ts,
    breakIdx,
    breakTs: brk.ts,
    barsSince: upto - breakIdx,
    impulse: {
      bars: impulseFlow.bars,
      volRatio: r3(breakFlow.volRatio),
      deltaRatio: r3(breakFlow.ratio),
      known: r3(impulseFlow.known),
      extensionAtr: r3(extensionAtr),
      climax,
      peak,
      peakIdx
    },
    pullback: {
      started,
      depth: r3(depth),
      bars: pullbackBars,
      volRatio: r3(pbVolRatio),
      deltaRatio: r3(pbDelta),
      known: r3(pullbackFlow?.known ?? 0),
      touched,
      held,
      failed,
      extreme
    },
    oiPct: oiPct == null ? null : r3(oiPct),
    bucket,
    verdict,
    followProb,
    chaseRate: chaseRate == null ? null : r3(chaseRate),
    empiricalN,
    reasons,
    headline,
    flowSource: sourceOf(known),
    zone: up ? { lo: L2 - 0.1 * a, hi: L2 + 0.3 * a } : { lo: L2 - 0.3 * a, hi: L2 + 0.1 * a }
  };
}

// src/vela/annotTypes.ts
var decimalsFor = (price2) => {
  const p2 = Math.abs(price2);
  return p2 >= 1e3 ? 1 : p2 >= 10 ? 2 : p2 >= 1 ? 3 : 5;
};

// src/vela/signals/patterns.ts
var p = DEFAULT_PARAMS;
var L = p.pivotLeft;
var R = p.pivotRight;
var MAX_TOL_ATR = 0.7;
function annotationTolerance(price2, atr) {
  if (!(atr > 0) || !Number.isFinite(price2)) return 0;
  return Math.min(Math.max(p.tolAtr * atr, p.tolPct * Math.abs(price2)), MAX_TOL_ATR * atr);
}
function scanAnnotationPatterns(ctx) {
  const { cs, atr } = ctx;
  if (cs.length < L + R + p.minGap) return [];
  const out = [];
  for (const side of ["bottom", "top"]) {
    const sign = side === "bottom" ? 1 : -1;
    const view = side === "bottom" ? cs : cs.map((c) => ({ ts: c.ts, o: -c.o, h: -c.l, l: -c.h, c: -c.c, v: c.v }));
    const active = [];
    const width = annotationTolerance;
    for (let i = 1; i < view.length; i++) {
      const c = view[i];
      const a = atr[i];
      if (!(a > 0)) continue;
      for (let k = active.length - 1; k >= 0; k--) {
        const lv = active[k];
        const tol2 = width(lv.price, a);
        if (i - lv.first > p.lookback || c.l < lv.price - p.sweepAtr * a || c.c < lv.price - tol2) {
          active.splice(k, 1);
          continue;
        }
        const range = Math.max(c.h - c.l, 1e-9);
        const closePos = (c.c - c.l) / range;
        const wick = (Math.min(c.o, c.c) - c.l) / range;
        const rejection = c.c >= lv.price + p.closeBufAtr * a && closePos >= 0.5 && (c.c > c.o || wick >= 0.35);
        const emit = (second) => {
          out.push({
            side,
            idx: i,
            first: lv.first,
            second,
            neckIdx: lv.neckIdx,
            firstLegStart: lv.firstLegStart,
            secondLegStart: lv.neckIdx,
            level: sign * lv.price,
            neck: sign * lv.neck,
            secondPrice: sign * view[second].l
          });
          active.splice(k, 1);
        };
        if (lv.pending !== null) {
          const test = view[lv.pending];
          if (i === lv.pending + 1 && rejection && c.c > test.c) emit(lv.pending);
          else active.splice(k, 1);
          continue;
        }
        const qualified = i - lv.first >= p.minGap && lv.neck - lv.price >= p.minHeightAtr * a;
        if (qualified && c.l <= lv.price + tol2) {
          if (rejection) emit(i);
          else lv.pending = i;
        } else if (c.h > lv.neck) {
          lv.neck = c.h;
          lv.neckIdx = i;
        }
      }
      const j = i - R;
      if (j < L) continue;
      const low = view[j].l;
      let pivot = true;
      for (let q = j - L; q < j && pivot; q++) if (view[q].l <= low) pivot = false;
      for (let q = j + 1; q <= i && pivot; q++) if (view[q].l < low) pivot = false;
      if (!pivot) continue;
      const priorBars = Math.max(3 * L, 24);
      let prior = -Infinity;
      let priorIdx = j;
      for (let q = Math.max(0, j - priorBars); q < j; q++) {
        if (view[q].h > prior) {
          prior = view[q].h;
          priorIdx = q;
        }
      }
      if (prior - low < p.priorMoveAtr * a) continue;
      const tol = width(low, a);
      if (active.some((lv) => Math.abs(lv.price - low) <= tol)) continue;
      let neck = -Infinity;
      let neckIdx = j;
      for (let q = j + 1; q <= i; q++) {
        if (view[q].h > neck) {
          neck = view[q].h;
          neckIdx = q;
        }
      }
      active.push({ first: j, firstLegStart: priorIdx, price: low, neck, neckIdx, pending: null });
    }
  }
  return out.sort((a, b) => a.idx - b.idx || a.first - b.first);
}

// src/quant/smartmoney.ts
var clamp012 = (v) => v < 0 ? 0 : v > 1 ? 1 : v;
function dealingRange(ctx, from, to) {
  const a = Math.max(0, Math.min(from, ctx.n - 1));
  const b = Math.max(a, Math.min(to, ctx.n - 1));
  let hi = -Infinity;
  let lo = Infinity;
  for (let i = a; i <= b; i++) {
    hi = Math.max(hi, ctx.cs[i].h);
    lo = Math.min(lo, ctx.cs[i].l);
  }
  if (!Number.isFinite(hi) || !Number.isFinite(lo) || hi <= lo) {
    const p2 = ctx.cs[b]?.c ?? 0;
    hi = p2;
    lo = p2;
  }
  const price2 = ctx.cs[b]?.c ?? lo;
  const mid = (hi + lo) / 2;
  const position = hi > lo ? clamp012((price2 - lo) / (hi - lo)) : 0.5;
  return { from: a, to: b, hi, lo, mid, price: price2, position, premium: price2 > mid, discount: price2 < mid };
}
function findFvgs(ctx, from, to, upto) {
  const start = Math.max(2, from);
  const end = Math.min(upto, ctx.n - 1);
  const out = [];
  for (let i = start; i <= end; i++) {
    const a = ctx.cs[i - 2];
    const c = ctx.cs[i];
    const bullish = c.l > a.h;
    const bearish = c.h < a.l;
    if (!bullish && !bearish) continue;
    const gap = bullish ? c.l - a.h : a.l - c.h;
    const atr = Math.max(ctx.atr[i] ?? 0, 1e-9);
    if (gap < 0.1 * atr) continue;
    const lo = bullish ? a.h : c.h;
    const hi = bullish ? c.l : a.l;
    let touched = false;
    let filled = false;
    let fillIdx = null;
    for (let q = i + 1; q <= end; q++) {
      const bar = ctx.cs[q];
      if (bullish) {
        if (bar.l <= hi) touched = true;
        if (bar.l <= lo) {
          filled = true;
          fillIdx = q;
          break;
        }
      } else {
        if (bar.h >= lo) touched = true;
        if (bar.h >= hi) {
          filled = true;
          fillIdx = q;
          break;
        }
      }
    }
    out.push({ kind: bullish ? "bullish" : "bearish", from: i - 2, to: i, lo, hi, touched, filled, fillIdx, aligned: false });
  }
  return out;
}
function latestStructure(ctx, idx) {
  const known = findSwingLevels(ctx).map((l) => ({ level: l, breakIdx: l.breakIdx })).filter((x) => x.breakIdx != null && x.breakIdx <= idx).sort((a, b) => a.breakIdx - b.breakIdx);
  if (!known.length) return null;
  const last = known[known.length - 1];
  const prev = known.length > 1 ? known[known.length - 2] : null;
  const kind = prev && prev.level.side !== last.level.side ? "CHOCH" : "BOS";
  return {
    kind,
    dir: last.level.side === "top" ? 1 : -1,
    idx: last.breakIdx,
    price: last.level.price
  };
}
function liquidityPool(ctx, p2, lookback = 160) {
  const from = Math.max(0, p2.second - lookback);
  const a = Math.max(ctx.atr[p2.idx] ?? 0, 1e-9);
  const tol = Math.max(0.15 * a, 4e-4 * Math.abs(p2.level));
  const top = p2.side === "top";
  let touches = 0;
  for (let i = from; i < p2.second; i++) {
    const ext = top ? ctx.cs[i].h : ctx.cs[i].l;
    if (Math.abs(ext - p2.level) <= tol) touches++;
  }
  if (touches < 1) return null;
  const test = ctx.cs[p2.second];
  const beyond = top ? test.h - p2.level : p2.level - test.l;
  const swept = beyond >= 0.05 * a;
  const confirm = ctx.cs[p2.idx];
  const reclaimed = top ? confirm.c < p2.level : confirm.c > p2.level;
  return {
    side: top ? "above" : "below",
    price: p2.level,
    touches,
    swept,
    sweptIdx: swept ? p2.second : null,
    reclaimed
  };
}
function orderBlockCandidate(ctx, p2) {
  const top = p2.side === "top";
  const a = Math.max(ctx.atr[p2.idx] ?? 0, 1e-9);
  let pivot = -1;
  for (let i = p2.second - 1; i >= Math.max(0, p2.second - 40); i--) {
    const c = ctx.cs[i];
    const opposite = top ? c.c < c.o : c.c > c.o;
    const displacement = top ? p2.level - c.l : c.h - p2.level;
    if (opposite && displacement >= 0.5 * a) {
      pivot = i;
      break;
    }
  }
  if (pivot < 0) return null;
  const bar = ctx.cs[pivot];
  const lo = Math.min(bar.o, bar.c);
  const hi = Math.max(bar.o, bar.c);
  let mitigated = false;
  let mitigatedIdx = null;
  for (let q = pivot + 1; q <= p2.idx; q++) {
    const c = ctx.cs[q];
    if (c.h >= lo && c.l <= hi) {
      mitigated = true;
      mitigatedIdx = q;
      break;
    }
  }
  return {
    from: pivot,
    to: p2.idx,
    lo,
    hi,
    displacementAtr: Number(((top ? p2.level - lo : hi - p2.level) / a).toFixed(2)),
    mitigated,
    mitigatedIdx
  };
}
function readSmartMoney(ctx, p2, flow, flowKnown = false) {
  const top = p2.side === "top";
  const dir = top ? -1 : 1;
  const range = dealingRange(ctx, Math.max(0, p2.first - 24), p2.idx);
  const liquidity = liquidityPool(ctx, p2);
  const structure = latestStructure(ctx, p2.idx);
  const fvgs = findFvgs(ctx, Math.max(0, p2.second - 60), p2.idx, p2.idx).map((z) => ({ ...z, aligned: top ? z.kind === "bearish" : z.kind === "bullish" })).sort((x, y) => Number(y.aligned) - Number(x.aligned) || y.to - x.to);
  const orderBlock = orderBlockCandidate(ctx, p2);
  const taker = flow && flowKnown && flow.known >= 0.5 ? { window: flow, aligned: flow.ratio * dir > 0.05 } : null;
  const evidence = [];
  const liquidityHit = !!liquidity?.swept && liquidity.reclaimed;
  evidence.push({
    key: "liquiditySweep",
    label: "\u626B\u6D41\u52A8\u6027\u540E\u6536\u56DE",
    state: liquidity ? liquidityHit ? "hit" : "miss" : "na",
    detail: liquidity ? `${liquidity.side === "above" ? "\u7B49\u9AD8\u7B49\u4F4E\u4E0A\u65B9" : "\u4E0B\u65B9"}\u6D41\u52A8\u6027\u4F4D ${liquidity.price}\uFF0C${liquidity.touches} \u6B21\u89E6\u53CA\uFF1B${liquidity.swept ? "\u672C\u6B21\u523A\u7834\u5E76" : "\u672A\u523A\u7834\uFF0C"}${liquidity.reclaimed ? "\u6536\u76D8\u6536\u56DE\u5173\u952E\u4F4D\u5185\u3002" : "\u6536\u76D8\u672A\u6536\u56DE\u3002"}` : "\u5173\u952E\u4F4D\u9644\u8FD1\u6CA1\u6709\u5F62\u6210\u53EF\u8BC6\u522B\u7684\u7B49\u9AD8\u7B49\u4F4E\u6D41\u52A8\u6027\u6C60\u3002"
  });
  const structureAligned = !!structure && structure.dir === dir;
  evidence.push({
    key: "structureShift",
    label: "\u7ED3\u6784\u4E8B\u4EF6\u540C\u5411",
    state: structure ? structureAligned ? "hit" : "miss" : "na",
    detail: structure ? `${structure.kind}\uFF08${structure.dir > 0 ? "\u5411\u4E0A" : "\u5411\u4E0B"}\u6536\u76D8\u8D8A\u8FC7\u6446\u52A8\u4F4D ${structure.price}\uFF09\uFF0C${structureAligned ? "\u4E0E\u672C\u6B21\u53CD\u8F6C\u65B9\u5411\u4E00\u81F4\u3002" : "\u65B9\u5411\u4E0E\u672C\u6B21\u53CD\u8F6C\u65B9\u5411\u76F8\u53CD\u3002"}` : "\u786E\u8BA4\u524D\u6CA1\u6709\u51FA\u73B0\u6536\u76D8\u8D8A\u4F4D\u578B\u7ED3\u6784\u4E8B\u4EF6\u3002"
  });
  const alignedFvg = fvgs.find((z) => z.aligned && !z.filled);
  evidence.push({
    key: "fvg",
    label: "\u540C\u5411\u672A\u56DE\u8865\u7F3A\u53E3",
    state: alignedFvg ? "hit" : fvgs.length ? "miss" : "na",
    detail: alignedFvg ? `${top ? "\u7A7A\u5934" : "\u591A\u5934"}\u7F3A\u53E3 ${alignedFvg.lo.toFixed(2)}\u2013${alignedFvg.hi.toFixed(2)} \u5C1A\u672A\u5B8C\u5168\u56DE\u8865${alignedFvg.touched ? "\uFF08\u5DF2\u88AB\u90E8\u5206\u56DE\u8E29\uFF09" : ""}\u3002` : fvgs.length ? "\u5B58\u5728\u7F3A\u53E3\uFF0C\u4F46\u540C\u5411\u7F3A\u53E3\u5DF2\u7ECF\u56DE\u8865\u6216\u4E0D\u5B58\u5728\u3002" : "\u7B2C\u4E8C\u6D4B\u8BD5\u524D\u540E\u6CA1\u6709\u8FBE\u5230 0.1 ATR \u7684\u4E09\u6839\u4E0D\u91CD\u53E0\u7F3A\u53E3\u3002"
  });
  const obHit = !!orderBlock && !orderBlock.mitigated;
  evidence.push({
    key: "orderBlock",
    label: "\u672A\u56DE\u8E29\u8BA2\u5355\u5757\u5019\u9009",
    state: orderBlock ? obHit ? "hit" : "miss" : "na",
    detail: orderBlock ? `${top ? "\u4F9B\u5E94" : "\u9700\u6C42"}\u533A ${orderBlock.lo.toFixed(2)}\u2013${orderBlock.hi.toFixed(2)}\uFF08\u4F4D\u79FB ${orderBlock.displacementAtr} ATR\uFF09\uFF0C\u786E\u8BA4\u524D${orderBlock.mitigated ? `\u5DF2\u5728\u7B2C ${orderBlock.mitigatedIdx} \u6839\u88AB\u56DE\u8E29\u3002` : "\u5C1A\u672A\u88AB\u56DE\u8E29\u3002"}` : "\u7B2C\u4E8C\u6D4B\u8BD5\u524D\u7684\u63A8\u8FDB\u6BB5\u6CA1\u6709\u627E\u5230\u6EE1\u8DB3\u6761\u4EF6\u7684\u53CD\u5411 K \u7EBF\u3002"
  });
  const pdHit = top ? range.premium : range.discount;
  evidence.push({
    key: "premiumDiscount",
    label: "\u6EA2\u4EF7/\u6298\u4EF7\u4F4D\u7F6E",
    state: pdHit ? "hit" : "miss",
    detail: `\u4EA4\u6613\u533A\u95F4 ${range.lo.toFixed(2)}\u2013${range.hi.toFixed(2)}\uFF0C\u786E\u8BA4\u6536\u76D8\u4F4D\u4E8E ${(range.position * 100).toFixed(0)}% \u5206\u4F4D\uFF08${range.premium ? "\u6EA2\u4EF7\u533A" : range.discount ? "\u6298\u4EF7\u533A" : "\u5747\u8861\u7EBF"}\uFF09\u3002`
  });
  if (taker) {
    evidence.push({
      key: "takerConfirm",
      label: "\u771F\u5B9E taker \u6210\u4EA4\u4F50\u8BC1",
      state: taker.aligned ? "hit" : "miss",
      detail: `\u7A97\u53E3\u771F\u5B9E\u4E3B\u52A8\u5DEE ${(taker.window.ratio * 100).toFixed(0)}%\uFF0C\u8986\u76D6 ${(taker.window.known * 100).toFixed(0)}%\uFF1B${taker.aligned ? "\u4E0E\u53CD\u8F6C\u65B9\u5411\u4E00\u81F4\u3002" : "\u672A\u7AD9\u5728\u53CD\u8F6C\u4E00\u4FA7\u3002"} \u8FD9\u662F taker \u6210\u4EA4\u65B9\u5411\uFF0C\u4E0D\u662F\u8BA2\u5355\u7C3F OFI\uFF0C\u4E5F\u4E0D\u8BC1\u660E\u5177\u4F53\u6B62\u635F\u6216\u673A\u6784\u4ED3\u4F4D\u3002`
    });
  } else {
    evidence.push({
      key: "takerConfirm",
      label: "\u771F\u5B9E taker \u6210\u4EA4\u4F50\u8BC1",
      state: "na",
      detail: "\u8BE5\u7A97\u53E3\u6CA1\u6709\u5B8C\u6574\u771F\u5B9E\u9010\u7B14\u8986\u76D6\uFF0C\u56E0\u6B64\u4E0D\u8F93\u51FA\u6210\u4EA4\u4F50\u8BC1\uFF0C\u4E5F\u4E0D\u636E\u6B64\u63A8\u65AD\u673A\u6784\u884C\u4E3A\u3002"
    });
  }
  const hits = evidence.filter((e) => e.state === "hit").length;
  const tags = evidence.filter((e) => e.state === "hit").map((e) => e.label);
  const headline = hits ? `${top ? "\u9876\u90E8" : "\u5E95\u90E8"}\u5173\u952E\u4F4D SMC \u89C2\u5BDF\uFF1A${tags.slice(0, 3).join(" \xB7 ")}\uFF08\u7ED3\u6784\u547D\u4E2D ${hits}/5\uFF0C\u4E0D\u662F\u80DC\u7387\uFF09` : `${top ? "\u9876\u90E8" : "\u5E95\u90E8"}\u5173\u952E\u4F4D SMC \u89C2\u5BDF\uFF1A\u6CA1\u6709\u547D\u4E2D\u53EF\u9A8C\u8BC1\u7684\u7ED3\u6784\u6761\u4EF6`;
  return {
    side: p2.side,
    dir,
    range,
    liquidity,
    structure,
    fvgs,
    orderBlock,
    evidence,
    hits,
    headline,
    taker,
    source: taker ? "real" : "price"
  };
}

// src/vela/signals/evidence.ts
function takerObservation(ctx, flow, i) {
  const c = ctx.cs[i], b = c && flow?.bars.get(c.ts);
  if (!c || !b || ctx.real[i] !== 1 || !(b.buy + b.sell > 0)) return null;
  const total = b.buy + b.sell;
  return {
    buy: b.buy,
    sell: b.sell,
    total,
    delta: b.buy - b.sell,
    ratio: (b.buy - b.sell) / total,
    src: b.src,
    coverage: c.v > 0 ? total / c.v : 0,
    volRatio: volumeRatio(ctx, i) ?? 0
  };
}
function volumeRatio(ctx, i) {
  return ctx.cs[i] && ctx.volMa[i] > 0 ? ctx.cs[i].v / ctx.volMa[i] : null;
}
function legFlow(ctx, flow, from, to, barMs) {
  const start = Math.max(0, Math.min(from, to)), end = Math.min(ctx.n - 1, Math.max(from, to));
  let covered = 0, buy = 0, sell = 0, continuous = end >= start;
  for (let i = start; i <= end; i++) {
    if (i > start && ctx.cs[i].ts - ctx.cs[i - 1].ts !== barMs) continuous = false;
    const obs = takerObservation(ctx, flow, i);
    if (!obs) {
      continuous = false;
      continue;
    }
    covered++;
    buy += obs.buy;
    sell += obs.sell;
  }
  const bars = Math.max(0, end - start + 1), total = buy + sell;
  const complete = continuous && covered === bars && total > 0;
  return { from: start, to: end, bars, covered, complete, buy, sell, total, delta: buy - sell, ratio: complete ? (buy - sell) / total : null };
}
function realCvdBetween(ctx, flow, first, second, barMs) {
  if (first < 0 || second <= first || second >= ctx.n) return null;
  const interval = legFlow(ctx, flow, first, second, barMs);
  if (!interval.complete) return null;
  return legFlow(ctx, flow, first + 1, second, barMs).ratio;
}
function unitVolume(ctx, from, to) {
  const a = Math.max(0, from), b = Math.min(ctx.n - 1, to);
  if (a > b) return 0;
  let sum = 0;
  for (let i = a; i <= b; i++) sum += ctx.cs[i].v;
  return sum / (b - a + 1);
}
var pct2 = (v) => `${v >= 0 ? "+" : ""}${(v * 100).toFixed(1)}%`;
var money = (v) => v >= 1e6 ? `${(v / 1e6).toFixed(2)}M` : v >= 1e3 ? `${(v / 1e3).toFixed(1)}K` : v.toFixed(0);
function observationText(name, o) {
  if (!o) return `${name}\uFF1A\u672A\u5B8C\u6574\u8986\u76D6\uFF0C\u4E0D\u5224\u65AD\u4E3B\u52A8\u65B9\u5411`;
  return `${name}\uFF1A\u4E70 ${money(o.buy)} / \u5356 ${money(o.sell)} USDT\uFF1B\u4E70\u5360 ${((1 + o.ratio) * 50).toFixed(1)}% / \u5356\u5360 ${((1 - o.ratio) * 50).toFixed(1)}%\uFF1B\u0394 ${pct2(o.ratio)}\uFF1B${o.src === "rubik" ? "OKX \u5B98\u65B9\u7EDF\u8BA1" : "\u9010\u7B14\u805A\u5408"}\uFF0C\u8986\u76D6 ${(o.coverage * 100).toFixed(1)}%`;
}
function readMwEvidence(ctx, p2, barMs, flow) {
  const top = p2.side === "top", dir = top ? -1 : 1;
  const c = ctx.cs[p2.second], confirm = ctx.cs[p2.idx], atr = Math.max(ctx.atr[p2.idx] || 0, 1e-9);
  const test = takerObservation(ctx, flow, p2.second), confirmation = takerObservation(ctx, flow, p2.idx);
  const firstLeg = legFlow(ctx, flow, p2.firstLegStart, p2.first, barMs);
  const secondLeg = legFlow(ctx, flow, p2.secondLegStart, p2.second, barMs);
  const v1 = unitVolume(ctx, p2.firstLegStart, p2.first), v2 = unitVolume(ctx, p2.secondLegStart, p2.second);
  const secondRatio = v1 > 0 && v2 > 0 ? v2 / v1 : null;
  const range = Math.max(c.h - c.l, 1e-9), closePos = (c.c - c.l) / range;
  const wickRatio = top ? (c.h - Math.max(c.o, c.c)) / range : (Math.min(c.o, c.c) - c.l) / range;
  const sweepAtr = Math.max(0, (top ? c.h - p2.level : p2.level - c.l) / atr);
  const closedInside = top ? confirm.c < p2.level : confirm.c > p2.level;
  const testVolume = volumeRatio(ctx, p2.second), confirmVolume = volumeRatio(ctx, p2.idx);
  const absorbed = !!test && (testVolume ?? 0) >= 2 && test.ratio * dir <= -0.15 && (top ? closePos <= 0.45 && c.c <= c.o : closePos >= 0.55 && c.c >= c.o);
  const cvdRatio = realCvdBetween(ctx, flow, p2.first, p2.second, barMs);
  let stance = "\u672A\u5B8C\u6574\u8986\u76D6\uFF0C\u4E0D\u5224\u65AD\u4E3B\u52A8\u65B9\u5411";
  if (test && confirmation) {
    const t = test.ratio * dir, k = confirmation.ratio * dir;
    stance = t >= 0.06 && k >= 0.06 ? "\u53CD\u8F6C\u4FA7\u4E3B\u52A8\u6210\u4EA4\u5360\u4F18" : t <= -0.12 && (k >= 0.04 || sweepAtr >= 0.05 && closedInside) ? "\u63A8\u8FDB\u4FA7\u6210\u4EA4\u672A\u80FD\u7AD9\u7A33" : t <= -0.06 && k <= -0.06 ? "\u63A8\u8FDB\u4FA7\u4E3B\u52A8\u6210\u4EA4\u5360\u4F18" : Math.abs(t) >= 0.02 && Math.abs(k) >= 0.02 && Math.sign(t) !== Math.sign(k) ? "\u6D4B\u8BD5\u4E0E\u786E\u8BA4\u65B9\u5411\u5206\u6B67" : "\u4E3B\u52A8\u6210\u4EA4\u63A5\u8FD1\u4E2D\u6027";
  } else if (test || confirmation) stance = test ? "\u4EC5\u6D4B\u8BD5K\u6709\u771F\u5B9E\u8986\u76D6" : "\u4EC5\u786E\u8BA4K\u6709\u771F\u5B9E\u8986\u76D6";
  const positive = [], negative = [], missing = [];
  if (secondRatio === null) missing.push("\u63A8\u8FDB\u817F\u91CF\u6BD4\u7F3A\u5931");
  else if (secondRatio <= 0.9) positive.push("\u7B2C\u4E8C\u817F\u7F29\u91CF");
  else if (secondRatio > 1.1) negative.push("\u7B2C\u4E8C\u817F\u653E\u91CF\uFF0C\u66F4\u50CF\u5EF6\u7EED");
  if (wickRatio >= 0.35) positive.push("\u5173\u952E\u4F4D\u62D2\u7EDD\u5F71\u7EBF");
  if (sweepAtr >= 0.05 && closedInside) positive.push("\u4EF7\u683C\u626B\u4F4D\u6536\u56DE");
  if ((confirmVolume ?? 0) >= 1.5) positive.push("\u786E\u8BA4K\u653E\u91CF");
  if (test && confirmation) {
    if (test.ratio * dir >= 0.06 && confirmation.ratio * dir >= -0.02) positive.push("\u771F\u5B9E\u6210\u4EA4\u652F\u6301\u53CD\u8F6C\u65B9\u5411");
    if (test.ratio * dir <= -0.12 && confirmation.ratio * dir <= -0.12) negative.push("\u771F\u5B9E\u6210\u4EA4\u4ECD\u504F\u7A81\u7834\u4FA7");
  } else missing.push("\u6D4B\u8BD5/\u786E\u8BA4K\u6210\u4EA4\u8986\u76D6\u4E0D\u5168");
  if (absorbed) positive.push("\u653E\u91CF\u63A8\u8FDB\u4F46\u4EF7\u683C\u672A\u8DDF\u968F\uFF08\u5438\u6536\u5019\u9009\uFF09");
  const score = positive.length - negative.length;
  const label = negative.length && positive.length ? "\u5206\u6B67" : score >= 3 ? "\u8F83\u5F3A" : score >= 1 ? "\u4E00\u822C" : "\u4E0D\u8DB3";
  return {
    test,
    confirmation,
    firstLeg,
    secondLeg,
    secondRatio,
    testVolume,
    confirmVolume,
    wickRatio,
    sweepAtr,
    closedInside,
    absorbed,
    cvdRatio,
    cvdDivergence: cvdRatio !== null && cvdRatio * dir >= 0.04,
    stance,
    strength: { score, label, positive, negative, missing }
  };
}

// src/vela/signals/scenario.ts
var BREAK_ATR = 0.2;
var RETEST_WINDOW = 48;
var RECLAIM_WINDOW = 12;
var MW_VOLUME = { breakout: 1.5, weakBreak: 1.2, contract: 0.9, deepRetest: 0.618 };
function evaluateLine(ctx, barMs, price2, dir, startIdx, kind, flow) {
  const { cs, atr, n } = ctx;
  if (startIdx < 0 || startIdx >= n - 1 || !(barMs > 0)) return null;
  const a = (i) => Math.max(atr[i] || 0, 1e-9);
  const beyond = (i) => i >= 0 && dir * (cs[i].c - price2) > BREAK_ATR * a(i);
  const inside = (i) => dir * (cs[i].c - price2) < -BREAK_ATR * a(i);
  const events = [];
  let latest = null, pending = -1;
  const emit = (r, event, i) => {
    events.push({ kind: event, idx: i, at: cs[i].ts + barMs });
    r.lastEventIdx = i;
  };
  const make = (i, acceptedAt) => {
    const anchor = acceptedAt >= 0 ? acceptedAt : i;
    const tol = Math.max(annotationTolerance(price2, a(anchor)), 0.15 * a(anchor));
    const w = acceptedAt >= 0 ? legFlow(ctx, flow, i, acceptedAt, barMs) : null;
    return {
      kind,
      price: price2,
      dir,
      state: acceptedAt >= 0 ? "broken" : "pending",
      firstBreak: i,
      acceptedAt,
      reachedIdx: -1,
      retestConfirmedAt: -1,
      failedAt: -1,
      expiredAt: -1,
      lastEventIdx: anchor,
      flowComplete: !!w?.complete,
      flowAligned: w?.ratio != null && w.ratio * dir >= 0.04,
      flowRatio: w?.ratio ?? null,
      waited: 0,
      distAtr: 0,
      lo: price2 - tol,
      hi: price2 + tol,
      events
    };
  };
  for (let i = startIdx + 1; i < n; i++) {
    if (cs[i].ts - cs[i - 1].ts !== barMs) {
      pending = -1;
      if (latest && !["expired", "failed"].includes(latest.state)) {
        latest.state = "expired";
        latest.expiredAt = i;
        emit(latest, "expired", i);
      }
      continue;
    }
    const active = latest && !["expired", "failed", "pending"].includes(latest.state);
    if (active && latest) {
      const r = latest;
      r.waited = i - r.acceptedAt;
      if (inside(i)) {
        r.state = "failed";
        r.failedAt = i;
        emit(r, "failed", i);
        continue;
      }
      if (r.reachedIdx < 0 && cs[i].h >= r.lo && cs[i].l <= r.hi) {
        r.reachedIdx = i;
        emit(r, "touch", i);
      }
      if (r.reachedIdx < 0 && r.waited >= RETEST_WINDOW || r.reachedIdx >= 0 && i - r.reachedIdx > RECLAIM_WINDOW) {
        r.state = "expired";
        r.expiredAt = i;
        emit(r, "expired", i);
        continue;
      }
      if (r.reachedIdx >= 0) {
        const old = r.state;
        if (!beyond(i)) r.state = "touch";
        else {
          r.state = "retest";
          if (r.retestConfirmedAt < 0) {
            r.retestConfirmedAt = i;
            emit(r, "held", i);
          }
          if (i > r.retestConfirmedAt && dir * (cs[i].c - price2) > (r.hi - r.lo) / 2 + 0.4 * a(i)) r.state = "continued";
          if (r.state === "continued" && old !== "continued") emit(r, "continued", i);
        }
      }
      r.distAtr = cs[i].c < r.lo ? (r.lo - cs[i].c) / a(i) : cs[i].c > r.hi ? (cs[i].c - r.hi) / a(i) : 0;
      continue;
    }
    if (pending === i - 1 && beyond(i)) {
      latest = make(pending, i);
      emit(latest, "accepted", i);
      pending = -1;
      continue;
    }
    pending = -1;
    if (beyond(i) && (i === startIdx + 1 || !beyond(i - 1))) {
      pending = i;
      events.push({ kind: "crossing", idx: i, at: cs[i].ts + barMs });
    }
  }
  if (pending === n - 1) return make(pending, -1);
  return latest;
}

// src/vela/signals/mwStory.ts
var price = (v) => v.toLocaleString("en-US", { minimumFractionDigits: decimalsFor(v), maximumFractionDigits: decimalsFor(v) });
var time = (ts) => new Date(ts).toISOString().slice(5, 16).replace("T", " ") + " UTC";
var ratio = (v) => v == null ? "\u65E0\u6570\u636E" : `${v.toFixed(2)}\xD7`;
var samePattern = (a, b) => a.side === b.side && a.first === b.first && a.second === b.second && a.idx === b.idx;
function groupMwPatterns(patterns, ctx) {
  const groups = [];
  for (const p2 of [...patterns].sort((a, b) => a.idx - b.idx || a.first - b.first)) {
    if (!ctx.cs[p2.idx] || !ctx.cs[p2.first] || !ctx.cs[p2.second] || !ctx.cs[p2.neckIdx]) continue;
    const match = groups.find((g) => {
      const q = g[g.length - 1];
      const atr = Math.max(ctx.atr[p2.idx] || 0, ctx.atr[q.idx] || 0, 1e-9);
      const overlaps = Math.max(p2.first, q.first) <= Math.min(p2.idx, q.idx);
      return q.side === p2.side && overlaps && (Math.abs(p2.level - q.level) <= atr || Math.abs(p2.neck - q.neck) <= Math.max(annotationTolerance(p2.neck, atr), annotationTolerance(q.neck, atr)));
    });
    if (!match) groups.push([p2]);
    else if (!match.some((q) => samePattern(q, p2))) match.push(p2);
  }
  return groups;
}
function trapAt(input, e, level) {
  const { pattern: p2, ctx, flow, barMs } = input;
  const top = p2.side === "top", dir = top ? -1 : 1, last = ctx.n - 1;
  let idx = p2.idx, form = "test-sweep", supported = false;
  if (level?.state === "failed" && level.failedAt >= 0) {
    idx = level.failedAt;
    form = "failed-break";
    const reclaim = takerObservation(ctx, flow, idx);
    supported = level.flowComplete && !!reclaim && reclaim.ratio * dir >= 0.04;
  } else if (e.sweepAtr >= 0.05 && e.closedInside) {
    const t = e.test?.ratio, c = e.confirmation?.ratio;
    supported = t != null && c != null && (t * dir >= 0.06 && c * dir >= -0.02 || t * dir <= -0.12 && (e.testVolume ?? 0) >= 1.3 && (p2.second === p2.idx || c * dir >= 0.04));
  } else return null;
  const label = supported ? top ? "\u8BF1\u591A\u5019\u9009" : "\u8BF1\u7A7A\u5019\u9009" : form === "failed-break" ? top ? "\u5047\u7A81\u7834\uFF08\u4EC5\u4EF7\u683C\uFF09" : "\u5047\u8DCC\u7834\uFF08\u4EC5\u4EF7\u683C\uFF09" : top ? "\u626B\u9AD8\u6536\u56DE\uFF08\u4EC5\u4EF7\u683C\uFF09" : "\u626B\u4F4E\u6536\u56DE\uFF08\u4EC5\u4EF7\u683C\uFF09";
  return {
    kind: top ? "bull" : "bear",
    form,
    source: supported ? "real" : "price",
    at: ctx.cs[idx].ts + barMs,
    barTs: ctx.cs[idx].ts,
    active: last - idx <= RECLAIM_WINDOW,
    label
  };
}
function analyzeMwStory(input) {
  const { pattern: p2, ctx, flow, barMs, livePrice, members = [p2] } = input;
  const { cs, atr } = ctx, last = ctx.n - 1;
  const top = p2.side === "top", rev = top ? -1 : 1, name = top ? "\u53CC\u9876" : "\u53CC\u5E95";
  const a = Math.max(atr[p2.idx] || 0, 1e-9), aNow = Math.max(atr[last] || a, 1e-9);
  const anchorFirst = Math.min(...members.map((m) => m.first));
  const id = `mw:${p2.side}:${cs[anchorFirst].ts}`;
  const e = readMwEvidence(ctx, p2, barMs, flow);
  const level = evaluateLine(ctx, barMs, p2.level, top ? 1 : -1, p2.idx, "level", flow);
  const neck = evaluateLine(ctx, barMs, p2.neck, rev, p2.idx, "neck", flow);
  const trap = trapAt(input, e, level);
  const validReads = [neck, level].filter((r) => r !== null);
  const line = validReads.sort((x, y) => y.lastEventIdx - x.lastEventIdx || (x.kind === "neck" ? -1 : 1))[0] ?? null;
  const liveStates = ["broken", "touch", "retest", "continued"];
  const invalidated = !!level && level.acceptedAt >= 0 && level.state !== "failed" && (liveStates.includes(level.state) || level.state === "expired" && (top ? cs[last].c > p2.level : cs[last].c < p2.level));
  let phase = "no-break", label = "\u4E8C\u6B21\u6D4B\u8BD5\xB7\u5F85\u7A81\u7834", bias = null;
  let activityIdx = p2.idx, priority = 1;
  let breakVolume = null, retestVolume = null, retestDepth = null;
  const pathLines = [];
  const side = (dir) => dir > 0 ? "long" : "short";
  if (line) {
    activityIdx = Math.max(activityIdx, line.lastEventIdx);
    const up = line.dir > 0, atLine = line.kind === "neck" ? "\u9888\u7EBF" : top ? "\u963B\u529B" : "\u652F\u6491";
    const back = up ? "\u56DE\u8E29" : "\u53CD\u62BD";
    breakVolume = line.acceptedAt >= 0 ? volumeRatio(ctx, line.acceptedAt) : null;
    const rIdx = line.retestConfirmedAt >= 0 ? line.retestConfirmedAt : line.reachedIdx;
    if (rIdx >= 0 && line.acceptedAt >= 0) {
      retestVolume = cs[line.acceptedAt].v > 0 ? cs[rIdx].v / cs[line.acceptedAt].v : null;
      let extreme = line.price;
      for (let i = line.acceptedAt; i <= line.reachedIdx; i++) extreme = up ? Math.max(extreme, cs[i].h) : Math.min(extreme, cs[i].l);
      const span = Math.max(Math.abs(extreme - line.price), 1.5 * Math.max(atr[line.acceptedAt] || a, 1e-9));
      retestDepth = Math.max(0, Math.min(1, line.dir * (extreme - cs[rIdx].c) / span));
    }
    if (line.kind === "level" && invalidated) pathLines.push(`\u539F${name}\u65B9\u5411\u5DF2\u88AB\u5173\u952E\u4F4D\u7A81\u7834\u5426\u5B9A\uFF1B\u6B64\u5904\u8DDF\u8E2A${up ? "\u5411\u4E0A" : "\u5411\u4E0B"}\u7A81\u7834\u7684${back}\uFF0C\u4E0D\u662F\u539F\u5F62\u6001\u7EE7\u7EED\u6210\u7ACB\u3002`);
    if (line.acceptedAt >= 0) {
      pathLines.push(`${time(cs[line.acceptedAt].ts + barMs)} \u4E24\u6839\u8FDE\u7EED\u6536\u76D8${up ? "\u4E0A\u7834" : "\u4E0B\u7834"}${atLine} ${price(line.price)}\uFF1B\u786E\u8BA4K\u91CF\u6BD4 ${ratio(breakVolume)}\u3002`);
      pathLines.push(line.flowComplete && line.flowRatio !== null ? `\u4E24\u6839\u786E\u8BA4K\u5408\u8BA1\u771F\u5B9E \u0394 ${pct2(line.flowRatio)}\uFF08\u6309\u771F\u5B9E\u4E70\u5356\u603B\u989D\u8BA1\u7B97\uFF09\uFF0C${line.flowAligned ? "\u4E0E\u7A81\u7834\u540C\u5411" : "\u672A\u540C\u5411"}\uFF1B\u4E0D\u662F\u8BA2\u5355\u7C3F OFI\u3002` : "\u4E24\u6839\u786E\u8BA4K\u6210\u4EA4\u8986\u76D6\u4E0D\u5168\uFF1A\u53EA\u786E\u8BA4\u4EF7\u683C\u7A81\u7834\uFF0C\u4E0D\u58F0\u79F0\u6210\u4EA4\u540C\u5411\u3002");
    }
    if (line.state === "pending") {
      phase = "break-pending";
      label = `${up ? "\u4E0A\u7834" : "\u4E0B\u7834"}\u5F85\u7B2C\u4E8C\u6839`;
      priority = 3;
      pathLines.push(`${time(cs[line.firstBreak].ts + barMs)} \u4EC5\u4E00\u6839\u6536\u76D8\u8D8A\u8FC7${atLine}\uFF1B\u7B49\u5F85\u7B2C\u4E8C\u6839\uFF0C\u76D8\u4E2D\u8D8A\u4F4D\u4E0D\u7B97\u786E\u8BA4\u3002`);
    } else if (line.state === "expired") {
      phase = "expired";
      label = "\u89C2\u5BDF\u7A97\u7ED3\u675F";
      priority = -1;
      pathLines.push("\u8BE5\u7A81\u7834\u5DF2\u8D85\u8FC7\u89C2\u5BDF\u7A97\uFF1B\u4FDD\u7559\u5386\u53F2\u8BC1\u636E\uFF0C\u4E0D\u5EF6\u4F38\u65E7\u533A\u5E26\uFF0C\u4E0D\u628A\u4E00\u76F4\u5728\u4F4D\u5916\u5F53\u6210\u65B0\u7A81\u7834\u3002");
    } else if (line.state === "failed") {
      phase = line.kind === "level" ? "sweep-level" : "break-failed";
      label = line.kind === "level" ? trap?.label ?? "\u5173\u952E\u4F4D\u6536\u56DE" : up ? "\u4E0A\u7834\u5931\u8D25\xB7\u5356\u5411\u5019\u9009" : "\u4E0B\u7834\u5931\u8D25\xB7\u4E70\u5411\u5019\u9009";
      bias = side(-line.dir);
      priority = last - line.failedAt <= RECLAIM_WINDOW ? 3 : -1;
      pathLines.push(`${time(cs[line.failedAt].ts + barMs)} \u6536\u76D8\u91CD\u56DE${atLine}${up ? "\u4E0B" : "\u4E0A"}\u65B9\uFF0C\u539F\u7A81\u7834\u5DF2\u5931\u8D25\uFF1B\u53CD\u5411\u4EC5\u4E3A\u5019\u9009\u3002`);
    } else {
      const strong = (breakVolume ?? 0) >= MW_VOLUME.breakout;
      const supported = strong || (breakVolume ?? 0) >= MW_VOLUME.weakBreak && line.flowAligned;
      if (!supported) {
        phase = "break-weak";
        label = (breakVolume ?? 0) < MW_VOLUME.weakBreak ? `${up ? "\u7F29\u91CF\u4E0A\u7834" : "\u7F29\u91CF\u4E0B\u7834"}\xB7\u89C2\u671B` : "\u7A81\u7834\u8BC1\u636E\u4E0D\u8DB3";
        priority = 2;
      } else if (line.reachedIdx < 0) {
        phase = "break-wait";
        label = `${strong ? "\u653E\u91CF\u7834\u4F4D" : "\u7834\u4F4D"}\xB7\u7B49${back}`;
        bias = side(line.dir);
        priority = 4;
      } else {
        const held = ["retest", "continued"].includes(line.state) && line.retestConfirmedAt >= 0;
        const quality = retestDepth !== null && retestDepth <= MW_VOLUME.deepRetest && retestVolume !== null && retestVolume <= MW_VOLUME.contract;
        if (held && quality) {
          phase = "break-held";
          label = up ? "\u56DE\u8E29\u5B88\u4F4F\xB7\u4E70\u5411" : "\u53CD\u62BD\u53D7\u963B\xB7\u5356\u5411";
          bias = side(line.dir);
          priority = 5;
        } else {
          phase = "break-retest";
          label = `${back}\u4E2D\xB7\u5F85\u786E\u8BA4`;
          priority = 3;
        }
      }
      if (line.reachedIdx < 0) {
        pathLines.push(`${back}\u5E26 ${price(line.lo)}\u2013${price(line.hi)}\uFF1B\u5DF2\u7B49 ${line.waited}/${RETEST_WINDOW} \u6839\uFF0C\u8DDD\u5E26 ${line.distAtr.toFixed(2)} ATR\u3002`);
        pathLines.push("\u5C1A\u672A\u56DE\u5230\u533A\u5E26\uFF1B\u4E0D\u80FD\u636E\u6B64\u5224\u65AD\u4E00\u5B9A\u4F1A\u56DE\u8E29\uFF0C\u4E5F\u4E0D\u80FD\u9884\u6D4B\u5230\u8FBE\u65F6\u95F4\uFF0C\u4E0D\u8FFD\u7A81\u7834\u3002");
      } else {
        pathLines.push(`${time(cs[line.reachedIdx].ts + barMs)} \u9996\u6B21\u89E6\u53CA${back}\u5E26 ${price(line.lo)}\u2013${price(line.hi)}\u3002`);
        pathLines.push(line.retestConfirmedAt < 0 ? "\u53EA\u662F\u89E6\u53CA\u533A\u5E26\uFF0C\u5C1A\u65E0\u6536\u76D8\u91CD\u65B0\u5B88\u5728\u7A81\u7834\u4FA7\u7684\u786E\u8BA4\u3002" : `${time(cs[line.retestConfirmedAt].ts + barMs)} \u6536\u76D8\u5B88\u5728\u7A81\u7834\u4FA7\uFF1B\u56DE\u64A4 ${retestDepth == null ? "\u65E0\u6570\u636E" : `${(retestDepth * 100).toFixed(1)}%`}\uFF0C\u56DE\u8E29\u91CF ${ratio(retestVolume)} \u7A81\u7834\u91CF\u3002`);
        pathLines.push("\u56DE\u8E29\u8D28\u91CF\u95E8\u69DB\uFF1A\u56DE\u64A4 \u226461.8%\u3001\u91CF \u22640.9\xD7 \u7A81\u7834\u786E\u8BA4K\uFF1B\u4E0D\u6EE1\u8DB3\u53EA\u663E\u793A\u5F85\u786E\u8BA4\u3002");
        pathLines.push(observationText("\u56DE\u8E29\u786E\u8BA4K", line.retestConfirmedAt >= 0 ? takerObservation(ctx, flow, line.retestConfirmedAt) : null));
      }
    }
  } else {
    pathLines.push(`\u9888\u7EBF ${price(p2.neck)} \u5C1A\u672A\u5F62\u6210\u4E24\u6839\u6536\u76D8${top ? "\u4E0B\u7834" : "\u4E0A\u7834"}\uFF1B\u4E8C\u6B21\u6D4B\u8BD5\u4E0D\u662F\u5DF2\u5B8C\u6210\u53CD\u8F6C\u3002`);
  }
  if (!line || line.state === "failed" && line.kind === "level") {
    if (trap?.active) {
      phase = "sweep-level";
      label = trap.label;
      bias = side(rev);
      priority = 3;
      activityIdx = Math.max(activityIdx, ctx.index.get(trap.barTs) ?? p2.idx);
    } else if (!line) {
      if ((e.secondRatio ?? 0) > 1.1 || e.strength.label === "\u5206\u6B67") label = "\u4E8C\u6D4B\u529B\u91CF\u5206\u6B67";
      else if (e.strength.score >= 1) {
        bias = side(rev);
        label = top ? "\u4E8C\u6D4B\u62D2\u7EDD\xB7\u5356\u5411\u5019\u9009" : "\u4E8C\u6D4B\u62D2\u7EDD\xB7\u4E70\u5411\u5019\u9009";
      } else label = "\u4E8C\u6D4B\u8BC1\u636E\u4E0D\u8DB3";
      if (last - p2.idx > 96) {
        phase = "expired";
        label = "\u5386\u53F2\u4E8C\u6B21\u6D4B\u8BD5";
        priority = -1;
        bias = null;
      }
    }
  }
  const extension = 2 * p2.neck - p2.level;
  const firstTouch = cs.findIndex((c, i) => i > p2.idx && (rev > 0 ? c.h >= p2.neck : c.l <= p2.neck));
  let extensionIdx = -1;
  if (extension > 0 && neck && neck.acceptedAt >= 0) {
    const end = Math.min(last, neck.failedAt >= 0 ? neck.failedAt - 1 : last, level?.acceptedAt != null && level.acceptedAt > neck.acceptedAt ? level.acceptedAt - 1 : last);
    for (let i = neck.acceptedAt + 1; i <= end; i++) {
      if (rev > 0 ? cs[i].h >= extension : cs[i].l <= extension) {
        extensionIdx = i;
        break;
      }
    }
  }
  if (extensionIdx >= 0 && !invalidated && !(neck?.state === "failed" && neck.failedAt > extensionIdx) && phase !== "expired") {
    phase = "target-reached";
    label = "\u5EF6\u4F38\u4F4D\u5DF2\u5230\xB7\u4E0D\u8FFD";
    priority = 0;
    bias = null;
    activityIdx = Math.max(activityIdx, extensionIdx);
  }
  const endActivity = cs[activityIdx].ts + barMs;
  const active = priority >= 0 && last - activityIdx <= 96;
  const targets = {
    first: p2.neck,
    extension: extension > 0 ? extension : null,
    firstTouchAt: firstTouch >= 0 ? cs[firstTouch].ts + barMs : null,
    extensionTouchAt: extensionIdx >= 0 ? cs[extensionIdx].ts + barMs : null,
    suspended: invalidated
  };
  const focus = line?.price ?? p2.level;
  const distanceAtr = Math.abs(cs[last].c - focus) / aNow;
  const testCount = (/* @__PURE__ */ new Set([cs[anchorFirst].ts, ...members.map((m) => cs[m.second].ts)])).size;
  const timeline = [
    ...[...new Map(members.map((m) => [cs[m.idx].ts, m])).values()].map((m, k) => ({ id: `${id}:confirm:${cs[m.idx].ts}`, at: cs[m.idx].ts + barMs, barTs: cs[m.idx].ts, label: `${name}\u7B2C${k + 2}\u6B21\u5DF2\u8BC6\u522B\u6D4B\u8BD5\u6536\u76D8\u786E\u8BA4` })),
    ...validReads.flatMap((r) => r.events.map((v) => ({
      id: `${id}:${r.kind}:${v.kind}:${v.idx}`,
      at: v.at,
      barTs: cs[v.idx].ts,
      label: `${r.kind === "neck" ? "\u9888\u7EBF" : "\u5173\u952E\u4F4D"} \xB7 ${{ crossing: "\u9996\u6839\u8D8A\u4F4D", accepted: "\u4E24\u6839\u6536\u76D8\u7834\u4F4D", touch: "\u9996\u6B21\u89E6\u5E26", held: "\u6536\u76D8\u5B88\u5728\u7A81\u7834\u4FA7", continued: "\u79BB\u5E26\u5EF6\u7EED", failed: "\u6536\u76D8\u6536\u56DE\uFF0C\u7A81\u7834\u5931\u8D25", expired: "\u89C2\u5BDF\u7A97\u7ED3\u675F" }[v.kind]}`
    })))
  ];
  if (extensionIdx >= 0) timeline.push({ id: `${id}:target`, at: cs[extensionIdx].ts + barMs, barTs: cs[extensionIdx].ts, label: "\u5EF6\u4F38\u53C2\u8003\u4F4D\u89E6\u8FBE\uFF08\u4E0D\u7B49\u4E8E\u5DF2\u76C8\u5229\uFF09" });
  timeline.sort((x, y) => x.at - y.at || x.id.localeCompare(y.id));
  let preview = null;
  if (livePrice != null && Number.isFinite(livePrice)) {
    const nearNeck = line ? line.kind === "neck" : rev * (livePrice - p2.neck) > 0 || Math.abs(livePrice - p2.neck) < Math.abs(livePrice - p2.level);
    const atLine = nearNeck ? "\u9888\u7EBF" : "\u5173\u952E\u4F4D";
    const reference = line?.price ?? (nearNeck ? p2.neck : p2.level);
    const tol2 = line ? (line.hi - line.lo) / 2 : annotationTolerance(reference, aNow);
    const status = Math.abs(livePrice - reference) <= tol2 ? "\u5DF2\u89E6\u53CA\u89C2\u5BDF\u5E26" : `\u5728\u4F4D${livePrice > reference ? "\u4E0A" : "\u4E0B"}\u65B9`;
    preview = `\u76D8\u4E2D ${price(livePrice)} \xB7 ${atLine} ${price(reference)} ${status}\uFF0C\u8DDD\u79BB ${(Math.abs(livePrice - reference) / aNow).toFixed(2)} ATR\u3002\u5F85\u6536\u76D8\uFF0C\u4E0D\u6539\u53D8\u5DF2\u786E\u8BA4\u9636\u6BB5\u3002`;
  }
  const flows = p2.second === p2.idx ? [observationText("\u6D4B\u8BD5/\u786E\u8BA4K\uFF08\u540C\u4E00\u6839\uFF09", e.test)] : [observationText("\u6D4B\u8BD5K", e.test), observationText("\u786E\u8BA4K", e.confirmation)];
  if (e.firstLeg.ratio !== null && e.secondLeg.ratio !== null) {
    const push = top ? 1 : -1, diff = (e.secondLeg.ratio - e.firstLeg.ratio) * push;
    flows.push(`\u63A8\u8FDB\u817F\u771F\u5B9E\u6210\u4EA4\uFF1A\u7B2C\u4E00\u817F \u0394 ${pct2(e.firstLeg.ratio * push)} \u2192 \u7B2C\u4E8C\u817F \u0394 ${pct2(e.secondLeg.ratio * push)}\uFF1B\u7B2C\u4E8C\u817F${diff < -0.02 ? "\u5F31\u4E8E" : diff > 0.02 ? "\u5F3A\u4E8E" : "\u63A5\u8FD1"}\u7B2C\u4E00\u817F\uFF0C\u76F8\u5DEE ${(Math.abs(diff) * 100).toFixed(1)} \u4E2A\u767E\u5206\u70B9\u3002`);
  } else flows.push(`\u63A8\u8FDB\u817F\u6BD4\u8F83\uFF1A\u8986\u76D6\u4E0D\u8DB3\uFF08\u7B2C\u4E00\u817F ${e.firstLeg.covered}/${e.firstLeg.bars} \u6839\u3001\u7B2C\u4E8C\u817F ${e.secondLeg.covered}/${e.secondLeg.bars} \u6839\uFF09\uFF0C\u4E0D\u62FC\u63A5\u8FD1\u4F3C\u6210\u4EA4\u3002`);
  flows.push(e.cvdRatio === null ? "CVD\uFF1A\u4E24\u6B21\u6D4B\u8BD5\u4E4B\u95F4\u7F3A\u5C11\u8FDE\u7EED\u771F\u5B9E\u8986\u76D6\uFF0C\u4E0D\u8BA1\u7B97\u80CC\u79BB\u3002" : `\u8FDE\u7EED\u771F\u5B9E CVD \u53D8\u5316 / \u540C\u671F\u6210\u4EA4\u989D ${pct2(e.cvdRatio)}\uFF1B${e.cvdDivergence ? "\u4E0E\u4EF7\u683C\u4E8C\u6B21\u6D4B\u8BD5\u80CC\u79BB" : "\u672A\u51FA\u73B0\u5BF9\u5E94\u65B9\u5411\u80CC\u79BB"}\u3002`);
  flows.push("taker \u4E3B\u52A8\u6210\u4EA4\u5DEE\u4E0D\u662F\u8BA2\u5355\u7C3F OFI\uFF0C\u65E0\u6CD5\u89C2\u5BDF\u5177\u4F53\u6B62\u635F\u5355\u3001\u6301\u4ED3\u8EAB\u4EFD\u6216\u88AB\u52A8\u6302\u5355\u3002");
  const biasLabel = bias === "long" ? "\u4E70\u5411\u5019\u9009" : bias === "short" ? "\u5356\u5411\u5019\u9009" : "\u89C2\u671B";
  const verdict = label + (bias ? label.includes(bias === "long" ? "\u4E70\u5411" : "\u5356\u5411") ? "" : ` \xB7 ${biasLabel}` : label.includes("\u89C2\u671B") ? "" : " \xB7 \u89C2\u671B");
  const sections = [
    { id: "conclusion", title: "\u5F53\u524D\u7ED3\u8BBA", lines: [verdict, `\u4F9D\u636E\u622A\u81F3 ${time(cs[last].ts + barMs)} \u7684\u5DF2\u6536\u76D8K\u7EBF\u3002\u5F62\u6001\u4E0E\u6210\u4EA4\u89C2\u5BDF\u4E0D\u662F\u6821\u51C6\u80DC\u7387\uFF0C\u4E5F\u4E0D\u6267\u884C\u4E0B\u5355\u3002`] },
    { id: "strength", title: "\u5173\u952E\u533A\u57DF\u529B\u91CF", lines: [
      `\u53CD\u8F6C\u8BC1\u636E${e.strength.label}\uFF1B\u89C4\u5219\u8BA1\u6570 ${e.strength.score}\uFF08\u4E0D\u662F\u6982\u7387\uFF09\uFF0C${testCount} \u6B21\u5DF2\u8BC6\u522B\u6D4B\u8BD5 / ${members.length} \u4E2A\u5F52\u5E76\u5F62\u6001\u3002`,
      `\u7B2C\u4E8C\u817F\u91CF ${ratio(e.secondRatio)} \u7B2C\u4E00\u817F\uFF1B\u6D4B\u8BD5K ${ratio(e.testVolume)} / \u786E\u8BA4K ${ratio(e.confirmVolume)} \u8FC7\u53BB20\u6839\u5747\u91CF\u3002`,
      `\u62D2\u7EDD\u5F71\u7EBF ${(e.wickRatio * 100).toFixed(1)}%\uFF1B\u626B\u4F4D ${e.sweepAtr.toFixed(2)} ATR\uFF1B${e.absorbed ? "\u771F\u5B9E\u6210\u4EA4\u653E\u91CF\u4F46\u4EF7\u683C\u672A\u8DDF\u968F\uFF08\u5438\u6536\u5019\u9009\uFF09" : "\u672A\u6EE1\u8DB3\u771F\u5B9E\u5438\u6536\u89C2\u5BDF\u6761\u4EF6"}\u3002`,
      `\u652F\u6301\uFF1A${e.strength.positive.join("\u3001") || "\u4E0D\u8DB3"}\uFF1B\u53CD\u8BC1\uFF1A${e.strength.negative.join("\u3001") || "\u672A\u89C1"}\uFF1B\u7F3A\u5931\uFF1A${e.strength.missing.join("\u3001") || "\u6D4B\u8BD5/\u786E\u8BA4\u6210\u4EA4\u9F50\u5168"}\u3002`
    ] },
    { id: "flow", title: "\u771F\u5B9E\u6210\u4EA4\u8BC1\u636E", lines: [e.stance, ...flows] },
    { id: "trap", title: "\u8BF1\u591A / \u8BF1\u7A7A", lines: trap ? [
      `${trap.label} \xB7 ${trap.form === "test-sweep" ? "\u6D4B\u8BD5\u626B\u4F4D\u578B" : "\u7834\u4F4D\u540E\u6536\u56DE\u578B"} \xB7 ${time(trap.at)}`,
      `${trap.active ? "\u6700\u8FD112\u6839\u5185\uFF0C\u4ECD\u5728\u89C2\u5BDF" : "\u5DF2\u8D85\u8FC712\u6839\uFF0C\u53EA\u4FDD\u7559\u5386\u53F2\u4E8B\u5B9E"}\uFF1B${trap.source === "real" ? "\u5C40\u90E8\u771F\u5B9E\u6210\u4EA4\u652F\u6301\u6536\u56DE\u65B9\u5411" : "\u53EA\u6709\u4EF7\u683C\u6536\u56DE\u4E8B\u5B9E\uFF0C\u6210\u4EA4\u672A\u63D0\u4F9B\u5B8C\u6574\u540C\u5411\u4F50\u8BC1"}\u3002`,
      "\u5019\u9009\u4E0D\u7B49\u4E8E\u89C2\u5BDF\u5230\u8FFD\u5355\u88AB\u5957\u6216\u771F\u5B9E\u6B62\u635F\uFF1B\u9888\u7EBF\u540E\u7EED\u4E8B\u4EF6\u53EF\u4EE5\u53D6\u4EE3\u5B83\u4F5C\u4E3A\u5F53\u524D\u9636\u6BB5\u3002"
    ] : ["\u672A\u51FA\u73B0\u7B26\u5408\u6761\u4EF6\u7684\u626B\u4F4D\u6216\u7834\u4F4D\u6536\u56DE\uFF1B\u4E0D\u5F3A\u884C\u5F52\u7C7B\u4E3A\u8BF1\u591A/\u8BF1\u7A7A\u3002"] },
    { id: "path", title: "\u7A81\u7834 \u2192 \u56DE\u8E29 / \u53CD\u62BD", lines: pathLines },
    { id: "targets", title: "\u53C2\u8003\u4F4D\u4E0E\u5931\u6548", lines: [
      `\u7B2C\u4E00\u53C2\u8003\u4F4D\uFF08\u9888\u7EBF\uFF09${price(p2.neck)}${firstTouch >= 0 ? `\uFF0C${time(targets.firstTouchAt)} \u5DF2\u89E6\u53CA` : "\uFF0C\u5C1A\u672A\u89E6\u53CA"}\uFF1B\u89E6\u53CA\u9888\u7EBF\u4E0D\u7B49\u4E8E\u5DF2\u5151\u73B0\u3002`,
      `\u5EF6\u4F38\u53C2\u8003\u4F4D ${targets.extension === null ? "\u65E0\u6709\u6548\u6B63\u4EF7\u683C" : price(targets.extension)}${targets.extensionTouchAt ? `\uFF0C${time(targets.extensionTouchAt)} \u5DF2\u89E6\u53CA` : "\uFF0C\u5C1A\u672A\u786E\u8BA4\u89E6\u8FBE"}\uFF1B\u4EF7\u683C\u89E6\u8FBE\u4E0D\u662F\u8D26\u6237\u5229\u6DA6\u3002`,
      invalidated ? "\u5916\u4FA7\u5173\u952E\u4F4D\u5DF2\u7834\uFF0C\u539F\u5F62\u6001\u7684\u65B9\u5411\u548C\u76EE\u6807\u53C2\u8003\u6682\u505C\uFF0C\u4E0D\u628A\u5B83\u5F53\u6210\u53CD\u8F6C\u4FE1\u53F7\u3002" : `\u539F\u5F62\u6001\u5931\u6548\u68C0\u67E5\uFF1A\u8FDE\u7EED\u4E24\u6839\u6536\u76D8${top ? "\u4E0A\u7834\u963B\u529B" : "\u4E0B\u7834\u652F\u6491"} ${price(p2.level)}\uFF0C\u6BCF\u6839\u8D85\u51FA ${BREAK_ATR} ATR\uFF1B\u5F53\u524D\u5BF9\u5E94\u7EA6 ${price(p2.level + (top ? 1 : -1) * BREAK_ATR * aNow)}\u3002`
    ] }
  ];
  const w = windowFlow(ctx, Math.max(0, p2.second - 6), p2.idx);
  const smcRead = readSmartMoney(ctx, { side: p2.side, idx: p2.idx, first: p2.first, second: p2.second, level: p2.level, neck: p2.neck }, w, w.known >= 0.95);
  const smc = { hits: smcRead.hits, source: smcRead.source, lines: smcRead.evidence.filter((v) => v.state === "hit").map((v) => v.label + "\uFF1A" + v.detail) };
  const tone = bias === "long" ? "long" : bias === "short" ? "short" : "warn";
  const shortDetails = [
    sections[0].lines[0],
    `\u53CD\u8F6C\u8BC1\u636E${e.strength.label} \xB7 ${e.stance}`,
    `\u5173\u952E\u4F4D ${price(p2.level)} / \u9888\u7EBF ${price(p2.neck)}`,
    pathLines.at(-1) ?? "",
    "\u5B8C\u6574\u529B\u91CF\u3001\u6210\u4EA4\u3001\u9677\u9631\u4E0E\u65F6\u95F4\u7EBF\u89C1\u4FA7\u680F\u300C\u53CC\u9876\u53CC\u5E95\u300D\u3002"
  ];
  const story = {
    phase,
    phaseLabel: label,
    bias,
    active,
    priority,
    side: p2.side,
    lineKind: line?.kind ?? null,
    invalidated,
    level: p2.level,
    neck: p2.neck,
    referenceAtr: a,
    distanceAtr,
    patternCount: members.length,
    testCount,
    origin: { firstTs: cs[p2.first].ts, secondTs: cs[p2.second].ts, confirmedAt: cs[p2.idx].ts + barMs, level: p2.level, neck: p2.neck },
    lastActivityAt: endActivity,
    evidence: e,
    trap,
    path: line,
    breakVolume,
    retestVolume,
    retestDepth,
    targets,
    sections,
    timeline,
    preview,
    smc
  };
  const bandAtr = a;
  const tol = Math.max(annotationTolerance(p2.level, bandAtr), 0.15 * bandAtr);
  const zlo = line?.lo ?? p2.level - tol, zhi = line?.hi ?? p2.level + tol;
  const zstart = line ? cs[line.firstBreak].ts : cs[p2.second].ts;
  const endTs = phase === "break-failed" || phase === "expired" || phase === "target-reached" ? cs[activityIdx].ts + barMs : cs[last].ts + barMs;
  return {
    id,
    type: top ? "doubleTop" : "doubleBottom",
    ts: cs[activityIdx].ts,
    fromTs: cs[anchorFirst].ts,
    price: p2.level,
    title: `${name} ${price(p2.level)} \xB7 ${label}`,
    detail: sections.flatMap((s) => [s.title, ...s.lines]),
    source: "price",
    confirmed: true,
    tone,
    story,
    event: {
      id: `${id}:event`,
      ts: cs[activityIdx].ts,
      side: (bias ?? side(rev)) === "long" ? "below" : "above",
      tone,
      text: `${top ? "M" : "W"} ${label}`,
      marker: "diamond",
      priority: 96,
      title: `${name} \xB7 ${label}`,
      detail: shortDetails
    },
    levels: [
      {
        id: `${id}:level`,
        fromTs: cs[anchorFirst].ts,
        toTs: active ? null : cs[activityIdx].ts,
        price: p2.level,
        tone,
        name: `${name} \xB7 ${label}`,
        style: "solid",
        rank: "read",
        priority: 98,
        label: true,
        detail: shortDetails
      },
      {
        id: `${id}:neck`,
        fromTs: cs[p2.first].ts,
        toTs: active ? null : cs[activityIdx].ts,
        price: p2.neck,
        tone: "neck",
        name: "\u9888\u7EBF",
        style: "dotted",
        rank: "normal",
        priority: 70,
        label: false,
        detail: shortDetails
      }
    ],
    ...phase === "expired" ? {} : { zone: {
      id: `${id}:zone`,
      fromTs: zstart,
      toTs: endTs,
      lo: zlo,
      hi: zhi,
      tone,
      text: `${line?.kind === "neck" ? "\u9888\u7EBF" : "\u5173\u952E\u4F4D"} \xB7 ${label}`,
      priority: 92,
      failed: phase === "break-failed",
      title: `${name} \xB7 ${label}`,
      detail: shortDetails
    } },
    path: { tone: top ? "short" : "long", points: [
      { ts: cs[p2.first].ts, price: p2.level },
      { ts: cs[p2.neckIdx].ts, price: p2.neck },
      { ts: cs[p2.second].ts, price: p2.secondPrice },
      ...p2.idx !== p2.second ? [{ ts: cs[p2.idx].ts, price: cs[p2.idx].c }] : []
    ] }
  };
}
function buildMwStories(input) {
  return groupMwPatterns(input.patterns, input.ctx).map((members) => analyzeMwStory({ ...input, pattern: members[members.length - 1], members }));
}
function selectMwStories(items, max = 3) {
  const ranked = items.filter((i) => i.story?.active && i.story.distanceAtr <= 12).sort((a, b) => b.story.priority - a.story.priority || b.story.lastActivityAt - a.story.lastActivityAt || a.story.distanceAtr - b.story.distanceAtr);
  const kept = [], directions = /* @__PURE__ */ new Set();
  for (const item of ranked) {
    const s = item.story, direction = s.bias ?? "wait";
    if (directions.has(direction)) continue;
    if (kept.some((k) => k.story.side === s.side && Math.abs(k.story.level - s.level) <= Math.max(k.story.referenceAtr, s.referenceAtr))) continue;
    kept.push(item);
    directions.add(direction);
    if (kept.length >= max) break;
  }
  return kept;
}

// src/vela/signals/store.ts
var SIGNAL_TYPES = [
  { id: "doubleTop", name: "\u53CC\u9876\u5224\u8BFB", group: "mw", flow: true, description: "\u4E00\u4E2A\u53CC\u9876\u4E00\u6761\u5B8C\u6574\u8BB0\u5F55\uFF1A\u5173\u952E\u4F4D\u529B\u91CF\u3001\u771F\u5B9E\u6210\u4EA4\u3001\u8BF1\u591A\u5019\u9009\u4E0E\u9888\u7EBF\u53CD\u62BD\u3002", rule: "\u53EA\u7528\u5DF2\u6536\u76D8K\u7EBF\uFF0C\u4FDD\u7559\u73B0\u6709\u4EF7\u683C\u5F62\u6001\u8BC6\u522B\u51E0\u4F55\u3002\u540C\u533A\u91CD\u53E0\u7ED3\u6784\u5F52\u5E76\uFF1B\u529B\u91CF\u662F\u8BC1\u636E\u8BA1\u6570\uFF0C\u4E0D\u662F\u80DC\u7387\u3002\u65E0\u771F\u5B9E\u6210\u4EA4\u8986\u76D6\u5C31\u660E\u786E\u7F3A\u5931\uFF0C\u4E0D\u7528OHLC\u8865\u9020\u4E3B\u52A8\u4E70\u5356\u3002" },
  { id: "doubleBottom", name: "\u53CC\u5E95\u5224\u8BFB", group: "mw", flow: true, description: "\u4E00\u4E2A\u53CC\u5E95\u4E00\u6761\u5B8C\u6574\u8BB0\u5F55\uFF1A\u5173\u952E\u4F4D\u529B\u91CF\u3001\u771F\u5B9E\u6210\u4EA4\u3001\u8BF1\u7A7A\u5019\u9009\u4E0E\u7A81\u7834\u56DE\u8E29\u3002", rule: "\u53CC\u9876\u7684\u955C\u50CF\u3002\u9996\u6839\u8D8A\u4F4D\u3001\u4E24\u6839\u6536\u76D8\u786E\u8BA4\u3001\u9996\u6B21\u89E6\u5E26\u3001\u6536\u76D8\u5B88\u4F4F\u548C\u5931\u8D25\u5206\u5F00\u8BB0\u65F6\uFF1B\u53EA\u89E6\u5E26\u4E0D\u7B49\u4E8E\u56DE\u8E29\u786E\u8BA4\u3002\u672A\u6536\u76D8\u4EF7\u683C\u53EA\u63D0\u4F9B\u72EC\u7ACB\u63D0\u793A\u3002" },
  { id: "keyLevelScenario", name: "\u7A81\u7834\u56DE\u8E29\u533A", group: "mw", flow: false, description: "\u663E\u793A\u540C\u4E00\u5F62\u6001\u7684\u5173\u952E\u4F4D/\u9888\u7EBF\u89C2\u5BDF\u5E26\uFF0C\u4E0D\u65B0\u589E\u4E00\u5F20\u4FE1\u53F7\u5361\u3002", rule: "\u4E24\u6839\u6536\u76D8\u8D8A\u8FC70.2 ATR\u786E\u8BA4\u4EF7\u683C\u7834\u4F4D\uFF1B\u653E\u91CF\u22651.5\xD7\u5747\u91CF\uFF0C\u6216\u91CF\u22651.2\xD7\u4E14\u771F\u5B9E\u6210\u4EA4\u540C\u5411\u3002\u56DE\u8E29\u6536\u76D8\u5B88\u4F4F\u3001\u56DE\u64A4\u226461.8%\u3001\u91CF\u22640.9\xD7\u624D\u5347\u7EA7\uFF1B\u6700\u591A\u4E24\u5757\u4E0D\u540C\u65B9\u5411\u533A\u5E26\u3002\u4E0D\u9884\u6D4B\u4E00\u5B9A\u4F1A\u56DE\u8E29\u6216\u5230\u8FBE\u65F6\u95F4\u3002" },
  { id: "keyLevels", name: "\u652F\u6491 / \u963B\u529B", group: "context", flow: true, description: "\u53EF\u9009\u76D8\u9762\u80CC\u666F\uFF0C\u9ED8\u8BA4\u5173\u95ED\uFF1B\u4E0D\u62A2\u53CC\u9876/\u53CC\u5E95\u7684\u4E3B\u8981\u6807\u7B7E\u3002", rule: "\u6700\u8FD1288\u6839\u4E2D\u672A\u7834\u7684\u6446\u52A8\u4F4D\uFF0C\u6309\u8DDD\u79BB\u9009\u62E9\u5E76\u53BB\u91CD\uFF0C\u6700\u591A6\u6761\u3002\u6700\u8FD1\u89E6\u78B0\u6709\u5B8C\u6574\u771F\u5B9E\u6210\u4EA4\u65F6\u9644\u5355\u6839\u89C2\u5BDF\uFF0C\u65E0\u8986\u76D6\u4E0D\u9020\u65B9\u5411\uFF1B\u4E0E\u4E3B\u5F62\u6001\u540C\u4EF7\u7EBF\u4E0D\u91CD\u590D\u7ED8\u5236\u3002" },
  { id: "retest", name: "\u5176\u4ED6\u7A81\u7834\u56DE\u8E29", group: "context", flow: true, description: "\u666E\u901A\u6446\u52A8\u4F4D\u7684\u4EF7\u683C\u56DE\u8E29\uFF0C\u72EC\u7ACB\u4E8E\u53CC\u9876/\u53CC\u5E95\u9888\u7EBF\uFF0C\u9ED8\u8BA4\u5173\u95ED\u3002", rule: "\u7B2C\u4E00\u6B21\u5B9E\u9645\u56DE\u8E29\u5E76\u6536\u76D8\u5B88\u4F4F\u624D\u6807\uFF0C\u65F6\u95F4\u662F\u786E\u8BA4\u90A3\u6839\uFF1B\u4EC5\u7A81\u7834K\u4E0E\u786E\u8BA4K\u90FD\u6709\u5B8C\u6574\u771F\u5B9E\u6210\u4EA4\u65F6\u9644\u4E24\u6839\u4F50\u8BC1\uFF0C\u4E0D\u80FD\u5192\u5145\u6574\u6BB5\u8FDE\u7EED\u8BA2\u5355\u6D41\u3002" },
  { id: "smartMoney", name: "\u7ED3\u6784\u8865\u5145", group: "context", flow: false, description: "\u5728\u53CC\u9876/\u53CC\u5E95\u8BE6\u60C5\u4E2D\u8865\u5145SMC\u7ED3\u6784\uFF0C\u4E0D\u518D\u989D\u5916\u751F\u6210\u591A\u5F20\u8BB0\u5F55\u3002", rule: "\u6CBF\u7528\u73B0\u6709\u806A\u660E\u94B1\u7ED3\u6784\u68C0\u6D4B\u3002\u547D\u4E2D\u8BA1\u6570\u53EA\u89E3\u91CA\u4EF7\u683C\u4E8B\u5B9E\uFF0C\u4E0D\u63A8\u65AD\u673A\u6784\u3001\u6B62\u635F\u6216\u76C8\u5229\uFF1B\u8BE5\u5F00\u5173\u53EA\u63A7\u5236\u9644\u52A0\u8BE6\u60C5\uFF0C\u4E0D\u5F71\u54CD\u4E3B\u5224\u8BFB\u3002" },
  { id: "deltaImpulse", name: "\u6210\u4EA4\u529B\u5EA6", group: "context", flow: true, description: "\u53EF\u9009\u76D8\u9762\u80CC\u666F\uFF0C\u9ED8\u8BA4\u5173\u95ED\uFF1B\u771F\u5B9E\u6210\u4EA4\u653E\u91CF\u65F6\u624D\u7ED9\u4E3B\u52A8\u65B9\u5411\u3002", rule: "\u4FDD\u7559\u65E2\u6709\u653E\u91CF\u3001\u4E3B\u52A8\u5DEE\u3001\u6536\u76D8\u4F4D\u7F6E\u89C2\u5BDF\uFF1B\u753B\u5E03\u6700\u591A4\u4E2A\u5DF2\u6536\u76D8\u6807\u7B7E\uFF0C\u5F62\u6210\u4E2D\u9884\u89C8\u5355\u72EC\u6807\u8BC6\u3002\u2248 \u4E3AOHLC\u4EE3\u7406\uFF0C\u7EDD\u4E0D\u7528\u4E8E\u53CC\u9876\u53CC\u5E95\u7684\u6210\u4EA4\u8BC1\u636E\u6216CVD\u3002" }
];
var DEFAULT_PREFERENCES = {
  enabled: true,
  selected: { doubleTop: true, doubleBottom: true, keyLevelScenario: true, keyLevels: false, retest: false, smartMoney: false, deltaImpulse: false },
  labels: true,
  geometry: true,
  allowApprox: false,
  preview: false,
  lookback: 600
};
var emptyCounts = () => Object.fromEntries(SIGNAL_TYPES.map((t) => [t.id, 0]));
var EMPTY_RUNTIME = { symbol: "", timeframe: "", status: "loading", message: "", bars: 0, requested: 600, gapTruncated: false, historyShort: false, covered: 0, flowSupported: true, flowConnected: false, flowSyncing: false, updatedAt: 0, counts: emptyCounts(), visible: [], total: 0 };
function emptySignalPayload() {
  return { events: [], levels: [], zones: [], paths: [], position: null, obstacles: [], decimals: 2, rev: 0 };
}

// src/vela/signals/analyze.ts
var priceText = (n) => n.toLocaleString("en-US", { minimumFractionDigits: decimalsFor(n), maximumFractionDigits: decimalsFor(n) });
var hhmmOf = (ts) => new Date(ts).toISOString().slice(5, 16).replace("T", " ") + " UTC";
function analyzeSignals(candles, barMs, preferences, flow, now = Date.now()) {
  if (!(barMs > 0) || !Number.isFinite(now)) return { items: [], covered: 0, bars: 0, requested: preferences.lookback, gapTruncated: false, historyShort: false, lastPrice: 0 };
  const valid = candles.filter(
    (c) => [c.ts, c.o, c.h, c.l, c.c, c.v].every(Number.isFinite) && c.ts <= now && c.v >= 0 && c.o > 0 && c.c > 0 && c.h >= Math.max(c.o, c.c) && c.l <= Math.min(c.o, c.c) && c.l > 0
  ).sort((a, b) => a.ts - b.ts);
  const chronological = [...new Map(valid.map((c) => [c.ts, c])).values()];
  const closed = chronological.filter((c) => c.ts + barMs <= now);
  let contiguousStart = closed.length ? closed.length - 1 : 0;
  while (contiguousStart > 0 && closed[contiguousStart].ts - closed[contiguousStart - 1].ts === barMs) contiguousStart--;
  const cs = closed.slice(contiguousStart).slice(-Math.max(1200, preferences.lookback + 900));
  const inScope = cs.slice(-preferences.lookback);
  const newest = chronological.at(-1);
  const lastPrice = newest?.c ?? 0;
  const forming = cs.length > 0 && newest && newest.ts === cs[cs.length - 1].ts + barMs && newest.ts + barMs > now ? newest : void 0;
  if (cs.length < 30) {
    const gapTruncated = contiguousStart > 0 && inScope.length < preferences.lookback;
    return {
      items: [],
      covered: 0,
      bars: inScope.length,
      requested: preferences.lookback,
      gapTruncated,
      historyShort: !gapTruncated && inScope.length < preferences.lookback,
      lastPrice
    };
  }
  const ctx = buildContext(cs, flow);
  const cutoff = inScope[0]?.ts ?? 0;
  const items = [];
  const patterns = scanAnnotationPatterns(ctx);
  const stories = buildMwStories({ patterns, ctx, flow, barMs, livePrice: preferences.preview ? forming?.c : void 0 });
  items.push(...stories.filter((i) => i.ts >= cutoff || (i.story?.origin.confirmedAt ?? 0) > cutoff));
  const current = cs.at(-1).c;
  const swings = findSwingLevels(ctx, { maxAge: 288 });
  const levelReach = Math.max(3 * (ctx.atr.at(-1) ?? 0), current * 0.012);
  const levelGap = Math.max(0.6 * (ctx.atr.at(-1) ?? 0), current * 2e-3);
  const levels = [];
  for (const lv of swings.filter((l) => l.breakIdx === null && ctx.n - 1 - l.idx <= 288 && Math.abs(l.price - current) <= levelReach).sort((a, b) => Math.abs(a.price - current) - Math.abs(b.price - current))) {
    if (levels.some((k) => k.side === lv.side && Math.abs(k.price - lv.price) <= levelGap)) continue;
    levels.push(lv);
    if (levels.length >= 6) break;
  }
  for (const lv of levels) {
    const top = lv.side === "top";
    const tone = top ? "top" : "bottom";
    const id = `level:${lv.side}:${lv.ts}`;
    const title = `${top ? "\u963B\u529B" : "\u652F\u6491"} ${priceText(lv.price)}`;
    const tested = patterns.some((p2) => p2.side === lv.side && p2.first === lv.idx);
    const detail = ["\u5DF2\u786E\u8BA4\u6446\u52A8\u5173\u952E\u4F4D \xB7 \u76EE\u524D\u672A\u89C1\u6536\u76D8\u7A81\u7834", tested ? "\u5DF2\u53D1\u751F\u4E8C\u6B21\u6D4B\u8BD5" : "\u7B49\u5F85\u4E8C\u6B21\u6D4B\u8BD5"];
    items.push({
      id,
      type: "keyLevels",
      ts: lv.ts,
      fromTs: lv.ts,
      price: lv.price,
      title,
      detail,
      source: "price",
      confirmed: true,
      tone,
      levels: [{ id, fromTs: lv.ts, toTs: null, price: lv.price, tone, style: "dashed", name: top ? "\u963B\u529B" : "\u652F\u6491", priority: 45, rank: "normal", label: true, detail }]
    });
    const tol = annotationTolerance(lv.price, ctx.atr.at(-1) ?? 0);
    let touchIdx = -1;
    if (tol > 0) {
      for (let q = ctx.n - 1; q > lv.idx; q--) {
        const c = ctx.cs[q];
        if (top ? c.h >= lv.price - tol : c.l <= lv.price + tol) {
          touchIdx = q;
          break;
        }
      }
    }
    const touchObs = touchIdx >= 0 ? takerObservation(ctx, flow, touchIdx) : null;
    if (touchObs) {
      const tc = ctx.cs[touchIdx];
      const ratio2 = touchObs.ratio;
      const range = Math.max(tc.h - tc.l, 1e-12);
      const closePos = (tc.c - tc.l) / range;
      const held = top ? tc.c < lv.price : tc.c > lv.price;
      const stalled = top ? ratio2 >= 0.12 && closePos <= 0.45 : ratio2 <= -0.12 && closePos >= 0.55;
      const text = stalled && held ? top ? "\u51B2\u4E0D\u4E0A\u53BB" : "\u8DCC\u4E0D\u4E0B\u53BB" : held && (top ? ratio2 <= -0.06 : ratio2 >= 0.06) ? top ? "\u5356\u65B9\u5360\u4F18" : "\u4E70\u65B9\u5360\u4F18" : !held && (top ? ratio2 >= 0.06 : ratio2 <= -0.06) ? top ? "\u4E70\u65B9\u5360\u4F18" : "\u5356\u65B9\u5360\u4F18" : "";
      if (text) {
        const side = top ? "\u963B\u529B" : "\u652F\u6491";
        const flowTitle = `${side} ${priceText(lv.price)} \u6700\u8FD1\u89E6\u78B0\u6210\u4EA4 \xB7 ${text}`;
        const touchDetail = [
          `\u6700\u8FD1\u4E00\u6B21\u89E6\u78B0 ${priceText(lv.price)}\uFF1A${hhmmOf(tc.ts)} \u90A3\u6839\uFF0C\u6536\u76D8 ${priceText(tc.c)}\uFF08${held ? `\u4ECD\u5728${side}\u5185\u4FA7` : `\u5DF2\u6536\u5728${side}\u5916\u4FA7`}\uFF09`,
          `\u8BE5\u6839\u4E3B\u52A8\u4E70 ${money(touchObs.buy)} / \u4E3B\u52A8\u5356 ${money(touchObs.sell)} USDT\uFF1B\u4E70\u5360 ${Math.round((1 + ratio2) * 50)}% / \u5356\u5360 ${Math.round((1 - ratio2) * 50)}%\uFF1B${touchObs.src === "rubik" ? "OKX \u5B98\u65B9\u7EDF\u8BA1" : "\u9010\u7B14\u805A\u5408"}\uFF0C\u8986\u76D6 ${(touchObs.coverage * 100).toFixed(0)}% \xB7 \u91CF\u6BD4 ${touchObs.volRatio.toFixed(2)}\xD7`,
          stalled ? "\u4E3B\u52A8\u6210\u4EA4\u5F88\u731B\u4F46\u6536\u76D8\u6CA1\u8DDF\u4E0A\uFF1A\u529B\u6C14\u6CA1\u6362\u6210\u4EF7\u683C\uFF08\u5355\u6839\u89C2\u5BDF\uFF09\u3002" : "\u53EA\u53CD\u6620\u8FD9\u4E00\u6839\u7684\u4E3B\u52A8\u6210\u4EA4\u65B9\u5411\u4E0E\u6536\u76D8\u4F4D\u7F6E\u3002",
          "\u8FD9\u662F\u5355\u6839 taker \u6210\u4EA4\u89C2\u5BDF\uFF0C\u4E0D\u662F\u8BA2\u5355\u7C3F OFI\uFF0C\u4E5F\u4E0D\u8BC1\u660E\u6B62\u635F\u5355\u3001\u4ED3\u4F4D\u6216\u88AB\u52A8\u6302\u5355\uFF1B\u5173\u952E\u4F4D\u672C\u8EAB\u4ECD\u662F\u4EF7\u683C\u7ED3\u6784\u3002"
        ];
        const owner = items.find((i) => i.id === id);
        owner.detail = [...owner.detail, ...touchDetail];
        owner.levels[0].detail = owner.detail;
        owner.event = {
          id: `${id}:flow`,
          ts: tc.ts,
          side: top ? "above" : "below",
          tone: text === "\u4E70\u65B9\u5360\u4F18" || text === "\u8DCC\u4E0D\u4E0B\u53BB" ? "long" : "short",
          text,
          marker: "diamond",
          priority: 50,
          title: flowTitle,
          detail: touchDetail
        };
      }
    }
  }
  const deltaCs = preferences.preview && forming ? [...cs, forming] : cs;
  const deltaCtx = deltaCs === cs ? ctx : buildContext(deltaCs, flow);
  const lastImpulse = { real: { index: -4, direction: 0 }, approx: { index: -4, direction: 0 } };
  const flowMarks = [];
  for (let i = Math.max(20, deltaCtx.n - preferences.lookback); i < deltaCtx.n; i++) {
    const candle = deltaCtx.cs[i];
    const confirmed = candle.ts + barMs <= now;
    const real = deltaCtx.real[i] === 1;
    const fb = flow?.bars.get(candle.ts);
    const denominator = real && fb ? fb.buy + fb.sell : candle.v;
    const ratio2 = denominator > 0 ? deltaCtx.delta[i] / denominator : 0;
    const volRatio = deltaCtx.volMa[i] > 0 ? candle.v / deltaCtx.volMa[i] : 0;
    const range = Math.max(candle.h - candle.l, 1e-12);
    const closePos = (candle.c - candle.l) / range;
    const absorption = real && volRatio >= 2 && Math.abs(ratio2) >= 0.15 && (ratio2 < 0 ? closePos >= 0.55 && candle.c >= candle.o : closePos <= 0.45 && candle.c <= candle.o);
    const impulse = Math.abs(ratio2) >= 0.25 && volRatio >= 1.5 || real && Math.abs(ratio2) >= 0.12 && volRatio >= 2.5;
    const climax = real && !absorption && volRatio >= 4 && Math.abs(ratio2) < 0.12;
    if (!absorption && !impulse && !climax) continue;
    const direction = Math.sign(ratio2);
    const source = real ? "real" : "approx";
    const previous = lastImpulse[source];
    if (!absorption && !climax && direction === previous.direction && i - previous.index < 3) continue;
    previous.index = i;
    previous.direction = direction;
    const buy = ratio2 > 0;
    const id = `delta:${candle.ts}`;
    const pv = `${pct2(ratio2).replace(".0%", "%")} \xB7 ${volRatio.toFixed(1)}\xD7`;
    const preview = confirmed ? "" : " \xB7 \u9884\u89C8";
    const tone = climax ? "warn" : absorption ? buy ? "short" : "long" : buy ? "long" : "short";
    const text = climax ? `\u7206\u91CF${preview}` : absorption ? `${buy ? "\u6DA8\u4E0D\u4E0A\u53BB" : "\u8DCC\u4E0D\u4E0B\u53BB"}${preview}` : real ? `${buy ? "\u4E70\u5F97\u731B" : "\u5356\u5F97\u731B"}${preview}` : `${buy ? "\u504F\u5F3A" : "\u504F\u5F31"}${preview}`;
    const title = climax ? `\u6210\u4EA4\u91CF\u7A81\u7136\u653E\u5927 ${volRatio.toFixed(1)} \u500D\uFF0C\u4E70\u548C\u5356\u90FD\u5F88\u591A${preview}` : absorption ? `${buy ? "\u4E3B\u52A8\u4E70\u5165" : "\u4E3B\u52A8\u5356\u51FA"}\u5F88\u591A\uFF0C\u4EF7\u683C\u5374\u6CA1\u8DDF\u7740\u8D70${preview}` : real ? `\u8FD9\u4E00\u6839\u4EE5${buy ? "\u4E3B\u52A8\u4E70\u5165" : "\u4E3B\u52A8\u5356\u51FA"}\u4E3A\u4E3B\uFF08${pv}\uFF09${preview}` : `K \u7EBF\u91CF\u4EF7\u504F${buy ? "\u5F3A" : "\u5F31"}\uFF0C\u65B9\u5411\u9760\u6536\u76D8\u4F4D\u7F6E\u63A8\u6D4B\uFF08${pv}\uFF09${preview}`;
    const notional = real && fb ? `\u4E70 ${money(fb.buy)} / \u5356 ${money(fb.sell)} USDT` : "\u6CA1\u6709\u9010\u7B14\u6570\u636E\uFF0C\u6309\u6536\u76D8\u4F4D\u7F6E\u63A8\u6D4B\uFF0C\u4E0D\u4EE3\u8868\u771F\u5B9E\u4E70\u5356\u65B9\u5411";
    const detail = [`${notional} \xB7 \u91CF\u662F\u8FD1 20 \u6839\u7684 ${volRatio.toFixed(1)} \u500D`];
    if (climax) detail.push("\u4E70\u5356\u4E24\u8FB9\u90FD\u5F88\u5927\uFF0C\u4E0D\u662F\u5355\u8FB9\u884C\u60C5\uFF1B\u770B\u4E0B\u4E00\u6839\u80FD\u4E0D\u80FD\u6536\u5728\u8FD9\u6839\u4E2D\u95F4\u4F4D\u7F6E\u4E0A\u65B9/\u4E0B\u65B9\u3002");
    if (absorption) detail.push(`\u4E3B\u52A8\u5DEE ${pct2(ratio2)}\uFF0C\u4F46\u6536\u5728\u6574\u6839\u7684 ${(closePos * 100).toFixed(0)}% \u4F4D\u7F6E\uFF1A\u529B\u6C14\u6CA1\u6362\u6210\u4EF7\u683C\u3002`);
    const score = climax ? 3.2 : absorption ? 2.6 : 1 + Math.min(3, Math.abs(ratio2) * 3) + Math.min(1.5, volRatio / 4);
    flowMarks.push({
      idx: i,
      score,
      item: {
        id,
        type: "deltaImpulse",
        ts: candle.ts,
        fromTs: candle.ts,
        price: candle.c,
        title,
        detail,
        source,
        confirmed,
        tone,
        event: {
          id,
          ts: candle.ts,
          side: climax ? candle.c < candle.o ? "below" : "above" : absorption ? buy ? "above" : "below" : buy ? "below" : "above",
          tone,
          text,
          marker: "diamond",
          priority: climax ? 72 : absorption ? 70 : confirmed ? 62 : 40,
          title,
          detail
        }
      }
    });
  }
  const ranked = flowMarks.map((c) => ({ ...c, rank: (c.item.source === "real" ? 10 : 0) + c.score })).sort((a, b) => b.rank - a.rank);
  const painted = [];
  for (const c of ranked) {
    const preview = c.item.confirmed === false;
    const keep = preview || painted.length < 4 && !painted.some((p2) => Math.abs(p2.idx - c.idx) < 6);
    if (keep) painted.push(c);
    c.item.paint = keep;
  }
  items.push(...flowMarks.map((c) => c.item));
  const broken = swings.filter((l) => l.breakIdx !== null && cs[l.breakIdx].ts >= cutoff).slice(-24);
  for (const lv of broken) {
    const b = lv.breakIdx;
    const end = Math.min(ctx.n - 1, b + 48);
    for (let q = b + 1; q <= end; q++) {
      const read = readBreakout(ctx, lv, b, q);
      if (read.pullback.failed) break;
      if (!read.pullback.held) continue;
      const up = read.dir > 0;
      const firstFlow = takerObservation(ctx, flow, b)?.ratio ?? null;
      const holdFlow = takerObservation(ctx, flow, q)?.ratio ?? null;
      const corroborated = firstFlow !== null && holdFlow !== null && firstFlow * read.dir >= 0.08 && holdFlow * read.dir >= -0.12;
      const source = corroborated ? "real" : "price";
      const id = `retest:${lv.ts}:${cs[b].ts}`;
      const title = up ? "\u7A81\u7834\u56DE\u8E29 \xB7 \u5B88\u4F4F\u652F\u6491" : "\u8DCC\u7834\u53CD\u62BD \xB7 \u963B\u529B\u6709\u6548";
      const detail = [
        "\u7A81\u7834\u540E\u9996\u6B21\u6536\u76D8\u5B88\u4F4F\u5173\u952E\u4F4D\uFF08\u4EF7\u683C\u7ED3\u6784\uFF0C\u4E0D\u662F\u9884\u8BBE\u76C8\u5229\u76EE\u6807\uFF09\u3002",
        corroborated ? `\u7A81\u7834K\u771F\u5B9E\u4E3B\u52A8\u5DEE ${pct2(firstFlow)} \xB7 \u786E\u8BA4K ${pct2(holdFlow)}\uFF1B\u4EC5\u8FD9\u4E24\u6839\u5177\u5907\u6210\u4EA4\u4F50\u8BC1\uFF0C\u4E2D\u95F4\u4E0D\u4EE3\u8868\u8FDE\u7EED\u8986\u76D6\u3002` : "\u65E0\u4E24\u6839\u5B8C\u6574\u540C\u5411\u4E3B\u52A8\u6210\u4EA4\u4F50\u8BC1\uFF1B\u6B64\u6807\u6CE8\u4EC5\u8BF4\u660E\u4EF7\u683C\u56DE\u8E29\uFF0C\u4E0D\u58F0\u79F0\u8BA2\u5355\u6D41\u786E\u8BA4\u3002"
      ];
      items.push({
        id,
        type: "retest",
        ts: cs[q].ts,
        fromTs: cs[b].ts,
        price: lv.price,
        title,
        detail,
        source,
        confirmed: true,
        tone: "zone",
        event: { id, ts: cs[q].ts, side: up ? "below" : "above", tone: "zone", text: up ? "\u56DE\u8E29\u786E\u8BA4" : "\u53CD\u62BD\u786E\u8BA4", marker: "tri", priority: 70, title, detail },
        zone: { id: `${id}:zone`, fromTs: cs[b].ts, toTs: cs[q].ts + barMs, lo: read.zone.lo, hi: read.zone.hi, tone: "zone", text: up ? "\u56DE\u8E29\u533A" : "\u53CD\u62BD\u533A", priority: 70, title, detail }
      });
      break;
    }
  }
  const covered = [...ctx.real].slice(-preferences.lookback).reduce((sum, n) => sum + n, 0);
  return {
    items: [...new Map(items.map((i) => [i.id, i])).values()].sort((a, b) => b.ts - a.ts),
    covered,
    bars: inScope.length,
    requested: preferences.lookback,
    // 加密货币连续交易：历史缺口会让分析只覆盖最新连续段。范围变小必须对用户可见，
    // 否则「识别数 0」看起来像检测器坏了，其实是没有那么多连续历史。
    gapTruncated: contiguousStart > 0 && inScope.length < preferences.lookback,
    historyShort: contiguousStart === 0 && inScope.length < preferences.lookback,
    lastPrice
  };
}
function projectSignals(analysis, preferences, focusId = null) {
  const eligible = analysis.items.filter((i) => (i.source === "price" || i.source === "real" || preferences.allowApprox) && (i.confirmed || preferences.preview));
  const counts = emptyCounts();
  for (const i of eligible) {
    counts[i.type]++;
    if (i.story?.active && i.zone) counts.keyLevelScenario++;
    if (i.story?.smc && i.story.smc.hits >= 2) counts.smartMoney++;
  }
  const visible = preferences.enabled ? eligible.filter((i) => preferences.selected[i.type]).sort((a, b) => Number(!!b.story) - Number(!!a.story) || b.ts - a.ts).slice(0, 160) : [];
  const payload = emptySignalPayload();
  payload.decimals = decimalsFor(analysis.lastPrice);
  const selected = visible.find((i) => i.story && i.id === focusId);
  const rankedStories = selectMwStories(visible.filter((i) => i.story));
  const paintedStories = selected ? [selected, ...rankedStories.filter((i) => i.id !== selected.id && Math.abs(i.price - selected.price) > Math.max(i.story.referenceAtr, selected.story.referenceAtr))].slice(0, 3) : rankedStories;
  const storyIds = new Set(paintedStories.map((i) => i.id));
  const directions = /* @__PURE__ */ new Set();
  const byText = /* @__PURE__ */ new Map();
  for (const item of visible) {
    if (item.paint === false || item.story && !storyIds.has(item.id)) continue;
    if (item.type === "keyLevels" && paintedStories.some((i) => Math.min(Math.abs(i.story.level - item.price), Math.abs(i.story.neck - item.price)) <= annotationTolerance(item.price, i.story.referenceAtr))) continue;
    const approximate = item.source === "mixed" || item.source === "approx";
    if (item.event) {
      const event = { ...item.event, text: preferences.labels ? `${approximate ? "\u2248 " : ""}${item.event.text}` : "" };
      const key = `${event.ts}|${event.text || event.id}`;
      const prev = byText.get(key);
      if (!prev || event.priority > prev.priority) byText.set(key, event);
    }
    if (item.levels) {
      const levels = item.story ? item.levels.filter((l) => preferences.geometry || l.id.endsWith(":level")) : item.type === "keyLevels" || preferences.geometry ? item.levels : [];
      payload.levels.push(...levels.map((l) => ({ ...l, ...item.id === focusId ? { rank: "focus", priority: 100 } : {}, label: l.label && preferences.labels })));
    }
    if (item.zone && (!item.story || preferences.selected.keyLevelScenario)) {
      const direction = item.story?.bias ?? item.story?.side ?? item.id;
      if (!item.story || !directions.has(direction) && directions.size < 2) {
        payload.zones.push({ ...item.zone, text: preferences.labels ? `${approximate ? "\u2248 " : ""}${item.zone.text}` : "" });
        if (item.story) directions.add(direction);
      }
    }
    if (item.path && preferences.geometry) payload.paths.push({ id: `${item.id}:path`, ...item.path });
  }
  payload.events.push(...byText.values());
  return { payload, visible, counts };
}

// tests/flow-markers.test.ts
var passed = 0;
var pass = (n) => {
  passed++;
  console.log(`  \u2713 ${n}`);
};
{
  const p2 = new OKXProvider();
  const sol = await p2.getSymbolInfo("SOL-USDT-SWAP");
  const btc = await p2.getSymbolInfo("BTC-USDT-SWAP");
  assert.equal(sol?.mintick, 0.01);
  assert.equal(btc?.mintick, 0.1);
  pass("OKXProvider \u63D0\u4F9B mintick\uFF08SOL 0.01 / BTC 0.1\uFF09\uFF0C\u4EF7\u683C\u8F74\u521D\u59CB\u5373\u663E\u793A\u6B63\u786E\u5C0F\u6570\u4F4D");
}
{
  const res = await GET(new Request("http://x/api/okx/api/v5/account/balance"), { params: Promise.resolve({ path: ["api", "v5", "account", "balance"] }) });
  assert.equal(res.status, 404);
  pass("rubik \u4EE3\u7406\u53EA\u653E\u884C taker-volume / open-interest\uFF0C\u5176\u5B83\u8DEF\u5F84 404");
}
{
  const MS = 3e5;
  const NOW = 18e11;
  const end = Math.floor(NOW / MS) * MS - MS;
  const cs = Array.from({ length: 100 }, (_, i) => ({ ts: end - (99 - i) * MS, o: 100, h: 100.3, l: 99.7, c: 100, v: 1e3 }));
  cs[70] = { ...cs[70], o: 100, h: 100.2, l: 98.8, c: 99, v: 3e3 };
  cs[80] = { ...cs[80], o: 99.6, h: 100.3, l: 99, c: 100.2, v: 3e3 };
  cs[90] = { ...cs[90], o: 100, h: 100.1, l: 97.5, c: 98.4, v: 9e3 };
  const bars = new Map(cs.map((c, i) => {
    const r = i === 70 || i === 80 ? -0.35 : i === 90 ? -0.08 : 0;
    return [c.ts, { ts: c.ts, buy: c.v * (1 + r) / 2, sell: c.v * (1 - r) / 2, src: "rubik" }];
  }));
  const flow = { instId: "SOL-USDT-SWAP", period: "5m", barMs: MS, bars, from: cs[0].ts, to: cs.at(-1).ts, oiFrom: Infinity, updatedAt: 0, complete: true, tape: { connected: true, trades: 1, bootstrapped: true } };
  const prefs = { ...DEFAULT_PREFERENCES, selected: { ...DEFAULT_PREFERENCES.selected, deltaImpulse: true } };
  const items = analyzeSignals(cs, MS, prefs, flow, NOW).items.filter((i) => i.type === "deltaImpulse");
  const push = items.find((i) => i.ts === cs[70].ts);
  const absorbed = items.find((i) => i.ts === cs[80].ts);
  assert.ok(push && push.event.text === "\u5356\u5F97\u731B", `push marker: ${push?.event?.text}`);
  assert.equal(push.tone, "short");
  assert.ok(absorbed && absorbed.event.text === "\u8DCC\u4E0D\u4E0B\u53BB", `absorption marker: ${absorbed?.event?.text}`);
  assert.equal(absorbed.tone, "long", "absorbed selling is a buy-side read");
  assert.ok(absorbed.detail[0].includes("\u4E70 ") && absorbed.detail[0].includes("\u5356 "), "shows actual buy/sell notional");
  const climax = items.find((i) => i.ts === cs[90].ts);
  assert.ok(climax && climax.event.text === "\u7206\u91CF", `climax marker: ${climax?.event?.text}`);
  assert.equal(climax.tone, "warn");
  const crowd = Array.from({ length: 120 }, (_, i) => ({ ts: end - (119 - i) * MS, o: 100, h: 100.3, l: 99.7, c: 100, v: 1e3 }));
  for (const i of [60, 64, 68, 72, 76, 80]) crowd[i] = { ...crowd[i], o: 100, h: 100.2, l: 98.5, c: 98.7, v: 6e3 };
  const cflow = { ...flow, bars: new Map(crowd.map((c) => [c.ts, { ts: c.ts, buy: c.v * 0.3, sell: c.v * 0.7, src: "rubik" }])) };
  const crowdAnalysis = analyzeSignals(crowd, MS, prefs, cflow, NOW);
  const crowdItems = crowdAnalysis.items.filter((i) => i.type === "deltaImpulse");
  assert.ok(crowdItems.length >= 4, "\u4FA7\u680F\u5217\u8868\u4FDD\u7559\u5168\u90E8\u653E\u91CF\u4E8B\u4EF6");
  const { payload, visible } = projectSignals(crowdAnalysis, prefs);
  const paintedIds = new Set(payload.events.map((e) => e.id));
  const painted = crowdItems.filter((i) => paintedIds.has(`delta:${i.ts}`));
  assert.ok(painted.length <= 4, `\u753B\u5E03\u6700\u591A 4 \u4E2A\u529B\u5EA6\u6807\u7B7E\uFF0C\u5B9E\u9645 ${painted.length}`);
  const idx = painted.map((i) => crowd.findIndex((c) => c.ts === i.ts)).sort((a, b) => a - b);
  for (let k = 1; k < idx.length; k++) assert.ok(idx[k] - idx[k - 1] >= 6, "\u753B\u5E03\u4E0A\u7684\u6807\u7B7E\u81F3\u5C11\u9694 6 \u6839");
  assert.equal(visible.filter((i) => i.type === "deltaImpulse").length, crowdItems.length, "\u4FA7\u680F\u4ECD\u80FD\u770B\u5230\u5168\u90E8");
  pass("\u653E\u91CF\u5356\u51FA\u6536\u4F4E \u2192 \u5356\u5F97\u731B\uFF1B\u6536\u9AD8 \u2192 \u8DCC\u4E0D\u4E0B\u53BB\uFF1B\u5DE8\u91CF\u5747\u8861 \u2192 \u7206\u91CF\uFF1B\u753B\u5E03\u6700\u591A 4 \u4E2A\u3001\u95F4\u9694 \u22656 \u6839\uFF0C\u5217\u8868\u5B8C\u6574");
}
console.log(`
flow-markers: ${passed} \u7EC4\u65AD\u8A00\u5168\u90E8\u901A\u8FC7`);
