// tests/data-layer.test.ts
import assert from "node:assert/strict";

// src/lib/types.ts
var SYMBOLS = [
  { id: "BTC-USDT-SWAP", base: "BTC", label: "BTC \u6C38\u7EED", ctVal: 0.01, minTick: 0.1 },
  { id: "ETH-USDT-SWAP", base: "ETH", label: "ETH \u6C38\u7EED", ctVal: 0.1, minTick: 0.01 },
  { id: "SOL-USDT-SWAP", base: "SOL", label: "SOL \u6C38\u7EED", ctVal: 1, minTick: 0.01 }
];
function ctValOf(symbol) {
  return SYMBOLS.find((s) => s.id === symbol)?.ctVal ?? 1;
}
var barMs = (bar) => bar === "15m" ? 9e5 : bar === "1m" ? 6e4 : 3e5;

// src/lib/okxVolume.ts
function quoteVolumeOfRow(row2, symbol) {
  const finite = (v) => v !== "" && v != null && Number.isFinite(Number(v)) && Number(v) >= 0;
  const quote = Number(row2[7]), base = Number(row2[6]), contracts = Number(row2[5]), close = Number(row2[4]);
  if (finite(row2[7]) && (quote > 0 || contracts === 0 && (!finite(row2[6]) || base === 0))) return { value: quote, source: "quote" };
  if (!(close > 0) || !Number.isFinite(close)) return null;
  if (finite(row2[6]) && base > 0) return { value: base * close, source: "base_close_estimate" };
  if (finite(row2[5]) && contracts > 0) {
    const value = contracts * ctValOf(symbol) * close;
    return Number.isFinite(value) ? { value, source: "contracts_close_estimate" } : null;
  }
  return null;
}

// src/lib/okxCandles.ts
function parseOkxCandle(row2, symbol) {
  if (!Array.isArray(row2) || row2.length < 6) return null;
  const [ts, o, h, l, c] = row2.slice(0, 5).map(Number);
  if (![ts, o, h, l, c].every(Number.isFinite) || !Number.isSafeInteger(ts) || ts <= 0 || Math.min(o, h, l, c) <= 0 || h < l || h < Math.max(o, c) || l > Math.min(o, c)) return null;
  const volume = quoteVolumeOfRow(row2, symbol);
  if (!volume) return null;
  const rawConfirm = row2[8];
  const confirm = rawConfirm === 1 || rawConfirm === "1" ? 1 : rawConfirm === 0 || rawConfirm === "0" ? 0 : void 0;
  return { ts, o, h, l, c, v: volume.value, volumeSource: volume.source, ...confirm === void 0 ? {} : { confirm } };
}
function isClosedCandle(c, intervalMs, now = Date.now(), legacyGraceMs = 1500) {
  if (c.confirm === 1) return true;
  if (c.confirm === 0) return false;
  return Number.isFinite(c.ts) && c.ts + intervalMs + legacyGraceMs <= now;
}
function preferCandle(existing, incoming, existingVolume, incomingVolume, expired = false) {
  if (!existing) return incoming;
  const rank = (c) => c.confirm === 1 ? 2 : c.confirm === 0 || expired ? 1 : 0;
  const quality = (c) => c.volumeSource === "quote" ? 1 : 0;
  const a = rank(existing), b = rank(incoming);
  if (a !== b) return b > a ? incoming : existing;
  const qa = quality(existing), qb = quality(incoming);
  if (qa !== qb) return qb > qa ? incoming : existing;
  return incomingVolume >= existingVolume ? incoming : existing;
}
function mergeCandles(base, incoming, intervalMs, now = Date.now()) {
  const out = /* @__PURE__ */ new Map();
  for (const c of base) out.set(c.ts, c);
  for (const c of incoming) {
    const old = out.get(c.ts);
    out.set(c.ts, preferCandle(old, c, old?.v ?? 0, c.v, isClosedCandle(c, intervalMs, now)));
  }
  return [...out.values()].sort((a, b) => a.ts - b.ts);
}

// src/server/okx.ts
var BASE = "https://www.okx.com";
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function makeGate(gapMs) {
  let chain = Promise.resolve();
  return () => {
    const next = chain.then(() => sleep(gapMs));
    chain = next.catch(() => void 0);
    return next;
  };
}
var candlesGate = makeGate(55);
var historyGate = makeGate(105);
var OkxError = class extends Error {
  constructor(message, retryable = true) {
    super(message);
    this.retryable = retryable;
    this.name = "OkxError";
  }
};
async function okxGet(path, params, timeoutMs = 5e3) {
  if (path.includes("history-candles")) await historyGate();
  else if (path.includes("candles")) await candlesGate();
  const url = new URL(BASE + path);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(url.toString(), { signal: ctl.signal });
    if (!res.ok) throw new OkxError("HTTP " + res.status, res.status === 429 || res.status >= 500);
    const json = await res.json();
    if (json.code && json.code !== "0") throw new OkxError("OKX code " + json.code);
    return json.data;
  } finally {
    clearTimeout(t);
  }
}
async function okxGetRetry(path, params, tries = 3) {
  let lastErr = null;
  for (let t = 0; t < tries; t++) {
    try {
      const d = await okxGet(path, params, 8e3);
      return d ?? [];
    } catch (e) {
      lastErr = e;
      if (e instanceof OkxError && !e.retryable) break;
      if (t < tries - 1) await sleep(300 * (t + 1));
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("OKX request failed");
}
function parseCandleRow(row2, symbol) {
  return parseOkxCandle(row2, symbol);
}
async function fetchCandlesWithMeta(symbol, bar, count) {
  const want = Math.max(1, Math.min(count, 12e3));
  const bm = barMs(bar);
  const map = /* @__PURE__ */ new Map();
  const add = (rows) => {
    for (const r of rows ?? []) {
      const c = parseCandleRow(r, symbol);
      if (c) map.set(c.ts, c);
    }
  };
  const first = await okxGetRetry("/api/v5/market/candles", {
    instId: symbol,
    bar,
    limit: String(Math.min(300, want))
  });
  add(first);
  if (map.size === 0) throw new OkxError("empty candles", false);
  if (map.size < want) {
    const oldest = Math.min(...map.keys());
    let step = 100;
    let startK = 0;
    const failed = [];
    if (want > 1200) {
      try {
        const probe = await okxGetRetry("/api/v5/market/history-candles", {
          instId: symbol,
          bar,
          after: String(oldest),
          limit: "300"
        });
        add(probe);
        if (probe.length >= 200) step = 300;
        startK = 1;
      } catch {
      }
    }
    if (map.size < want) {
      const remPages = Math.ceil((want - map.size) / step);
      const limitStr = String(step);
      const loadPage = async (k) => {
        const rows = await okxGetRetry("/api/v5/market/history-candles", {
          instId: symbol,
          bar,
          after: String(oldest - k * step * bm),
          limit: limitStr
        });
        add(rows);
      };
      await Promise.all(
        Array.from({ length: remPages }, (_, idx) => {
          const k = startK + idx;
          return loadPage(k).catch(() => {
            failed.push(k);
          });
        })
      );
      if (failed.length) {
        await Promise.all(
          [...new Set(failed)].map(
            (k) => loadPage(k).catch(() => {
            })
          )
        );
      }
    }
    if (want > 1200 && map.size < want && map.size >= want - 600 && failed.length === 0) {
      for (let extra = 0; extra < 2 && map.size < want; extra++) {
        const curOldest = Math.min(...map.keys());
        const rows = await okxGetRetry("/api/v5/market/history-candles", {
          instId: symbol,
          bar,
          after: String(curOldest),
          limit: String(step)
        }).catch(() => []);
        const before = map.size;
        add(rows);
        if (map.size === before) break;
      }
    }
  }
  const sorted = [...map.values()].sort((a, b) => a.ts - b.ts);
  const candles = sorted.slice(-want);
  let missingBars = 0;
  for (let i = 1; i < candles.length; i++) {
    const step = Math.round((candles[i].ts - candles[i - 1].ts) / bm);
    if (step > 1) missingBars += step - 1;
  }
  return { candles, missingBars, short: candles.length < want };
}
function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = a + 1831565813 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
var SYNTH_BASE = {
  "BTC-USDT-SWAP": { price: 97400, vol: 11e-4, volUnit: 9200 },
  "ETH-USDT-SWAP": { price: 3625, vol: 16e-4, volUnit: 26e3 },
  "SOL-USDT-SWAP": { price: 214, vol: 22e-4, volUnit: 9e3 }
};
function synthCandles(symbol, bar, count, endTs) {
  const cfg = SYNTH_BASE[symbol] ?? { price: 100, vol: 2e-3, volUnit: 1e3 };
  const bm = barMs(bar);
  const dayKey = Math.floor((endTs ?? Date.now()) / 864e5);
  const rng = mulberry32(hashStr(`${symbol}|${bar}|${dayKey}`));
  const lastStart = Math.floor((endTs ?? Date.now()) / bm) * bm - bm;
  const start = lastStart - (count - 1) * bm;
  const out = [];
  let price = cfg.price * (0.97 + rng() * 0.06);
  let regime = 0;
  for (let i = 0; i < count; i++) {
    regime = regime * 0.982 + (rng() - 0.5) * 0.09;
    if (rng() < 0.012) regime += (rng() - 0.5) * 0.9;
    const vScale = 1 + 1.6 * Math.abs(regime) + (rng() < 0.06 ? rng() * 2.4 : 0);
    const pull = -15e-4 * Math.log(price / cfg.price);
    const ret = regime * cfg.vol * 1.6 + pull + (rng() + rng() - 1) * cfg.vol * vScale;
    const o = price * (rng() < 0.02 ? 1 + (rng() - 0.5) * cfg.vol * 6 : 1);
    let p = o;
    let hi = o;
    let lo = o;
    let pc = o;
    for (let s = 0; s < 4; s++) {
      pc = p * (1 + ret / 4 + (rng() - 0.5) * cfg.vol * 0.55 * vScale);
      p = pc;
      hi = Math.max(hi, p);
      lo = Math.min(lo, p);
    }
    const c = p;
    hi = Math.max(hi, o, c) * (1 + rng() * cfg.vol * 0.5 * vScale);
    lo = Math.min(lo, o, c) * (1 - rng() * cfg.vol * 0.5 * vScale);
    const bodyPct = Math.abs(c - o) / o;
    const v = cfg.volUnit * ctValOf(symbol) * (0.45 + rng() * 0.8) * (1 + bodyPct / cfg.vol / 2.2) * c;
    out.push({ ts: start + i * bm, o, h: hi, l: lo, c, v, volumeSource: "synthetic" });
    price = c;
  }
  return out;
}
var CACHE_MAX = 12;
var TTL_LIVE = 12e4;
var TTL_DEGRADED = 15e3;
var cache = /* @__PURE__ */ new Map();
var inflight = /* @__PURE__ */ new Map();
var tailRefresh = /* @__PURE__ */ new Map();
function mergeByTs(base, incoming, intervalMs) {
  return mergeCandles(base, incoming, intervalMs);
}
function holesOf(cs, bm) {
  let n = 0;
  for (let i = 1; i < cs.length; i++) {
    const step = Math.round((cs[i].ts - cs[i - 1].ts) / bm);
    if (step > 1) n += step - 1;
  }
  return n;
}
function refreshTail(key, entry, symbol, bar) {
  const running = tailRefresh.get(key);
  if (running) return running;
  const job = (async () => {
    try {
      const rows = await okxGetRetry("/api/v5/market/candles", { instId: symbol, bar, limit: "300" });
      const fresh = [];
      for (const r of rows) {
        const c = parseCandleRow(r, symbol);
        if (c) fresh.push(c);
      }
      if (!fresh.length) return false;
      const bm = barMs(bar);
      const merged = mergeByTs(entry.data, fresh, bm).slice(-Math.max(entry.data.length, 1));
      if (holesOf(merged, bm) > holesOf(entry.data, bm)) return false;
      entry.data = merged;
      const now = Date.now();
      entry.tailAt = now;
      entry.tailAttemptAt = now;
      return true;
    } catch {
      entry.tailAttemptAt = Date.now();
      return false;
    }
  })().finally(() => {
    if (tailRefresh.get(key) === job) tailRefresh.delete(key);
  });
  tailRefresh.set(key, job);
  return job;
}
function remember(key, entry) {
  cache.delete(key);
  cache.set(key, entry);
  while (cache.size > CACHE_MAX) {
    const oldest = cache.keys().next().value;
    if (oldest === void 0) break;
    cache.delete(oldest);
  }
}
async function getCandles(symbol, bar, count, fresh = false) {
  const key = `${symbol}|${bar}`;
  if (!fresh) {
    const hit = cache.get(key);
    if (hit && (hit.data.length >= count || hit.want >= count)) {
      const ttl = hit.live && !hit.gapped ? TTL_LIVE : TTL_DEGRADED;
      if (Date.now() - hit.at < ttl) {
        const last = hit.data[hit.data.length - 1];
        const bm = barMs(bar);
        const now = Date.now();
        const needsTail = hit.live && !!last && last.ts + bm <= now && now - hit.tailAttemptAt >= 2e3;
        const usable = !needsTail || await refreshTail(key, hit, symbol, bar);
        if (usable) return { live: hit.live, gapped: hit.gapped, candles: hit.data.slice(-count) };
      }
    }
    const pending = inflight.get(key);
    if (pending && pending.count >= count) {
      const r = await pending.promise;
      return { live: r.live, gapped: r.gapped, candles: r.candles.slice(-count) };
    }
  }
  const job = (async () => {
    try {
      const { candles, missingBars, short } = await fetchCandlesWithMeta(symbol, bar, count);
      if (candles.length < Math.min(count, 200)) throw new Error("insufficient live data");
      const gapped = missingBars > 0 || short;
      const now = Date.now();
      remember(key, { at: now, live: true, gapped, data: candles, want: count, tailAt: now, tailAttemptAt: now });
      return { live: true, gapped, candles };
    } catch {
      const candles = synthCandles(symbol, bar, count);
      const now = Date.now();
      remember(key, { at: now, live: false, gapped: false, data: candles, want: count, tailAt: now, tailAttemptAt: now });
      return { live: false, gapped: false, candles };
    }
  })();
  inflight.set(key, { promise: job, count });
  try {
    return await job;
  } finally {
    if (inflight.get(key)?.promise === job) inflight.delete(key);
  }
}

// src/lib/market.ts
var SYMBOL_IDS = SYMBOLS.map((s) => s.id);
var SCAN_BARS_ALLOWED = ["5m", "15m"];
function parseSymbol(raw, opts = {}) {
  const value = (raw ?? "").trim().replace(/^okx:/i, "");
  if (!value) return opts.fallback ?? SYMBOL_IDS[0] ?? "BTC-USDT-SWAP";
  if (opts.allowAll && value === "ALL") return "ALL";
  return SYMBOL_IDS.includes(value) ? value : null;
}
function parseBar(raw, allowed, opts = {}) {
  const value = (raw ?? "").trim();
  if (!value) return opts.fallback ?? allowed[0] ?? "5m";
  if (opts.allowAll && value === "ALL") return "ALL";
  return allowed.includes(value) ? value : null;
}

// src/lib/lru.ts
function setBounded(map, key, value, max) {
  map.delete(key);
  map.set(key, value);
  while (map.size > max) {
    const oldest = map.keys().next().value;
    if (oldest === void 0) break;
    map.delete(oldest);
  }
}

// tests/data-layer.test.ts
var B = 3e5;
var NOW = Math.floor(1793e9 / B) * B;
var realFetch = globalThis.fetch;
var row = (ts) => [String(ts), "100", "101", "99", "100", "1", "0", "1"];
var page = (n, from) => Array.from({ length: n }, (_, i) => row(from - i * B));
var reply = (data, status = 200, code = "0") => new Response(JSON.stringify({ code, data }), { status });
var calls = 0;
function install(script = {}) {
  calls = 0;
  const attempts = /* @__PURE__ */ new Map();
  globalThis.fetch = (async (input) => {
    const u = new URL(String(input));
    if (!u.pathname.includes("candles")) return reply([]);
    calls++;
    if (u.pathname.endsWith("/market/candles")) {
      if (script.firstPageStatus) return reply([], script.firstPageStatus, "60012");
      const rows = page(300, NOW);
      return reply(script.firstPage ? script.firstPage(rows) : rows);
    }
    const after = Number(u.searchParams.get("after"));
    if (script.allHistory429) return reply([], 429, "50011");
    if (script.failWindow?.(after)) return reply([], 429, "50011");
    const failN = script.flaky?.get(after);
    if (failN) {
      const n = (attempts.get(after) ?? 0) + 1;
      attempts.set(after, n);
      if (n <= failN) return reply([], 429, "50011");
    }
    return reply(page(100, after - B));
  });
}
var holes = (cs) => {
  let n = 0;
  for (let i = 1; i < cs.length; i++) {
    const d = Math.round((cs[i].ts - cs[i - 1].ts) / B);
    if (d > 1) n += d - 1;
  }
  return n;
};
var passed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`PASS ${name}`);
  } catch (e) {
    console.error(`FAIL ${name}
  ${e.message}`);
    process.exitCode = 1;
  }
}
await test("\u5B8C\u6574\u6210\u529F\uFF1A\u53D6\u6EE1\u3001\u65E0\u6D1E\u3001gapped=false", async () => {
  install();
  const r = await getCandles("T1-USDT-SWAP", "5m", 900);
  assert.equal(r.live, true);
  assert.equal(r.candles.length, 900);
  assert.equal(holes(r.candles), 0);
  assert.equal(r.gapped, false);
});
await test("\u8BF7\u6C42\u6CA1\u53D6\u6EE1\uFF08\u5386\u53F2\u9875\u5168\u90E8 429\uFF09\u2192 gapped=true\uFF0C\u4E0D\u5F97\u9759\u9ED8\u622A\u65AD", async () => {
  install({ allHistory429: true });
  const r = await getCandles("T2-USDT-SWAP", "5m", 900);
  assert.equal(r.live, true);
  assert.equal(r.candles.length, 300);
  assert.equal(r.gapped, true);
});
await test("\u5355\u9875\u6C38\u4E45\u5931\u8D25 \u2192 live=true\u3001gapped=true\u3001\u7CBE\u786E\u7559\u4E0B 100 \u6839\u6D1E", async () => {
  install({ failWindow: (a) => a === NOW - 499 * B });
  const r = await getCandles("T3-USDT-SWAP", "5m", 900);
  assert.equal(r.live, true);
  assert.equal(r.gapped, true);
  assert.equal(holes(r.candles), 100);
  assert.equal(r.candles.length, 800);
});
await test("\u5355\u9875\u8FDE\u7EED\u5931\u8D25 2 \u6B21 \u2192 \u9760\u8BF7\u6C42\u5185\u91CD\u8BD5\u8865\u9F50\uFF08\u7B2C 3 \u6B21\u6210\u529F\uFF09\uFF0C\u65E0\u7F3A\u53E3", async () => {
  install({ flaky: /* @__PURE__ */ new Map([[NOW - 499 * B, 2]]) });
  const r = await getCandles("T4A-USDT-SWAP", "5m", 900);
  assert.equal(r.candles.length, 900);
  assert.equal(holes(r.candles), 0);
  assert.equal(r.gapped, false);
});
await test("\u5355\u9875\u8FDE\u7EED\u5931\u8D25 4 \u6B21 \u2192 \u8BF7\u6C42\u5185\u91CD\u8BD5\u8017\u5C3D\uFF0C\u9760\u5931\u8D25\u9875\u8865\u62C9\u4E00\u8F6E\u8865\u9F50\uFF0C\u65E0\u7F3A\u53E3", async () => {
  install({ flaky: /* @__PURE__ */ new Map([[NOW - 499 * B, 4]]) });
  const r = await getCandles("T4B-USDT-SWAP", "5m", 900);
  assert.equal(r.candles.length, 900);
  assert.equal(holes(r.candles), 0);
  assert.equal(r.gapped, false);
});
await test("\u5355\u9875\u8FDE\u7EED\u5931\u8D25 6 \u6B21 \u2192 \u4E24\u5C42\u91CD\u8BD5\u90FD\u8017\u5C3D\uFF0C\u5982\u5B9E\u7559\u4E0B 100 \u6839\u6D1E", async () => {
  install({ flaky: /* @__PURE__ */ new Map([[NOW - 499 * B, 6]]) });
  const r = await getCandles("T4C-USDT-SWAP", "5m", 900);
  assert.equal(holes(r.candles), 100);
  assert.equal(r.gapped, true);
});
await test("\u7578\u5F62\u884C\uFF08\u5B57\u6BB5\u4E0D\u8DB3 / NaN / high<low\uFF09\u88AB\u5254\u9664\uFF0C\u4E14\u5982\u5B9E\u7559\u4E0B\u7F3A\u53E3", async () => {
  install({
    firstPage: (rows) => {
      rows[5] = ["bad"];
      rows[9] = [rows[9][0], "NaN", "1", "1", "1", "1", "0", "1"];
      rows[20] = [rows[20][0], "100", "99", "101", "100", "1", "0", "1"];
      return rows;
    }
  });
  const r = await getCandles("T5-USDT-SWAP", "5m", 300);
  assert.equal(r.live, true, "\u7578\u5F62\u884C\u4E0D\u5E94\u5BFC\u81F4\u6574\u4F53\u964D\u7EA7\u4E3A\u5408\u6210\u884C\u60C5");
  assert.equal(holes(r.candles), 3);
  assert.equal(r.gapped, true);
  assert.ok(r.candles.every((c) => [c.o, c.h, c.l, c.c, c.v].every(Number.isFinite) && c.h >= Math.max(c.o, c.c) && c.l <= Math.min(c.o, c.c)));
});
await test("\u4E0A\u6E38\u6301\u7EED\u9650\u9891\uFF1A\u51B7\u5374\u671F\u5185\u4E0D\u91CD\u590D\u6574\u6BB5\u91CD\u62C9\uFF1B\u66F4\u6D45\u8BF7\u6C42\u547D\u4E2D\u7F13\u5B58\uFF1B\u66F4\u6DF1\u8BF7\u6C42\u4ECD\u91CD\u62C9", async () => {
  install({ allHistory429: true });
  await getCandles("T6-USDT-SWAP", "5m", 900);
  const first = calls;
  assert.ok(first > 0);
  await getCandles("T6-USDT-SWAP", "5m", 900);
  await getCandles("T6-USDT-SWAP", "5m", 900);
  assert.equal(calls, first, "\u5931\u8D25\u7ED3\u679C\u5FC5\u987B\u5728\u51B7\u5374\u671F\u5185\u88AB\u7F13\u5B58");
  await getCandles("T6-USDT-SWAP", "5m", 300);
  assert.equal(calls, first, "\u66F4\u6D45\u8BF7\u6C42\u5E94\u590D\u7528\u7F13\u5B58");
  await getCandles("T6-USDT-SWAP", "5m", 1200);
  assert.ok(calls > first, "\u66F4\u6DF1\u8BF7\u6C42\u5FC5\u987B\u91CD\u62C9");
});
await test("5 \u4E2A\u5E76\u53D1\u540C key \u8BF7\u6C42\u53EA\u62C9\u4E00\u6B21\uFF081 \u9996\u9875 + 3 \u5386\u53F2\u9875\uFF09", async () => {
  install();
  const rs = await Promise.all([1, 2, 3, 4, 5].map(() => getCandles("T7-USDT-SWAP", "5m", 600)));
  assert.equal(calls, 4);
  assert.ok(rs.every((r) => JSON.stringify(r.candles) === JSON.stringify(rs[0].candles)));
});
await test("\u786E\u5B9A\u6027 4xx \u4E0D\u91CD\u8BD5", async () => {
  install({ firstPageStatus: 400 });
  const r = await getCandles("T8-USDT-SWAP", "5m", 600);
  assert.equal(calls, 1);
  assert.equal(r.live, false, "\u5E94\u964D\u7EA7\u4E3A\u5408\u6210\u884C\u60C5");
});
await test("\u7F13\u5B58\u6309 symbol / bar \u9694\u79BB", async () => {
  install();
  const a = await getCandles("T9A-USDT-SWAP", "5m", 600);
  const b = await getCandles("T9B-USDT-SWAP", "15m", 600);
  assert.ok(a.candles.every((c) => c.ts % 3e5 === 0));
  assert.equal(b.live, true);
});
await test("\u53C2\u6570\u767D\u540D\u5355\uFF1A\u672A\u77E5\u6807\u7684 / \u5468\u671F\u8FD4\u56DE null\uFF0Cokx: \u524D\u7F00\u88AB\u5265\u79BB", () => {
  assert.equal(parseSymbol("FAKE-USDT-SWAP"), null);
  assert.equal(parseSymbol("okx:ETH-USDT-SWAP"), "ETH-USDT-SWAP");
  assert.equal(parseSymbol("ALL"), null);
  assert.equal(parseSymbol("ALL", { allowAll: true }), "ALL");
  assert.equal(parseSymbol(null, { fallback: "BTC-USDT-SWAP" }), "BTC-USDT-SWAP");
  assert.equal(parseBar("7m", SCAN_BARS_ALLOWED), null);
  assert.equal(parseBar("15m", SCAN_BARS_ALLOWED), "15m");
});
await test("\u6709\u754C\u7F13\u5B58\uFF1A\u8D85\u9650\u6DD8\u6C70\u6700\u65E9\u5199\u5165\uFF0C\u91CD\u590D\u5199\u5165\u5237\u65B0\u987A\u5E8F", () => {
  const m = /* @__PURE__ */ new Map();
  for (let i = 0; i < 10; i++) setBounded(m, `k${i}`, i, 3);
  assert.deepEqual([...m.keys()], ["k7", "k8", "k9"]);
  setBounded(m, "k7", 99, 3);
  setBounded(m, "k10", 10, 3);
  assert.deepEqual([...m.keys()], ["k9", "k7", "k10"]);
});
globalThis.fetch = realFetch;
console.log(`
data-layer: ${passed} \u7EC4\u65AD\u8A00\u901A\u8FC7`);
if (process.exitCode) process.exit(process.exitCode);
