// tests/realtime-transport.test.ts
import assert from "node:assert/strict";

// src/runtime/statsProxy.ts
async function fetchStatsProxy(request, nativeFetch) {
  if (request.signal.aborted) throw request.signal.reason ?? new DOMException("Request aborted", "AbortError");
  try {
    const response = await nativeFetch(request);
    if (request.signal.aborted) throw request.signal.reason ?? new DOMException("Request aborted", "AbortError");
    if (response.headers.get("content-type")?.includes("application/json")) return response;
    return Response.json({ code: "503", msg: "OKX statistics require the server-side proxy; live trades remain available", data: [] }, { status: 503 });
  } catch (error) {
    if (request.signal.aborted || error instanceof Error && error.name === "AbortError") throw error;
    return Response.json({ code: "502", msg: "Statistics proxy unavailable; no browser upstream fallback", data: [] }, { status: 502 });
  }
}

// src/lib/types.ts
var SYMBOLS = [
  { id: "BTC-USDT-SWAP", base: "BTC", label: "BTC \u6C38\u7EED", ctVal: 0.01, minTick: 0.1 },
  { id: "ETH-USDT-SWAP", base: "ETH", label: "ETH \u6C38\u7EED", ctVal: 0.1, minTick: 0.01 },
  { id: "SOL-USDT-SWAP", base: "SOL", label: "SOL \u6C38\u7EED", ctVal: 1, minTick: 0.01 }
];
function ctValOf(symbol) {
  return SYMBOLS.find((s) => s.id === symbol)?.ctVal ?? 1;
}

// src/quant/flow.ts
var REST = "https://www.okx.com";
var WS_PUBLIC = "wss://ws.okx.com/ws/v5/public";
var PAGE = 100;
var cache = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var inflight = /* @__PURE__ */ new Map();
var PERIOD_MS = { "5m": 3e5, "15m": 9e5, "30m": 18e5, "1H": 36e5, "2H": 72e5, "4H": 144e5 };
var flowKey = (instId, period) => `${instId}|${period}`;
function getFlow(instId, period) {
  return cache.get(flowKey(instId, period));
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var notify = (snap) => {
  snap.updatedAt = Date.now();
  listeners.forEach((fn) => fn(snap));
};
function emptySnapshot(instId, period) {
  return {
    instId,
    period,
    barMs: PERIOD_MS[period] ?? 3e5,
    bars: /* @__PURE__ */ new Map(),
    recent: [],
    from: Infinity,
    to: 0,
    oiFrom: Infinity,
    updatedAt: 0,
    complete: false,
    rubikComplete: false,
    rubikFailedAt: 0,
    tape: { connected: false, trades: 0, bootstrapped: false }
  };
}
function rubikBase() {
  if (typeof window === "undefined") return REST;
  try {
    const v = localStorage.getItem("pulsedesk.okx-proxy");
    if (v && /^https?:\/\//.test(v)) return v.replace(/\/$/, "");
  } catch {
  }
  return `${window.location.origin}/api/okx`;
}
async function okxGet(base, path, params, signal) {
  const url = new URL(base + path);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch(url.toString(), { signal, cache: "no-store" });
    if (res.status === 429) {
      if (attempt === 2) throw new Error("OKX rate limited (429)");
      await sleep(900 * (attempt + 1));
      continue;
    }
    if (!res.ok) throw new Error(`OKX HTTP ${res.status}`);
    const json = await res.json();
    if (json.code && json.code !== "0") throw new Error(`OKX code ${json.code}`);
    return json.data ?? [];
  }
  return [];
}
var seenBySnapshot = /* @__PURE__ */ new WeakMap();
var seenMaxBySnapshot = /* @__PURE__ */ new WeakMap();
var SEEN_KEEP = 15e4;
var SEEN_TRIM_AT = 25e4;
function aggregateFlowTrades(snap, trades, ctVal) {
  let seen = seenBySnapshot.get(snap);
  if (!seen) {
    seen = /* @__PURE__ */ new Set();
    seenBySnapshot.set(snap, seen);
  }
  let maxId = seenMaxBySnapshot.get(snap) ?? 0;
  const recentStart = Math.floor(Date.now() / snap.barMs) * snap.barMs - 2 * snap.barMs;
  for (const t of trades) {
    if (!(t.px > 0 && t.sz > 0 && ctVal > 0) || !Number.isSafeInteger(t.tradeId) || !(t.ts > 0) || !Number.isFinite(t.ts) || t.side !== "buy" && t.side !== "sell") continue;
    if (seen.has(t.tradeId)) continue;
    seen.add(t.tradeId);
    if (t.tradeId > maxId) maxId = t.tradeId;
    const ts = Math.floor(t.ts / snap.barMs) * snap.barMs;
    const notional = t.px * t.sz * ctVal;
    if (!Number.isFinite(notional)) continue;
    const current = snap.bars.get(ts);
    if (current?.src === "rubik" && ts < recentStart) continue;
    let tapeBar;
    if (ts >= recentStart) {
      const tapeBars = snap.tapeBars ??= /* @__PURE__ */ new Map();
      tapeBar = tapeBars.get(ts) ?? (current?.src === "tape" ? { ...current } : { ts, buy: 0, sell: 0, src: "tape", trades: 0 });
      tapeBars.set(ts, tapeBar);
      if (current?.oiContracts) tapeBar.oiContracts = current.oiContracts;
      if (current?.oiUsd) tapeBar.oiUsd = current.oiUsd;
    } else {
      tapeBar = current?.src === "tape" ? current : { ts, buy: 0, sell: 0, src: "tape", trades: 0 };
    }
    if (t.side === "buy") tapeBar.buy += notional;
    else tapeBar.sell += notional;
    tapeBar.trades = (tapeBar.trades ?? 0) + 1;
    if (!current || current.src === "tape" || tapeBar.buy + tapeBar.sell > current.buy + current.sell) {
      snap.bars.set(ts, tapeBar);
    }
    const recent = snap.recent ??= [];
    recent.push({ ts: t.ts, side: t.side, notional });
    if (recent.length > 5e3) {
      const cutoff = Date.now() - 18e4;
      let drop = 0;
      while (drop < recent.length && recent[drop].ts < cutoff) drop++;
      if (drop > 0) recent.splice(0, drop);
      if (recent.length > 5e3) recent.splice(0, recent.length - 5e3);
    }
    snap.tape.trades++;
    snap.from = Math.min(snap.from, ts);
    snap.to = Math.max(snap.to, ts);
  }
  if (snap.tapeBars) {
    for (const ts of snap.tapeBars.keys()) if (ts < recentStart) snap.tapeBars.delete(ts);
  }
  seenMaxBySnapshot.set(snap, maxId);
  if (seen.size > SEEN_TRIM_AT) {
    const cutoff = maxId - SEEN_KEEP;
    for (const id of seen) if (id < cutoff) seen.delete(id);
  }
}
var parseTrades = (rows) => rows.filter((r) => r && (r.side === "buy" || r.side === "sell")).map((r) => ({ ts: Number(r.ts), px: Number(r.px), sz: Number(r.sz), side: r.side, tradeId: Number(r.tradeId) })).filter((t) => t.ts > 0 && t.px > 0 && t.sz > 0 && Number.isSafeInteger(t.tradeId) && Number.isFinite(t.ts));
var tapes = /* @__PURE__ */ new Map();
function ensureTape(instId, snap) {
  let tape = tapes.get(instId);
  if (!tape) {
    tape = { instId, ws: null, closed: false, snaps: /* @__PURE__ */ new Set(), retry: null, ping: null, rollover: null, needsRepair: false };
    tapes.set(instId, tape);
    openTape(tape);
  }
  tape.snaps.add(snap);
  if (snap.tape.bootstrapped && !snap.tape.connected) tape.needsRepair = true;
  return tape;
}
function openTape(tape) {
  if (tape.closed || typeof WebSocket === "undefined") return;
  let ws;
  try {
    ws = new WebSocket(WS_PUBLIC);
  } catch {
    tape.retry = setTimeout(() => openTape(tape), 3e3);
    return;
  }
  tape.ws = ws;
  const ctVal = ctValOf(tape.instId);
  ws.onopen = () => {
    if (tape.closed) {
      ws.close();
      return;
    }
    ws.send(JSON.stringify({ op: "subscribe", args: [{ channel: "trades", instId: tape.instId }] }));
    tape.ping = setInterval(() => ws.readyState === WebSocket.OPEN && ws.send("ping"), 25e3);
    tape.snaps.forEach((s) => {
      s.tape.connected = true;
      notify(s);
    });
  };
  ws.onmessage = (ev) => {
    if (tape.closed || ev.data === "pong") return;
    try {
      const msg = JSON.parse(ev.data);
      if (msg.arg?.channel !== "trades" || !Array.isArray(msg.data)) return;
      const trades = parseTrades(msg.data);
      for (const s of tape.snaps) {
        aggregateFlowTrades(s, trades, ctVal);
        if (trades.length && !tape.rollover) {
          tape.rollover = setTimeout(() => {
            tape.rollover = null;
            tape.snaps.forEach(notify);
          }, 250);
        }
      }
    } catch {
    }
  };
  ws.onclose = () => {
    if (tape.ping) clearInterval(tape.ping);
    tape.ping = null;
    tape.snaps.forEach((s) => {
      s.tape.connected = false;
      notify(s);
    });
    if (!tape.closed) {
      tape.needsRepair = true;
      tape.retry = setTimeout(() => openTape(tape), 2e3);
    }
  };
  ws.onerror = () => ws.close();
}
function releaseTape(instId) {
  const tape = tapes.get(instId);
  if (!tape) return;
  tape.closed = true;
  tape.snaps.forEach((s) => {
    s.tape.connected = false;
    notify(s);
  });
  if (tape.retry) clearTimeout(tape.retry);
  if (tape.ping) clearInterval(tape.ping);
  if (tape.rollover) clearTimeout(tape.rollover);
  try {
    tape.ws?.close();
  } catch {
  }
  tapes.delete(instId);
}
async function bootstrapTape(snap, tape, minTs, maxPages, signal) {
  const ctVal = ctValOf(snap.instId);
  let after;
  for (let p = 0; p < maxPages; p++) {
    if (signal?.aborted || tape.closed) return;
    const params = { instId: snap.instId, limit: String(PAGE), type: "1" };
    if (after) params.after = String(after);
    const rows = await okxGet(REST, "/api/v5/market/history-trades", params, signal);
    const trades = parseTrades(rows);
    if (!trades.length) break;
    if (signal?.aborted || tape.closed) return;
    aggregateFlowTrades(snap, trades, ctVal);
    const oldest = trades.reduce((m, t) => t.tradeId < m.tradeId ? t : m, trades[0]);
    after = oldest.tradeId;
    if (oldest.ts <= minTs) break;
    if (p % 15 === 14) notify(snap);
    await sleep(220);
  }
  snap.tape.bootstrapped = true;
}
var MAX_FLOW_BARS = 12e3;
function trimFlowBars(snap) {
  if (snap.bars.size <= MAX_FLOW_BARS) return;
  const keys = [...snap.bars.keys()].sort((a, b) => a - b);
  const drop = keys.length - MAX_FLOW_BARS;
  for (let i = 0; i < drop; i++) snap.bars.delete(keys[i]);
  if (keys.length > drop) snap.from = Math.max(snap.from, keys[drop]);
}
async function syncRubik(snap, base, minTs, maxPages, oiPages, signal) {
  const { instId, period } = snap;
  const takerStopTs = snap.rubikComplete && (snap.syncedPages ?? 0) >= maxPages && snap.to > 0 ? Math.max(minTs, snap.to - snap.barMs) : minTs;
  const oiStopTs = snap.rubikComplete && (snap.syncedOiPages ?? 0) >= oiPages && (snap.oiTo ?? 0) > 0 ? Math.max(minTs, snap.oiTo - snap.barMs) : Math.max(minTs, snap.from);
  const syncTaker = async () => {
    let end;
    for (let pages = 0; pages < maxPages; pages++) {
      const params = { instId, period, unit: "2", limit: String(PAGE) };
      if (end) params.end = String(end);
      const rows = await okxGet(base, "/api/v5/rubik/stat/taker-volume-contract", params, signal);
      if (!rows.length) break;
      let nonZero = 0;
      let oldest = Infinity;
      for (const r of rows) {
        const ts = Number(r[0]);
        const sell = Number(r[1]);
        const buy = Number(r[2]);
        if (!Number.isFinite(ts)) continue;
        oldest = Math.min(oldest, ts);
        if (!(buy > 0 || sell > 0)) continue;
        if (ts + snap.barMs > Date.now()) continue;
        nonZero++;
        const prev = snap.bars.get(ts);
        const tapeTotal = prev && prev.src === "tape" ? prev.buy + prev.sell : 0;
        if (tapeTotal > buy + sell) continue;
        snap.bars.set(ts, { ts, buy, sell, oiContracts: prev?.oiContracts, oiUsd: prev?.oiUsd, src: "rubik" });
        snap.from = Math.min(snap.from, ts);
        snap.to = Math.max(snap.to, ts);
      }
      if (!nonZero || !Number.isFinite(oldest) || oldest <= takerStopTs) break;
      end = oldest;
      if (pages + 1 < maxPages) await sleep(410);
    }
    snap.syncedPages = Math.max(snap.syncedPages ?? 0, maxPages);
  };
  const syncOi = async () => {
    let oiEnd;
    for (let p = 0; p < oiPages; p++) {
      const params = { instId, period, limit: String(PAGE) };
      if (oiEnd) params.end = String(oiEnd);
      const rows = await okxGet(base, "/api/v5/rubik/stat/contracts/open-interest-history", params, signal);
      if (!rows.length) break;
      let oldest = Infinity;
      for (const r of rows) {
        const ts = Number(r[0]);
        const oiContracts = Number(r[1]);
        const oiUsd = Number(r[3]);
        if (!Number.isFinite(ts) || !(oiContracts > 0) && !(oiUsd > 0)) continue;
        oldest = Math.min(oldest, ts);
        const prev = snap.bars.get(ts);
        if (prev) {
          prev.oiContracts = oiContracts > 0 ? oiContracts : void 0;
          prev.oiUsd = oiUsd > 0 ? oiUsd : void 0;
        } else {
          snap.bars.set(ts, {
            ts,
            buy: 0,
            sell: 0,
            oiContracts: oiContracts > 0 ? oiContracts : void 0,
            oiUsd: oiUsd > 0 ? oiUsd : void 0,
            src: "rubik"
          });
        }
        snap.oiFrom = Math.min(snap.oiFrom, ts);
        snap.oiTo = Math.max(snap.oiTo ?? 0, ts);
      }
      const stop = oiStopTs > 0 ? oiStopTs : Math.max(minTs, snap.from);
      if (!Number.isFinite(oldest) || oldest <= stop) break;
      oiEnd = oldest;
      if (p + 1 < oiPages) await sleep(410);
    }
    snap.syncedOiPages = Math.max(snap.syncedOiPages ?? 0, oiPages);
  };
  await Promise.all([syncTaker(), syncOi()]);
  trimFlowBars(snap);
}
function syncFlow(instId, period, opts) {
  const key = flowKey(instId, period);
  const running = inflight.get(key);
  if (running && !running.signal?.aborted) return running.promise;
  const job = (async () => {
    const snap = cache.get(key) ?? emptySnapshot(instId, period);
    cache.set(key, snap);
    if (opts.signal?.aborted) return snap;
    const liveTape = typeof window !== "undefined" ? ensureTape(instId, snap) : null;
    const base = rubikBase();
    try {
      const rubikCooling = !!snap.rubikFailedAt && Date.now() - snap.rubikFailedAt < 5 * 6e4;
      if (base && !rubikCooling) {
        try {
          await syncRubik(snap, base, opts.minTs, opts.maxPages ?? 16, opts.oiPages ?? 12, opts.signal);
          snap.rubikComplete = true;
          snap.rubikFailedAt = 0;
          snap.complete = true;
        } catch (e) {
          if (!opts.signal?.aborted) {
            snap.rubikFailedAt = Date.now();
            console.warn("[\u8BA2\u5355\u6D41] rubik \u7EDF\u8BA1\u4E0D\u53EF\u7528\uFF0C\u6539\u7528\u9010\u7B14\u6210\u4EA4\uFF1A", e);
          }
        }
      }
      if (opts.signal?.aborted) return snap;
      if (liveTape) {
        const tape = liveTape;
        if (snap.tape.bootstrapped && shouldRepairFlow(snap, tape.needsRepair)) {
          const repairMin = Math.floor(Date.now() / snap.barMs) * snap.barMs - 2 * snap.barMs;
          await bootstrapTape(snap, tape, repairMin, 24, opts.signal);
          tape.needsRepair = false;
          snap.repairedAt = Date.now();
        }
        if (!snap.tape.bootstrapped) {
          const rawBars = opts.bootstrapBars ?? 8;
          const targetBars = snap.rubikComplete ? Math.min(rawBars, 2) : rawBars;
          const recent = Math.floor(Date.now() / snap.barMs) * snap.barMs - targetBars * snap.barMs;
          await bootstrapTape(snap, tape, Math.max(opts.minTs, recent), opts.bootstrapPages ?? 220, opts.signal);
        }
        snap.complete = true;
      }
    } catch (e) {
      if (!opts.signal?.aborted) console.warn("[\u8BA2\u5355\u6D41] OKX \u540C\u6B65\u5931\u8D25\uFF1A", e);
    }
    notify(snap);
    return snap;
  })();
  inflight.set(key, { promise: job, signal: opts.signal });
  job.finally(() => {
    if (inflight.get(key)?.promise === job) inflight.delete(key);
  });
  return job;
}
function shouldRepairFlow(snap, needsRepair, now = Date.now()) {
  const stale = snap.to > 0 && now - snap.to > snap.barMs * 2;
  if (!needsRepair && !stale) return false;
  return now - (snap.repairedAt ?? 0) > snap.barMs;
}

// tests/realtime-transport.test.ts
var req = () => new Request("http://localhost/api/okx/api/v5/rubik/stat/taker-volume-contract");
var calls = 0;
{
  const error = Response.json({ code: "502", data: [] }, { status: 502 });
  assert.equal(await fetchStatsProxy(req(), async () => {
    calls++;
    return error;
  }), error);
  assert.equal(calls, 1, "do not retry direct to non-CORS upstream after a proxy error");
  const html = await fetchStatsProxy(req(), async () => new Response("<!doctype html>", { headers: { "content-type": "text/html" } }));
  assert.equal(html.status, 503);
  assert.deepEqual((await html.json()).data, []);
  const ctl = new AbortController();
  const r = new Request(req(), { signal: ctl.signal });
  ctl.abort();
  const before = calls;
  await assert.rejects(fetchStatsProxy(r, async () => {
    calls++;
    return Response.json({ data: [] });
  }), { name: "AbortError" });
  assert.equal(calls, before);
  await assert.rejects(fetchStatsProxy(req(), async () => {
    throw new DOMException("aborted", "AbortError");
  }), { name: "AbortError" });
  console.log("PASS proxy JSON errors pass through, HTML is not statistics, abort never becomes upstream CORS fallback");
}
{
  const g = globalThis;
  const original = { window: g.window, WebSocket: g.WebSocket, fetch: globalThis.fetch };
  const sockets = [];
  class FakeSocket {
    constructor() {
      this.readyState = 0;
      this.onopen = null;
      this.onclose = null;
      sockets.push(this);
    }
    static {
      this.OPEN = 1;
    }
    send() {
    }
    close() {
      this.readyState = 3;
      this.onclose?.();
    }
  }
  try {
    g.window = { location: { origin: "http://localhost" } };
    g.WebSocket = FakeSocket;
    const ctl = new AbortController();
    globalThis.fetch = (async (_input, init) => new Promise((_resolve, reject) => {
      init?.signal?.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")), { once: true });
    }));
    const pending = syncFlow("BTC-USDT-SWAP", "5m", { minTs: 0, maxPages: 1, oiPages: 0, bootstrapPages: 0, signal: ctl.signal });
    assert.equal(sockets.length, 1, "live WebSocket must exist before the first history response");
    ctl.abort();
    await pending;
    assert.equal(getFlow("BTC-USDT-SWAP", "5m").rubikFailedAt, 0, "user cancellation is not a 5-minute upstream outage");
    releaseTape("BTC-USDT-SWAP");
    let requests = 0;
    globalThis.fetch = (async () => {
      requests++;
      return Response.json({ code: "0", data: [] });
    });
    await syncFlow("BTC-USDT-SWAP", "5m", { minTs: 0, maxPages: 1, oiPages: 0, bootstrapPages: 0 });
    assert.equal(sockets.length, 2);
    assert.ok(requests > 0, "re-enable must retry statistics rather than inherit cancellation cooldown");
    console.log("PASS live tape connects before history; cancellation does not block immediate re-subscription");
  } finally {
    releaseTape("BTC-USDT-SWAP");
    globalThis.fetch = original.fetch;
    if (original.window === void 0) delete g.window;
    else g.window = original.window;
    g.WebSocket = original.WebSocket;
  }
}
