// tests/annot-layout.test.ts
import assert from "node:assert/strict";

// src/vela/annotLayout.ts
var intersects = (a, b, pad = 0) => a.x < b.x + b.w + pad && b.x < a.x + a.w + pad && a.y < b.y + b.h + pad && b.y < a.y + a.h + pad;
var inside = (r, b) => r.x >= b.x && r.y >= b.y && r.x + r.w <= b.x + b.w && r.y + r.h <= b.y + b.h;
function mergeLevels(levels, gapPx = 6) {
  const sorted = levels.filter((l) => Number.isFinite(l.y)).sort((a, b) => a.y - b.y || b.priority - a.priority);
  const out = [];
  for (const l of sorted) {
    const g = out[out.length - 1];
    if (g && l.y - g.yBottom <= gapPx) {
      g.items.push(l);
      g.yBottom = l.y;
      g.lo = Math.min(g.lo, l.price);
      g.hi = Math.max(g.hi, l.price);
      if (l.priority > g.lead.priority) g.lead = l;
    } else {
      out.push({ lead: l, items: [l], y: l.y, yTop: l.y, yBottom: l.y, lo: l.price, hi: l.price });
    }
  }
  for (const g of out) g.y = g.lead.y;
  return out;
}
function layoutRail(items, top, bottom, opts = {}) {
  const gap = opts.gap ?? 2;
  const win = opts.window ?? 60;
  const maxPer = opts.maxPerWindow ?? 4;
  const maxTotal = opts.maxTotal ?? Infinity;
  const visible = items.filter((it) => Number.isFinite(it.y) && it.y >= top - it.h / 2 && it.y <= bottom + it.h / 2);
  const byPriority = [...visible].sort((a, b) => b.priority - a.priority || a.y - b.y || (a.id < b.id ? -1 : 1));
  const kept = [];
  for (const it of byPriority) {
    const crowd = kept.filter((k) => Math.abs(k.it.y - it.y) < win / 2).length;
    if (kept.length < maxTotal && crowd < maxPer) {
      kept.push({ it, folded: [] });
      continue;
    }
    let host = kept[0];
    for (const k of kept) if (Math.abs(k.it.y - it.y) < Math.abs(host.it.y - it.y)) host = k;
    host?.folded.push(it.id);
  }
  const sorted = kept.sort((a, b) => a.it.y - b.it.y || (a.it.id < b.it.id ? -1 : 1));
  const clusters = [];
  const settle = (c) => {
    let s = 0;
    for (const m of c.members) s += m.it.y - m.it.h / 2 - m.offset;
    c.top = s / c.members.length;
    c.top = Math.min(c.top, bottom - c.size);
    c.top = Math.max(c.top, top);
  };
  for (const k of sorted) {
    clusters.push({ members: [{ ...k, offset: 0 }], size: k.it.h, top: 0 });
    settle(clusters[clusters.length - 1]);
    while (clusters.length >= 2) {
      const b = clusters[clusters.length - 1];
      const a = clusters[clusters.length - 2];
      if (a.top + a.size + gap <= b.top) break;
      const base = a.size + gap;
      for (const m of b.members) a.members.push({ ...m, offset: m.offset + base });
      a.size = base + b.size;
      clusters.pop();
      settle(a);
    }
  }
  const out = [];
  for (const c of clusters) for (const m of c.members) out.push({ id: m.it.id, y: c.top + m.offset + m.it.h / 2, desiredY: m.it.y, folded: m.folded });
  return out;
}
function buildOccupancy(cols, halfWidth) {
  const cs = [...cols].sort((a, b) => a.x - b.x);
  const firstAtOrAfter = (x) => {
    let lo = 0;
    let hi = cs.length;
    while (lo < hi) {
      const mid = lo + hi >> 1;
      if (cs[mid].x < x) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  };
  return {
    span(x0, x1) {
      let top = Infinity;
      let bottom = -Infinity;
      for (let i = firstAtOrAfter(x0 - halfWidth); i < cs.length && cs[i].x <= x1 + halfWidth; i++) {
        top = Math.min(top, cs[i].top);
        bottom = Math.max(bottom, cs[i].bottom);
      }
      return top === Infinity ? null : { top, bottom };
    },
    hits(r, pad = 1) {
      for (let i = firstAtOrAfter(r.x - halfWidth - pad); i < cs.length && cs[i].x <= r.x + r.w + halfWidth + pad; i++) {
        const c = cs[i];
        if (c.top - pad < r.y + r.h && r.y < c.bottom + pad) return true;
      }
      return false;
    }
  };
}
function isFree(r, occ, taken, bounds) {
  if (!inside(r, bounds)) return false;
  if (occ.hits(r)) return false;
  for (const t of taken) if (intersects(r, t, 2)) return false;
  return true;
}
function pickCandidate(cands, occ, taken, bounds, prevKey) {
  let best = null;
  let bestCost = Infinity;
  for (const c of cands) {
    if (!isFree(c.rect, occ, taken, bounds)) continue;
    const cost = c.cost - (prevKey && c.key === prevKey ? 30 : 0);
    if (cost < bestCost) {
      best = c;
      bestCost = cost;
    }
  }
  return best;
}
function eventCandidates(g, occ) {
  const out = [];
  const shifts = [0, 0.6, -0.6, 1.2, -1.2, 2, -2];
  const lifts = [0, 12, 26, 44];
  for (const side of [g.side, g.side === "above" ? "below" : "above"]) {
    const flip = side !== g.side;
    for (const s of shifts) {
      const x = g.x + s * g.w - g.w / 2;
      const span = occ.span(x, x + g.w);
      for (const lift of lifts) {
        let y;
        if (side === "above") {
          const ref = Math.min(flip ? Infinity : g.markerEdge, span ? span.top : Infinity);
          y = (Number.isFinite(ref) ? ref : g.markerEdge) - 4 - g.h - lift;
        } else {
          const ref = Math.max(flip ? -Infinity : g.markerEdge, span ? span.bottom : -Infinity);
          y = (Number.isFinite(ref) ? ref : g.markerEdge) + 4 + lift;
        }
        const dist = Math.abs((side === "above" ? y + g.h : y) - g.markerEdge);
        out.push({
          rect: { x, y, w: g.w, h: g.h },
          cost: Math.abs(s) * 18 + lift * 0.8 + dist * 0.25 + (flip ? 60 : 0),
          key: `${side}:${s}:${lift}`
        });
      }
    }
  }
  return out;
}
function zoneCandidates(box, w, h, occ) {
  const right = box.x + box.w - w - 4;
  const span = occ?.span(right, right + w);
  const beyond = span ? [
    { rect: { x: right, y: span.top - h - 4, w, h }, cost: 30, key: "over-candles" },
    { rect: { x: right, y: span.bottom + 4, w, h }, cost: 32, key: "under-candles" }
  ] : [];
  return [
    ...beyond,
    { rect: { x: right, y: box.y + 3, w, h }, cost: 0, key: "in-top" },
    { rect: { x: right, y: box.y + box.h - h - 3, w, h }, cost: 5, key: "in-bottom" },
    { rect: { x: right, y: box.y - h - 3, w, h }, cost: 10, key: "above" },
    { rect: { x: right, y: box.y + box.h + 3, w, h }, cost: 12, key: "below" },
    { rect: { x: box.x + 4, y: box.y - h - 3, w, h }, cost: 20, key: "above-left" },
    { rect: { x: box.x + 4, y: box.y + box.h + 3, w, h }, cost: 22, key: "below-left" }
  ];
}
function placeCard(cursor, w, h, bounds, offset = 14) {
  let x = cursor.x + offset;
  let y = cursor.y + offset;
  if (x + w > bounds.x + bounds.w) x = cursor.x - offset - w;
  if (y + h > bounds.y + bounds.h) y = cursor.y - offset - h;
  x = Math.max(bounds.x + 2, Math.min(x, bounds.x + bounds.w - w - 2));
  y = Math.max(bounds.y + 2, Math.min(y, bounds.y + bounds.h - h - 2));
  return { x, y, w, h };
}
function wrapText(text, maxW, measure) {
  const out = [];
  let line = "";
  for (const ch of text) {
    const next = line + ch;
    if (line && measure(next) > maxW) {
      out.push(line);
      line = ch.trimStart();
    } else {
      line = next;
    }
  }
  if (line) out.push(line);
  return out;
}

// tests/annot-layout.test.ts
var H = 14;
{
  const lv = (id, y, price, priority = 50) => ({ id, y, price, priority });
  const zoomedOut = mergeLevels([lv("a", 100, 93.78), lv("b", 103, 93.76, 90), lv("c", 108, 93.7), lv("d", 200, 92)], 6);
  assert.equal(zoomedOut.length, 2, "6px \u5185\u7684\u5173\u952E\u4F4D\u5408\u5E76\u6210\u4E00\u6761");
  assert.equal(zoomedOut[0].lead.id, "b", "\u5408\u5E76\u7EC4\u7531\u4F18\u5148\u7EA7\u6700\u9AD8\u7684\u4EE3\u8868");
  assert.equal(zoomedOut[0].y, 103, "\u7EBF\u753B\u5728\u4EE3\u8868\u9879\u7684\u4EF7\u4F4D\u4E0A");
  assert.deepEqual([zoomedOut[0].lo, zoomedOut[0].hi], [93.7, 93.78]);
  const zoomedIn = mergeLevels([lv("a", 100, 93.78), lv("b", 130, 93.76), lv("c", 170, 93.7)], 6);
  assert.equal(zoomedIn.length, 3, "\u653E\u5927\u540E\u5206\u5F00");
  console.log("PASS \u5173\u952E\u4F4D\u5408\u5E76 \xB7 \u7F29\u5C0F\u5408\u5E76 / \u653E\u5927\u5206\u5F00");
}
{
  const items = [0, 1, 2, 3, 4].map((i) => ({ id: `l${i}`, y: 100 + i, h: H, priority: 50 + i }));
  const out = layoutRail(items, 0, 400, { gap: 2, window: 60, maxPerWindow: 4 });
  assert.equal(out.length, 4, "60px \u5185\u6700\u591A 4 \u4E2A");
  assert.equal(out.reduce((s, o) => s + o.folded.length, 0), 1, "\u591A\u51FA\u6765\u7684\u6298\u53E0\u6210 +1");
  assert.ok(!out.some((o) => o.id === "l0"), "\u6298\u53E0\u7684\u662F\u4F18\u5148\u7EA7\u6700\u4F4E\u7684");
  const ys = out.map((o) => o.y).sort((a2, b2) => a2 - b2);
  for (let i = 1; i < ys.length; i++) assert.ok(ys[i] - ys[i - 1] >= H + 2 - 1e-9, "\u8F68\u9053\u6807\u7B7E\u4E0D\u91CD\u53E0");
  const edge = layoutRail(
    [0, 1, 2].map((i) => ({ id: `e${i}`, y: 398 + i, h: H, priority: 50 })),
    0,
    400
  );
  for (const o of edge) assert.ok(o.y + H / 2 <= 400 + 1e-9 && o.y - H / 2 >= 0, "\u8D34\u5E95\u65F6\u6574\u4F53\u4E0A\u63A8\uFF0C\u4E0D\u51FA\u754C");
  const a = layoutRail(items.slice(1), 0, 400);
  const b = layoutRail([...items.slice(1), { id: "far", y: 380, h: H, priority: 10 }], 0, 400);
  for (const o of a) assert.equal(b.find((x) => x.id === o.id).y, o.y, "\u8FDC\u5904\u6807\u7B7E\u4E0D\u5F71\u54CD\u8FD1\u5904\u6392\u7248");
  console.log("PASS \u53F3\u4FA7\u8F68\u9053 \xB7 \u63A8\u5F00 / \u8D34\u8FB9 / +N / \u7A33\u5B9A");
}
function candles(n, x0, step, f) {
  return Array.from({ length: n }, (_, i) => {
    const [top, bottom] = f(i);
    return { x: x0 + i * step, top, bottom };
  });
}
{
  const bounds = { x: 0, y: 0, w: 800, h: 400 };
  const cols = candles(40, 20, 8, (i) => i === 11 || i === 12 ? [40, 260] : [200 - (i === 10 ? 20 : 0), 260]);
  const occ = buildOccupancy(cols, 3);
  const ev = cols[10];
  const markerEdge = ev.top - 3 - 10;
  const cands = eventCandidates({ x: ev.x, markerEdge, side: "above", w: 64, h: H }, occ);
  const pick = pickCandidate(cands, occ, [], bounds);
  assert.ok(pick, "\u5E94\u80FD\u627E\u5230\u4F4D\u7F6E");
  assert.ok(!occ.hits(pick.rect), "\u6807\u7B7E\u4E0D\u538B K \u7EBF");
  assert.ok(inside(pick.rect, bounds), "\u6807\u7B7E\u5728\u7ED8\u56FE\u533A\u5185");
  assert.ok(pick.rect.y + pick.rect.h <= 40 || pick.rect.x + pick.rect.w < cols[11].x - 3 || pick.rect.y >= 260, "\u88AB\u957F\u5F71\u7EBF\u6321\u4F4F\u65F6\u7ED5\u5F00");
  const full = buildOccupancy(candles(100, 0, 8, () => [0, 400]), 3);
  assert.equal(pickCandidate(eventCandidates({ x: 400, markerEdge: 10, side: "above", w: 64, h: H }, full), full, [], bounds), null);
  console.log("PASS \u4E8B\u4EF6\u6807\u7B7E \xB7 \u7ED5\u5F00 K \u7EBF / \u653E\u4E0D\u4E0B\u53EA\u7559\u6807\u8BB0");
}
{
  const bounds = { x: 0, y: 0, w: 800, h: 400 };
  const cols = candles(60, 10, 8, () => [150, 250]);
  const occ = buildOccupancy(cols, 3);
  const box = { x: 200, y: 180, w: 200, h: 40 };
  const pick = pickCandidate(zoneCandidates(box, 50, H, occ), occ, [], bounds);
  assert.ok(pick && !occ.hits(pick.rect), "\u533A\u57DF\u6807\u7B7E\u4E0D\u538B K \u7EBF");
  console.log("PASS \u533A\u57DF\u6807\u7B7E \xB7 \u6846\u5185\u88AB\u5360\u65F6\u79FB\u5230\u6846\u5916", pick.key);
}
{
  let seed = 42;
  const rnd = () => (seed = seed * 1664525 + 1013904223 >>> 0) / 2 ** 32;
  const bounds = { x: 0, y: 0, w: 900, h: 420 };
  let placedTotal = 0;
  for (let t = 0; t < 300; t++) {
    let px = 210;
    const cols = candles(100, 4, 8, () => {
      px += (rnd() - 0.5) * 18;
      px = Math.max(40, Math.min(380, px));
      const top = px - rnd() * 30;
      return [top, top + 8 + rnd() * 40];
    });
    const occ = buildOccupancy(cols, 3);
    const taken = [{ x: 0, y: 0, w: 320, h: 44 }];
    const lastX = cols[cols.length - 1].x;
    const rail = layoutRail(
      Array.from({ length: 12 }, (_, i) => ({ id: `r${i}`, y: 20 + rnd() * 380, h: H, priority: rnd() * 100 })),
      2,
      418
    );
    const railRects = rail.map((r) => ({ x: 900 - 4 - 60, y: r.y - H / 2, w: 60, h: H }));
    for (const r of railRects) {
      assert.ok(r.x > lastX + 4, "\u8F68\u9053\u5728\u6700\u65B0 K \u7EBF\u53F3\u4FA7\u7684\u7A7A\u767D\u91CC");
      assert.ok(!occ.hits(r));
      taken.push(r);
    }
    const placed = [...railRects];
    for (let e = 0; e < 6; e++) {
      const c = cols[5 + Math.floor(rnd() * 95)];
      const side = rnd() > 0.5 ? "above" : "below";
      const edge = side === "above" ? c.top - 13 : c.bottom + 13;
      const mr = { x: c.x - 5, y: Math.min(edge, side === "above" ? c.top - 3 : c.bottom + 3), w: 10, h: 10 };
      taken.push(mr);
      const w = 40 + Math.floor(rnd() * 40);
      const pick = pickCandidate(eventCandidates({ x: c.x, markerEdge: edge, side, w, h: H }, occ), occ, taken, bounds);
      if (!pick) continue;
      assert.ok(!occ.hits(pick.rect), "\u4E0D\u538B K \u7EBF");
      assert.ok(inside(pick.rect, bounds), "\u4E0D\u51FA\u754C");
      for (const p of placed) assert.ok(!intersects(pick.rect, p), "\u6807\u7B7E\u4E92\u4E0D\u91CD\u53E0");
      placed.push(pick.rect);
      taken.push(pick.rect);
      placedTotal++;
    }
    const ys = rail.map((r) => r.y).sort((a, b) => a - b);
    for (let i = 1; i < ys.length; i++) assert.ok(ys[i] - ys[i - 1] >= H + 2 - 1e-9);
  }
  assert.ok(placedTotal > 1200, `\u5927\u90E8\u5206\u4E8B\u4EF6\u5E94\u80FD\u653E\u4E0B\u6807\u7B7E\uFF08${placedTotal}/1800\uFF09`);
  console.log(`PASS \u968F\u673A\u538B\u529B\u6D4B\u8BD5 \xB7 300 \u4E2A\u573A\u666F \xB7 ${placedTotal}/1800 \u4E2A\u4E8B\u4EF6\u6807\u7B7E\u5168\u90E8\u5408\u6CD5`);
}
{
  const cols = candles(220, 2, 4, (i) => [150 + Math.sin(i / 7) * 60, 190 + Math.sin(i / 7) * 60]);
  const bounds = { x: 0, y: 0, w: 1100, h: 480 };
  const runs = 300;
  const t0 = performance.now();
  for (let k = 0; k < runs; k++) {
    const occ = buildOccupancy(cols, 1.5);
    const taken = [];
    const groups = mergeLevels(Array.from({ length: 50 }, (_, i) => ({ id: `m${i}`, y: i * 37 % 470, price: i, priority: i })), 6);
    layoutRail(groups.map((g) => ({ id: g.lead.id, y: g.y, h: H, priority: g.lead.priority })), 2, 478);
    for (let e = 0; e < 20; e++) {
      const c = cols[10 + e * 9];
      const p = pickCandidate(eventCandidates({ x: c.x, markerEdge: c.top - 13, side: "above", w: 60, h: H }, occ), occ, taken, bounds);
      if (p) taken.push(p.rect);
    }
  }
  const per = (performance.now() - t0) / runs;
  assert.ok(per < 1, `\u6BCF\u5E27\u6392\u7248 ${per.toFixed(3)}ms \u5E94 < 1ms`);
  console.log(`PASS \u6027\u80FD \xB7 \u6BCF\u5E27\u6392\u7248 ${per.toFixed(3)}ms`);
}
{
  const b = { x: 0, y: 0, w: 500, h: 300 };
  const r = placeCard({ x: 490, y: 290 }, 200, 80, b);
  assert.ok(inside(r, b) && r.x + r.w <= 490 && r.y + r.h <= 290, "\u9760\u53F3\u4E0B\u89D2\u65F6\u7FFB\u5230\u9F20\u6807\u5DE6\u4E0A");
  const lines = wrapText("\u51B2\u5411\u524D\u9AD8\u65F6\u4E3B\u52A8\u4E70\u5165\u504F\u5F31\uFF08+3%\uFF09\uFF1A\u7F3A\u5C11\u7A81\u7834\u52A8\u80FD", 60, (s) => s.length * 10);
  assert.ok(lines.length > 1 && lines.every((l) => l.length * 10 <= 60));
  console.log("PASS \u60AC\u505C\u5361\u7247\u7FFB\u8F6C \xB7 \u6298\u884C");
}
console.log("\n\u6807\u6CE8\u6392\u7248\u6D4B\u8BD5\u5168\u90E8\u901A\u8FC7");
