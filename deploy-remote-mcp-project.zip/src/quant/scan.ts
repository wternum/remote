import type { Candle, PatternId, Side } from '@/lib/types';
import {
  DEFAULT_PARAMS,
  FEE_RATE,
  SLIP_RATE,
  MAX_HOLD_5M,
  MAX_HOLD_15M,
  scanDoubles,
  type ScanSignal,
} from '../../remote/setup-mcp-project-locally/src/lib/engine';
import { FACTORS, FACTOR_INDEX, clamp, scoreEvidence, gradeOf, type FactorKey } from './model';
import type { EntryMode } from './config';
import { buildContext, type Ctx } from './context';
import { legsOf, pivotOf, readSecondTest, type FlowSource, type SecondTestRead, type TrapKind } from './orderflow';
import type { FlowSnapshot } from './flow';

export { buildContext, type Ctx };

export interface LiveFlow {
  /** 十档盘口失衡度 -1..1 */
  bookImb?: number | null;
  /** 大单主动成交偏向 -1..1 */
  bigBias?: number | null;
  /** 确认K成交量 / 近 20 根均量 */
  volRatio?: number | null;
}

export interface Outcome {
  filled: boolean;
  /** 未成交为 gap；成交为 tp / sl / time / be（保本离场） */
  why: string;
  entryPrice: number;
  entryTs: number;
  exitPrice: number;
  exitTs: number;
  r: number;
  pnlPct: number;
  holdingBars: number;
  costR: number;
}

export interface Candidate {
  id: string;
  idx: number;
  ts: number;
  side: Side;
  pattern: PatternId;
  mode: EntryMode;
  level: number;
  neck: number;
  firstTs: number;
  secondTs: number;
  entry: number;
  stop: number;
  tp: number;
  /** 原项目的结构强度 0-100 */
  structure: number;
  proba: number;
  grade: 'A' | 'B' | 'C' | 'D';
  evidence: (number | null)[];
  /** 出网时可省略：由 evidence × weight × gain 还原 */
  parts?: number[];
  tags: string[];
  note: string;
  rr: number;
  heightAtr: number;
  spanBars: number;
  live: boolean;
  sym?: string;
  bar?: string;
  outcome: Outcome | null;
  /** 五种出场方案的结果一次算好，面板切换方案时无需再请求 */
  exits?: Partial<Record<ExitPlan, Outcome | null>>;
  /** 诱多 / 诱空判定（扫损 + 订单流） */
  trap: TrapKind;
  trapScore: number;
  /** 订单流数据来源：taker = OKX 真实主动成交；approx = K 线近似 */
  flowSource: FlowSource;
  /** 二次测试判读一句话 */
  headline: string;
  /** 完整订单流判读（面板展示用） */
  read: SecondTestRead;
}

export interface ScanPayload {
  symbol: string;
  bar: string;
  live: boolean;
  from: number;
  to: number;
  bars: number;
  lastTs: number;
  generatedAt: number;
  barMs: number;
  maxHold: number;
  factors: { key: FactorKey; label: string; short: string; hint: string; group: string; weight: number; liveOnly: boolean }[];
  confirm: Candidate[];
  touch: Candidate[];
  model: { base: number; gain: number };
}

const r6 = (v: number) => (Number.isFinite(v) ? Number(v.toFixed(v >= 1000 ? 2 : 6)) : 0);
const r3 = (v: number) => (Number.isFinite(v) ? Number(v.toFixed(3)) : 0);
const r1 = (v: number) => (Number.isFinite(v) ? Number(v.toFixed(1)) : 0);

const sum = (arr: number[], from: number, to: number) => {
  let s = 0;
  for (let i = Math.max(0, from); i <= Math.min(arr.length - 1, to); i++) s += arr[i];
  return s;
};

/**
 * 计算全部因子的证据值。
 * dir = +1（做多双底）/ -1（做空双顶），所有方向性因子统一按 dir 归一，
 * 因此模型对两侧使用同一套权重，不额外拟合。
 * 订单流因子优先使用真实主动买卖差（OKX taker volume），无覆盖时退回 K 线近似。
 */
export function collectEvidence(ctx: Ctx, sig: ScanSignal, live?: LiveFlow): (number | null)[] {
  const { cs, n, atr, delta, vols, ema20, ema50, volMa } = ctx;
  const i = Math.min(sig.idx, n - 1);
  const a = Math.max(atr[i] || 0, 1e-9);
  const pv = pivotOf(ctx, sig);
  const dir = sig.side === 'long' ? 1 : -1;
  const out: (number | null)[] = new Array(FACTORS.length).fill(null);
  // 触价挂单在触及关键位当根成交，并不存在随后的拒绝/确认K：
  // 相关“确认K”证据必须记为缺失，而不是拿信号K本身充当确认K（会系统性压低 touch 概率）。
  const isTouch = sig.fill === 'limit';
  const { l1a, l1b, l2a, l2b } = legsOf(pv);
  const read = readSecondTest(ctx, sig);

  const set = (key: FactorKey, v: number | null) => {
    out[FACTOR_INDEX[key]] = v == null || !Number.isFinite(v) ? null : clamp(v);
  };

  // 1) 二次测试缩量：单位根成交量对比
  const v1 = sum(vols, l1a, l1b) / Math.max(1, l1b - l1a + 1);
  const v2 = sum(vols, l2a, l2b) / Math.max(1, l2b - l2a + 1);
  set('volDiverge', v1 + v2 > 0 ? ((v1 - v2) / ((v1 + v2) / 2)) * 1.1 : 0);

  // 2) 主动成交差背离（两腿 delta/vol 之差）
  set('deltaDiverge', read.legDeltaDiff);

  // 3) 关键位吸收（测试窗口）
  set('absorption', (read.absorption.count - read.absorption.breach) / 2);

  // 4) 拒绝影线 + 确认K收盘位置
  const deepest = cs[read.test.idx];
  const dr = Math.max(1e-9, deepest.h - deepest.l);
  const tail = dir > 0 ? (Math.min(deepest.o, deepest.c) - deepest.l) / dr : (deepest.h - Math.max(deepest.o, deepest.c)) / dr;
  const cb = cs[i];
  const cRange = Math.max(1e-9, cb.h - cb.l);
  const closePos = (cb.c - cb.l) / cRange;
  set(
    'wickReject',
    (tail - 0.3) * 1.8 + (isTouch ? 0 : (dir > 0 ? closePos - 0.5 : 0.5 - closePos) * 1.6),
  );

  // 5-7) 仅实时可得的盘口 / 成交带因子
  if (live) {
    set('thrustVolume', isTouch || live.volRatio == null ? null : ((live.volRatio || 0) - 1) / 1.0);
    set('bookImbalance', live.bookImb == null ? null : (live.bookImb || 0) * 2 * dir);
    set('tapeBias', live.bigBias == null ? null : (live.bigBias || 0) * 1.5 * dir);
  }

  // 8) 关键位完整度：测试次数、期间是否收盘击穿、扫损回收
  const to = Math.min(n - 1, Math.max(i, pv.second));
  let touches = 0;
  let broken = false;
  for (let q = Math.max(0, pv.first); q <= to; q++) {
    const c = cs[q];
    const extreme = dir > 0 ? c.l : c.h;
    if (Math.abs(extreme - pv.level) <= 0.25 * a) touches++;
    if (dir > 0 ? c.c < pv.level - 0.15 * a : c.c > pv.level + 0.15 * a) broken = true;
  }
  const sweepReclaim = read.sweep.occurred && read.confirm.closedInside;
  set('levelIntegrity', 0.4 - (Math.min(touches, 5) - 2) * 0.3 + (sweepReclaim ? 0.35 : 0) - (broken ? 0.6 : 0));

  // 9) 形态高度（ATR）
  const height = (pv.neckPrice - pv.level) * dir;
  set('patternHeight', (height / a - 2.2) / 2.5);

  // 10) 时间跨度：对数最优区间
  const span = Math.max(1, i - pv.first);
  set('patternSpan', 1 - clamp(Math.abs(Math.log(span / 110)) / Math.log(4), 0, 1) * 2);

  // 11) 趋势衰竭度：需要“有趋势但已伸展乏力”
  const stretch = ((ema20[i] - ema50[i]) / a) * -dir;
  set('trendExhaust', 1 - clamp(Math.abs(stretch + 0.3) / 1.9, 0, 1) * 2);

  // 12) 推进减速
  const mag1 = Math.abs(pv.level - (dir > 0 ? cs[Math.min(l1a, n - 1)]?.h ?? pv.level : cs[Math.min(l1a, n - 1)]?.l ?? pv.level));
  const slope1 = mag1 / Math.max(1, l1b - l1a);
  const slope2 = Math.abs(pv.neckPrice - pv.secondPrice) / Math.max(1, l2b - l2a);
  set('legDecel', slope2 > 0 ? (slope1 / slope2 - 1) * 0.8 : 0);

  // 13) 波动环境分位
  const look = 500;
  let below = 0;
  let seen = 0;
  for (let q = Math.max(1, i - look); q <= i; q++) {
    if (atr[q] <= 0) continue;
    seen++;
    if (atr[q] <= a) below++;
  }
  const pct = seen > 20 ? below / seen : 0.5;
  set('volRegime', 1 - clamp(Math.abs(pct - 0.6) / 0.42, 0, 1) * 1.7);

  // 14) 净盈亏比 + 成本占比
  const risk = Math.abs(sig.entry - sig.stop);
  const rr = risk > 0 ? Math.abs(sig.tp - sig.entry) / risk : 0;
  const costDrag = sig.entry > 0 && risk > 0 ? (Math.abs(sig.entry) * 2 * (FEE_RATE + SLIP_RATE)) / risk : 9;
  set('rrQuality', clamp((2.1 - rr) / 1.1) - clamp((costDrag - 0.18) / 0.5, 0, 1) * 0.8);

  // 15) CVD 极值背离
  set('cvdDiverge', read.cvdDiv);

  // 16) 扫损陷阱：诱多 / 诱空 → +；收盘接受突破 → −
  if (read.sweep.accepted) set('sweepTrap', -0.8);
  else if (read.sweep.occurred) set('sweepTrap', (read.trap.score - 0.35) / 0.45);
  else set('sweepTrap', 0);

  // 16b) 触顶/触底订单流：真突破 vs 假突破（本策略的核心判据）
  set('touchFlow', read.touch.evidence);

  // 17) 确认K真实主动方向（仅真实数据）
  set('testDelta', !isTouch && read.confirm.known ? read.confirm.deltaRatio * dir * 3 : null);

  // 18) 持仓被套（仅有持仓量数据）
  set('oiTrap', read.oi.pct == null ? null : (read.oi.pct / 0.006) * 1);

  void volMa;
  void delta;
  return out;
}

/** 与远程引擎完全一致的成交/离场规则，只把“是否入场”交给概率门槛 */
export function simulateOutcome(
  ctx: Ctx,
  sig: ScanSignal,
  mode: EntryMode,
  maxHold: number,
): Outcome | null {
  const { cs, n } = ctx;
  const i = sig.idx;
  if (i < 30 || i > n - 2) return null;
  const limit = mode === 'touch';
  const next = cs[i + 1];
  let entryPrice: number;
  let entryTs: number;
  if (limit) {
    entryPrice = sig.entry;
    entryTs = sig.ts;
  } else {
    if (sig.side === 'long' ? next.o <= sig.stop || next.o >= sig.tp : next.o >= sig.stop || next.o <= sig.tp) {
      return {
        filled: false,
        why: 'gap',
        entryPrice: 0,
        entryTs: 0,
        exitPrice: 0,
        exitTs: 0,
        r: 0,
        pnlPct: 0,
        holdingBars: 0,
        costR: 0,
      };
    }
    entryPrice = sig.side === 'long' ? next.o * (1 + SLIP_RATE) : next.o * (1 - SLIP_RATE);
    entryTs = next.ts;
  }
  let exitPrice: number | null = null;
  let exitTs = 0;
  let why: Outcome['why'] = 'time';
  let exitIdx = -1;
  const endJ = Math.min(i + maxHold, n - 1);
  for (let j = limit ? i : i + 1; j <= endJ; j++) {
    const k = cs[j];
    const hitSL = sig.side === 'long' ? k.l <= sig.stop : k.h >= sig.stop;
    const hitTP = !(limit && j === i) && (sig.side === 'long' ? k.h >= sig.tp : k.l <= sig.tp);
    if (hitSL) {
      exitPrice = sig.stop;
      why = 'sl';
    } else if (hitTP) {
      exitPrice = sig.tp;
      why = 'tp';
    }
    if (exitPrice != null) {
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
  }
  if (exitPrice == null) {
    exitPrice = cs[endJ].c;
    exitTs = cs[endJ].ts;
    exitIdx = endJ;
  }
  const exitAdj = sig.side === 'long' ? exitPrice * (1 - SLIP_RATE) : exitPrice * (1 + SLIP_RATE);
  const gross = sig.side === 'long' ? exitAdj - entryPrice : entryPrice - exitAdj;
  const fee = (entryPrice + exitAdj) * FEE_RATE;
  const slipCost = (limit ? exitPrice : next.o + exitPrice) * SLIP_RATE;
  const pnl = gross - fee;
  const risk = sig.side === 'long' ? entryPrice - sig.stop : sig.stop - entryPrice;
  return {
    filled: true,
    why,
    entryPrice: r6(entryPrice),
    entryTs,
    exitPrice: r6(exitAdj),
    exitTs,
    r: r3(risk > 0 ? pnl / risk : 0),
    pnlPct: r3((pnl / entryPrice) * 100),
    holdingBars: Math.max(1, exitIdx - i),
    costR: r3(risk > 0 ? (fee + slipCost) / risk : 0),
  };
}

export function candidateFrom(
  ctx: Ctx,
  sig: ScanSignal,
  mode: EntryMode,
  maxHold: number,
  live?: LiveFlow,
  sym?: string,
  bar?: string,
  plan: ExitPlan = 'neck',
): Candidate | null {
  if (sig.idx < 30 || sig.idx > ctx.n - 1) return null;
  const evidence = collectEvidence(ctx, sig, sig.idx >= ctx.n - 1 ? live : undefined);
  const score = scoreEvidence(evidence);
  const pv = pivotOf(ctx, sig);
  const read = readSecondTest(ctx, sig);
  const risk = Math.abs(sig.entry - sig.stop);
  const rr = risk > 0 ? Math.abs(sig.tp - sig.entry) / risk : 0;
  const outcome = simulateWithPlan(ctx, sig, mode, maxHold, plan);
  const proba = r3(score.proba);
  const prefix = `${sym ? `${sym}_` : ''}${bar ? `${bar}_` : ''}`;
  return {
    id: `${prefix}${mode}_${sig.ts}_${sig.pattern}_${sig.side}`,
    idx: sig.idx,
    ts: sig.ts,
    side: sig.side,
    pattern: sig.pattern,
    mode,
    level: r6(pv.level),
    neck: r6(pv.neckPrice),
    firstTs: ctx.cs[pv.first]?.ts ?? sig.ts,
    secondTs: ctx.cs[pv.second]?.ts ?? sig.ts,
    entry: r6(sig.entry),
    stop: r6(sig.stop),
    tp: r6(sig.tp),
    structure: Math.round(sig.strength ?? sig.conf),
    proba,
    grade: gradeOf(proba),
    evidence: evidence.map(v => (v == null ? null : r3(v))),
    parts: score.parts.map(v => r3(v)),
    tags: [...(read.trap.kind ? [read.trap.kind === 'bullTrap' ? '诱多·扫位收回候选' : '诱空·扫位收回候选'] : []), ...(sig.tags ?? [])],
    note: sig.note ?? '',
    trap: read.trap.kind,
    trapScore: read.trap.score,
    flowSource: read.flowSource,
    headline: read.headline,
    read,
    rr: r1(rr),
    heightAtr: r1((pv.neckPrice - pv.level) * (sig.side === 'long' ? 1 : -1) / Math.max(1e-9, ctx.atr[sig.idx])),
    spanBars: Math.max(0, sig.idx - pv.first),
    live: sig.idx >= ctx.n - 2,
    sym,
    bar,
    outcome,
    exits: {
      neck: plan === 'neck' ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, 'neck'),
      r15: plan === 'r15' ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, 'r15'),
      r10: plan === 'r10' ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, 'r10'),
      be: plan === 'be' ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, 'be'),
      partial: plan === 'partial' ? outcome : simulateWithPlan(ctx, sig, mode, maxHold, 'partial'),
    },
  };
}

/** 双轨扫描：confirm = 等确认K；touch = 触价即成交（原逻辑），用于同一批形态上的 A/B 对照 */
export function runScan(
  cs: Candle[],
  bar: string,
  live?: LiveFlow,
  sym?: string,
  plan: ExitPlan = 'neck',
  flow?: FlowSnapshot | null,
): { confirm: Candidate[]; touch: Candidate[]; ctx: Ctx } {
  const ctx = buildContext(cs, flow);
  const maxHold = bar === '15m' ? MAX_HOLD_15M : MAX_HOLD_5M;
  const pick = (mode: EntryMode) => {
    // 与 src/lib/engine.ts 的 paramsFor 保持同一口径：关闭原引擎的一刀切趋势屏蔽，
    // 否则回测（simulate）与侧栏 / 引擎面板（runScan）会在同一形态上给出不同信号集合。
    const p = {
      ...DEFAULT_PARAMS,
      entryMode: mode === 'touch' ? ('limit' as const) : ('confirm' as const),
      trendBlock: 50,
    };
    return scanDoubles(cs, p).signals
      .map(s => candidateFrom(ctx, s, mode, maxHold, live, sym, bar, plan))
      .filter((c): c is Candidate => !!c);
  };
  return { confirm: pick('confirm'), touch: pick('touch'), ctx };
}

export function liveFlowOf(cs: Candle[], bookImb?: number | null, bigBias?: number | null): LiveFlow {
  const n = cs.length;
  if (n < 2) return { bookImb: null, bigBias: null, volRatio: null };
  let av = 0;
  let m = 0;
  for (let q = Math.max(0, n - 21); q < n - 1; q++) {
    av += cs[q].v;
    m++;
  }
  const last = cs[n - 1];
  return { bookImb: bookImb ?? null, bigBias: bigBias ?? null, volRatio: m && av > 0 ? last.v / (av / m) : null };
}

export const SCAN_BARS = (bar: string) => (bar === '15m' ? 4320 : 8640);

// ─────────────────────────────────────────────────────────────
//  出场方案：入场概率解决“做不做”，出场方案解决“赚多少”
//  双顶/双底的颈线目标常常太远，超时平仓把胜率吃掉；这里给出可对照的替代方案。
// ─────────────────────────────────────────────────────────────
export type ExitPlan = 'neck' | 'r15' | 'r10' | 'be' | 'partial';

export const EXIT_PLANS: { id: ExitPlan; label: string; hint: string }[] = [
  { id: 'neck', label: '颈线目标', hint: '原方案：目标看颈线（受 maxRR 封顶），超时按收盘价平仓' },
  { id: 'r15', label: '固定 1.5R', hint: '目标 = 入场 ± 1.5 倍风险，放弃远端颈线，换取更高兑现率' },
  { id: 'r10', label: '固定 1.0R', hint: '目标 = 入场 ± 1 倍风险，通常兑现率较高但赔付比较低，成本占比敏感' },
  { id: 'be', label: '1R 保本', hint: '盈利达到 1R 后把止损移到成本价，剩余仓位继续看颈线，降低回吐风险；滑点/跳空仍可能亏损' },
  { id: 'partial', label: '1R 减半 + 保本', hint: '1R 处平掉一半并锁定成本，剩余一半跑颈线目标' },
];

/** 按指定出场方案模拟；同一根内先判止损（保守），与原引擎一致 */
export function simulateWithPlan(
  ctx: Ctx,
  sig: ScanSignal,
  mode: EntryMode,
  maxHold: number,
  plan: ExitPlan,
): Outcome | null {
  if (plan === 'neck') return simulateOutcome(ctx, sig, mode, maxHold);
  const { cs, n, atr } = ctx;
  const i = sig.idx;
  if (i < 30 || i > n - 2) return null;
  const limit = mode === 'touch';
  const next = cs[i + 1];
  const dir = sig.side === 'long' ? 1 : -1;
  let entryPrice: number;
  let entryTs: number;
  if (limit) {
    entryPrice = sig.entry;
    entryTs = sig.ts;
  } else {
    if (dir > 0 ? next.o <= sig.stop : next.o >= sig.stop) {
      return { filled: false, why: 'gap', entryPrice: 0, entryTs: 0, exitPrice: 0, exitTs: 0, r: 0, pnlPct: 0, holdingBars: 0, costR: 0 };
    }
    entryPrice = dir > 0 ? next.o * (1 + SLIP_RATE) : next.o * (1 - SLIP_RATE);
    entryTs = next.ts;
  }
  const risk = (entryPrice - sig.stop) * dir;
  if (!(risk > 0)) return null;
  const target = plan === 'r10' ? entryPrice + dir * risk : plan === 'r15' ? entryPrice + dir * 1.5 * risk : sig.tp;
  if (!limit && (dir > 0 ? next.o >= target : next.o <= target)) {
    return { filled: false, why: 'gap', entryPrice: 0, entryTs: 0, exitPrice: 0, exitTs: 0, r: 0, pnlPct: 0, holdingBars: 0, costR: 0 };
  }
  const trigger = entryPrice + dir * risk; // 1R 触发点
  const targetBeforeTrigger = (target - entryPrice) * dir < risk;
  const useBe = plan === 'be' || plan === 'partial';
  const half = plan === 'partial';

  let stop = sig.stop;
  let armed = false;
  let tookHalf = false;
  let halfExitAdj = 0;
  let lockedR = 0;
  let exitPrice: number | null = null;
  let exitTs = 0;
  let why: Outcome['why'] = 'time';
  let exitIdx = -1;
  const endJ = Math.min(i + maxHold, n - 1);
  const feePct = FEE_RATE;

  for (let j = limit ? i : i + 1; j <= endJ; j++) {
    const k = cs[j];
    const hitStop = dir > 0 ? k.l <= stop : k.h >= stop;
    const hitTrig = useBe && !armed && !(limit && j === i) && (dir > 0 ? k.h >= trigger : k.l <= trigger);
    const hitTarget = !(limit && j === i) && (dir > 0 ? k.h >= target : k.l <= target);

    // 保守：同根内先算止损
    if (hitStop) {
      exitPrice = stop;
      why = armed ? 'be' : 'sl';
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
    if (targetBeforeTrigger && hitTarget) {
      exitPrice = target;
      why = 'tp';
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
    if (hitTrig) {
      armed = true;
      stop = entryPrice * (1 + dir * feePct * 2); // 移到成本 + 双边手续费
      if (half && !tookHalf) {
        tookHalf = true;
        const trigAdj = dir > 0 ? trigger * (1 - SLIP_RATE) : trigger * (1 + SLIP_RATE);
        halfExitAdj = trigAdj;
        const halfGross = (trigAdj - entryPrice) * dir;
        const halfFee = (entryPrice + trigAdj) * FEE_RATE;
        lockedR = 0.5 * ((halfGross - halfFee) / risk);
      }
    }
    if (hitTarget) {
      exitPrice = target;
      why = 'tp';
      exitTs = k.ts;
      exitIdx = j;
      break;
    }
  }
  if (exitPrice == null) {
    exitPrice = cs[endJ].c;
    exitTs = cs[endJ].ts;
    exitIdx = endJ;
  }
  const exitAdj = dir > 0 ? exitPrice * (1 - SLIP_RATE) : exitPrice * (1 + SLIP_RATE);
  const gross = (exitAdj - entryPrice) * dir;
  const fee = (entryPrice + exitAdj) * FEE_RATE;
  const pnl = gross - fee;
  const restR = pnl / risk;
  const r = tookHalf ? lockedR + 0.5 * restR : restR;
  // Cost accounting follows actual legs: one full entry, half exit at trigger,
  // half exit at the final target/time/stop. Weighting two full round trips
  // understated entry fees and distorted grossR - costR reconciliation.
  const entrySlip = limit ? 0 : next.o * SLIP_RATE;
  const totalFees = entryPrice * FEE_RATE + (tookHalf ? 0.5 * halfExitAdj * FEE_RATE : 0) + (tookHalf ? 0.5 : 1) * exitAdj * FEE_RATE;
  const totalCost = totalFees + entrySlip + (tookHalf ? 0.5 * trigger * SLIP_RATE : 0) + (tookHalf ? 0.5 : 1) * exitPrice * SLIP_RATE;
  void atr;
  return {
    filled: true,
    // `be` describes the exit mechanism, not the sign of the final R.
    // Fees/slippage can make a break-even stop slightly negative; reclassifying
    // it as `sl` corrupts tp/sl/time/be statistics.
    why,
    entryPrice: r6(entryPrice),
    entryTs,
    exitPrice: r6(exitAdj),
    exitTs,
    r: r3(r),
    pnlPct: r3(tookHalf ? r * (risk / entryPrice) * 100 : (pnl / entryPrice) * 100),
    holdingBars: Math.max(1, exitIdx - i),
    costR: r3(totalCost / risk),
  };
}
